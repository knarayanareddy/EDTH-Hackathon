"use client";

import React, { useEffect, useRef, useState } from "react";
import { RoiBox } from "@/lib/thermal/types";

export type ThermalPalette = "grayscale" | "ironbow" | "amber_hot" | "diff_heatmap";

interface ThermalCanvasRendererProps {
  width: number;
  height: number;
  display8: Uint8ClampedArray;
  reference8?: Uint8ClampedArray;
  raw14?: Float32Array;
  postLine14?: Float32Array;
  splitWipePct?: number; // 0 = full processed, 50 = 50% reference left / 50% processed right
  leftLabel?: string;
  rightLabel?: string;
  palette?: ThermalPalette;
  rois?: {
    animal: RoiBox;
    bridge: RoiBox;
    background: RoiBox;
  };
  activeRoiRole?: "animal" | "bridge" | "background" | null;
  onUpdateRoi?: (role: "animal" | "bridge" | "background", updated: RoiBox) => void;
  showRoiOverlays?: boolean;
  captionBadge?: string;
  isMonotonicVerified?: boolean;
}

function mapPaletteRgb(val: number, palette: ThermalPalette): [number, number, number] {
  const v = Math.max(0, Math.min(255, val));
  if (palette === "grayscale") {
    return [v, v, v];
  }
  if (palette === "amber_hot") {
    if (v < 190) return [v, v, v];
    const t = (v - 190) / 65;
    return [
      Math.min(255, Math.round(190 + t * 65)),
      Math.min(255, Math.round(190 - t * 35)),
      Math.max(0, Math.round(190 - t * 145)),
    ];
  }
  if (palette === "diff_heatmap") {
    // Black -> Deep Blue -> Cyan -> Amber -> White for difference magnitude
    const t = v / 255;
    if (t < 0.25) {
      const s = t / 0.25;
      return [Math.round(10 * s), Math.round(35 * s), Math.round(140 * s)];
    }
    if (t < 0.6) {
      const s = (t - 0.25) / 0.35;
      return [
        Math.round(10 + 235 * s),
        Math.round(35 + 125 * s),
        Math.round(140 - 110 * s),
      ];
    }
    const s = (t - 0.6) / 0.4;
    return [
      255,
      Math.round(160 + 95 * s),
      Math.round(30 + 225 * s),
    ];
  }
  // Ironbow interpretive palette
  const t = v / 255;
  const r = Math.min(255, Math.max(0, Math.round(255 * Math.min(1, t * 1.55))));
  const g = Math.min(
    255,
    Math.max(0, Math.round(255 * Math.pow(Math.max(0, (t - 0.25) / 0.75), 1.35)))
  );
  const b = Math.min(
    255,
    Math.max(
      0,
      Math.round(
        t < 0.35
          ? 220 * (t / 0.35)
          : t < 0.75
          ? 220 * (1 - (t - 0.35) / 0.4)
          : 255 * ((t - 0.75) / 0.25)
      )
    )
  );
  return [r, g, b];
}

export default function ThermalCanvasRenderer({
  width,
  height,
  display8,
  reference8,
  raw14,
  postLine14,
  splitWipePct = 0,
  leftLabel = "Global Monotonic Ref",
  rightLabel = "Active Pipeline",
  palette = "grayscale",
  rois,
  activeRoiRole = null,
  onUpdateRoi,
  showRoiOverlays = true,
  captionBadge,
  isMonotonicVerified,
}: ThermalCanvasRendererProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [hoverInfo, setHoverInfo] = useState<{
    x: number;
    y: number;
    rawAdu: number;
    postLineAdu: number;
    disp8: number;
  } | null>(null);
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(
    null
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const imgData = ctx.createImageData(width, height);
    const data = imgData.data;
    const splitX =
      reference8 && splitWipePct > 0
        ? Math.floor((width * splitWipePct) / 100)
        : 0;

    for (let y = 0; y < height; y++) {
      const rowOff = y * width;
      for (let x = 0; x < width; x++) {
        const idx = rowOff + x;
        const useLeft = reference8 && x < splitX;
        const val = useLeft ? reference8[idx] : display8[idx];
        const [r, g, b] = mapPaletteRgb(val, palette);
        const p = idx * 4;
        data[p] = r;
        data[p + 1] = g;
        data[p + 2] = b;
        data[p + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);

    // Draw split wipe divider line if active
    if (reference8 && splitX > 0 && splitX < width) {
      ctx.save();
      ctx.strokeStyle = "#F59E0B";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(splitX + 0.5, 0);
      ctx.lineTo(splitX + 0.5, height);
      ctx.stroke();
      ctx.restore();
    }

    // Draw ROI overlays if enabled
    if (showRoiOverlays && rois) {
      const boxes: Array<{
        box: RoiBox;
        stroke: string;
        fill: string;
        tag: string;
      }> = [
        {
          box: rois.animal,
          stroke: "#F59E0B",
          fill: "rgba(245, 158, 11, 0.16)",
          tag: "ANIMAL ROI",
        },
        {
          box: rois.bridge,
          stroke: "#38BDF8",
          fill: "rgba(56, 189, 248, 0.16)",
          tag: "BRIDGE ROI",
        },
        {
          box: rois.background,
          stroke: "#10B981",
          fill: "rgba(16, 185, 129, 0.14)",
          tag: "BG NOISE ROI",
        },
      ];

      ctx.save();
      ctx.font = "bold 10px monospace";
      for (const item of boxes) {
        const { box, stroke, fill, tag } = item;
        ctx.fillStyle = fill;
        ctx.fillRect(box.x, box.y, box.w, box.h);
        ctx.strokeStyle = stroke;
        ctx.lineWidth = activeRoiRole === box.role ? 2.2 : 1.4;
        ctx.strokeRect(box.x + 0.5, box.y + 0.5, box.w, box.h);

        // Label pill
        const labelText = `${tag} (${box.w}×${box.h})`;
        const tw = ctx.measureText(labelText).width + 8;
        const ly = Math.max(0, box.y - 14);
        ctx.fillStyle = "rgba(11, 15, 23, 0.86)";
        ctx.fillRect(box.x, ly, tw, 13);
        ctx.fillStyle = stroke;
        ctx.fillText(labelText, box.x + 4, ly + 10);
      }
      ctx.restore();
    }
  }, [
    width,
    height,
    display8,
    reference8,
    splitWipePct,
    palette,
    rois,
    activeRoiRole,
    showRoiOverlays,
  ]);

  const getCanvasCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const x = Math.max(
      0,
      Math.min(
        width - 1,
        Math.floor(((e.clientX - rect.left) / rect.width) * width)
      )
    );
    const y = Math.max(
      0,
      Math.min(
        height - 1,
        Math.floor(((e.clientY - rect.top) / rect.height) * height)
      )
    );
    return { x, y };
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!activeRoiRole || !onUpdateRoi || !rois) return;
    const pt = getCanvasCoords(e);
    setDragStart(pt);
    const existing = rois[activeRoiRole];
    onUpdateRoi(activeRoiRole, {
      ...existing,
      x: pt.x,
      y: pt.y,
      w: 10,
      h: 10,
    });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const pt = getCanvasCoords(e);
    const idx = pt.y * width + pt.x;
    setHoverInfo({
      x: pt.x,
      y: pt.y,
      rawAdu: raw14 ? raw14[idx] : 0,
      postLineAdu: postLine14 ? postLine14[idx] : 0,
      disp8: display8[idx] ?? 0,
    });

    if (dragStart && activeRoiRole && onUpdateRoi && rois) {
      const x0 = Math.min(dragStart.x, pt.x);
      const y0 = Math.min(dragStart.y, pt.y);
      const w = Math.max(6, Math.abs(pt.x - dragStart.x));
      const h = Math.max(6, Math.abs(pt.y - dragStart.y));
      onUpdateRoi(activeRoiRole, {
        ...rois[activeRoiRole],
        x: x0,
        y: y0,
        w: Math.min(width - x0, w),
        h: Math.min(height - y0, h),
      });
    }
  };

  const handleMouseUp = () => {
    setDragStart(null);
  };

  return (
    <div className="relative rounded-lg overflow-hidden border border-slate-800 bg-[#070A10] select-none">
      {/* Top Overlay Telemetry Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 bg-slate-950/90 border-b border-slate-800/80 text-[11px] font-mono">
        <div className="flex items-center gap-2">
          {captionBadge && (
            <span className="px-2 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold">
              {captionBadge}
            </span>
          )}
          <span className="text-slate-400">
            {width}×{height} px
          </span>
          {splitWipePct > 0 && reference8 && (
            <span className="text-sky-300">
              Split Wipe: {leftLabel} ({splitWipePct}%) | {rightLabel}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {isMonotonicVerified !== undefined && (
            <span
              className={`px-2 py-0.5 rounded border text-[10px] font-semibold ${
                isMonotonicVerified
                  ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/30"
                  : "bg-amber-500/15 text-amber-300 border-amber-500/30"
              }`}
              title="Indicates whether every pixel pair preserves global ADU brightness ordering or uses spatially adaptive local contrast"
            >
              {isMonotonicVerified
                ? "GLOBAL MONOTONIC (ORDERING PRESERVED)"
                : "INTERPRETIVE DISPLAY INTENSITY (NON-MONOTONIC)"}
            </span>
          )}
        </div>
      </div>

      {/* Canvas */}
      <div className="relative flex items-center justify-center bg-[#05070B]">
        <canvas
          ref={canvasRef}
          width={width}
          height={height}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={() => {
            setDragStart(null);
            setHoverInfo(null);
          }}
          className={`w-full h-auto max-h-[460px] object-contain ${
            activeRoiRole ? "cursor-crosshair" : "cursor-default"
          }`}
          style={{ imageRendering: "pixelated" }}
        />
      </div>

      {/* Bottom Live Cursor Probe */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 bg-slate-950/95 border-t border-slate-800/80 text-[11px] font-mono text-slate-300">
        {hoverInfo ? (
          <div className="flex flex-wrap items-center gap-4">
            <span className="text-slate-400">
              XY: ({hoverInfo.x}, {hoverInfo.y})
            </span>
            <span className="text-amber-300">
              Raw Sensor: <strong>{hoverInfo.rawAdu.toFixed(0)} ADU</strong>{" "}
              <span className="text-slate-500">(uncalibrated 14-bit)</span>
            </span>
            <span className="text-sky-300">
              Post-Line: <strong>{hoverInfo.postLineAdu.toFixed(1)} ADU</strong>
            </span>
            <span className="text-emerald-300">
              Display Intensity:{" "}
              <strong>{hoverInfo.disp8} / 255</strong>{" "}
              <span className="text-slate-500">(NOT °C)</span>
            </span>
          </div>
        ) : (
          <span className="text-slate-400">
            Hover over thermal canvas to inspect Raw 14-bit ADU, Post-Line 14-bit ADU, and 8-bit Display Intensity.{" "}
            {activeRoiRole
              ? `Click and drag on canvas to reposition ${activeRoiRole.toUpperCase()} ROI.`
              : ""}
          </span>
        )}
        <span className="text-[10px] text-slate-500">
          Display Intensity ≠ Physical Temperature (°C)
        </span>
      </div>
    </div>
  );
}
