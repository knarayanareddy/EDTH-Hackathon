"use client";

import React, { useMemo, useState } from "react";
import {
  MethodId,
  RoiBox,
  UnifiedPipelineConfig,
} from "@/lib/thermal/types";
import {
  executeThermalPipeline,
  METHOD_CATALOG,
} from "@/lib/thermal/unifiedEngine";
import ThermalCanvasRenderer from "./ThermalCanvasRenderer";
import { Shuffle, Eye, CheckCircle2, Scale } from "lucide-react";

interface BlindedAbReviewProps {
  width: number;
  height: number;
  raw14Input: Uint16Array | Float32Array;
  frameIndex: number;
  sceneLabel: string;
  cfg: UnifiedPipelineConfig;
  configHash: string;
  rois: {
    animal: RoiBox;
    bridge: RoiBox;
    background: RoiBox;
  };
  persistedReviews: Array<{
    id: number;
    sceneLabel: string;
    frameIndex: number;
    methodLeftId: string;
    methodRightId: string;
    selectedOutcome: string;
    winningMethodId: string;
    criterion: string;
    reviewerId: string;
    notes: string;
    createdAt: string;
  }>;
  onSubmitVote: (payload: {
    sceneLabel: string;
    frameIndex: number;
    methodLeftId: MethodId;
    methodRightId: MethodId;
    selectedOutcome: "left" | "right" | "tie";
    winningMethodId: string;
    criterion: string;
    reviewerId: string;
    notes: string;
    configHash: string;
  }) => Promise<void>;
}

const CANDIDATE_POOL: MethodId[] = [
  "argos_2",
  "exp1_argos2_radiometric",
  "exp2_global_monotonic_locked",
  "claude_a",
  "claude_c",
  "argos_1",
  "exp3_blended_clahe_monotonic",
  "exp4_causal_temporal_stabilized",
];

function drawRandomPair(): { left: MethodId; right: MethodId } {
  const i = Math.floor(Math.random() * CANDIDATE_POOL.length);
  let j = Math.floor(Math.random() * (CANDIDATE_POOL.length - 1));
  if (j >= i) j++;
  return { left: CANDIDATE_POOL[i], right: CANDIDATE_POOL[j] };
}

function wilson95Interval(wins: number, totalDecisive: number): [number, number] {
  if (totalDecisive <= 0) return [0, 100];
  const z = 1.96;
  const p = wins / totalDecisive;
  const denom = 1 + (z * z) / totalDecisive;
  const center = p + (z * z) / (2 * totalDecisive);
  const half =
    z *
    Math.sqrt(
      (p * (1 - p)) / totalDecisive +
        (z * z) / (4 * totalDecisive * totalDecisive)
    );
  const lo = Math.max(0, ((center - half) / denom) * 100);
  const hi = Math.min(100, ((center + half) / denom) * 100);
  return [lo, hi];
}

export default function BlindedAbReviewModalAndTab({
  width,
  height,
  raw14Input,
  frameIndex,
  sceneLabel,
  cfg,
  configHash,
  rois,
  persistedReviews,
  onSubmitVote,
}: BlindedAbReviewProps) {
  const [pair, setPair] = useState<{ left: MethodId; right: MethodId }>({
    left: "argos_2",
    right: "exp1_argos2_radiometric",
  });
  const [criterion, setCriterion] = useState<string>("animal_bridge_separation");
  const [reviewerId, setReviewerId] = useState<string>("evaluator-1");
  const [notes, setNotes] = useState<string>("");
  const [revealed, setRevealed] = useState<{
    outcome: "left" | "right" | "tie";
    leftId: MethodId;
    rightId: MethodId;
  } | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const leftOut = useMemo(
    () =>
      executeThermalPipeline({
        methodId: pair.left,
        raw14Input,
        W: width,
        H: height,
        frameIndex,
        cfg,
      }),
    [pair.left, raw14Input, width, height, frameIndex, cfg]
  );

  const rightOut = useMemo(
    () =>
      executeThermalPipeline({
        methodId: pair.right,
        raw14Input,
        W: width,
        H: height,
        frameIndex,
        cfg,
      }),
    [pair.right, raw14Input, width, height, frameIndex, cfg]
  );

  const handleNewRandomTrial = () => {
    setRevealed(null);
    setNotes("");
    setPair(drawRandomPair());
  };

  const handleVote = async (outcome: "left" | "right" | "tie") => {
    setSubmitting(true);
    try {
      const winningMethodId =
        outcome === "left"
          ? pair.left
          : outcome === "right"
          ? pair.right
          : "tie";
      await onSubmitVote({
        sceneLabel,
        frameIndex,
        methodLeftId: pair.left,
        methodRightId: pair.right,
        selectedOutcome: outcome,
        winningMethodId,
        criterion,
        reviewerId,
        notes,
        configHash,
      });
      setRevealed({ outcome, leftId: pair.left, rightId: pair.right });
    } finally {
      setSubmitting(false);
    }
  };

  // Compute aggregate unblinded tally from persistedReviews
  const leaderboard = useMemo(() => {
    const stats: Record<
      string,
      { wins: number; losses: number; ties: number; appearances: number }
    > = {};
    for (const m of METHOD_CATALOG) {
      stats[m.id] = { wins: 0, losses: 0, ties: 0, appearances: 0 };
    }
    for (const rev of persistedReviews) {
      const l = stats[rev.methodLeftId];
      const r = stats[rev.methodRightId];
      if (l) l.appearances++;
      if (r) r.appearances++;
      if (rev.selectedOutcome === "tie") {
        if (l) l.ties++;
        if (r) r.ties++;
      } else if (rev.selectedOutcome === "left") {
        if (l) l.wins++;
        if (r) r.losses++;
      } else if (rev.selectedOutcome === "right") {
        if (r) r.wins++;
        if (l) l.losses++;
      }
    }
    return METHOD_CATALOG.map((m) => {
      const s = stats[m.id];
      const decisive = s.wins + s.losses;
      const [ciLo, ciHi] = wilson95Interval(s.wins, decisive);
      return {
        methodId: m.id,
        shortLabel: m.shortLabel,
        sourcePackage: m.sourcePackage,
        ...s,
        winRatePct: decisive > 0 ? (s.wins * 100) / decisive : 0,
        ciLo,
        ciHi,
      };
    }).filter((row) => row.appearances > 0);
  }, [persistedReviews]);

  return (
    <div className="space-y-6">
      {/* Blinded Trial Header */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/75 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-400">
              <Scale className="w-4 h-4" />
              Phase 3 — Blinded Randomized A/B Preference Evaluation
            </div>
            <h3 className="text-base font-semibold text-slate-100 mt-1">
              Neutral Blinded Side-by-Side Comparison ({sceneLabel}, Frame #{frameIndex})
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              The user&apos;s subjective observation that <strong>Argos 2 looks best</strong> is retained as a baseline hypothesis, NOT treated as an unblinded winner. Evaluate identical 14-bit frames below under neutral labels.
            </p>
          </div>

          <button
            type="button"
            onClick={handleNewRandomTrial}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-mono font-semibold bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 transition"
          >
            <Shuffle className="w-4 h-4" />
            Draw New Randomized Blinded Pair
          </button>
        </div>

        {/* Criterion & Reviewer Controls */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4 pt-3 border-t border-slate-800">
          <div>
            <label className="block text-[11px] font-mono text-slate-400 mb-1">
              Primary Evaluation Criterion
            </label>
            <select
              value={criterion}
              onChange={(e) => setCriterion(e.target.value)}
              className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-xs font-mono text-slate-200"
            >
              <option value="animal_bridge_separation">
                1. Animal vs. Bridge Brightness Distinguishability
              </option>
              <option value="thin_structure_retention">
                2. 1px Thin Cable / Wire / Outline Retention
              </option>
              <option value="stripe_suppression">
                3. Flat-Area Column & Row Stripe Suppression
              </option>
              <option value="halo_artifact_freedom">
                4. Freedom from Boundary Halos & Clipping
              </option>
              <option value="overall_interpretability">
                5. Overall Scene Interpretability
              </option>
            </select>
          </div>
          <div>
            <label className="block text-[11px] font-mono text-slate-400 mb-1">
              Reviewer Identifier
            </label>
            <input
              type="text"
              value={reviewerId}
              onChange={(e) => setReviewerId(e.target.value)}
              className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-xs font-mono text-slate-200"
              placeholder="evaluator-1"
            />
          </div>
          <div>
            <label className="block text-[11px] font-mono text-slate-400 mb-1">
              Observation / Disagreement Notes (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-xs font-mono text-slate-200"
              placeholder="e.g. Alpha preserves 1px bridge cable better..."
            />
          </div>
        </div>
      </div>

      {/* Blinded Side-by-Side Canvases */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-mono font-bold text-sky-300">
              CANDIDATE ALPHA (LEFT)
            </span>
            {revealed && (
              <span className="px-2.5 py-0.5 rounded bg-sky-500/20 text-sky-200 border border-sky-500/40 text-xs font-mono">
                Unblinded: {revealed.leftId}
              </span>
            )}
          </div>
          <ThermalCanvasRenderer
            width={width}
            height={height}
            display8={leftOut.display8}
            raw14={leftOut.raw14}
            postLine14={leftOut.postLine14}
            rois={rois}
            captionBadge="BLINDED ALPHA"
          />
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-mono font-bold text-amber-300">
              CANDIDATE BETA (RIGHT)
            </span>
            {revealed && (
              <span className="px-2.5 py-0.5 rounded bg-amber-500/20 text-amber-200 border border-amber-500/40 text-xs font-mono">
                Unblinded: {revealed.rightId}
              </span>
            )}
          </div>
          <ThermalCanvasRenderer
            width={width}
            height={height}
            display8={rightOut.display8}
            raw14={rightOut.raw14}
            postLine14={rightOut.postLine14}
            rois={rois}
            captionBadge="BLINDED BETA"
          />
        </div>
      </div>

      {/* Voting Bar */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={submitting}
            onClick={() => handleVote("left")}
            className="px-4 py-2 rounded-lg text-xs font-mono font-bold bg-sky-500/20 hover:bg-sky-500/30 text-sky-200 border border-sky-500/40 transition disabled:opacity-50"
          >
            Prefer Candidate Alpha (Left)
          </button>
          <button
            type="button"
            disabled={submitting}
            onClick={() => handleVote("tie")}
            className="px-4 py-2 rounded-lg text-xs font-mono font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition disabled:opacity-50"
          >
            Tie / Indistinguishable
          </button>
          <button
            type="button"
            disabled={submitting}
            onClick={() => handleVote("right")}
            className="px-4 py-2 rounded-lg text-xs font-mono font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 transition disabled:opacity-50"
          >
            Prefer Candidate Beta (Right)
          </button>
        </div>

        {revealed && (
          <div className="flex items-center gap-2 text-xs font-mono text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1.5 rounded-lg">
            <CheckCircle2 className="w-4 h-4" />
            <span>
              Vote recorded! Alpha = <strong>{revealed.leftId}</strong>, Beta ={" "}
              <strong>{revealed.rightId}</strong>.
            </span>
          </div>
        )}
      </div>

      {/* Aggregate Unblinded Preference Table with Wilson 95% Confidence Intervals */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-xs font-mono uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <Eye className="w-4 h-4 text-amber-400" />
            Unblinded Aggregate Preference Tallies & Wilson 95% Confidence Intervals (PostgreSQL)
          </h4>
          <span className="text-[11px] font-mono text-slate-400">
            Total Blinded Trials: {persistedReviews.length}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2 pr-3">Method</th>
                <th className="py-2 px-3">Source Package</th>
                <th className="py-2 px-3">Trials</th>
                <th className="py-2 px-3">Wins</th>
                <th className="py-2 px-3">Ties</th>
                <th className="py-2 px-3">Losses</th>
                <th className="py-2 px-3">Decisive Win Rate</th>
                <th className="py-2 pl-3">Wilson 95% CI (Exploratory)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {leaderboard.map((row) => (
                <tr key={row.methodId} className="hover:bg-slate-800/30">
                  <td className="py-2 pr-3 font-semibold text-amber-300">
                    {row.shortLabel}
                  </td>
                  <td className="py-2 px-3 text-slate-400">
                    {row.sourcePackage}
                  </td>
                  <td className="py-2 px-3">{row.appearances}</td>
                  <td className="py-2 px-3 text-emerald-300 font-semibold">
                    {row.wins}
                  </td>
                  <td className="py-2 px-3 text-slate-400">{row.ties}</td>
                  <td className="py-2 px-3 text-rose-300">{row.losses}</td>
                  <td className="py-2 px-3 font-semibold">
                    {row.winRatePct.toFixed(1)}%
                  </td>
                  <td className="py-2 pl-3 text-slate-400">
                    [{row.ciLo.toFixed(1)}%, {row.ciHi.toFixed(1)}%]
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
