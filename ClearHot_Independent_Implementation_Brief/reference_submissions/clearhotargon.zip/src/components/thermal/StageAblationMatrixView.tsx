"use client";

import React, { useState } from "react";
import { AblationStageEntry } from "@/lib/thermal/types";
import ThermalCanvasRenderer from "./ThermalCanvasRenderer";
import { CheckCircle2, AlertTriangle, Save, Layers } from "lucide-react";

interface StageAblationMatrixViewProps {
  width: number;
  height: number;
  methodLabel: string;
  methodId: string;
  frameIndex: number;
  sourceLabel: string;
  rawAnimalBridgeDeltaAdu: number;
  postLineAnimalBridgeDeltaAdu: number;
  stages: AblationStageEntry[];
  savedSnapshots: Array<{
    id: number;
    sourceLabel: string;
    frameIndex: number;
    methodId: string;
    rawSepAdu: number;
    stage1SepAdu: number;
    toneOnlySep8: number;
    detailOnlySep8: number;
    combinedClassicalSep8: number;
    combinedCnnSep8: number;
    lowClipPct: number;
    highClipPct: number;
    rootCauseDiagnosis: string;
  }>;
  onSaveSnapshot: (diagnosis: string) => Promise<void>;
}

export default function StageAblationMatrixView({
  width,
  height,
  methodLabel,
  methodId,
  frameIndex,
  sourceLabel,
  rawAnimalBridgeDeltaAdu,
  postLineAnimalBridgeDeltaAdu,
  stages,
  savedSnapshots,
  onSaveSnapshot,
}: StageAblationMatrixViewProps) {
  const [showDiffHeatmaps, setShowDiffHeatmaps] = useState(false);
  const [saving, setSaving] = useState(false);

  const stage0 = stages[0];
  const stageTone = stages[2];
  const stageCombined = stages[4];

  const diagnosisText =
    Math.abs(rawAnimalBridgeDeltaAdu) > 25 &&
    stageTone &&
    Math.abs(stageTone.animalBridgeDelta8) < 4.5
      ? `Separation Loss Introduced in Stage 2/3 Tone Mapping: Raw sensor clearly distinguishes Animal from Bridge (ΔADU = ${rawAnimalBridgeDeltaAdu.toFixed(
          1
        )} ADU) and Stage 1 Line Correction retains ${postLineAnimalBridgeDeltaAdu.toFixed(
          1
        )} ADU, but Stage 2/3 quantile clipping (pHigh) compresses both into Δ8 = ${stageTone.animalBridgeDelta8.toFixed(
          1
        )} gray levels.`
      : Math.abs(rawAnimalBridgeDeltaAdu) <= 25
      ? `Physical Sensor Overlap: Raw sensor ΔADU between Animal and Bridge is only ${rawAnimalBridgeDeltaAdu.toFixed(
          1
        )} ADU. Separation is already weak in the raw 14-bit sensor plane prior to any display processing.`
      : `Separation Retained Across Stages: Raw ΔADU = ${rawAnimalBridgeDeltaAdu.toFixed(
          1
        )} ADU -> Stage 1 ΔADU = ${postLineAnimalBridgeDeltaAdu.toFixed(
          1
        )} ADU -> Combined Classical Display Δ8 = ${(
          stageCombined?.animalBridgeDelta8 ?? 0
        ).toFixed(1)} gray levels (Fixed-Window Ref Δ8 = ${(
          stage0?.animalBridgeDelta8 ?? 0
        ).toFixed(1)}).`;

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSaveSnapshot(diagnosisText);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header & Diagnosis Banner */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/75 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-400">
              <Layers className="w-4 h-4" />
              Phase 1 Requirement 4 — Stage-by-Stage Ablation Matrix
            </div>
            <h3 className="text-base font-semibold text-slate-100 mt-1">
              Pipeline Stage Isolation for <span className="text-amber-300">{methodLabel}</span> (Frame #{frameIndex})
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowDiffHeatmaps((v) => !v)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono border transition ${
                showDiffHeatmaps
                  ? "bg-amber-500/20 border-amber-500/50 text-amber-200"
                  : "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700"
              }`}
            >
              {showDiffHeatmaps
                ? "Showing: |Stage − Prev| × 4 Heatmap"
                : "Show Stage Difference Heatmaps"}
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono bg-sky-500/20 hover:bg-sky-500/30 text-sky-200 border border-sky-500/40 transition disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              {saving ? "Recording..." : "Log Ablation to PostgreSQL"}
            </button>
          </div>
        </div>

        <div className="mt-3 p-3 rounded-lg bg-slate-950/90 border border-slate-800 flex items-start gap-3">
          {stageCombined && Math.abs(stageCombined.animalBridgeDelta8) >= 5 ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          )}
          <div className="text-xs font-mono text-slate-200 leading-relaxed">
            <span className="text-slate-400 font-bold uppercase mr-2">
              Ablation Root-Cause Verdict ({sourceLabel}):
            </span>
            {diagnosisText}
          </div>
        </div>
      </div>

      {/* 6-Stage Visual & Quantitative Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {stages.map((st, idx) => {
          const isDiff = showDiffHeatmaps && idx > 0;
          return (
            <div
              key={st.stageKey}
              className="rounded-xl border border-slate-800 bg-slate-900/60 p-3 flex flex-col justify-between space-y-3"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="text-xs font-mono font-bold text-slate-100">
                    {st.label}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                      st.orderingPreserved
                        ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30"
                        : "bg-rose-500/15 text-rose-300 border border-rose-500/30"
                    }`}
                  >
                    {st.orderingPreserved ? "Order Kept" : "Order Inverted"}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mb-2 leading-snug">
                  {st.description}
                </p>

                <ThermalCanvasRenderer
                  width={width}
                  height={height}
                  display8={isDiff ? st.diffFromPrev8 : st.display8}
                  palette={isDiff ? "diff_heatmap" : "grayscale"}
                  showRoiOverlays={false}
                  captionBadge={isDiff ? "|Δ vs Prev Stage| × 4" : `Stage ${idx + 1}`}
                />
              </div>

              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 text-[11px] font-mono">
                <div className="bg-slate-950/80 p-2 rounded border border-slate-800/70">
                  <div className="text-slate-500 text-[10px]">Animal / Bridge</div>
                  <div className="text-slate-200 font-semibold">
                    {st.animalMedian8.toFixed(0)} / {st.bridgeMedian8.toFixed(0)}
                  </div>
                </div>
                <div className="bg-slate-950/80 p-2 rounded border border-slate-800/70">
                  <div className="text-slate-500 text-[10px]">Δ8 (Anim−Brdg)</div>
                  <div
                    className={`font-semibold ${
                      Math.abs(st.animalBridgeDelta8) >= 5
                        ? "text-emerald-300"
                        : "text-amber-300"
                    }`}
                  >
                    {st.animalBridgeDelta8 >= 0 ? "+" : ""}
                    {st.animalBridgeDelta8.toFixed(1)} lvl
                  </div>
                </div>
                <div className="bg-slate-950/80 p-2 rounded border border-slate-800/70">
                  <div className="text-slate-500 text-[10px]">Clip Lo / Hi</div>
                  <div className="text-slate-200">
                    {st.lowClipPct.toFixed(1)}% / {st.highClipPct.toFixed(1)}%
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Persisted Ablation Snapshots Table */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
        <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
          Persisted Stage-by-Stage Ablation Snapshots (PostgreSQL Audit Log)
        </h4>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2 pr-3">Method</th>
                <th className="py-2 px-3">Frame</th>
                <th className="py-2 px-3">Raw ΔADU</th>
                <th className="py-2 px-3">Post-Line ΔADU</th>
                <th className="py-2 px-3">Tone-Only Δ8</th>
                <th className="py-2 px-3">Detail-Only Δ8</th>
                <th className="py-2 px-3">Combined (No CNN) Δ8</th>
                <th className="py-2 px-3">Combined (+CNN) Δ8</th>
                <th className="py-2 pl-3">Root-Cause Diagnosis</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {savedSnapshots.map((s) => (
                <tr key={s.id} className="hover:bg-slate-800/30">
                  <td className="py-2 pr-3 font-semibold text-amber-300">
                    {s.methodId}
                  </td>
                  <td className="py-2 px-3">#{s.frameIndex}</td>
                  <td className="py-2 px-3">{s.rawSepAdu.toFixed(1)} ADU</td>
                  <td className="py-2 px-3">{s.stage1SepAdu.toFixed(1)} ADU</td>
                  <td className="py-2 px-3">{s.toneOnlySep8.toFixed(1)} lvl</td>
                  <td className="py-2 px-3">
                    {s.detailOnlySep8.toFixed(1)} lvl
                  </td>
                  <td className="py-2 px-3 font-semibold text-sky-300">
                    {s.combinedClassicalSep8.toFixed(1)} lvl
                  </td>
                  <td className="py-2 px-3">
                    {s.combinedCnnSep8.toFixed(1)} lvl
                  </td>
                  <td className="py-2 pl-3 text-slate-400 max-w-md truncate" title={s.rootCauseDiagnosis}>
                    {s.rootCauseDiagnosis}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
