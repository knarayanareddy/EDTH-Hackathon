"use client";

import React, { useEffect, useState } from "react";
import {
  ShieldAlert,
  Cpu,
  FileText,
  GitBranch,
  ExternalLink,
  CheckCircle2,
} from "lucide-react";

interface DocEntry {
  id: string;
  title: string;
  badge: string;
  filename: string;
  content: string;
}

export default function CnnHonestyAndAuditPanel() {
  const [docs, setDocs] = useState<DocEntry[]>([]);
  const [selectedDocId, setSelectedDocId] = useState<string>("brief");
  const [loadingDocs, setLoadingDocs] = useState<boolean>(true);

  useEffect(() => {
    fetch("/api/docs")
      .then((r) => r.json())
      .then((data) => {
        if (data.docs) setDocs(data.docs);
      })
      .catch((err) => console.error("Error loading docs:", err))
      .finally(() => setLoadingDocs(false));
  }, []);

  const currentDoc =
    docs.find((d) => d.id === selectedDocId) ?? docs[0] ?? null;

  return (
    <div className="space-y-6">
      {/* Phase 4 CNN Honesty Audit Table */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/75 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-400">
              <Cpu className="w-4 h-4" />
              Phase 4 — Honest CNN Status, Weight Provenance & Offline Feedback Loop
            </div>
            <h3 className="text-base font-semibold text-slate-100 mt-1">
              Independent Verification of Argos & Claude Neural Claims
            </h3>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-mono bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
            Default Pipeline Policy: CNN OFF (Classical First)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2 pr-3">Model / Package</th>
                <th className="py-2 px-3">UI Label vs. Verified Parameter Count</th>
                <th className="py-2 px-3">What Browser &quot;Train&quot; Actually Optimizes</th>
                <th className="py-2 px-3">Dataset Provenance</th>
                <th className="py-2 pl-3">Verified Status & Persistence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              <tr>
                <td className="py-2.5 pr-3 font-semibold text-amber-300">
                  Argos 1 (StripeResNet-1D2D)
                </td>
                <td className="py-2.5 px-3">
                  UI: 148 params |{" "}
                  <span className="text-amber-300">
                    Actual trainable in browser: 4 scalars
                  </span>
                </td>
                <td className="py-2.5 px-3">
                  Finite-difference perturbation of 4 scalar{" "}
                  <code>mixWeights</code>. Kernel arrays (<code>kHoriz</code>,{" "}
                  <code>kVert</code>, <code>kSpatial</code>) are cloned and{" "}
                  <strong>never updated</strong>.
                </td>
                <td className="py-2.5 px-3">
                  Single 64×64 deterministic synthetic patch
                </td>
                <td className="py-2.5 pl-3 text-slate-400">
                  Hand-crafted directional filter; not a trained ConvNet on real sensor data.
                </td>
              </tr>
              <tr>
                <td className="py-2.5 pr-3 font-semibold text-amber-300">
                  Argos 2 (HaarWaveletCNN)
                </td>
                <td className="py-2.5 px-3">
                  UI: 192 params |{" "}
                  <span className="text-amber-300">
                    Actual trainable in browser: 4 scalars
                  </span>
                </td>
                <td className="py-2.5 px-3">
                  Finite-difference search on 4 scalar{" "}
                  <code>[hlGain, lhGain, hhGain, thresh]</code> entries; 2D Haar DWT basis is fixed.
                </td>
                <td className="py-2.5 px-3">
                  Single 64×64 deterministic synthetic patch
                </td>
                <td className="py-2.5 pl-3 text-slate-400">
                  Initial loss computed on training patch; no real-data validation.
                </td>
              </tr>
              <tr>
                <td className="py-2.5 pr-3 font-semibold text-amber-300">
                  Argos 3 (BurstTempCNN)
                </td>
                <td className="py-2.5 px-3">
                  UI: 224 params |{" "}
                  <span className="text-amber-300">
                    Actual trainable in browser: 4 scalars
                  </span>
                </td>
                <td className="py-2.5 px-3">
                  Finite-difference search on 4 scalar mixing/gating weights; kernels unchanged.
                </td>
                <td className="py-2.5 px-3">
                  Single 64×64 deterministic synthetic patch
                </td>
                <td className="py-2.5 pl-3 text-slate-400">
                  Separate downloadable PyTorch snippet is unverified and not connected to browser.
                </td>
              </tr>
              <tr>
                <td className="py-2.5 pr-3 font-semibold text-sky-300">
                  Claude A (DnCNN-lite)
                </td>
                <td className="py-2.5 px-3">
                  UI: ~1.9k |{" "}
                  <span className="text-emerald-300">
                    Verified TF.js: 1,905 params
                  </span>
                </td>
                <td className="py-2.5 px-3">
                  Genuine TensorFlow.js Adam backprop over 2D conv weights when user clicks Train.
                </td>
                <td className="py-2.5 px-3">
                  Procedural synthetic scenes + synthetic stripes
                </td>
                <td className="py-2.5 pl-3 text-slate-400">
                  Executes in memory; IndexedDB save can fail in sandboxed iframes.
                </td>
              </tr>
              <tr>
                <td className="py-2.5 pr-3 font-semibold text-sky-300">
                  Claude B (1-D Profile ConvNet)
                </td>
                <td className="py-2.5 px-3">
                  UI claims ~3k |{" "}
                  <span className="text-rose-300 font-bold">
                    Verified TF.js: 9,041 params (3× UI label!)
                  </span>
                </td>
                <td className="py-2.5 px-3">
                  Genuine TF.js Adam backprop over 1D/2D conv layers.
                </td>
                <td className="py-2.5 px-3">
                  Procedural synthetic scenes + synthetic stripes
                </td>
                <td className="py-2.5 pl-3 text-slate-400">
                  Hardware MACs must be counted from 9,041 actual parameters, not the ~3k UI label.
                </td>
              </tr>
              <tr>
                <td className="py-2.5 pr-3 font-semibold text-sky-300">
                  Claude C (Directional ConvNet)
                </td>
                <td className="py-2.5 px-3">
                  UI: ~3.2k |{" "}
                  <span className="text-emerald-300">
                    Verified TF.js: 3,167 params
                  </span>
                </td>
                <td className="py-2.5 px-3">
                  Genuine TF.js Adam backprop over directional conv kernels.
                </td>
                <td className="py-2.5 px-3">
                  Procedural synthetic scenes + synthetic stripes
                </td>
                <td className="py-2.5 pl-3 text-slate-400">
                  Untested on real challenge-owner thermal recordings.
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Proposed Offline Feedback Loop & Noise2Noise Caveat */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pt-3">
          <div className="rounded-lg border border-slate-800 bg-slate-950/80 p-4 space-y-2">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-300">
              <ShieldAlert className="w-4 h-4" />
              Why Adjacent-Frame Noise2Noise Fails on Thermal Stripes
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Lehtinen et al. (2018) <em>Noise2Noise</em> requires the corruption in target frame{" "}
              <code>t+1</code> to be conditionally independent of frame <code>t</code> given the clean scene. In uncooled LWIR bolometers, column/row readout fixed-pattern noise (FPN) is{" "}
              <strong>temporally correlated across adjacent frames</strong>. Training a network to predict frame <code>t+1</code> from frame <code>t</code> learns the identity on persistent stripes while blurring moving animals!
            </p>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-950/80 p-4 space-y-2">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-sky-300">
              <GitBranch className="w-4 h-4" />
              Proposed Defensible Offline Feedback Loop (Opt-In Only)
            </div>
            <ol className="text-xs text-slate-300 space-y-1 list-decimal list-inside leading-relaxed">
              <li>
                <strong>Curated Multi-Recording Split</strong>: Split strictly by{" "}
                <em>recording / environment / sensor serial</em> (never random frames from one 180 MB file).
              </li>
              <li>
                <strong>Trusted Targets</strong>: Blackbody/shutter NUC reference or physically calibrated FPN injection onto verified clean scenes.
              </li>
              <li>
                <strong>Uncertainty-Gated Classical Fallback</strong>: Gate CNN residual to 0 around high along-stripe gradients to protect 1px wires & animal boundaries.
              </li>
              <li>
                <strong>One-Shot Holdout & Versioned Rollback</strong>: Benchmark once on untouched recordings; deploy only as an opt-in checkpoint with instant classical fallback.
              </li>
            </ol>
          </div>
        </div>
      </div>

      {/* Interactive Verbatim Repository Document & Deliverable Reader */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/75 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-sky-400">
              <FileText className="w-4 h-4" />
              Repository Documentation & Deliverables Inspector
            </div>
            <h3 className="text-base font-semibold text-slate-100 mt-1">
              Read Verbatim Brief, Independent Review, README & New Audit Report
            </h3>
          </div>

          <a
            href="/ClearHot_Six_Method_Workbench.html"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 transition"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            Open Original Handoff HTML (ClearHot_Six_Method_Workbench.html)
          </a>
        </div>

        {/* Document Selector Pills */}
        <div className="flex flex-wrap gap-2">
          {docs.map((doc) => (
            <button
              key={doc.id}
              type="button"
              onClick={() => setSelectedDocId(doc.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono border transition flex items-center gap-2 ${
                selectedDocId === doc.id
                  ? "bg-sky-500/20 border-sky-500/50 text-sky-200 font-semibold"
                  : "bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200"
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{doc.filename}</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400">
                {doc.badge}
              </span>
            </button>
          ))}
        </div>

        {/* Document Content Viewer */}
        <div className="rounded-lg border border-slate-800 bg-slate-950 p-4 max-h-[540px] overflow-y-auto">
          {loadingDocs ? (
            <div className="text-xs font-mono text-slate-400">
              Loading repository markdown files...
            </div>
          ) : currentDoc ? (
            <pre className="text-xs font-mono text-slate-200 whitespace-pre-wrap leading-relaxed">
              {currentDoc.content}
            </pre>
          ) : (
            <div className="text-xs font-mono text-slate-400">
              No document selected.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
