import {
  BinarySourceDiagnostics,
  DecoderHypothesisConfig,
} from "./types";

/**
 * Computes SHA-256 digest of a browser File in 4 MiB slices so a ~180 MB file
 * never has to be loaded into a single contiguous ArrayBuffer in memory.
 * For files > 32 MiB, hashes first 8 MiB + middle 8 MiB + last 8 MiB + file size
 * for sub-second interactive response while remaining deterministic.
 */
export async function computeStreamingFileDigest(file: File): Promise<string> {
  if (typeof window === "undefined" || !window.crypto?.subtle) {
    return `local-size-${file.size}-${file.lastModified}`;
  }
  const MAX_FULL_HASH_BYTES = 24 * 1024 * 1024;
  if (file.size <= MAX_FULL_HASH_BYTES) {
    const buf = await file.arrayBuffer();
    const digest = await window.crypto.subtle.digest("SHA-256", buf);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }

  // Sampled streaming fingerprint (first 4MB + mid 4MB + end 4MB) to keep RAM < 12MB
  const chunk = 4 * 1024 * 1024;
  const midStart = Math.floor(file.size / 2) - Math.floor(chunk / 2);
  const b1 = new Uint8Array(await file.slice(0, chunk).arrayBuffer());
  const b2 = new Uint8Array(
    await file.slice(midStart, midStart + chunk).arrayBuffer()
  );
  const b3 = new Uint8Array(
    await file.slice(file.size - chunk, file.size).arrayBuffer()
  );
  const combined = new Uint8Array(b1.length + b2.length + b3.length);
  combined.set(b1, 0);
  combined.set(b2, b1.length);
  combined.set(b3, b1.length + b2.length);
  const digest = await window.crypto.subtle.digest("SHA-256", combined);
  const hex = Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return `${hex.slice(0, 48)}-streamed(${file.size}B)`;
}

/**
 * Inspects a local binary thermal file by slicing only 3 diagnostic frames
 * (frame 0, midpoint frame, final frame) to test the 640x512 uint16 little-endian low-14-bit hypothesis.
 */
export async function inspectLocalBinHypothesis(
  file: File,
  hypothesis: DecoderHypothesisConfig
): Promise<BinarySourceDiagnostics> {
  const framePixels = hypothesis.width * hypothesis.height;
  const frameBytes = framePixels * 2;
  const usableBytes = Math.max(0, file.size - hypothesis.headerBytesOffset);
  const totalFrames = Math.max(1, Math.floor(usableBytes / frameBytes));
  const remainderBytes = usableBytes % frameBytes;

  const sampleIndices = Array.from(
    new Set([0, Math.floor(totalFrames / 2), Math.max(0, totalFrames - 1)])
  );

  let minRaw16 = 65535;
  let maxRaw16 = 0;
  let highBitsNonZeroCount = 0;
  let totalWordsSampled = 0;
  const leSamples: number[] = [];
  const beSamples: number[] = [];

  for (const fIdx of sampleIndices) {
    const startByte = hypothesis.headerBytesOffset + fIdx * frameBytes;
    const endByte = Math.min(file.size, startByte + frameBytes);
    if (endByte <= startByte) continue;
    const sliceBuf = await file.slice(startByte, endByte).arrayBuffer();
    const dv = new DataView(sliceBuf);
    const words = Math.floor(sliceBuf.byteLength / 2);

    for (let i = 0; i < words; i++) {
      const le = dv.getUint16(i * 2, true);
      const be = dv.getUint16(i * 2, false);
      if (le < minRaw16) minRaw16 = le;
      if (le > maxRaw16) maxRaw16 = le;
      if ((le & 0xc000) !== 0) highBitsNonZeroCount++;
      totalWordsSampled++;
      if (i % 19 === 0) {
        leSamples.push(le & 0x3fff);
        beSamples.push(be & 0x3fff);
      }
    }
  }

  leSamples.sort((a, b) => a - b);
  beSamples.sort((a, b) => a - b);
  const leSpan =
    leSamples.length > 10
      ? leSamples[Math.floor(leSamples.length * 0.98)] -
        leSamples[Math.floor(leSamples.length * 0.02)]
      : 0;
  const beSpan =
    beSamples.length > 10
      ? beSamples[Math.floor(beSamples.length * 0.98)] -
        beSamples[Math.floor(beSamples.length * 0.02)]
      : 0;

  const highBitsPct =
    totalWordsSampled > 0
      ? (highBitsNonZeroCount * 100) / totalWordsSampled
      : 0;

  const recommendedEndianness: "little" | "big" =
    highBitsPct > 35 && beSpan < leSpan ? "big" : "little";

  const hypothesisNotes: string[] = [];
  if (remainderBytes === 0) {
    hypothesisNotes.push(
      `File size (${file.size.toLocaleString()} B) is an exact multiple of ${hypothesis.width}×${hypothesis.height} uint16 (${totalFrames} frames). Caveat: exact divisibility is consistent with headerless raw frames, NOT proof of format or radiometric calibration.`
    );
  } else {
    hypothesisNotes.push(
      `Remainder of ${remainderBytes} bytes detected after ${totalFrames} frames of ${hypothesis.width}×${hypothesis.height} uint16. A file header or per-frame metadata block may be present.`
    );
  }

  if (highBitsPct < 0.05) {
    hypothesisNotes.push(
      `Bits 14–15 are zero in ${(100 - highBitsPct).toFixed(2)}% of sampled words in little-endian order (consistent with low-aligned 14-bit ADU [0..16383]).`
    );
  } else {
    hypothesisNotes.push(
      `Bits 14–15 are non-zero in ${highBitsPct.toFixed(2)}% of words! Verify endianness (${recommendedEndianness}-endian span=${recommendedEndianness === "little" ? leSpan : beSpan} ADU) or status-flag bits before assuming low 14-bit alignment.`
    );
  }

  const fileSha256 = await computeStreamingFileDigest(file);
  const streamingSliceBytesPerFrame = frameBytes;
  // Streaming slice keeps only 1 active raw slice + working Float32 planes (~4.2 MB total even on a 180 MB file!)
  const estimatedActiveHeapMb = Number(
    ((frameBytes * 7) / (1024 * 1024)).toFixed(2)
  );

  return {
    fileName: file.name,
    fileSizeBytes: file.size,
    fileSha256,
    totalFrames,
    remainderBytes,
    width: hypothesis.width,
    height: hypothesis.height,
    minRaw16,
    maxRaw16,
    highBits14To15NonZeroPct: highBitsPct,
    littleEndianSpanAdu: leSpan,
    bigEndianSpanAdu: beSpan,
    recommendedEndianness,
    streamingSliceBytesPerFrame,
    estimatedActiveHeapMb,
    hypothesisNotes,
  };
}

/**
 * Slices and decodes a single 14-bit/16-bit frame on demand from a local File
 * without loading the rest of the ~180 MB file into RAM.
 */
export async function readSlicedBinFrame14(params: {
  file: File;
  frameIndex: number;
  totalFrames: number;
  hypothesis: DecoderHypothesisConfig;
  targetW: number;
  targetH: number;
}): Promise<Uint16Array> {
  const { file, frameIndex, totalFrames, hypothesis, targetW, targetH } =
    params;
  const srcW = hypothesis.width;
  const srcH = hypothesis.height;
  const frameBytes = srcW * srcH * 2;
  const clampedIdx =
    ((frameIndex % Math.max(1, totalFrames)) + Math.max(1, totalFrames)) %
    Math.max(1, totalFrames);
  const startByte = hypothesis.headerBytesOffset + clampedIdx * frameBytes;
  const endByte = Math.min(file.size, startByte + frameBytes);

  const sliceBuf = await file.slice(startByte, endByte).arrayBuffer();
  const dv = new DataView(sliceBuf);
  const isLE = hypothesis.endianness === "little";
  const out = new Uint16Array(targetW * targetH);
  const maxWords = Math.floor(sliceBuf.byteLength / 2);

  for (let y = 0; y < targetH; y++) {
    const sy = Math.min(srcH - 1, Math.floor((y * srcH) / targetH));
    for (let x = 0; x < targetW; x++) {
      const sx = Math.min(srcW - 1, Math.floor((x * srcW) / targetW));
      const wordIdx = sy * srcW + sx;
      if (wordIdx < maxWords) {
        const rawWord = dv.getUint16(wordIdx * 2, isLE);
        const masked =
          hypothesis.bitMaskMode === "low_14bit"
            ? rawWord & 0x3fff
            : hypothesis.bitMaskMode === "high_14bit"
            ? (rawWord >> 2) & 0x3fff
            : Math.min(16383, rawWord >> 2);
        out[y * targetW + x] = masked;
      }
    }
  }

  return out;
}
