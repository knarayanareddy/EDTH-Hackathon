import { RoiBox, SyntheticSceneId } from "./types";

export interface SyntheticFrameBundle {
  sceneId: SyntheticSceneId;
  sceneLabel: string;
  scientificPurpose: string;
  width: number;
  height: number;
  frameIndex: number;
  totalFrames: number;
  corrupted14: Uint16Array;
  clean14: Float32Array;
  cleanNoThin14: Float32Array;
  thinMask: Uint8Array;
  defaultRois: {
    animal: RoiBox;
    bridge: RoiBox;
    background: RoiBox;
  };
}

export const SYNTHETIC_SCENE_CATALOG: Array<{
  id: SyntheticSceneId;
  label: string;
  shortTag: string;
  description: string;
}> = [
  {
    id: "bridge_animal_ambiguity",
    label: "1. Bridge & Animal Thermal Ambiguity (Core Brief Scenario)",
    shortTag: "Bridge + Animals",
    description:
      "Solar-warmed bridge deck (~7760 ADU) + suspension cables (1px, +70 ADU) + two animals on/near bridge (Animal A ~7910 ADU, fur-insulated Animal B ~7715 ADU) over cool river/embankment (~7180–7340 ADU) with sensor FPN stripes.",
  },
  {
    id: "full_height_wire_hard_negative",
    label: "2. Full-Height Structural Wire / Mast (Hard Negative)",
    shortTag: "1px Wire Protection",
    description:
      "Contains genuine 1-pixel full-height vertical suspension cables and horizontal utility wires alongside periodic column/row stripes. Tests whether destriping erases real thin scene structures.",
  },
  {
    id: "strong_stripe_150adu_probe",
    label: "3. Strong Alternating ±150 ADU Stripe Probe (Review Benchmark)",
    shortTag: "±150 ADU Stripe Probe",
    description:
      "Reproduces the Independent Review's synthetic probe where alternating columns have ±150 ADU offsets that exceed naive cross-column gradient gates (<180 ADU) in original Argos defaults.",
  },
  {
    id: "clean_no_stripe_preservation",
    label: "4. Zero-Stripe Clean Reference (False-Correction Probe)",
    shortTag: "Clean No-Stripe",
    description:
      "Contains zero column/row FPN stripes and zero bad pixels. Quantifies how much true scene detail and contrast each algorithm damages when no stripe corruption is present.",
  },
  {
    id: "moving_animal_ghost_probe",
    label: "5. Moving Animals Across Bridge (Temporal Ghosting & Look-Ahead Probe)",
    shortTag: "Motion / Ghosting",
    description:
      "Warm animals move 3 px/frame across a textured bridge deck. Tests causal vs look-ahead behavior at frame 0 (Claude B) and motion-gate ghost suppression (Argos 3 & Exp-4).",
  },
  {
    id: "horizon_pan_flicker",
    label: "6. Transient Flare & Horizon Pan (AGC Window Jump Probe)",
    shortTag: "AGC Flicker Probe",
    description:
      "Introduces a periodic hot exhaust flare on frames 4..7 of every 8-frame cycle to test whether quantile AGC causes global brightness jumps vs locked-window monotonic mapping.",
  },
];

export function getDefaultRoisForResolution(
  W: number,
  H: number
): { animal: RoiBox; bridge: RoiBox; background: RoiBox } {
  const sx = W / 320;
  const sy = H / 256;
  return {
    animal: {
      id: "roi-animal-1",
      role: "animal",
      label: "Animal ROI (Warm Quadruped on Span)",
      x: Math.round(138 * sx),
      y: Math.round(115 * sy),
      w: Math.max(8, Math.round(18 * sx)),
      h: Math.max(8, Math.round(14 * sy)),
    },
    bridge: {
      id: "roi-bridge-1",
      role: "bridge",
      label: "Bridge Deck / Girder ROI (Solar-Heated Structure)",
      x: Math.round(202 * sx),
      y: Math.round(124 * sy),
      w: Math.max(10, Math.round(34 * sx)),
      h: Math.max(8, Math.round(16 * sy)),
    },
    background: {
      id: "roi-bg-1",
      role: "background",
      label: "Local Background ROI (River / Embankment)",
      x: Math.round(74 * sx),
      y: Math.round(168 * sy),
      w: Math.max(12, Math.round(38 * sx)),
      h: Math.max(12, Math.round(28 * sy)),
    },
  };
}

/**
 * Generates a deterministic synthetic frame bundle with ground truth (clean14, cleanNoThin14, thinMask)
 * and corrupted14 raw sensor input.
 */
export function generateSyntheticFrameBundle(
  sceneId: SyntheticSceneId,
  W: number,
  H: number,
  frameIndex: number,
  totalFrames = 60
): SyntheticFrameBundle {
  const N = W * H;
  const cleanNoThin14 = new Float32Array(N);
  const clean14 = new Float32Array(N);
  const thinMask = new Uint8Array(N);
  const corrupted14 = new Uint16Array(N);

  const sx = W / 320;
  const sy = H / 256;

  const pitchShift =
    sceneId === "horizon_pan_flicker"
      ? Math.round(Math.sin(frameIndex * 0.22) * 18 * sy)
      : 0;
  const horizonY = Math.round(82 * sy) + pitchShift;
  const bridgeTopY = Math.round(122 * sy) + pitchShift;
  const bridgeBotY = Math.round(144 * sy) + pitchShift;

  // Motion offset for moving animal probe
  const motionDx =
    sceneId === "moving_animal_ghost_probe"
      ? Math.round(((frameIndex * 3) % 90) * sx)
      : Math.round(Math.sin(frameIndex * 0.15) * 2 * sx);

  for (let y = 0; y < H; y++) {
    const isSky = y < horizonY;
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;

      // Base background: cool sky (~7090 ADU) and river/valley (~7260..7380 ADU)
      let val = isSky
        ? 7090 + Math.sin(x * 0.03 + y * 0.04) * 28
        : 7265 +
          Math.sin(x * 0.05) * 42 +
          Math.cos((y - horizonY) * 0.09) * 55 +
          ((x ^ y) % 13) * 2.2;

      // Bridge structure: concrete/steel deck + piers heated by solar loading (~7740..7810 ADU)
      const inBridgeDeck = y >= bridgeTopY && y <= bridgeBotY;
      const inLeftPier =
        y > bridgeBotY &&
        y < Math.round(215 * sy) &&
        Math.abs(x - Math.round(86 * sx)) < Math.round(11 * sx);
      const inRightPier =
        y > bridgeBotY &&
        y < Math.round(215 * sy) &&
        Math.abs(x - Math.round(238 * sx)) < Math.round(11 * sx);

      if (inBridgeDeck) {
        const deckRib = Math.sin(x * 0.35) * 22 + Math.cos(y * 0.8) * 14;
        val = 7765 + deckRib;
      } else if (inLeftPier || inRightPier) {
        val = 7690 + Math.cos(y * 0.25) * 18;
      }

      // Animal 1 (Warm quadruped on bridge span: core ~7915 ADU, pelage contour ~7830 ADU)
      const a1x = Math.round(147 * sx) + motionDx;
      const a1y = Math.round(121 * sy) + pitchShift;
      const distA1 = Math.hypot((x - a1x) / (7.5 * sx), (y - a1y) / (5.2 * sy));
      if (distA1 < 1.35) {
        const internalDetail =
          Math.sin((x - a1x) * 1.1) * 18 + Math.cos((y - a1y) * 1.3) * 15;
        val =
          distA1 < 0.75
            ? 7920 + internalDetail
            : 7825 + internalDetail * 0.7;
      }

      // Animal 2 (Thick-furred animal near right bridge approach: ~7715 ADU — physically cooler apparent signal than solar-heated bridge deck!)
      const a2x = Math.round(182 * sx);
      const a2y = Math.round(154 * sy) + pitchShift;
      const distA2 = Math.hypot((x - a2x) / (6.5 * sx), (y - a2y) / (4.8 * sy));
      if (distA2 < 1.25) {
        val =
          7715 +
          Math.sin((x - a2x) * 1.2) * 14 -
          distA2 * 24;
      }

      // Transient hot flare on horizon_pan_flicker (frames 4..7 of 8-frame cycle)
      if (
        sceneId === "horizon_pan_flicker" &&
        frameIndex % 8 >= 4 &&
        x >= Math.round(32 * sx) &&
        x <= Math.round(58 * sx) &&
        y >= Math.round(182 * sy) &&
        y <= Math.round(208 * sy)
      ) {
        val = 14800;
      }

      cleanNoThin14[idx] = val;
      clean14[idx] = val;
    }
  }

  // Add thin 1-pixel structural features (bridge suspension cables, vertical masts, utility wires)
  const cableCols = [
    Math.round(112 * sx),
    Math.round(164 * sx),
    Math.round(216 * sx),
  ];
  for (const cx of cableCols) {
    if (cx >= 1 && cx < W - 1) {
      const yStart =
        sceneId === "full_height_wire_hard_negative"
          ? 0
          : Math.max(0, Math.round(44 * sy) + pitchShift);
      const yEnd =
        sceneId === "full_height_wire_hard_negative" ? H : bridgeTopY;
      for (let y = yStart; y < yEnd; y++) {
        const idx = y * W + cx;
        clean14[idx] += 68;
        thinMask[idx] = 1;
      }
    }
  }

  // Horizontal 1px bridge guard wire / utility line
  const wireY = Math.max(
    2,
    Math.min(H - 3, Math.round(104 * sy) + pitchShift)
  );
  const wireX0 =
    sceneId === "full_height_wire_hard_negative" ? 0 : Math.round(60 * sx);
  const wireX1 =
    sceneId === "full_height_wire_hard_negative" ? W : Math.round(265 * sx);
  for (let x = wireX0; x < wireX1; x++) {
    const idx = wireY * W + x;
    clean14[idx] += 58;
    thinMask[idx] = 1;
  }

  // Apply sensor corruption (Column FPN, Row FPN, Temporal Readout Noise, Bad Pixels)
  for (let y = 0; y < H; y++) {
    let rowStripe = 0;
    if (sceneId !== "clean_no_stripe_preservation") {
      rowStripe =
        ((y * 29) % 9 === 0 ? 34 : 0) -
        ((y * 17) % 11 === 0 ? 28 : 0) +
        Math.round(Math.cos(y * 1.35) * 12);
    }

    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      let colStripe = 0;
      if (sceneId === "strong_stripe_150adu_probe") {
        // Exact alternating ±150 ADU stripe probe from Independent Review
        colStripe = x % 2 === 0 ? 150 : -150;
      } else if (sceneId !== "clean_no_stripe_preservation") {
        colStripe =
          ((x * 37) % 11 === 0 ? 48 : 0) -
          ((x * 19) % 13 === 0 ? 38 : 0) +
          Math.round(Math.sin(x * 0.85) * 16);
      }

      const temporalReadoutNoise =
        sceneId === "clean_no_stripe_preservation"
          ? 0
          : (((x * 73 + y * 131 + frameIndex * 47) % 23) - 11) * 1.15;

      const noisyVal = Math.round(
        clean14[idx] + colStripe + rowStripe + temporalReadoutNoise
      );
      corrupted14[idx] = Math.max(0, Math.min(16383, noisyVal));
    }
  }

  // Sprinkle 20 deterministic isolated bad pixels (except on clean_no_stripe_preservation)
  if (sceneId !== "clean_no_stripe_preservation") {
    for (let k = 0; k < 20; k++) {
      const bx = ((k * 97 + 31) % (W - 4)) + 2;
      const by = ((k * 53 + 17) % (H - 4)) + 2;
      corrupted14[by * W + bx] = k % 2 === 0 ? 16380 : 120;
    }
  }

  const defaultRois = getDefaultRoisForResolution(W, H);
  // Adjust animal ROI x slightly if moving_animal_ghost_probe
  if (sceneId === "moving_animal_ghost_probe") {
    defaultRois.animal.x = Math.max(
      4,
      Math.min(
        W - defaultRois.animal.w - 4,
        Math.round(138 * sx) + motionDx
      )
    );
  }

  const meta =
    SYNTHETIC_SCENE_CATALOG.find((s) => s.id === sceneId) ??
    SYNTHETIC_SCENE_CATALOG[0];

  return {
    sceneId,
    sceneLabel: meta.label,
    scientificPurpose: meta.description,
    width: W,
    height: H,
    frameIndex,
    totalFrames,
    corrupted14,
    clean14,
    cleanNoThin14,
    thinMask,
    defaultRois,
  };
}
