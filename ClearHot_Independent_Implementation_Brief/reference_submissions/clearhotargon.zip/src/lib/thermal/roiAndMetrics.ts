import { boxBlur, noiseSigma, percentileSample, quickselect } from "./dspCore";
import {
  MultiPlaneRoiReport,
  PlaneRoiStats,
  RoiBox,
} from "./types";

export function computePlaneRoiStats(
  plane: ArrayLike<number>,
  W: number,
  H: number,
  roi: RoiBox,
  lowClipVal: number,
  highClipVal: number
): PlaneRoiStats {
  const x0 = Math.max(0, Math.min(W - 1, Math.round(roi.x)));
  const y0 = Math.max(0, Math.min(H - 1, Math.round(roi.y)));
  const x1 = Math.max(x0 + 1, Math.min(W, Math.round(roi.x + roi.w)));
  const y1 = Math.max(y0 + 1, Math.min(H, Math.round(roi.y + roi.h)));

  const count = (x1 - x0) * (y1 - y0);
  if (count <= 0) {
    return {
      median: 0,
      mean: 0,
      iqr: 0,
      mad: 0,
      robustSigma: 1,
      min: 0,
      max: 0,
      lowClipFraction: 0,
      highClipFraction: 0,
      validPixelCount: 0,
    };
  }

  const vals = new Float32Array(count);
  let k = 0;
  let sum = 0;
  let min = Infinity;
  let max = -Infinity;
  let lowClips = 0;
  let highClips = 0;

  for (let y = y0; y < y1; y++) {
    const rowOff = y * W;
    for (let x = x0; x < x1; x++) {
      const v = plane[rowOff + x];
      vals[k++] = v;
      sum += v;
      if (v < min) min = v;
      if (v > max) max = v;
      if (v <= lowClipVal) lowClips++;
      if (v >= highClipVal) highClips++;
    }
  }

  const sorted = Float32Array.from(vals);
  sorted.sort();
  const med =
    count % 2 === 1
      ? sorted[count >> 1]
      : 0.5 * (sorted[(count >> 1) - 1] + sorted[count >> 1]);
  const q25 = sorted[Math.floor(count * 0.25)];
  const q75 = sorted[Math.floor(count * 0.75)];
  const iqr = q75 - q25;

  const absDevs = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    absDevs[i] = Math.abs(vals[i] - med);
  }
  const mad = quickselect(absDevs, count, count >> 1);
  const robustSigma = Math.max(0.25, 1.4826 * mad);

  return {
    median: med,
    mean: sum / count,
    iqr,
    mad,
    robustSigma,
    min,
    max,
    lowClipFraction: lowClips / count,
    highClipFraction: highClips / count,
    validPixelCount: count - lowClips - highClips,
  };
}

export function computeMultiPlaneRoiReport(params: {
  raw14: Float32Array;
  postLine14: Float32Array;
  display8: Uint8ClampedArray;
  W: number;
  H: number;
  animalRoi: RoiBox;
  bridgeRoi: RoiBox;
  backgroundRoi: RoiBox;
  isGloballyMonotonicFrame: boolean;
}): MultiPlaneRoiReport {
  const {
    raw14,
    postLine14,
    display8,
    W,
    H,
    animalRoi,
    bridgeRoi,
    backgroundRoi,
    isGloballyMonotonicFrame,
  } = params;

  const rawAnimal = computePlaneRoiStats(raw14, W, H, animalRoi, 0, 16383);
  const rawBridge = computePlaneRoiStats(raw14, W, H, bridgeRoi, 0, 16383);
  const rawBg = computePlaneRoiStats(raw14, W, H, backgroundRoi, 0, 16383);

  const postAnimal = computePlaneRoiStats(
    postLine14,
    W,
    H,
    animalRoi,
    0,
    16383
  );
  const postBridge = computePlaneRoiStats(
    postLine14,
    W,
    H,
    bridgeRoi,
    0,
    16383
  );
  const postBg = computePlaneRoiStats(
    postLine14,
    W,
    H,
    backgroundRoi,
    0,
    16383
  );

  const dispAnimal = computePlaneRoiStats(display8, W, H, animalRoi, 0, 255);
  const dispBridge = computePlaneRoiStats(display8, W, H, bridgeRoi, 0, 255);
  const dispBg = computePlaneRoiStats(display8, W, H, backgroundRoi, 0, 255);

  const rawAnimalVsBg = rawAnimal.median - rawBg.median;
  const rawBridgeVsBg = rawBridge.median - rawBg.median;
  const rawAnimalVsBridge = rawAnimal.median - rawBridge.median;
  const cnrAnimalVsBg = Math.abs(rawAnimalVsBg) / rawBg.robustSigma;
  const cnrBridgeVsBg = Math.abs(rawBridgeVsBg) / rawBg.robustSigma;
  const rawSepSigma = Math.abs(rawAnimalVsBridge) / rawBg.robustSigma;

  const postAnimalVsBridge = postAnimal.median - postBridge.median;
  const postSepSigma = Math.abs(postAnimalVsBridge) / postBg.robustSigma;

  const dispAnimalVsBridge = dispAnimal.median - dispBridge.median;
  const cnrAnimalVsBg8 =
    Math.abs(dispAnimal.median - dispBg.median) / dispBg.robustSigma;
  const cnrBridgeVsBg8 =
    Math.abs(dispBridge.median - dispBg.median) / dispBg.robustSigma;
  const dispSepSigma8 = Math.abs(dispAnimalVsBridge) / dispBg.robustSigma;

  // Check if relative ordering between Animal and Bridge is preserved from Raw 14-bit to Display 8-bit
  const rawSign =
    Math.abs(rawAnimalVsBridge) < 1.0 ? 0 : Math.sign(rawAnimalVsBridge);
  const dispSign =
    Math.abs(dispAnimalVsBridge) < 0.5 ? 0 : Math.sign(dispAnimalVsBridge);
  const orderingPreserved =
    rawSign === 0 || (dispSign !== 0 && rawSign === dispSign);

  let rootCauseCategory: MultiPlaneRoiReport["rootCauseCategory"] =
    "WELL_SEPARATED_PRESERVED";
  let diagnosticExplanation = "";

  if (rawSepSigma < 1.5) {
    rootCauseCategory = "RAW_OVERLAP_PHYSICAL";
    diagnosticExplanation = `Raw sensor overlap: |median(Animal) - median(Bridge)| is only ${Math.abs(
      rawAnimalVsBridge
    ).toFixed(1)} ADU (${rawSepSigma.toFixed(
      2
    )}× background noise σ). Physical apparent radiance does not strongly separate these two ROIs (e.g., solar-heated bridge vs fur-insulated animal). Enhancement cannot recover a trustworthy temperature difference without hallucinating it.`;
  } else if (!orderingPreserved) {
    rootCauseCategory = "LOCAL_CONTRAST_ORDER_INVERSION";
    diagnosticExplanation = `Ordering loss / inversion in display processing: Raw sensor separates Animal from Bridge by ${rawAnimalVsBridge.toFixed(
      1
    )} ADU (${rawSepSigma.toFixed(
      1
    )}σ), and post-destripe preserves ${postAnimalVsBridge.toFixed(
      1
    )} ADU, but display processing resulted in Δ8 = ${dispAnimalVsBridge.toFixed(
      1
    )} levels. Local contrast or plateau saturation altered relative brightness ordering.`;
  } else if (rawSepSigma >= 2.5 && Math.abs(dispAnimalVsBridge) < 4.5) {
    rootCauseCategory = "TONEMAP_HIGHLIGHT_COMPRESSION_LOSS";
    diagnosticExplanation = `Tone-mapping highlight compression loss: Raw sensor clearly distinguishes Animal from Bridge by ${rawAnimalVsBridge.toFixed(
      1
    )} ADU (${rawSepSigma.toFixed(
      1
    )}σ above background noise), and post-line-correction retains ${postAnimalVsBridge.toFixed(
      1
    )} ADU, but Stage 2/3 quantile clipping (pHigh) compressed both warm structures into only ${Math.abs(
      dispAnimalVsBridge
    ).toFixed(
      1
    )} gray levels of 8-bit display separation (Animal=${dispAnimal.median.toFixed(
      1
    )}, Bridge=${dispBridge.median.toFixed(1)}).`;
  } else {
    rootCauseCategory = "WELL_SEPARATED_PRESERVED";
    diagnosticExplanation = `Radiometric separation preserved: Raw ΔADU = ${rawAnimalVsBridge.toFixed(
      1
    )} ADU (${rawSepSigma.toFixed(
      1
    )}σ), Post-Line ΔADU = ${postAnimalVsBridge.toFixed(
      1
    )} ADU, mapped cleanly to Display Δ8 = ${dispAnimalVsBridge.toFixed(
      1
    )} gray levels (${dispSepSigma8.toFixed(
      1
    )}σ display contrast) with matching intensity ordering.`;
  }

  return {
    animalRoi,
    bridgeRoi,
    backgroundRoi,
    raw14: {
      animal: rawAnimal,
      bridge: rawBridge,
      background: rawBg,
      animalVsBgDeltaAdu: rawAnimalVsBg,
      bridgeVsBgDeltaAdu: rawBridgeVsBg,
      animalVsBridgeDeltaAdu: rawAnimalVsBridge,
      cnrAnimalVsBg,
      cnrBridgeVsBg,
      animalBridgeSeparationSigma: rawSepSigma,
    },
    postLine14: {
      animal: postAnimal,
      bridge: postBridge,
      background: postBg,
      animalVsBridgeDeltaAdu: postAnimalVsBridge,
      animalBridgeSeparationSigma: postSepSigma,
      lineCorrectionDeltaShiftAdu: postAnimalVsBridge - rawAnimalVsBridge,
    },
    display8: {
      animal: dispAnimal,
      bridge: dispBridge,
      background: dispBg,
      animalVsBridgeDelta8: dispAnimalVsBridge,
      cnrAnimalVsBg8,
      cnrBridgeVsBg8,
      animalBridgeSeparationSigma8: dispSepSigma8,
    },
    orderingPreserved,
    monotonicityCheckPassed: isGloballyMonotonicFrame && orderingPreserved,
    rootCauseCategory,
    diagnosticExplanation,
  };
}

function grad(img: Float32Array, W: number, H: number) {
  const gx = new Float32Array(W * H);
  const gy = new Float32Array(W * H);
  for (let y = 1; y < H - 1; y++) {
    for (let x = 1; x < W - 1; x++) {
      const i = y * W + x;
      gx[i] = (img[i + 1] - img[i - 1]) * 0.5;
      gy[i] = (img[i + W] - img[i - W]) * 0.5;
    }
  }
  return { gx, gy };
}

/**
 * Gradient-projection edge retention over the strongest 5% reference edges.
 * Returns empirical ratio (never a hardcoded 98.5% fallback!).
 */
export function computeEmpiricalEdgeKeep(
  test: Float32Array,
  ref: Float32Array,
  W: number,
  H: number
): number {
  const a = grad(test, W, H);
  const b = grad(ref, W, H);
  const mag = new Float32Array(W * H);
  for (let i = 0; i < mag.length; i++) {
    mag[i] = Math.hypot(b.gx[i], b.gy[i]);
  }
  const thr = percentileSample(mag, 0.95, 3);
  if (thr < 1e-3) return 0; // Honest 0 when frame is completely flat
  let num = 0;
  let den = 0;
  for (let i = 0; i < mag.length; i++) {
    if (mag[i] >= thr && mag[i] > 0) {
      num += a.gx[i] * b.gx[i] + a.gy[i] * b.gy[i];
      den += mag[i] * mag[i];
    }
  }
  return den > 0 ? Math.max(0, Math.min(1.5, num / den)) : 0;
}

/**
 * Empirical reference-free stripe proxy and halo overshoot estimator.
 */
export function computeEmpiricalNoRefMetrics(
  restored14: Float32Array,
  raw14: Float32Array,
  display8: Uint8ClampedArray,
  monotonicRef8: Uint8ClampedArray,
  W: number,
  H: number
): {
  colStripeProxyAdu: number;
  rowStripeProxyAdu: number;
  noiseSigmaAdu: number;
  edgeRetentionProxy: number;
  haloOvershootProxy: number;
  lowClipPct8: number;
  highClipPct8: number;
} {
  const stripeProxy = (horizontal: boolean) => {
    const nL = horizontal ? W : H;
    const nA = horizontal ? H : W;
    const st = horizontal ? 1 : W;
    const as = horizontal ? W : 1;
    const g: number[] = [];
    for (let l = 1; l < nL - 1; l += 4) {
      for (let t = 1; t < nA - 1; t += 4) {
        g.push(
          Math.abs(
            restored14[l * st + (t + 1) * as] -
              restored14[l * st + (t - 1) * as]
          )
        );
      }
    }
    const ga = Float32Array.from(g);
    ga.sort();
    const thr = Math.max(8, ga[Math.floor(ga.length * 0.5)] || 8);
    const prof: number[] = [];
    for (let l = 1; l < nL - 1; l++) {
      let s = 0;
      let c = 0;
      for (let t = 1; t < nA - 1; t++) {
        const p = t * as;
        if (
          Math.abs(restored14[l * st + p + as] - restored14[l * st + p - as]) >
          thr
        )
          continue;
        const d =
          restored14[l * st + p] -
          0.5 * (restored14[(l - 1) * st + p] + restored14[(l + 1) * st + p]);
        if (Math.abs(d) < 220) {
          s += d;
          c++;
        }
      }
      if (c > 8) prof.push(s / c);
    }
    if (prof.length === 0) return 0;
    return Math.sqrt(
      prof.reduce((p, q) => p + q * q, 0) / Math.max(1, prof.length)
    );
  };

  let lowClips = 0;
  let highClips = 0;
  for (let i = 0; i < display8.length; i++) {
    if (display8[i] === 0) lowClips++;
    if (display8[i] === 255) highClips++;
  }

  // Empirical halo overshoot: measure local extremum overshoot near strong edges in display8 vs monotonicRef8
  let haloAcc = 0;
  let haloCount = 0;
  for (let y = 2; y < H - 2; y += 2) {
    const rowOff = y * W;
    for (let x = 2; x < W - 2; x += 2) {
      const idx = rowOff + x;
      const refGrad =
        Math.abs(monotonicRef8[idx + 1] - monotonicRef8[idx - 1]) +
        Math.abs(monotonicRef8[idx + W] - monotonicRef8[idx - W]);
      if (refGrad > 18) {
        const nbMin = Math.min(
          monotonicRef8[idx - 1],
          monotonicRef8[idx + 1],
          monotonicRef8[idx - W],
          monotonicRef8[idx + W]
        );
        const nbMax = Math.max(
          monotonicRef8[idx - 1],
          monotonicRef8[idx + 1],
          monotonicRef8[idx - W],
          monotonicRef8[idx + W]
        );
        const val = display8[idx];
        const over =
          val > nbMax ? val - nbMax : val < nbMin ? nbMin - val : 0;
        haloAcc += over;
        haloCount++;
      }
    }
  }

  return {
    colStripeProxyAdu: stripeProxy(true),
    rowStripeProxyAdu: stripeProxy(false),
    noiseSigmaAdu: noiseSigma(restored14, W, H),
    edgeRetentionProxy: computeEmpiricalEdgeKeep(restored14, raw14, W, H),
    haloOvershootProxy: haloCount > 0 ? haloAcc / haloCount : 0,
    lowClipPct8: (lowClips * 100) / display8.length,
    highClipPct8: (highClips * 100) / display8.length,
  };
}

/**
 * Computes synthetic ground-truth metrics ONLY when a known synthetic clean target is present.
 * Never called on unlabeled real sensor files.
 */
export function computeSyntheticGroundTruthMetrics(params: {
  restored14: Float32Array;
  clean14: Float32Array;
  cleanNoThin14: Float32Array;
  thinMask: Uint8Array;
  W: number;
  H: number;
  animalBridgeRetentionRatio: number;
}): {
  psnrDb: number;
  ssim: number;
  colStripeResidualRmsAdu: number;
  rowStripeResidualRmsAdu: number;
  thinStructureRetentionRatio: number;
  edgeKeepRatio: number;
  animalBridgeContrastRetentionRatio: number;
} {
  const {
    restored14,
    clean14,
    cleanNoThin14,
    thinMask,
    W,
    H,
    animalBridgeRetentionRatio,
  } = params;
  const N = W * H;
  const lo = percentileSample(clean14, 0.01, 3);
  const hi = Math.max(lo + 100, percentileSample(clean14, 0.99, 3));
  const L = hi - lo;
  const a = new Float32Array(N);
  const b = new Float32Array(N);
  let mse = 0;

  for (let i = 0; i < N; i++) {
    a[i] = ((Math.max(lo, Math.min(hi, restored14[i])) - lo) / L) * 255;
    b[i] = ((Math.max(lo, Math.min(hi, clean14[i])) - lo) / L) * 255;
    mse += (a[i] - b[i]) ** 2;
  }
  mse = Math.max(1e-6, mse / N);
  const psnrDb = 10 * Math.log10((255 * 255) / mse);

  const mu1 = boxBlur(a, W, H, 3);
  const mu2 = boxBlur(b, W, H, 3);
  const a2 = new Float32Array(N);
  const b2 = new Float32Array(N);
  const ab = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    a2[i] = a[i] * a[i];
    b2[i] = b[i] * b[i];
    ab[i] = a[i] * b[i];
  }
  const s11 = boxBlur(a2, W, H, 3);
  const s22 = boxBlur(b2, W, H, 3);
  const s12 = boxBlur(ab, W, H, 3);
  const C1 = 6.5025;
  const C2 = 58.5225;
  let ss = 0;
  for (let i = 0; i < N; i++) {
    const v1 = s11[i] - mu1[i] ** 2;
    const v2 = s22[i] - mu2[i] ** 2;
    const cv = s12[i] - mu1[i] * mu2[i];
    ss +=
      ((2 * mu1[i] * mu2[i] + C1) * (2 * cv + C2)) /
      ((mu1[i] ** 2 + mu2[i] ** 2 + C1) * (v1 + v2 + C2));
  }

  const colM = new Float64Array(W);
  const colC = new Float64Array(W);
  const rowM = new Float64Array(H);
  const rowC = new Float64Array(H);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      const d = restored14[i] - clean14[i];
      if (Math.abs(d) < 350 && clean14[i] < 12000) {
        colM[x] += d;
        colC[x]++;
        rowM[y] += d;
        rowC[y]++;
      }
    }
  }
  const rms = (m: Float64Array, c: Float64Array) => {
    const v: number[] = [];
    for (let i = 0; i < m.length; i++) {
      if (c[i] > 0) v.push(m[i] / c[i]);
    }
    const mean = v.reduce((p, q) => p + q, 0) / Math.max(1, v.length);
    return Math.sqrt(
      v.reduce((p, q) => p + (q - mean) ** 2, 0) / Math.max(1, v.length)
    );
  };

  let tn = 0;
  let td = 0;
  for (let i = 0; i < N; i++) {
    if (thinMask[i] && clean14[i] < 12000) {
      tn += restored14[i] - cleanNoThin14[i];
      td += clean14[i] - cleanNoThin14[i];
    }
  }

  return {
    psnrDb,
    ssim: ss / N,
    colStripeResidualRmsAdu: rms(colM, colC),
    rowStripeResidualRmsAdu: rms(rowM, rowC),
    thinStructureRetentionRatio: td !== 0 ? Math.max(0, tn / td) : 1,
    edgeKeepRatio: computeEmpiricalEdgeKeep(restored14, clean14, W, H),
    animalBridgeContrastRetentionRatio: animalBridgeRetentionRatio,
  };
}
