export type MethodId =
  | "raw_monotonic"
  | "orig_clearhot"
  | "argos_1"
  | "argos_2"
  | "argos_3"
  | "claude_a"
  | "claude_b"
  | "claude_c"
  | "exp1_argos2_radiometric"
  | "exp2_global_monotonic_locked"
  | "exp3_blended_clahe_monotonic"
  | "exp4_causal_temporal_stabilized";

export type MethodCategory =
  | "reference_baseline"
  | "original_argos"
  | "original_claude"
  | "phase2_experimental";

export interface MethodMetadata {
  id: MethodId;
  shortLabel: string;
  fullName: string;
  category: MethodCategory;
  sourcePackage: "Reference" | "Argos (Original)" | "Claude (Original)" | "Phase 2 Candidate";
  isGloballyMonotonic: boolean;
  temporalBehavior: "Pure Spatial (0-frame)" | "Causal Temporal (Past Only)" | "Look-Ahead at Startup (Claude B)";
  lineSuppressionSummary: string;
  enhancementSummary: string;
  cnnSummary: string;
  principalCaveat: string;
}

export type SyntheticSceneId =
  | "bridge_animal_ambiguity"
  | "full_height_wire_hard_negative"
  | "strong_stripe_150adu_probe"
  | "clean_no_stripe_preservation"
  | "moving_animal_ghost_probe"
  | "horizon_pan_flicker";

export interface DecoderHypothesisConfig {
  width: number;
  height: number;
  endianness: "little" | "big";
  bitMaskMode: "low_14bit" | "high_14bit" | "full_16bit";
  headerBytesOffset: number;
}

export interface BinarySourceDiagnostics {
  fileName: string;
  fileSizeBytes: number;
  fileSha256: string;
  totalFrames: number;
  remainderBytes: number;
  width: number;
  height: number;
  minRaw16: number;
  maxRaw16: number;
  highBits14To15NonZeroPct: number;
  littleEndianSpanAdu: number;
  bigEndianSpanAdu: number;
  recommendedEndianness: "little" | "big";
  streamingSliceBytesPerFrame: number;
  estimatedActiveHeapMb: number;
  hypothesisNotes: string[];
}

export interface UnifiedPipelineConfig {
  // Global Reference Window controls
  fixedWindowMode: "auto_percentile" | "locked_manual_adu";
  manualWindowLowAdu: number;
  manualWindowHighAdu: number;
  percentileLow: number;
  percentileHigh: number;
  highlightKneeStrength: number; // 0..1 soft highlight compression above pHigh

  // Stage toggles (for Stage-by-Stage Ablation & Safe Bypass)
  enableStage1LineCorrection: boolean;
  enableStage2And3ToneMap: boolean;
  enableStage4DetailEnhancement: boolean;
  enableCnnResidual: boolean;

  // Line suppression knobs
  verticalStripeStrength: number; // 0..1.2
  horizontalStripeStrength: number; // 0..1.2
  edgeGateThresholdAdu: number; // 25..350 ADU
  waveletShrinkThresholdAdu: number; // 8..160 ADU
  spectralCutoffFreq: number; // 0.005..0.08

  // Base/Detail & Local Contrast knobs
  guidedRadius: number; // 1..8 px
  guidedEpsilonAduSq: number; // 100..6400
  detailGain: number; // 0.5..3.0
  noiseCoringSigmaMult: number; // 0..3.5
  sCurveStrength: number; // 0..0.8
  claheClipLimit: number; // 1.0..5.0
  claheTileCount: number; // 4..12
  localContrastBlend: number; // 0..0.85 (blend with global monotonic anchor)

  // Temporal Stabilization knobs
  causalTemporalEnabled: boolean;
  claudeBCausalOverride: boolean; // false = original look-ahead at frame 0; true = strictly causal
  temporalMotionGateAdu: number; // 15..250 ADU
  temporalAlpha: number; // 0..0.85
  agcSlewLimitAdu: number; // 5..200 ADU
  declaredWarmupFrames: number; // e.g. 8 frames
}

export interface RoiBox {
  id: string;
  role: "animal" | "bridge" | "background";
  label: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface PlaneRoiStats {
  median: number;
  mean: number;
  iqr: number;
  mad: number;
  robustSigma: number; // 1.4826 * MAD
  min: number;
  max: number;
  lowClipFraction: number;
  highClipFraction: number;
  validPixelCount: number;
}

export interface MultiPlaneRoiReport {
  animalRoi: RoiBox;
  bridgeRoi: RoiBox;
  backgroundRoi: RoiBox;
  raw14: {
    animal: PlaneRoiStats;
    bridge: PlaneRoiStats;
    background: PlaneRoiStats;
    animalVsBgDeltaAdu: number;
    bridgeVsBgDeltaAdu: number;
    animalVsBridgeDeltaAdu: number; // signed: median(animal) - median(bridge)
    cnrAnimalVsBg: number;
    cnrBridgeVsBg: number;
    animalBridgeSeparationSigma: number; // |med(animal) - med(bridge)| / robustSigma(bg)
  };
  postLine14: {
    animal: PlaneRoiStats;
    bridge: PlaneRoiStats;
    background: PlaneRoiStats;
    animalVsBridgeDeltaAdu: number;
    animalBridgeSeparationSigma: number;
    lineCorrectionDeltaShiftAdu: number;
  };
  display8: {
    animal: PlaneRoiStats;
    bridge: PlaneRoiStats;
    background: PlaneRoiStats;
    animalVsBridgeDelta8: number; // signed: median8(animal) - median8(bridge)
    cnrAnimalVsBg8: number;
    cnrBridgeVsBg8: number;
    animalBridgeSeparationSigma8: number;
  };
  orderingPreserved: boolean;
  monotonicityCheckPassed: boolean;
  rootCauseCategory:
    | "RAW_OVERLAP_PHYSICAL"
    | "TONEMAP_HIGHLIGHT_COMPRESSION_LOSS"
    | "LOCAL_CONTRAST_ORDER_INVERSION"
    | "WELL_SEPARATED_PRESERVED";
  diagnosticExplanation: string;
}

export interface PipelineExecutionOutput {
  methodId: MethodId;
  width: number;
  height: number;
  frameIndex: number;
  raw14: Float32Array;
  postLine14: Float32Array;
  postCnn14: Float32Array;
  toneMappedFloat8: Float32Array;
  display8: Uint8ClampedArray;
  monotonicReference8: Uint8ClampedArray;
  diffFromRawMonotonic8: Uint8ClampedArray;
  pLowAdu: number;
  pHighAdu: number;
  rawMinAdu: number;
  rawMaxAdu: number;
  noiseSigmaAdu: number;
  lowClipPct8: number;
  highClipPct8: number;
  colStripeProxyAdu: number;
  rowStripeProxyAdu: number;
  edgeRetentionProxy: number;
  haloOvershootProxy: number;
  isStrictlyMonotonicFrame: boolean;
  monotonicViolationsCount: number;
  executionTimeMs: number;
  stageTimingsMs: {
    lineCorrection: number;
    cnnInference: number;
    temporalOrSpatialDenoise: number;
    toneMapping: number;
    detailEnhancement: number;
  };
  temporalContextInfo: {
    usedPastFrames: number[];
    usedFutureFrames: number[];
    wasResetOnThisFrame: boolean;
    warmupComplete: boolean;
  };
  groundTruthMetrics?: {
    psnrDb: number;
    ssim: number;
    colStripeResidualRmsAdu: number;
    rowStripeResidualRmsAdu: number;
    thinStructureRetentionRatio: number; // 1.0 = ideal preservation of 1px wires/cables
    edgeKeepRatio: number;
    animalBridgeContrastRetentionRatio: number;
  };
  auditNotes: string[];
}

export interface AblationStageEntry {
  stageKey:
    | "stage0_raw_fixed"
    | "stage1_line_only"
    | "stage2_tonemap_only"
    | "stage4_detail_only"
    | "stage_combined_classical"
    | "stage_combined_cnn";
  label: string;
  description: string;
  display8: Uint8ClampedArray;
  diffFromPrev8: Uint8ClampedArray;
  lowClipPct: number;
  highClipPct: number;
  colStripeProxyAdu: number;
  rowStripeProxyAdu: number;
  animalMedian8: number;
  bridgeMedian8: number;
  bgMedian8: number;
  animalBridgeDelta8: number;
  animalBridgeSeparationSigma8: number;
  orderingPreserved: boolean;
}
