import { computeMultiPlaneRoiReport } from "./roiAndMetrics";
import {
  generateSyntheticFrameBundle,
  SYNTHETIC_SCENE_CATALOG,
} from "./syntheticFixtures";
import {
  MethodId,
  SyntheticSceneId,
  UnifiedPipelineConfig,
} from "./types";
import {
  DEFAULT_UNIFIED_CONFIG,
  executeThermalPipeline,
  METHOD_CATALOG,
} from "./unifiedEngine";

export interface MethodBenchmarkRow {
  methodId: MethodId;
  shortLabel: string;
  sourcePackage: string;
  isGloballyMonotonic: boolean;
  // Synthetic Ground Truth averages across held-out test block
  meanPsnrDb: number;
  meanSsim: number;
  colStripeRmsAdu: number;
  rowStripeRmsAdu: number;
  thinWireRetentionPct: number;
  strong150AduStripeAfterRms: number;
  cleanFramePsnrDb: number; // False-correction damage test on clean_no_stripe_preservation
  // Core Brief Scenario: Bridge vs Animal Separation
  bridgeAnimalRawDeltaAdu: number;
  bridgeAnimalPostLineDeltaAdu: number;
  bridgeAnimalDisplayDelta8: number;
  bridgeAnimalDisplaySeparationSigma: number;
  orderingPreservedRatePct: number;
  // Reference-Free & Artifact metrics
  colStripeProxyAdu: number;
  rowStripeProxyAdu: number;
  empiricalEdgeKeepPct: number;
  haloOvershootIndex: number;
  highClipPct8: number;
  monotonicViolationsMean: number;
  // Timing & Real-Time Budget (25 fps = 40.0 ms frame budget)
  p50LatencyMs: number;
  p95LatencyMs: number;
  frameDropRateAt25FpsPct: number;
  honestFailureCases: string[];
}

export interface FrozenBenchmarkReport {
  configHash: string;
  timestampIso: string;
  resolution: string;
  devBlockRange: string;
  exclusionBufferRange: string;
  holdoutBlockRange: string;
  rows: MethodBenchmarkRow[];
}

export function computeConfigHash(cfg: UnifiedPipelineConfig): string {
  const canonical = JSON.stringify(cfg);
  let h1 = 0xdeadbeef ^ canonical.length;
  let h2 = 0x41c6ce57 ^ canonical.length;
  for (let i = 0; i < canonical.length; i++) {
    const ch = canonical.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 =
    Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^
    Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 =
    Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^
    Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (
    (h2 >>> 0).toString(16).padStart(8, "0") +
    (h1 >>> 0).toString(16).padStart(8, "0")
  );
}

/**
 * Runs the frozen Phase 3 evaluation across held-out contiguous frame blocks [25..30]
 * (separated from Development block [0..19] by a 5-frame exclusion buffer [20..24] so
 * temporal state / multi-frame windows cannot leak across blocks).
 */
export function runFrozenPhase3Benchmark(
  W = 320,
  H = 256,
  cfg: UnifiedPipelineConfig = DEFAULT_UNIFIED_CONFIG,
  holdoutFrames: number[] = [25, 27, 29]
): FrozenBenchmarkReport {
  const configHash = computeConfigHash(cfg);
  const rows: MethodBenchmarkRow[] = [];

  const evalScenes: SyntheticSceneId[] = SYNTHETIC_SCENE_CATALOG.map(
    (s) => s.id
  );

  for (const meta of METHOD_CATALOG) {
    const mId = meta.id;
    const latencies: number[] = [];
    let psnrSum = 0;
    let ssimSum = 0;
    let colRmsSum = 0;
    let rowRmsSum = 0;
    let thinWireRetSum = 0;
    let thinWireCount = 0;
    let strong150Rms = 0;
    let cleanScenePsnr = 0;

    let bridgeAnimalRawDelta = 0;
    let bridgeAnimalPostDelta = 0;
    let bridgeAnimalDispDelta = 0;
    let bridgeAnimalDispSigma = 0;
    let orderingPreservedHits = 0;
    let bridgeSceneCount = 0;

    let colProxySum = 0;
    let rowProxySum = 0;
    let edgeKeepSum = 0;
    let haloSum = 0;
    let highClipSum = 0;
    let monoViolSum = 0;
    let totalCases = 0;

    for (const sceneId of evalScenes) {
      for (const fIdx of holdoutFrames) {
        const bundle = generateSyntheticFrameBundle(sceneId, W, H, fIdx, 60);
        // Provide 2 past frames within the held-out block (never crossing exclusion boundary < 25)
        const pastFrames: Float32Array[] = [];
        if (fIdx - 1 >= 25) {
          const p1 = generateSyntheticFrameBundle(
            sceneId,
            W,
            H,
            fIdx - 1,
            60
          );
          pastFrames.push(Float32Array.from(p1.corrupted14));
        }
        if (fIdx - 2 >= 25) {
          const p2 = generateSyntheticFrameBundle(
            sceneId,
            W,
            H,
            fIdx - 2,
            60
          );
          pastFrames.push(Float32Array.from(p2.corrupted14));
        }

        const out = executeThermalPipeline({
          methodId: mId,
          raw14Input: bundle.corrupted14,
          W,
          H,
          frameIndex: fIdx,
          cfg,
          pastFrames14: pastFrames,
          futureFrames14: [],
          wasReset: fIdx === holdoutFrames[0],
          consecutiveFramesProcessed: fIdx - 24,
          syntheticGroundTruth: {
            clean14: bundle.clean14,
            cleanNoThin14: bundle.cleanNoThin14,
            thinMask: bundle.thinMask,
            animalRoi: bundle.defaultRois.animal,
            bridgeRoi: bundle.defaultRois.bridge,
          },
        });

        latencies.push(out.executionTimeMs);
        totalCases++;

        if (out.groundTruthMetrics) {
          psnrSum += out.groundTruthMetrics.psnrDb;
          ssimSum += out.groundTruthMetrics.ssim;
          colRmsSum += out.groundTruthMetrics.colStripeResidualRmsAdu;
          rowRmsSum += out.groundTruthMetrics.rowStripeResidualRmsAdu;
          if (sceneId === "full_height_wire_hard_negative") {
            thinWireRetSum +=
              out.groundTruthMetrics.thinStructureRetentionRatio * 100;
            thinWireCount++;
          }
          if (
            sceneId === "strong_stripe_150adu_probe" &&
            fIdx === holdoutFrames[0]
          ) {
            strong150Rms = out.groundTruthMetrics.colStripeResidualRmsAdu;
          }
          if (
            sceneId === "clean_no_stripe_preservation" &&
            fIdx === holdoutFrames[0]
          ) {
            cleanScenePsnr = out.groundTruthMetrics.psnrDb;
          }
        }

        if (sceneId === "bridge_animal_ambiguity") {
          const roiRep = computeMultiPlaneRoiReport({
            raw14: out.raw14,
            postLine14: out.postLine14,
            display8: out.display8,
            W,
            H,
            animalRoi: bundle.defaultRois.animal,
            bridgeRoi: bundle.defaultRois.bridge,
            backgroundRoi: bundle.defaultRois.background,
            isGloballyMonotonicFrame: out.isStrictlyMonotonicFrame,
          });
          bridgeAnimalRawDelta += roiRep.raw14.animalVsBridgeDeltaAdu;
          bridgeAnimalPostDelta += roiRep.postLine14.animalVsBridgeDeltaAdu;
          bridgeAnimalDispDelta += roiRep.display8.animalVsBridgeDelta8;
          bridgeAnimalDispSigma +=
            roiRep.display8.animalBridgeSeparationSigma8;
          if (roiRep.orderingPreserved) orderingPreservedHits++;
          bridgeSceneCount++;
        }

        colProxySum += out.colStripeProxyAdu;
        rowProxySum += out.rowStripeProxyAdu;
        edgeKeepSum += out.edgeRetentionProxy * 100;
        haloSum += out.haloOvershootProxy;
        highClipSum += out.highClipPct8;
        monoViolSum += out.monotonicViolationsCount;
      }
    }

    latencies.sort((a, b) => a - b);
    const p50 = latencies[Math.floor(latencies.length * 0.5)] || 0;
    const p95 = latencies[Math.floor(latencies.length * 0.95)] || 0;
    const drops = latencies.filter((l) => l > 40.0).length;

    const meanBridgeDispDelta =
      bridgeAnimalDispDelta / Math.max(1, bridgeSceneCount);
    const meanThinWirePct = thinWireRetSum / Math.max(1, thinWireCount);

    const honestFailureCases: string[] = [];
    if (strong150Rms > 85) {
      honestFailureCases.push(
        `Fails strong ±150 ADU alternating stripe probe (residual ${strong150Rms.toFixed(1)} ADU) because cross-column diff exceeds local gradient gate.`
      );
    }
    if (meanThinWirePct < 75) {
      honestFailureCases.push(
        `Attenuates full-height 1px vertical structural wires (${meanThinWirePct.toFixed(1)}% contrast retained).`
      );
    }
    if (Math.abs(meanBridgeDispDelta) < 4.5) {
      honestFailureCases.push(
        `Compresses Animal vs Bridge display contrast to ${meanBridgeDispDelta.toFixed(1)} gray levels due to p97.5 upper quantile highlight clipping.`
      );
    }
    if (monoViolSum / totalCases > 2) {
      honestFailureCases.push(
        `Non-monotonic spatial mapping (${(monoViolSum / totalCases).toFixed(1)} sampled ordering inversions/frame); must be labeled Display Intensity, not temperature.`
      );
    }
    if (honestFailureCases.length === 0) {
      honestFailureCases.push(
        `Maintains monotonic intensity ordering and >80% thin-wire retention, though fixed-window contrast in dark background regions is lower than adaptive CLAHE.`
      );
    }

    rows.push({
      methodId: mId,
      shortLabel: meta.shortLabel,
      sourcePackage: meta.sourcePackage,
      isGloballyMonotonic: meta.isGloballyMonotonic,
      meanPsnrDb: psnrSum / totalCases,
      meanSsim: ssimSum / totalCases,
      colStripeRmsAdu: colRmsSum / totalCases,
      rowStripeRmsAdu: rowRmsSum / totalCases,
      thinWireRetentionPct: meanThinWirePct,
      strong150AduStripeAfterRms: strong150Rms,
      cleanFramePsnrDb: cleanScenePsnr,
      bridgeAnimalRawDeltaAdu:
        bridgeAnimalRawDelta / Math.max(1, bridgeSceneCount),
      bridgeAnimalPostLineDeltaAdu:
        bridgeAnimalPostDelta / Math.max(1, bridgeSceneCount),
      bridgeAnimalDisplayDelta8: meanBridgeDispDelta,
      bridgeAnimalDisplaySeparationSigma:
        bridgeAnimalDispSigma / Math.max(1, bridgeSceneCount),
      orderingPreservedRatePct:
        (orderingPreservedHits * 100) / Math.max(1, bridgeSceneCount),
      colStripeProxyAdu: colProxySum / totalCases,
      rowStripeProxyAdu: rowProxySum / totalCases,
      empiricalEdgeKeepPct: edgeKeepSum / totalCases,
      haloOvershootIndex: haloSum / totalCases,
      highClipPct8: highClipSum / totalCases,
      monotonicViolationsMean: monoViolSum / totalCases,
      p50LatencyMs: p50,
      p95LatencyMs: p95,
      frameDropRateAt25FpsPct: (drops * 100) / latencies.length,
      honestFailureCases,
    });
  }

  return {
    configHash,
    timestampIso: new Date().toISOString(),
    resolution: `${W}×${H}`,
    devBlockRange: "Frames [0..19] (Development / Parameter Tuning Block)",
    exclusionBufferRange:
      "Frames [20..24] (5-Frame Temporal Context Exclusion Guard)",
    holdoutBlockRange: `Frames [${holdoutFrames[0]}..${
      holdoutFrames[holdoutFrames.length - 1]
    }] (Frozen Held-Out Evaluation Block)`,
    rows,
  };
}
