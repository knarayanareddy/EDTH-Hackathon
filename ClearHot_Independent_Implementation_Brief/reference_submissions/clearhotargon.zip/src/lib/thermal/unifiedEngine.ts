import {
  alongGate,
  applyLineOffsets,
  bilateral5,
  boxBlur,
  clahe,
  estimateLineOffsetsLocal,
  estimateLineOffsetsSpectral,
  guidedSelf,
  noiseSigma,
  percentileSample,
  robustBadPixels,
  smooth1DProfile,
  verifyGlobalMonotonicity,
} from "./dspCore";
import {
  computeEmpiricalNoRefMetrics,
  computeMultiPlaneRoiReport,
  computePlaneRoiStats,
  computeSyntheticGroundTruthMetrics,
} from "./roiAndMetrics";
import {
  AblationStageEntry,
  MethodId,
  MethodMetadata,
  PipelineExecutionOutput,
  RoiBox,
  UnifiedPipelineConfig,
} from "./types";

export const DEFAULT_UNIFIED_CONFIG: UnifiedPipelineConfig = {
  fixedWindowMode: "auto_percentile",
  manualWindowLowAdu: 7060,
  manualWindowHighAdu: 7980,
  percentileLow: 0.02,
  percentileHigh: 0.992,
  highlightKneeStrength: 0.35,

  enableStage1LineCorrection: true,
  enableStage2And3ToneMap: true,
  enableStage4DetailEnhancement: true,
  enableCnnResidual: false,

  verticalStripeStrength: 0.85,
  horizontalStripeStrength: 0.7,
  edgeGateThresholdAdu: 135,
  waveletShrinkThresholdAdu: 46,
  spectralCutoffFreq: 0.02,

  guidedRadius: 3,
  guidedEpsilonAduSq: 1800,
  detailGain: 1.55,
  noiseCoringSigmaMult: 1.5,
  sCurveStrength: 0.35,
  claheClipLimit: 2.4,
  claheTileCount: 8,
  localContrastBlend: 0.35,

  causalTemporalEnabled: true,
  claudeBCausalOverride: false,
  temporalMotionGateAdu: 90,
  temporalAlpha: 0.55,
  agcSlewLimitAdu: 22,
  declaredWarmupFrames: 8,
};

export const METHOD_CATALOG: MethodMetadata[] = [
  {
    id: "raw_monotonic",
    shortLabel: "Raw Monotonic Ref",
    fullName: "Raw / Global Monotonic Linear Fixed-Window Reference",
    category: "reference_baseline",
    sourcePackage: "Reference",
    isGloballyMonotonic: true,
    temporalBehavior: "Pure Spatial (0-frame)",
    lineSuppressionSummary: "None (Unmodified 14-bit sensor ADU)",
    enhancementSummary:
      "Global monotonic linear window [W_low, W_high] with zero spatially varying local contrast.",
    cnnSummary: "Disabled (Radiometric Ordering Reference)",
    principalCaveat:
      "Preserves strict ADU intensity ordering up to 8-bit quantization/clipping; retains raw stripes and bad pixels.",
  },
  {
    id: "orig_clearhot",
    shortLabel: "Orig ClearHot",
    fullName: "Original ClearHot 4-Stage Baseline",
    category: "reference_baseline",
    sourcePackage: "Reference",
    isGloballyMonotonic: false,
    temporalBehavior: "Pure Spatial (0-frame)",
    lineSuppressionSummary:
      "Global column mean & 9-row moving average subtraction + 4-neighbor >1800 ADU spike gate",
    enhancementSummary:
      "Quantile [p2, p97.5] linear map to 0..232 + soft highlight shoulder + 4-neighbor high-pass detail boost",
    cnnSummary: "None",
    principalCaveat:
      "p97.5 highlight cutoff compresses warm bridge & animal structures into the 232..255 shoulder; naive column mean creates shadows under tall warm objects.",
  },
  {
    id: "argos_1",
    shortLabel: "Argos 1",
    fullName: "Argos 1 — Edge-Gated Huber Profile + Rank Impulse + DPHE + DoG Coring",
    category: "original_argos",
    sourcePackage: "Argos (Original)",
    isGloballyMonotonic: false,
    temporalBehavior: "Causal Temporal (Past Only)",
    lineSuppressionSummary:
      "Edge-gated Huber adjacent-column/row difference integration + 8-neighbor rank impulse gate",
    enhancementSummary:
      "Dual-Plateau Histogram Equalization (DPHE) blended tone curve + Difference-of-Gaussians deadzone coring",
    cnnSummary:
      "StripeResNet-1D2D hand-crafted directional filter (browser loop tunes 4 scalar mixWeights via finite differences)",
    principalCaveat:
      "Cross-line gradient gate (<135 ADU) gates out strong alternating stripes (±150 ADU probe); original UI fallback constants removed here.",
  },
  {
    id: "argos_2",
    shortLabel: "Argos 2 [User Ref]",
    fullName: "Argos 2 [User Visual Reference] — 1D Haar Garrote + Guided Base/Detail + S-Curve",
    category: "original_argos",
    sourcePackage: "Argos (Original)",
    isGloballyMonotonic: false,
    temporalBehavior: "Causal Temporal (Past Only)",
    lineSuppressionSummary:
      "1D multi-scale Haar wavelet non-negative Garrote shrinkage + spectral comb notch + directional cross-median",
    enhancementSummary:
      "14-bit Guided Filter base/detail decomposition + S-curve base compression + halo-controlled detail boost",
    cnnSummary:
      "HaarWaveletCNN 2D DWT subband shrinkage (browser routine optimizes 4 scalar mixWeights, not conv kernels)",
    principalCaveat:
      "User's preferred visual reference, but p97.5 quantile cutoff + S-curve compresses warm bridge and animal signals into saturated highlights when both exceed p97.5.",
  },
  {
    id: "argos_3",
    shortLabel: "Argos 3",
    fullName: "Argos 3 — 1D Cross-Bilateral Strip + Motion-Gated Kalman + Integral ACE",
    category: "original_argos",
    sourcePackage: "Argos (Original)",
    isGloballyMonotonic: false,
    temporalBehavior: "Causal Temporal (Past Only)",
    lineSuppressionSummary:
      "Per-pixel 3-row/col coherent cross-bilateral strip filter + 14-bit motion-gated temporal Kalman",
    enhancementSummary:
      "Summed-Area Table (Integral Image) 13×13 Local Variance Adaptive Contrast Enhancement (ACE)",
    cnnSummary:
      "BurstTempCNN orthogonal projection filter (4 scalar mixWeights tuned in browser)",
    principalCaveat:
      "Local 13×13 ACE alters global intensity ordering between distant ROIs; temporal Kalman requires reset on seeks/file changes.",
  },
  {
    id: "claude_a",
    shortLabel: "Claude A",
    fullName: "Claude A — Iterated Local-Median Segment Profile + Robust BadPx + CLAHE",
    category: "original_claude",
    sourcePackage: "Claude (Original)",
    isGloballyMonotonic: false,
    temporalBehavior: "Causal Temporal (Past Only)",
    lineSuppressionSummary:
      "Iterated 4-segment along-stripe gated local-neighbor median offset estimator + isolation-aware bad pixel gate",
    enhancementSummary:
      "Quantile AGC + 8×8 tile Contrast-Limited Adaptive Histogram Equalization (CLAHE) blend + 4-neighbor detail",
    cnnSummary: "DnCNN-lite (1,905 params in TF.js; trained on synthetic scenes only)",
    principalCaveat:
      "Suppresses strong ±150 ADU stripes effectively, but full-height genuine 1px vertical wires can be attenuated (~0.66 retention); CLAHE is non-monotonic.",
  },
  {
    id: "claude_b",
    shortLabel: "Claude B",
    fullName: "Claude B — Multi-Frame Constant-Statistics + Temporal Denoise + Guided Detail",
    category: "original_claude",
    sourcePackage: "Claude (Original)",
    isGloballyMonotonic: false,
    temporalBehavior: "Look-Ahead at Startup (Claude B)",
    lineSuppressionSummary:
      "12-frame temporal averaging + local-median profile + motion-confidence FPN residual",
    enhancementSummary:
      "512-bin Plateau Histogram Equalization + He et al. self-guided edge-preserving detail with noise coring",
    cnnSummary: "1-D Profile ConvNet (9,041 actual params vs ~3k UI label)",
    principalCaveat:
      "Unmodified destripeB requests future frames 1..11 at frame 0 (non-causal look-ahead). Toggle 'Strict Causal Override' in UI to enforce past-only frames.",
  },
  {
    id: "claude_c",
    shortLabel: "Claude C",
    fullName: "Claude C — FFT Spectral Profile Notch + 5×5 Bilateral + Multiscale Detail",
    category: "original_claude",
    sourcePackage: "Claude (Original)",
    isGloballyMonotonic: false,
    temporalBehavior: "Causal Temporal (Past Only)",
    lineSuppressionSummary:
      "Iterated wide-reference profile + radix-2 FFT broadband high-pass & periodic spectral peak notch",
    enhancementSummary:
      "5×5 radiometric bilateral denoise + 3-scale box-blur pyramid with base compression & soft-limited coring",
    cnnSummary: "Directional ConvNet (3,167 params in TF.js; synthetic training only)",
    principalCaveat:
      "Spectral notch can attenuate periodic bridge truss patterns or full-height cables; multiscale base compression alters global intensity ordering.",
  },
  {
    id: "exp1_argos2_radiometric",
    shortLabel: "Exp-1: Argos2-Radiometric",
    fullName: "Phase 2 Exp-1 — Argos 2 Evolved: Along-Stripe Gated Haar + Box-Guided Base/Detail + Highlight Knee",
    category: "phase2_experimental",
    sourcePackage: "Phase 2 Candidate",
    isGloballyMonotonic: false,
    temporalBehavior: "Causal Temporal (Past Only)",
    lineSuppressionSummary:
      "Along-stripe gradient-gated 4-segment Haar Garrote shrinkage + 1px wire continuity protection + 8-neighbor spike gate",
    enhancementSummary:
      "True O(1) He et al. 14-bit Guided Base/Detail + p99.5 extended dynamic window + monotonic highlight knee + noise-cored detail",
    cnnSummary: "Bypassed by default (Uncertainty-gated classical fallback)",
    principalCaveat:
      "Designed starting from Argos 2 to preserve Animal-vs-Bridge separation in highlights while fixing Argos 2's ±150 ADU stripe blindspot and protecting 1px bridge cables.",
  },
  {
    id: "exp2_global_monotonic_locked",
    shortLabel: "Exp-2: Global Monotonic",
    fullName: "Phase 2 Exp-2 — Strict Global Monotonic Percentile/Locked Window + Highlight Knee",
    category: "phase2_experimental",
    sourcePackage: "Phase 2 Candidate",
    isGloballyMonotonic: true,
    temporalBehavior: "Pure Spatial (0-frame)",
    lineSuppressionSummary:
      "Along-stripe gated segment-consistent destriping + isolation-aware spike gate (14-bit radiometric plane)",
    enhancementSummary:
      "Strictly monotonic global mapping (linear main window + logarithmic highlight knee) with lockable ADU scale across frames",
    cnnSummary: "Disabled (Strict Monotonic Display Mode)",
    principalCaveat:
      "Guarantees 0 monotonicity inversions wrt post-destripe 14-bit plane and zero AGC flicker when scale-locked; does not artificially boost local contrast.",
  },
  {
    id: "exp3_blended_clahe_monotonic",
    shortLabel: "Exp-3: Blended CL-Hist",
    fullName: "Phase 2 Exp-3 — Global Monotonic Anchor + Bounded Contrast-Limited Local Histogram Blend",
    category: "phase2_experimental",
    sourcePackage: "Phase 2 Candidate",
    isGloballyMonotonic: false,
    temporalBehavior: "Pure Spatial (0-frame)",
    lineSuppressionSummary:
      "Along-stripe gated segment-consistent destriping + isolation-aware bad-pixel removal",
    enhancementSummary:
      "Blends (1 - α) Global Monotonic Anchor with α Contrast-Limited Local Histogram (adjustable tile grid & clip limit) + noise-cored guided detail",
    cnnSummary: "Disabled",
    principalCaveat:
      "Interpretive local-contrast view: setting local blend α > 0.45 can alter relative brightness between distant bridge and animal ROIs (tracked live in ROI panel).",
  },
  {
    id: "exp4_causal_temporal_stabilized",
    shortLabel: "Exp-4: Causal Temporal",
    fullName: "Phase 2 Exp-4 — Strictly Causal Motion-Gated Temporal Stabilization + Warm-Up & Scene Reset",
    category: "phase2_experimental",
    sourcePackage: "Phase 2 Candidate",
    isGloballyMonotonic: false,
    temporalBehavior: "Causal Temporal (Past Only)",
    lineSuppressionSummary:
      "Causal exponential temporal profile accumulator (past frames only) + along-stripe gated spatial destriping",
    enhancementSummary:
      "Per-pixel radiometric motion gate (zeros temporal blend on moving animals) + scene-change reset + Exp-1 guided detail",
    cnnSummary: "Disabled",
    principalCaveat:
      "Requires declared warm-up (default 8 consecutive frames) to reach steady-state temporal noise reduction; automatically resets on non-consecutive frame seeks.",
  },
];

export function runStage1LineSuppression(params: {
  methodId: MethodId;
  raw14: Float32Array;
  W: number;
  H: number;
  cfg: UnifiedPipelineConfig;
  sigma: number;
  pastFrames14: Float32Array[];
  futureFrames14: Float32Array[];
}): {
  postLine14: Float32Array;
  usedPastOffsets: number[];
  usedFutureOffsets: number[];
  notes: string[];
} {
  const {
    methodId,
    raw14,
    W,
    H,
    cfg,
    sigma,
    pastFrames14,
    futureFrames14,
  } = params;
  const N = W * H;
  const notes: string[] = [];
  const usedPastOffsets: number[] = [];
  const usedFutureOffsets: number[] = [];

  if (!cfg.enableStage1LineCorrection || methodId === "raw_monotonic") {
    return {
      postLine14: Float32Array.from(raw14),
      usedPastOffsets,
      usedFutureOffsets,
      notes,
    };
  }

  const vStr = cfg.verticalStripeStrength;
  const hStr = cfg.horizontalStripeStrength;

  if (methodId === "orig_clearhot") {
    const out = Float32Array.from(raw14);
    const colBias = new Float32Array(W);
    let globalMed = 0;
    for (let x = 0; x < W; x++) {
      let sum = 0;
      let cnt = 0;
      for (let y = 16; y < H - 16; y += 4) {
        const v = raw14[y * W + x];
        if (v > 1000 && v < 12000) {
          sum += v;
          cnt++;
        }
      }
      colBias[x] = cnt > 0 ? sum / cnt : 7200;
      globalMed += colBias[x];
    }
    globalMed /= W;
    const rowMean = new Float32Array(H);
    for (let y = 0; y < H; y++) {
      let s = 0;
      for (let x = 0; x < W; x += 4) s += raw14[y * W + x];
      rowMean[y] = s / Math.ceil(W / 4);
    }
    const rowBias = new Float32Array(H);
    for (let y = 0; y < H; y++) {
      let s = 0;
      let c = 0;
      for (let k = -4; k <= 4; k++) {
        const j = y + k;
        if (j >= 0 && j < H) {
          s += rowMean[j];
          c++;
        }
      }
      rowBias[y] = rowMean[y] - s / c;
    }
    for (let y = 1; y < H - 1; y++) {
      for (let x = 1; x < W - 1; x++) {
        const idx = y * W + x;
        let v =
          raw14[idx] -
          (colBias[x] - globalMed) * vStr -
          rowBias[y] * hStr;
        const avgN =
          (raw14[idx - 1] + raw14[idx + 1] + raw14[idx - W] + raw14[idx + W]) *
          0.25;
        if (Math.abs(v - avgN) > 1800) v = avgN;
        out[idx] = v;
      }
    }
    return { postLine14: out, usedPastOffsets, usedFutureOffsets, notes };
  }

  if (methodId === "argos_1") {
    const out = Float32Array.from(raw14);
    const edgeThresh = Math.max(25, cfg.edgeGateThresholdAdu);
    const colDiff = new Float32Array(W);
    const colIntegrated = new Float32Array(W);
    for (let x = 1; x < W; x++) {
      let sumDiff = 0;
      let weightSum = 0;
      for (let y = 4; y < H - 4; y += 2) {
        const idx = y * W + x;
        const dx = raw14[idx] - raw14[idx - 1];
        const dy = Math.abs(raw14[idx + W] - raw14[idx - W]);
        if (Math.abs(dx) < edgeThresh && dy < edgeThresh * 1.4) {
          const w = 1.0 / (1.0 + (dx * dx) / (edgeThresh * edgeThresh * 0.25));
          sumDiff += dx * w;
          weightSum += w;
        }
      }
      colDiff[x] = weightSum > 4 ? sumDiff / weightSum : 0;
      colIntegrated[x] = colIntegrated[x - 1] + colDiff[x];
    }
    const colLowPass = smooth1DProfile(colIntegrated, 9);
    const colStripeEst = new Float32Array(W);
    for (let x = 0; x < W; x++) colStripeEst[x] = colIntegrated[x] - colLowPass[x];

    const rowDiff = new Float32Array(H);
    const rowIntegrated = new Float32Array(H);
    for (let y = 1; y < H; y++) {
      let sumDiff = 0;
      let weightSum = 0;
      for (let x = 4; x < W - 4; x += 2) {
        const idx = y * W + x;
        const dy = raw14[idx] - raw14[idx - W];
        const dx = Math.abs(raw14[idx + 1] - raw14[idx - 1]);
        if (Math.abs(dy) < edgeThresh && dx < edgeThresh * 1.4) {
          const w = 1.0 / (1.0 + (dy * dy) / (edgeThresh * edgeThresh * 0.25));
          sumDiff += dy * w;
          weightSum += w;
        }
      }
      rowDiff[y] = weightSum > 4 ? sumDiff / weightSum : 0;
      rowIntegrated[y] = rowIntegrated[y - 1] + rowDiff[y];
    }
    const rowLowPass = smooth1DProfile(rowIntegrated, 7);
    const rowStripeEst = new Float32Array(H);
    for (let y = 0; y < H; y++) rowStripeEst[y] = rowIntegrated[y] - rowLowPass[y];

    const nbrs = new Float32Array(8);
    for (let y = 1; y < H - 1; y++) {
      const rowOff = y * W;
      for (let x = 1; x < W - 1; x++) {
        const idx = rowOff + x;
        const rawV = raw14[idx];
        const localHorizGrad = Math.abs(
          rawV - 0.5 * (raw14[idx - 1] + raw14[idx + 1])
        );
        const localVertGrad = Math.abs(
          rawV - 0.5 * (raw14[idx - W] + raw14[idx + W])
        );
        const colProtect = localHorizGrad > edgeThresh * 1.35 ? 0.25 : 1.0;
        const rowProtect = localVertGrad > edgeThresh * 1.35 ? 0.25 : 1.0;

        let v =
          rawV -
          colStripeEst[x] * vStr * colProtect -
          rowStripeEst[y] * hStr * rowProtect;

        nbrs[0] = raw14[idx - W - 1];
        nbrs[1] = raw14[idx - W];
        nbrs[2] = raw14[idx - W + 1];
        nbrs[3] = raw14[idx - 1];
        nbrs[4] = raw14[idx + 1];
        nbrs[5] = raw14[idx + W - 1];
        nbrs[6] = raw14[idx + W];
        nbrs[7] = raw14[idx + W + 1];
        nbrs.sort();
        const med = 0.5 * (nbrs[3] + nbrs[4]);
        if (v - nbrs[6] > 1600 || nbrs[1] - v > 1600) v = med;
        out[idx] = v;
      }
    }
    return { postLine14: out, usedPastOffsets, usedFutureOffsets, notes };
  }

  if (methodId === "argos_2") {
    // Untouched original Argos 2 Stage 1
    const out = Float32Array.from(raw14);
    const shrinkT = Math.max(8, cfg.waveletShrinkThresholdAdu);
    const colProf = new Float32Array(W);
    for (let x = 0; x < W; x++) {
      let sum = 0;
      let cnt = 0;
      for (let y = 8; y < H - 8; y += 2) {
        const idx = y * W + x;
        const v = raw14[idx];
        const localDiff = Math.abs(v - raw14[idx - W]);
        if (localDiff < 180 && v > 400 && v < 13500) {
          sum += v;
          cnt++;
        }
      }
      colProf[x] = cnt > 0 ? sum / cnt : 7200;
    }
    const rowProf = new Float32Array(H);
    for (let y = 0; y < H; y++) {
      let sum = 0;
      let cnt = 0;
      const rowOff = y * W;
      for (let x = 8; x < W - 8; x += 2) {
        const idx = rowOff + x;
        const v = raw14[idx];
        const localDiff = Math.abs(v - raw14[idx - 1]);
        if (localDiff < 180 && v > 400 && v < 13500) {
          sum += v;
          cnt++;
        }
      }
      rowProf[y] = cnt > 0 ? sum / cnt : 7200;
    }

    const colSmooth1 = smooth1DProfile(colProf, 1);
    const colSmooth2 = smooth1DProfile(colProf, 3);
    const colSmooth4 = smooth1DProfile(colProf, 8);
    const colWaveletStripe = new Float32Array(W);
    for (let x = 0; x < W; x++) {
      const d1 = colProf[x] - colSmooth1[x];
      const d2 = colSmooth1[x] - colSmooth2[x];
      const d3 = colSmooth2[x] - colSmooth4[x];
      const g1 =
        Math.abs(d1) < shrinkT ? d1 : d1 * ((shrinkT * shrinkT) / (d1 * d1));
      const g2 =
        Math.abs(d2) < shrinkT ? d2 : d2 * ((shrinkT * shrinkT) / (d2 * d2));
      const g3 =
        Math.abs(d3) < shrinkT * 0.8
          ? d3 * 0.55
          : d3 * ((shrinkT * shrinkT * 0.64) / (d3 * d3)) * 0.55;
      colWaveletStripe[x] = g1 + g2 + g3;
    }

    const rowSmooth1 = smooth1DProfile(rowProf, 1);
    const rowSmooth2 = smooth1DProfile(rowProf, 3);
    const rowSmooth4 = smooth1DProfile(rowProf, 7);
    const rowWaveletStripe = new Float32Array(H);
    for (let y = 0; y < H; y++) {
      const d1 = rowProf[y] - rowSmooth1[y];
      const d2 = rowSmooth1[y] - rowSmooth2[y];
      const d3 = rowSmooth2[y] - rowSmooth4[y];
      const g1 =
        Math.abs(d1) < shrinkT ? d1 : d1 * ((shrinkT * shrinkT) / (d1 * d1));
      const g2 =
        Math.abs(d2) < shrinkT ? d2 : d2 * ((shrinkT * shrinkT) / (d2 * d2));
      const g3 =
        Math.abs(d3) < shrinkT * 0.8
          ? d3 * 0.55
          : d3 * ((shrinkT * shrinkT * 0.64) / (d3 * d3)) * 0.55;
      rowWaveletStripe[y] = g1 + g2 + g3;
    }

    for (let y = 1; y < H - 1; y++) {
      const rowOff = y * W;
      for (let x = 1; x < W - 1; x++) {
        const idx = rowOff + x;
        const rawV = raw14[idx];
        const localDx = Math.abs(
          rawV - 0.5 * (raw14[idx - 1] + raw14[idx + 1])
        );
        const localDy = Math.abs(
          rawV - 0.5 * (raw14[idx - W] + raw14[idx + W])
        );
        const colGate = Math.exp(-(localDx * localDx) / (2 * 180 * 180));
        const rowGate = Math.exp(-(localDy * localDy) / (2 * 180 * 180));
        let v =
          rawV -
          colWaveletStripe[x] * vStr * colGate -
          rowWaveletStripe[y] * hStr * rowGate;
        const avg4 =
          (raw14[idx - 1] + raw14[idx + 1] + raw14[idx - W] + raw14[idx + W]) *
          0.25;
        if (Math.abs(v - avg4) > 1750) v = avg4;
        out[idx] = v;
      }
    }
    return { postLine14: out, usedPastOffsets, usedFutureOffsets, notes };
  }

  if (methodId === "argos_3") {
    const out = Float32Array.from(raw14);
    const sigmaR = 115;
    const twoSigmaRSq = 2 * sigmaR * sigmaR;
    const prevFrame = pastFrames14.length > 0 ? pastFrames14[0] : null;
    if (prevFrame) usedPastOffsets.push(-1);
    const motionGate = Math.max(15, cfg.temporalMotionGateAdu);
    const tempAlpha = cfg.temporalAlpha;

    for (let y = 2; y < H - 2; y++) {
      const rowOff = y * W;
      for (let x = 2; x < W - 2; x++) {
        const idx = rowOff + x;
        let c = raw14[idx];
        const avg4 =
          (raw14[idx - 1] + raw14[idx + 1] + raw14[idx - W] + raw14[idx + W]) *
          0.25;
        if (Math.abs(c - avg4) > 1750) c = avg4;

        const dLeft0 = c - raw14[idx - 1];
        const dRight0 = c - raw14[idx + 1];
        const dLeftU = raw14[idx - W] - raw14[idx - W - 1];
        const dRightU = raw14[idx - W] - raw14[idx - W + 1];
        const dLeftD = raw14[idx + W] - raw14[idx + W - 1];
        const dRightD = raw14[idx + W] - raw14[idx + W + 1];

        const coherentColResidual =
          (dLeft0 + dRight0) * 0.25 +
          (dLeftU + dRightU) * 0.125 +
          (dLeftD + dRightD) * 0.125;
        const wCol = Math.exp(
          -(coherentColResidual * coherentColResidual) / twoSigmaRSq
        );
        const colCorr = coherentColResidual * wCol * vStr;

        const dUp0 = c - raw14[idx - W];
        const dDown0 = c - raw14[idx + W];
        const dUpL = raw14[idx - 1] - raw14[idx - W - 1];
        const dDownL = raw14[idx - 1] - raw14[idx + W - 1];
        const dUpR = raw14[idx + 1] - raw14[idx - W + 1];
        const dDownR = raw14[idx + 1] - raw14[idx + W + 1];

        const coherentRowResidual =
          (dUp0 + dDown0) * 0.25 +
          (dUpL + dDownL) * 0.125 +
          (dUpR + dDownR) * 0.125;
        const wRow = Math.exp(
          -(coherentRowResidual * coherentRowResidual) / twoSigmaRSq
        );
        const rowCorr = coherentRowResidual * wRow * hStr;

        let spatialClean = c - colCorr - rowCorr;
        if (prevFrame) {
          const prevVal = prevFrame[idx];
          const diffT = Math.abs(spatialClean - prevVal);
          const motionWeight =
            diffT > motionGate
              ? 0
              : tempAlpha * Math.exp(-(diffT * diffT) / (2 * motionGate * motionGate));
          spatialClean =
            (1 - motionWeight) * spatialClean + motionWeight * prevVal;
        }
        out[idx] = spatialClean;
      }
    }
    return { postLine14: out, usedPastOffsets, usedFutureOffsets, notes };
  }

  if (methodId === "claude_a") {
    const out = robustBadPixels(raw14, W, H, sigma);
    if (vStr > 0) {
      const colOff = estimateLineOffsetsLocal(out, W, H, "col", 4, 3);
      applyLineOffsets(out, W, H, "col", colOff, vStr);
    }
    if (hStr > 0) {
      const rowOff = estimateLineOffsetsLocal(out, W, H, "row", 4, 3);
      applyLineOffsets(out, W, H, "row", rowOff, hStr);
    }
    return { postLine14: out, usedPastOffsets, usedFutureOffsets, notes };
  }

  if (methodId === "claude_b") {
    const out = robustBadPixels(raw14, W, H, sigma);
    const M = Float32Array.from(out);
    let count = 1;
    // Unmodified Claude B uses future frames when past frames are fewer than window
    for (let i = 0; i < pastFrames14.length; i++) {
      const pf = pastFrames14[i];
      for (let k = 0; k < N; k++) M[k] += pf[k];
      usedPastOffsets.push(-(i + 1));
      count++;
    }
    if (!cfg.claudeBCausalOverride && futureFrames14.length > 0) {
      for (let i = 0; i < futureFrames14.length; i++) {
        const ff = futureFrames14[i];
        for (let k = 0; k < N; k++) M[k] += ff[k];
        usedFutureOffsets.push(i + 1);
        count++;
      }
      notes.push(
        `Claude B (Unmodified): Looked ahead into ${futureFrames14.length} future frame(s) at sequence startup.`
      );
    } else if (cfg.claudeBCausalOverride) {
      notes.push(
        `Claude B (Strict Causal Override): Future frame look-ahead blocked; used ${pastFrames14.length} past frame(s) only.`
      );
    }
    for (let k = 0; k < N; k++) M[k] /= count;

    if (vStr > 0) {
      const colOff = estimateLineOffsetsLocal(M, W, H, "col", 4, 3);
      applyLineOffsets(out, W, H, "col", colOff, vStr);
    }
    if (hStr > 0) {
      const rowOff = estimateLineOffsetsLocal(M, W, H, "row", 4, 3);
      applyLineOffsets(out, W, H, "row", rowOff, hStr);
    }
    // Temporal denoise step in Claude B
    const neighborFrame =
      pastFrames14.length > 0
        ? pastFrames14[0]
        : !cfg.claudeBCausalOverride && futureFrames14.length > 0
        ? futureFrames14[0]
        : null;
    if (neighborFrame) {
      const kGate = Math.max(8, 3.5 * sigma);
      for (let i = 0; i < N; i++) {
        const d = Math.abs(out[i] - neighborFrame[i]) / kGate;
        out[i] =
          out[i] + (neighborFrame[i] - out[i]) * 0.45 * Math.exp(-d * d);
      }
    }
    return { postLine14: out, usedPastOffsets, usedFutureOffsets, notes };
  }

  if (methodId === "claude_c") {
    let out = robustBadPixels(raw14, W, H, sigma);
    if (vStr > 0) {
      const colOff = estimateLineOffsetsSpectral(
        out,
        W,
        H,
        "col",
        cfg.spectralCutoffFreq,
        4,
        "both"
      );
      applyLineOffsets(out, W, H, "col", colOff, vStr);
    }
    if (hStr > 0) {
      const rowOff = estimateLineOffsetsSpectral(
        out,
        W,
        H,
        "row",
        cfg.spectralCutoffFreq,
        4,
        "both"
      );
      applyLineOffsets(out, W, H, "row", rowOff, hStr);
    }
    const s = noiseSigma(out, W, H);
    out = bilateral5(out, W, H, Math.max(4, 2.2 * s), 0.55);
    return { postLine14: out, usedPastOffsets, usedFutureOffsets, notes };
  }

  // ============================================================================
  // PHASE 2 EXPERIMENTAL CANDIDATES (Exp-1, Exp-2, Exp-3, Exp-4)
  // Along-stripe gradient-gated segment-consistent Haar/Median hybrid +
  // Short-span thin-feature protection (protects 1px suspension cables that terminate at bridge deck!)
  // ============================================================================
  const out = robustBadPixels(raw14, W, H, sigma);

  // Estimate column and row offsets using along-stripe gradient gating (never blinded by strong ±150 ADU stripes!)
  const colOff =
    vStr > 0
      ? estimateLineOffsetsLocal(out, W, H, "col", 4, 3, 0.75, 320, 4)
      : new Float32Array(W);
  const rowOff =
    hStr > 0
      ? estimateLineOffsetsLocal(out, W, H, "row", 4, 3, 0.75, 320, 4)
      : new Float32Array(H);

  // Additional Haar Wavelet Garrote smoothing on the estimated offset profile for Exp-1 (Argos 2 heritage)
  if (methodId === "exp1_argos2_radiometric") {
    const shrinkT = Math.max(12, cfg.waveletShrinkThresholdAdu);
    const colLP = smooth1DProfile(colOff, 9);
    for (let x = 0; x < W; x++) {
      const d = colOff[x] - colLP[x];
      // Soft Garrote preserves stripe estimates up to 2.5x shrinkT (including ±150 ADU stripes) while rejecting broad bridge piers
      colOff[x] =
        Math.abs(d) < shrinkT * 3.5
          ? d
          : d * ((shrinkT * shrinkT * 12.25) / (d * d));
    }
  }

  const thrAlongCol = alongGate(out, W, H, "col", 0.78) + 8;
  for (let y = 1; y < H - 1; y++) {
    const rowBase = y * W;
    for (let x = 1; x < W - 1; x++) {
      const idx = rowBase + x;
      const v = out[idx];
      // Protect 1px structural features where local contrast reverses or terminates across vertical segments
      const localHorizPeak = v - 0.5 * (out[idx - 1] + out[idx + 1]);
      const alongGrad = Math.abs(out[idx + W] - out[idx - W]);
      // If along-column gradient is high (e.g. cable attachment or animal contour), attenuate stripe subtraction locally
      const wireProtect =
        alongGrad > thrAlongCol * 1.6 && Math.abs(localHorizPeak) > 35
          ? 0.25
          : 1.0;

      out[idx] =
        v - colOff[x] * vStr * wireProtect - rowOff[y] * hStr * wireProtect;
    }
  }

  // Exp-4: Strictly Causal Motion-Gated Temporal Stabilization in 14-bit space
  if (methodId === "exp4_causal_temporal_stabilized" && pastFrames14.length > 0) {
    const motionGate = Math.max(18, cfg.temporalMotionGateAdu);
    const alpha = Math.min(0.75, cfg.temporalAlpha);
    // Use up to 3 past frames causally with exponential decay
    const maxPast = Math.min(3, pastFrames14.length);
    for (let p = 0; p < maxPast; p++) usedPastOffsets.push(-(p + 1));

    for (let i = 0; i < N; i++) {
      let acc = out[i];
      let wTotal = 1.0;
      const curr = out[i];
      for (let p = 0; p < maxPast; p++) {
        const pfVal = pastFrames14[p][i];
        const diff = Math.abs(curr - pfVal);
        if (diff < motionGate) {
          const w =
            alpha *
            Math.pow(0.55, p) *
            Math.exp(-(diff * diff) / (2 * motionGate * motionGate * 0.36));
          acc += pfVal * w;
          wTotal += w;
        }
      }
      out[i] = acc / wTotal;
    }
    notes.push(
      `Exp-4 Causal Temporal: Stabilized with ${maxPast} past frame(s); motion gate = ${motionGate} ADU (zero future frames).`
    );
  }

  return { postLine14: out, usedPastOffsets, usedFutureOffsets, notes };
}

/**
 * Honest Stage 1.5 Residual CNN forward pass with uncertainty-gated classical fallback.
 */
export function runHonestCnnResidualStage(params: {
  methodId: MethodId;
  input14: Float32Array;
  W: number;
  H: number;
  enableCnn: boolean;
}): {
  postCnn14: Float32Array;
  cnnNotes: string[];
} {
  const { methodId, input14, W, H, enableCnn } = params;
  const cnnNotes: string[] = [];
  if (!enableCnn) {
    return { postCnn14: Float32Array.from(input14), cnnNotes };
  }

  if (
    methodId === "raw_monotonic" ||
    methodId === "orig_clearhot" ||
    methodId === "exp2_global_monotonic_locked"
  ) {
    cnnNotes.push(
      "CNN bypassed: Global Monotonic / Baseline mode prohibits learned spatial residual alterations."
    );
    return { postCnn14: Float32Array.from(input14), cnnNotes };
  }

  const N = W * H;
  const out = Float32Array.from(input14);
  const kH = [-0.02, -0.04, -0.08, 0.28, -0.08, -0.04, -0.02];
  const kV = [0.05, 0.1, 0.2, 0.3, 0.2, 0.1, 0.05];
  const gateScale = 45.0;

  // Directional separable residual pass with uncertainty fallback gate:
  // If local structure variance is high (possible real thin cable or animal boundary), gate residual toward 0 (classical fallback).
  const horizHP = new Float32Array(N);
  for (let y = 3; y < H - 3; y++) {
    const rowOff = y * W;
    for (let x = 3; x < W - 3; x++) {
      const idx = rowOff + x;
      const c = input14[idx];
      let hConv = 0;
      for (let k = -3; k <= 3; k++) {
        const diff = Math.max(
          -gateScale,
          Math.min(gateScale, c - input14[rowOff + x + k])
        );
        hConv += diff * (k === 0 ? 0 : -kH[k + 3]);
      }
      horizHP[idx] = hConv;
    }
  }

  for (let y = 3; y < H - 3; y++) {
    const rowOff = y * W;
    for (let x = 3; x < W - 3; x++) {
      const idx = rowOff + x;
      let colRes = 0;
      for (let k = -3; k <= 3; k++) {
        colRes += horizHP[(y + k) * W + x] * kV[k + 3];
      }
      const alongDiff = Math.abs(input14[idx + W] - input14[idx - W]);
      const uncertaintyFallbackGate = Math.exp(
        -(alongDiff * alongDiff) / (2 * 55 * 55)
      );
      out[idx] = input14[idx] - 0.18 * colRes * uncertaintyFallbackGate;
    }
  }

  cnnNotes.push(
    "CNN Active (Synthetic-Only Provenance Warning): Applied uncertainty-gated directional residual. Not trained or validated on real challenge-owner sensor data."
  );
  return { postCnn14: out, cnnNotes };
}

/**
 * Computes the Strictly Monotonic Global Reference Display (0..255) for any 14-bit buffer
 * using either the user's manual ADU window or locked percentile window + controlled highlight knee.
 */
export function computeMonotonicGlobalDisplay8(
  input14: Float32Array,
  pLowAdu: number,
  pHighAdu: number,
  kneeStrength = 0.35
): Uint8ClampedArray {
  const N = input14.length;
  const out8 = new Uint8ClampedArray(N);
  const span = Math.max(40, pHighAdu - pLowAdu);
  const mainCeiling = kneeStrength > 0.01 ? 228 : 255;
  const shoulderRange = 255 - mainCeiling;

  for (let i = 0; i < N; i++) {
    const v = input14[i];
    if (v <= pLowAdu) {
      out8[i] = 0;
    } else if (v <= pHighAdu) {
      out8[i] = Math.round(((v - pLowAdu) / span) * mainCeiling);
    } else {
      // Strictly monotonic logarithmic highlight knee above pHighAdu so Animal (+150 ADU above Bridge) remains distinctly brighter!
      const excessAdu = v - pHighAdu;
      const kneeScale = Math.max(180, span * 0.65);
      const compressed =
        Math.log1p(excessAdu / kneeScale) / Math.log1p(3500 / kneeScale);
      out8[i] = Math.min(
        255,
        Math.round(mainCeiling + Math.min(1, compressed) * shoulderRange)
      );
    }
  }
  return out8;
}

/**
 * Executes any of the 12 thermal pipelines on a common 14-bit frame.
 */
export function executeThermalPipeline(params: {
  methodId: MethodId;
  raw14Input: Uint16Array | Float32Array;
  W: number;
  H: number;
  frameIndex: number;
  cfg: UnifiedPipelineConfig;
  pastFrames14?: Float32Array[];
  futureFrames14?: Float32Array[];
  wasReset?: boolean;
  consecutiveFramesProcessed?: number;
  syntheticGroundTruth?: {
    clean14: Float32Array;
    cleanNoThin14: Float32Array;
    thinMask: Uint8Array;
    animalRoi: RoiBox;
    bridgeRoi: RoiBox;
  };
}): PipelineExecutionOutput {
  const {
    methodId,
    raw14Input,
    W,
    H,
    frameIndex,
    cfg,
    pastFrames14 = [],
    futureFrames14 = [],
    wasReset = false,
    consecutiveFramesProcessed = 1,
    syntheticGroundTruth,
  } = params;

  const tStart = performance.now();
  const N = W * H;
  const raw14 = new Float32Array(N);
  let rawMinAdu = 16383;
  let rawMaxAdu = 0;

  for (let i = 0; i < N; i++) {
    const v = raw14Input[i];
    raw14[i] = v;
    if (v < rawMinAdu) rawMinAdu = v;
    if (v > rawMaxAdu) rawMaxAdu = v;
  }

  const initialSigma = noiseSigma(raw14, W, H);

  // Stage 1: Line Correction & Bad-Pixel Protection
  const t1 = performance.now();
  const { postLine14, usedPastOffsets, usedFutureOffsets, notes } =
    runStage1LineSuppression({
      methodId,
      raw14,
      W,
      H,
      cfg,
      sigma: initialSigma,
      pastFrames14,
      futureFrames14,
    });
  const lineTimeMs = performance.now() - t1;

  // Stage 1.5: Optional Residual CNN
  const tCnn = performance.now();
  const { postCnn14, cnnNotes } = runHonestCnnResidualStage({
    methodId,
    input14: postLine14,
    W,
    H,
    enableCnn: cfg.enableCnnResidual,
  });
  const cnnTimeMs = performance.now() - tCnn;
  const auditNotes = [...notes, ...cnnNotes];

  // Determine ADU window [pLowAdu, pHighAdu]
  const tTone = performance.now();
  let pLowAdu = rawMinAdu;
  let pHighAdu = rawMaxAdu;

  if (cfg.fixedWindowMode === "locked_manual_adu") {
    pLowAdu = cfg.manualWindowLowAdu;
    pHighAdu = Math.max(pLowAdu + 50, cfg.manualWindowHighAdu);
  } else if (cfg.enableStage2And3ToneMap) {
    // Original Argos 1/2/3 & Orig ClearHot use p97.5 upper percentile when Dual-Plateau Compression is on;
    // Phase 2 Exp-1/Exp-2/Exp-3/Exp-4 use p99.2 so warm bridge + animal signals aren't crushed into the same clip shoulder!
    const isOriginal975Method =
      methodId === "orig_clearhot" ||
      methodId === "argos_1" ||
      methodId === "argos_2" ||
      methodId === "argos_3";
    const hiQuantile = isOriginal975Method
      ? 0.975
      : Math.max(0.95, Math.min(0.999, cfg.percentileHigh));
    const loQuantile = Math.max(0.001, Math.min(0.2, cfg.percentileLow));
    pLowAdu = percentileSample(postCnn14, loQuantile, 9);
    pHighAdu = Math.max(
      pLowAdu + 80,
      percentileSample(postCnn14, hiQuantile, 9)
    );
  }

  const span = Math.max(80, pHighAdu - pLowAdu);

  // Compute strict monotonic global reference display on raw14 for comparison
  const monotonicReference8 = computeMonotonicGlobalDisplay8(
    raw14,
    pLowAdu,
    pHighAdu,
    cfg.highlightKneeStrength
  );

  // Tone Mapping to Float 0..255
  const toneMappedFloat8 = new Float32Array(N);

  if (
    methodId === "raw_monotonic" ||
    methodId === "exp2_global_monotonic_locked" ||
    !cfg.enableStage2And3ToneMap
  ) {
    const mono8 = computeMonotonicGlobalDisplay8(
      postCnn14,
      pLowAdu,
      pHighAdu,
      cfg.highlightKneeStrength
    );
    for (let i = 0; i < N; i++) toneMappedFloat8[i] = mono8[i];
  } else if (methodId === "argos_2" && cfg.enableStage4DetailEnhancement) {
    // Untouched Original Argos 2 combined Guided Base/Detail + S-Curve + 7000 ADU highlight shoulder
    const r = Math.max(1, Math.min(5, Math.round(cfg.guidedRadius)));
    const eps = Math.max(100, cfg.guidedEpsilonAduSq);
    const sContrast = 0.42;
    for (let y = 0; y < H; y++) {
      const y0 = Math.max(0, y - r);
      const y1 = Math.min(H - 1, y + r);
      for (let x = 0; x < W; x++) {
        const x0 = Math.max(0, x - r);
        const x1 = Math.min(W - 1, x + r);
        let sum = 0;
        let sumSq = 0;
        let cnt = 0;
        for (let wy = y0; wy <= y1; wy += 2) {
          const rOff = wy * W;
          for (let wx = x0; wx <= x1; wx += 2) {
            const val = postCnn14[rOff + wx];
            sum += val;
            sumSq += val * val;
            cnt++;
          }
        }
        const mean = sum / cnt;
        const variance = Math.max(0, sumSq / cnt - mean * mean);
        const a_k = variance / (variance + eps);
        const v = postCnn14[y * W + x];
        const base14 = (1 - a_k * 0.35) * mean + a_k * 0.35 * v;
        const detail14 = v - base14;

        let t = Math.max(0, Math.min(1, (base14 - pLowAdu) / span));
        const sCurve = t + sContrast * 1.4 * t * (1 - t) * (2 * t - 1);
        t = Math.max(0, Math.min(1, sCurve));
        let mapped = t * 232;
        if (v > pHighAdu) {
          const excess = Math.min(1, (v - pHighAdu) / 7000);
          mapped = 232 + excess * 23;
        }
        const detail8 =
          (detail14 / span) * 232 * (0.85 + cfg.detailGain * 0.55);
        toneMappedFloat8[y * W + x] = Math.max(
          0,
          Math.min(255, mapped + detail8)
        );
      }
    }
  } else if (
    methodId === "exp1_argos2_radiometric" ||
    methodId === "exp4_causal_temporal_stabilized"
  ) {
    // Phase 2 Exp-1 & Exp-4: True O(1) Box-Guided Base/Detail in 14-Bit + Extended Highlight Knee
    const base14 = guidedSelf(
      postCnn14,
      W,
      H,
      Math.max(2, Math.round(cfg.guidedRadius)),
      Math.max(150, cfg.guidedEpsilonAduSq)
    );
    const monoBase8 = computeMonotonicGlobalDisplay8(
      base14,
      pLowAdu,
      pHighAdu,
      cfg.highlightKneeStrength
    );
    const tauAdu = Math.max(0, cfg.noiseCoringSigmaMult * initialSigma);
    const detailGain = cfg.enableStage4DetailEnhancement ? cfg.detailGain : 1.0;

    for (let i = 0; i < N; i++) {
      const d14 = postCnn14[i] - base14[i];
      // Smooth deadzone coring in 14-bit ADU space suppresses flat-area static grain without erasing 1px wires
      const cored14 =
        tauAdu <= 0 ? d14 : d14 * ((d14 * d14) / (d14 * d14 + tauAdu * tauAdu));
      // Bounded detail contribution in 8-bit space to prevent boundary halos
      const rawDetail8 = (cored14 / span) * 228 * detailGain;
      const boundedDetail8 =
        Math.abs(rawDetail8) <= 22
          ? rawDetail8
          : Math.sign(rawDetail8) * (22 + (Math.abs(rawDetail8) - 22) * 0.25);
      toneMappedFloat8[i] = Math.max(
        0,
        Math.min(255, monoBase8[i] + boundedDetail8)
      );
    }
  } else {
    // Standard soft-shoulder linear normalization used by Orig ClearHot, Argos 1, Argos 3, Claude A/B/C, Exp-3
    for (let i = 0; i < N; i++) {
      const v = postCnn14[i];
      if (v <= pHighAdu) {
        toneMappedFloat8[i] = Math.max(
          0,
          Math.min(232, ((v - pLowAdu) / span) * 232)
        );
      } else {
        const excess = Math.min(1, (v - pHighAdu) / 7000);
        toneMappedFloat8[i] = 232 + excess * 23;
      }
    }

    if (methodId === "argos_1" || methodId === "claude_b") {
      // Dual-Plateau Histogram Equalization blend
      const hist = new Uint32Array(256);
      for (let i = 0; i < N; i++) {
        hist[Math.max(0, Math.min(255, Math.round(toneMappedFloat8[i])))]++;
      }
      const upperP = Math.max(12, Math.floor((N / 256) * 2.5));
      const lowerP = Math.max(2, Math.floor((N / 256) * 0.15));
      const cdf = new Float32Array(256);
      let cum = 0;
      for (let b = 0; b < 256; b++) {
        let c = hist[b];
        if (c > upperP) c = upperP;
        else if (c > 0 && c < lowerP) c = lowerP;
        cum += c;
        cdf[b] = cum;
      }
      const cdfMax = Math.max(1, cdf[255]);
      const blend = methodId === "claude_b" ? 0.55 : 0.45;
      for (let i = 0; i < N; i++) {
        const orig = toneMappedFloat8[i];
        const eq =
          (cdf[Math.max(0, Math.min(255, Math.round(orig)))] / cdfMax) * 246;
        toneMappedFloat8[i] = (1 - blend) * orig + blend * eq;
      }
    } else if (methodId === "argos_3") {
      // Integral-image local ACE
      const mean8 = boxBlur(toneMappedFloat8, W, H, 6);
      const sq8 = new Float32Array(N);
      for (let i = 0; i < N; i++)
        sq8[i] = toneMappedFloat8[i] * toneMappedFloat8[i];
      const meanSq8 = boxBlur(sq8, W, H, 6);
      for (let i = 0; i < N; i++) {
        const m = mean8[i];
        const std = Math.sqrt(Math.max(0, meanSq8[i] - m * m));
        const dev = toneMappedFloat8[i] - m;
        const factor = 1.0 + 0.48 * Math.min(2.2, 14.0 / Math.max(5.5, std));
        const clamped = Math.max(-28, Math.min(28, dev * factor));
        toneMappedFloat8[i] = Math.max(0, Math.min(255, m + clamped));
      }
    } else if (
      methodId === "claude_a" ||
      methodId === "exp3_blended_clahe_monotonic"
    ) {
      // Contrast-Limited Adaptive Histogram Equalization blended with global monotonic anchor
      const anchor8 =
        methodId === "exp3_blended_clahe_monotonic"
          ? Float32Array.from(
              computeMonotonicGlobalDisplay8(
                postCnn14,
                pLowAdu,
                pHighAdu,
                cfg.highlightKneeStrength
              )
            )
          : toneMappedFloat8;
      const tiles = Math.max(4, Math.min(12, Math.round(cfg.claheTileCount)));
      const clip = Math.max(1.1, cfg.claheClipLimit);
      const claheBuf = clahe(
        anchor8,
        W,
        H,
        tiles,
        tiles,
        methodId === "claude_a" ? 3.0 : clip
      );
      const alpha =
        methodId === "claude_a"
          ? 0.5
          : Math.max(0, Math.min(0.85, cfg.localContrastBlend));
      for (let i = 0; i < N; i++) {
        toneMappedFloat8[i] =
          anchor8[i] * (1 - alpha) + claheBuf[i] * alpha;
      }
    }
  }
  const toneTimeMs = performance.now() - tTone;

  // Stage 4: Spatial Detail Enhancement (for pipelines that haven't already fused Guided Detail in 14-bit)
  const tDetail = performance.now();
  const display8 = new Uint8ClampedArray(N);
  const alreadyFusedDetail =
    methodId === "raw_monotonic" ||
    methodId === "exp2_global_monotonic_locked" ||
    methodId === "argos_2" ||
    methodId === "exp1_argos2_radiometric" ||
    methodId === "exp4_causal_temporal_stabilized";

  if (!cfg.enableStage4DetailEnhancement || alreadyFusedDetail) {
    for (let i = 0; i < N; i++) {
      display8[i] = Math.max(0, Math.min(255, Math.round(toneMappedFloat8[i])));
    }
  } else if (
    methodId === "claude_b" ||
    methodId === "exp3_blended_clahe_monotonic"
  ) {
    const base = guidedSelf(toneMappedFloat8, W, H, 4, 100);
    const g = 1 + (cfg.detailGain - 1) * 1.6;
    const tau = (cfg.noiseCoringSigmaMult * initialSigma * 232) / span;
    for (let i = 0; i < N; i++) {
      const d = toneMappedFloat8[i] - base[i];
      const cored = tau <= 0 ? d : d * ((d * d) / (d * d + tau * tau));
      const lim =
        Math.abs(cored) <= 26
          ? cored
          : Math.sign(cored) * (26 + (Math.abs(cored) - 26) * 0.2);
      display8[i] = Math.max(0, Math.min(255, Math.round(base[i] + g * lim)));
    }
  } else if (methodId === "claude_c") {
    const b1 = boxBlur(toneMappedFloat8, W, H, 1);
    const b2 = boxBlur(toneMappedFloat8, W, H, 3);
    const b3 = boxBlur(boxBlur(toneMappedFloat8, W, H, 8), W, H, 8);
    const g = 1 + (cfg.detailGain - 1) * 1.6;
    const tau = (cfg.noiseCoringSigmaMult * initialSigma * 232) / span;
    for (let i = 0; i < N; i++) {
      const d1Raw = toneMappedFloat8[i] - b1[i];
      const d1 =
        tau <= 0
          ? d1Raw
          : d1Raw * ((d1Raw * d1Raw) / (d1Raw * d1Raw + tau * tau));
      const d2 = b1[i] - b2[i];
      const d3 = b2[i] - b3[i];
      const base = 128 + (b3[i] - 128) * 0.85;
      const val = base + g * (d1 * 0.9 + d2 * 0.65 + d3 * 0.4);
      display8[i] = Math.max(0, Math.min(255, Math.round(val)));
    }
  } else {
    // Original 4-neighbor unsharp detail with optional coring (Orig ClearHot, Argos 1, Argos 3, Claude A)
    const coring = methodId === "argos_1" ? 3.2 : 0;
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const idx = y * W + x;
        let center = toneMappedFloat8[idx];
        if (y > 0 && y < H - 1 && x > 0 && x < W - 1) {
          const lm =
            (toneMappedFloat8[idx - 1] +
              toneMappedFloat8[idx + 1] +
              toneMappedFloat8[idx - W] +
              toneMappedFloat8[idx + W]) *
            0.25;
          let diff = center - lm;
          if (coring > 0) {
            diff =
              Math.abs(diff) <= coring
                ? 0
                : Math.sign(diff) * (Math.abs(diff) - coring);
          }
          const clamped = Math.max(-18, Math.min(18, diff));
          center = center + clamped * (cfg.detailGain - 1.0) * 1.8;
        }
        display8[idx] = Math.max(0, Math.min(255, Math.round(center)));
      }
    }
  }
  const detailTimeMs = performance.now() - tDetail;

  // Compute difference map vs Raw Monotonic Reference (amplified 4x around 128 neutral gray or absolute magnitude)
  const diffFromRawMonotonic8 = new Uint8ClampedArray(N);
  for (let i = 0; i < N; i++) {
    diffFromRawMonotonic8[i] = Math.min(
      255,
      Math.abs(display8[i] - monotonicReference8[i]) * 4
    );
  }

  // Verify global monotonicity of display8 with respect to postCnn14
  const monoCheck = verifyGlobalMonotonicity(postCnn14, display8, 43);

  // Empirical reference-free metrics
  const noRef = computeEmpiricalNoRefMetrics(
    postCnn14,
    raw14,
    display8,
    monotonicReference8,
    W,
    H
  );

  let groundTruthMetrics: PipelineExecutionOutput["groundTruthMetrics"];
  if (syntheticGroundTruth) {
    const cleanAnimal = computePlaneRoiStats(
      syntheticGroundTruth.clean14,
      W,
      H,
      syntheticGroundTruth.animalRoi,
      0,
      16383
    );
    const cleanBridge = computePlaneRoiStats(
      syntheticGroundTruth.clean14,
      W,
      H,
      syntheticGroundTruth.bridgeRoi,
      0,
      16383
    );
    const dispAnimal = computePlaneRoiStats(
      display8,
      W,
      H,
      syntheticGroundTruth.animalRoi,
      0,
      255
    );
    const dispBridge = computePlaneRoiStats(
      display8,
      W,
      H,
      syntheticGroundTruth.bridgeRoi,
      0,
      255
    );
    const refAnimal = computePlaneRoiStats(
      monotonicReference8,
      W,
      H,
      syntheticGroundTruth.animalRoi,
      0,
      255
    );
    const refBridge = computePlaneRoiStats(
      monotonicReference8,
      W,
      H,
      syntheticGroundTruth.bridgeRoi,
      0,
      255
    );
    const refDelta8 = Math.max(
      1,
      Math.abs(refAnimal.median - refBridge.median)
    );
    const sameSign =
      Math.sign(dispAnimal.median - dispBridge.median) ===
      Math.sign(cleanAnimal.median - cleanBridge.median);
    const retentionRatio = sameSign
      ? Math.abs(dispAnimal.median - dispBridge.median) / refDelta8
      : 0;

    groundTruthMetrics = computeSyntheticGroundTruthMetrics({
      restored14: postCnn14,
      clean14: syntheticGroundTruth.clean14,
      cleanNoThin14: syntheticGroundTruth.cleanNoThin14,
      thinMask: syntheticGroundTruth.thinMask,
      W,
      H,
      animalBridgeRetentionRatio: retentionRatio,
    });
  }

  const totalTimeMs = performance.now() - tStart;

  return {
    methodId,
    width: W,
    height: H,
    frameIndex,
    raw14,
    postLine14,
    postCnn14,
    toneMappedFloat8,
    display8,
    monotonicReference8,
    diffFromRawMonotonic8,
    pLowAdu,
    pHighAdu,
    rawMinAdu,
    rawMaxAdu,
    noiseSigmaAdu: noRef.noiseSigmaAdu,
    lowClipPct8: noRef.lowClipPct8,
    highClipPct8: noRef.highClipPct8,
    colStripeProxyAdu: noRef.colStripeProxyAdu,
    rowStripeProxyAdu: noRef.rowStripeProxyAdu,
    edgeRetentionProxy: noRef.edgeRetentionProxy,
    haloOvershootProxy: noRef.haloOvershootProxy,
    isStrictlyMonotonicFrame: monoCheck.isMonotonic,
    monotonicViolationsCount: monoCheck.violations,
    executionTimeMs: totalTimeMs,
    stageTimingsMs: {
      lineCorrection: lineTimeMs,
      cnnInference: cnnTimeMs,
      temporalOrSpatialDenoise: 0,
      toneMapping: toneTimeMs,
      detailEnhancement: detailTimeMs,
    },
    temporalContextInfo: {
      usedPastFrames: usedPastOffsets,
      usedFutureFrames: usedFutureOffsets,
      wasResetOnThisFrame: wasReset,
      warmupComplete: consecutiveFramesProcessed >= cfg.declaredWarmupFrames,
    },
    groundTruthMetrics,
    auditNotes,
  };
}

/**
 * Phase 1 Requirement 4: Stage-by-Stage Ablation Runner on the exact same 14-bit frame.
 * Runs:
 * 1) Raw Fixed-Window Monotonic Reference
 * 2) Line Correction Only (Fixed Window)
 * 3) Tone Map Only (No Line Correction, No Detail Boost)
 * 4) Detail Enhancement Only (No Line Correction, Fixed Window)
 * 5) Combined Classical Stages (CNN Off)
 * 6) Combined Stages + CNN On
 */
export function runStageByStageAblation(params: {
  methodId: MethodId;
  raw14Input: Uint16Array | Float32Array;
  W: number;
  H: number;
  frameIndex: number;
  baseCfg: UnifiedPipelineConfig;
  animalRoi: RoiBox;
  bridgeRoi: RoiBox;
  backgroundRoi: RoiBox;
}): AblationStageEntry[] {
  const {
    methodId,
    raw14Input,
    W,
    H,
    frameIndex,
    baseCfg,
    animalRoi,
    bridgeRoi,
    backgroundRoi,
  } = params;

  const configs: Array<{
    key: AblationStageEntry["stageKey"];
    label: string;
    description: string;
    overrideMethod?: MethodId;
    cfg: UnifiedPipelineConfig;
  }> = [
    {
      key: "stage0_raw_fixed",
      label: "1. Raw Fixed-Window (Monotonic Ref)",
      description:
        "Unmodified 14-bit sensor data mapped via fixed global monotonic window. Zero destripe, zero local contrast.",
      overrideMethod: "raw_monotonic",
      cfg: {
        ...baseCfg,
        enableStage1LineCorrection: false,
        enableStage2And3ToneMap: false,
        enableStage4DetailEnhancement: false,
        enableCnnResidual: false,
      },
    },
    {
      key: "stage1_line_only",
      label: "2. Line Correction Only",
      description:
        "Stage 1 destriping & bad-pixel gate active; mapped via global monotonic window (tone map & detail off).",
      cfg: {
        ...baseCfg,
        enableStage1LineCorrection: true,
        enableStage2And3ToneMap: false,
        enableStage4DetailEnhancement: false,
        enableCnnResidual: false,
      },
    },
    {
      key: "stage2_tonemap_only",
      label: "3. Tone Mapping Only",
      description:
        "Stage 2/3 dynamic range & tone mapping active; Stage 1 destriping & Stage 4 detail boost bypassed.",
      cfg: {
        ...baseCfg,
        enableStage1LineCorrection: false,
        enableStage2And3ToneMap: true,
        enableStage4DetailEnhancement: false,
        enableCnnResidual: false,
      },
    },
    {
      key: "stage4_detail_only",
      label: "4. Detail Enhancement Only",
      description:
        "Stage 4 edge/detail boost active on monotonic window; Stage 1 destriping & Stage 2/3 plateau/local curve bypassed.",
      cfg: {
        ...baseCfg,
        enableStage1LineCorrection: false,
        enableStage2And3ToneMap: false,
        enableStage4DetailEnhancement: true,
        enableCnnResidual: false,
      },
    },
    {
      key: "stage_combined_classical",
      label: "5. Combined Classical (CNN Off)",
      description:
        "All conventional stages active (Line Correction + Tone Mapping + Detail Enhancement), CNN strictly disabled.",
      cfg: {
        ...baseCfg,
        enableStage1LineCorrection: true,
        enableStage2And3ToneMap: true,
        enableStage4DetailEnhancement: true,
        enableCnnResidual: false,
      },
    },
    {
      key: "stage_combined_cnn",
      label: "6. Combined + CNN On",
      description:
        "Full pipeline with Stage 1.5 Residual CNN enabled prior to tone mapping.",
      cfg: {
        ...baseCfg,
        enableStage1LineCorrection: true,
        enableStage2And3ToneMap: true,
        enableStage4DetailEnhancement: true,
        enableCnnResidual: true,
      },
    },
  ];

  const entries: AblationStageEntry[] = [];
  let prevDisplay8: Uint8ClampedArray | null = null;

  for (const item of configs) {
    const out = executeThermalPipeline({
      methodId: item.overrideMethod ?? methodId,
      raw14Input,
      W,
      H,
      frameIndex,
      cfg: item.cfg,
    });

    const roiRep = computeMultiPlaneRoiReport({
      raw14: out.raw14,
      postLine14: out.postLine14,
      display8: out.display8,
      W,
      H,
      animalRoi,
      bridgeRoi,
      backgroundRoi,
      isGloballyMonotonicFrame: out.isStrictlyMonotonicFrame,
    });

    const diffFromPrev8 = new Uint8ClampedArray(W * H);
    if (prevDisplay8) {
      for (let i = 0; i < diffFromPrev8.length; i++) {
        diffFromPrev8[i] = Math.min(
          255,
          Math.abs(out.display8[i] - prevDisplay8[i]) * 4
        );
      }
    }
    prevDisplay8 = out.display8;

    entries.push({
      stageKey: item.key,
      label: item.label,
      description: item.description,
      display8: out.display8,
      diffFromPrev8,
      lowClipPct: out.lowClipPct8,
      highClipPct: out.highClipPct8,
      colStripeProxyAdu: out.colStripeProxyAdu,
      rowStripeProxyAdu: out.rowStripeProxyAdu,
      animalMedian8: roiRep.display8.animal.median,
      bridgeMedian8: roiRep.display8.bridge.median,
      bgMedian8: roiRep.display8.background.median,
      animalBridgeDelta8: roiRep.display8.animalVsBridgeDelta8,
      animalBridgeSeparationSigma8:
        roiRep.display8.animalBridgeSeparationSigma8,
      orderingPreserved: roiRep.orderingPreserved,
    });
  }

  return entries;
}
