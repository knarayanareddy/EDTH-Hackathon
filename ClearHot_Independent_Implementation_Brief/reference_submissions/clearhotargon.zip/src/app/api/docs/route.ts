import { NextResponse } from "next/server";
import fs from "fs/promises";
import path from "path";

const DOC_FILES = [
  {
    id: "brief",
    title: "ClearHot_Independent_Evaluation_and_Agent_Brief.md",
    badge: "Primary Brief (Phases 1–4)",
    filename: "ClearHot_Independent_Evaluation_and_Agent_Brief.md",
  },
  {
    id: "report",
    title: "INDEPENDENT_AUDIT_AND_EVALUATION_REPORT.md",
    badge: "New Agent Deliverable Report",
    filename: "INDEPENDENT_AUDIT_AND_EVALUATION_REPORT.md",
  },
  {
    id: "review",
    title: "ClearHot_Six_Method_Independent_Review.md",
    badge: "Prior 6-Method Independent Review",
    filename: "ClearHot_Six_Method_Independent_Review.md",
  },
  {
    id: "readme",
    title: "README.md",
    badge: "Package Overview & Build Rules",
    filename: "README.md",
  },
  {
    id: "sha256",
    title: "SHA256SUMS.txt",
    badge: "Provenance Checksums",
    filename: "SHA256SUMS.txt",
  },
];

export async function GET() {
  try {
    const docs = await Promise.all(
      DOC_FILES.map(async (doc) => {
        const fullPath = path.join(/*turbopackIgnore: true*/ process.cwd(), doc.filename);
        let content = "";
        try {
          content = await fs.readFile(fullPath, "utf8");
        } catch {
          content = `File ${doc.filename} not found at ${fullPath}`;
        }
        return {
          ...doc,
          content,
        };
      })
    );

    return NextResponse.json({
      status: "ok",
      docs,
    });
  } catch (error) {
    return NextResponse.json(
      {
        status: "error",
        message: error instanceof Error ? error.message : "Failed to read docs",
      },
      { status: 500 }
    );
  }
}
