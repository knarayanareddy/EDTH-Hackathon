import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "ClearHot — Independent Thermal Evaluation & Enhancement Workbench",
  description:
    "Phase 1–4 Independent Evidence, Multi-Plane ROI Telemetry, Stage-by-Stage Ablation, Candidate Enhancements, Contiguous Holdout Benchmark, and Honest CNN Audit.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#0B0F17] text-slate-100 antialiased">{children}</body>
    </html>
  );
}
