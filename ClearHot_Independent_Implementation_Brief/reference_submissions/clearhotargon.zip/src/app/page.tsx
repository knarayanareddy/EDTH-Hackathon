"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertCircle,
  CheckCircle2,
  Database,
  ExternalLink,
  FileUp,
  Layers,
  Lock,
  Play,
  RotateCcw,
  Scale,
  ShieldCheck,
  Sliders,
  Sparkles,
  Target,
  Unlock,
} from "lucide-react";
import ThermalCanvasRenderer, {
  ThermalPalette,
} from "@/components/thermal/ThermalCanvasRenderer";
import StageAblationMatrixView from "@/components/thermal/StageAblationMatrixView";
import BlindedAbReviewModalAndTab from "@/components/thermal/BlindedAbReviewModalAndTab";
import CnnHonestyAndAuditPanel from "@/components/thermal/CnnHonestyAndAuditPanel";
import {
  BinarySourceDiagnostics,
  DecoderHypothesisConfig,
  MethodId,
  RoiBox,
  SyntheticSceneId,
  UnifiedPipelineConfig,
} from "@/lib/thermal/types";
import {
  generateSyntheticFrameBundle,
  getDefaultRoisForResolution,
  SYNTHETIC_SCENE_CATALOG,
} from "@/lib/thermal/syntheticFixtures";
import {
  DEFAULT_UNIFIED_CONFIG,
  executeThermalPipeline,
  METHOD_CATALOG,
  runStageByStageAblation,
} from "@/lib/thermal/unifiedEngine";
import { computeMultiPlaneRoiReport } from "@/lib/thermal/roiAndMetrics";
import {
  computeConfigHash,
  MethodBenchmarkRow,
} from "@/lib/thermal/benchmarkHarness";
import {
  inspectLocalBinHypothesis,
  readSlicedBinFrame14,
} from "@/lib/thermal/streamingBinDecoder";

type WorkbenchTab =
  | "inspector"
  | "ablation"
  | "benchmark"
  | "blind_ab"
  | "cnn_and_docs";

export default function ClearHotIndependentEvaluationWorkbench() {
  const [activeTab, setActiveTab] = useState<WorkbenchTab>("inspector");

  // Source & Decoder Hypothesis State
  const [sourceMode, setSourceMode] = useState<"synthetic" | "local_bin">(
    "synthetic"
  );
  const [syntheticScene, setSyntheticScene] = useState<SyntheticSceneId>(
    "bridge_animal_ambiguity"
  );
  const [resolution, setResolution] = useState<"320x256" | "640x512">(
    "320x256"
  );
  const W = resolution === "640x512" ? 640 : 320;
  const H = resolution === "640x512" ? 512 : 256;

  const [frameIndex, setFrameIndex] = useState<number>(25); // Starts in Frozen Holdout Block [25..59]
  const [prevFrameIndex, setPrevFrameIndex] = useState<number>(25);
  const [consecutiveCount, setConsecutiveCount] = useState<number>(8);

  // Local .bin Streaming File State (never uploaded to server)
  const [localFile, setLocalFile] = useState<File | null>(null);
  const [decoderHypothesis, setDecoderHypothesis] =
    useState<DecoderHypothesisConfig>({
      width: 640,
      height: 512,
      endianness: "little",
      bitMaskMode: "low_14bit",
      headerBytesOffset: 0,
    });
  const [binDiagnostics, setBinDiagnostics] =
    useState<BinarySourceDiagnostics | null>(null);
  const [slicedLocalFrame14, setSlicedLocalFrame14] =
    useState<Uint16Array | null>(null);
  const [pastSlicedFrames14, setPastSlicedFrames14] = useState<Float32Array[]>(
    []
  );
  const [futureSlicedFrames14, setFutureSlicedFrames14] = useState<
    Float32Array[]
  >([]);

  // Selected Primary & Reference Methods
  const [primaryMethodId, setPrimaryMethodId] = useState<MethodId>(
    "exp1_argos2_radiometric"
  );
  const [referenceMethodId, setReferenceMethodId] =
    useState<MethodId>("argos_2");
  const [splitWipePct, setSplitWipePct] = useState<number>(0);
  const [palette, setPalette] = useState<ThermalPalette>("grayscale");

  // Pipeline Configuration State
  const [cfg, setCfg] = useState<UnifiedPipelineConfig>(DEFAULT_UNIFIED_CONFIG);

  // Manual Multi-ROI State (Animal, Bridge, Background)
  const [rois, setRois] = useState<{
    animal: RoiBox;
    bridge: RoiBox;
    background: RoiBox;
  }>(() => getDefaultRoisForResolution(320, 256));
  const [activeRoiDragRole, setActiveRoiDragRole] = useState<
    "animal" | "bridge" | "background" | null
  >(null);
  const [roiNoteInput, setRoiNoteInput] = useState<string>("");
  const [loggingRoi, setLoggingRoi] = useState<boolean>(false);

  // Persisted Database Records from PostgreSQL (/api/evaluation)
  const [dbState, setDbState] = useState<{
    roiLogs: Array<Record<string, unknown>>;
    abReviews: Array<{
      id: number;
      sceneLabel: string;
      frameIndex: number;
      methodLeftId: string;
      methodRightId: string;
      selectedOutcome: string;
      winningMethodId: string;
      criterion: string;
      reviewerId: string;
      notes: string;
      createdAt: string;
    }>;
    evalRuns: Array<{
      id: number;
      runTitle: string;
      configHash: string;
      decoderHypothesis: string;
      resolution: string;
      devBlockRange: string;
      exclusionBufferRange: string;
      holdoutBlockRange: string;
      isSyntheticGroundTruth: boolean;
      p50LatencyMs: number;
      p95LatencyMs: number;
      peakMemoryMb: number;
      frameDropPct: number;
      metricsTableJson: MethodBenchmarkRow[];
      verdictSummary: string;
      createdAt: string;
    }>;
    ablations: Array<{
      id: number;
      sourceLabel: string;
      frameIndex: number;
      methodId: string;
      rawSepAdu: number;
      stage1SepAdu: number;
      toneOnlySep8: number;
      detailOnlySep8: number;
      combinedClassicalSep8: number;
      combinedCnnSep8: number;
      lowClipPct: number;
      highClipPct: number;
      rootCauseDiagnosis: string;
    }>;
  }>({
    roiLogs: [],
    abReviews: [],
    evalRuns: [],
    ablations: [],
  });
  const [runningFrozenEval, setRunningFrozenEval] = useState<boolean>(false);

  const fetchDatabaseRecords = useCallback(async () => {
    try {
      const res = await fetch("/api/evaluation");
      const data = await res.json();
      if (data.status === "ok") {
        setDbState({
          roiLogs: data.roiLogs ?? [],
          abReviews: data.abReviews ?? [],
          evalRuns: data.evalRuns ?? [],
          ablations: data.ablations ?? [],
        });
      }
    } catch (e) {
      console.error("Failed to fetch evaluation DB records:", e);
    }
  }, []);

  useEffect(() => {
    fetchDatabaseRecords();
  }, [fetchDatabaseRecords]);

  // Reset default ROI coordinates when resolution changes
  useEffect(() => {
    setRois(getDefaultRoisForResolution(W, H));
  }, [W, H]);

  // Slice local .bin frame on demand when localFile, frameIndex, or decoderHypothesis changes
  useEffect(() => {
    if (sourceMode !== "local_bin" || !localFile || !binDiagnostics) return;
    let cancelled = false;
    (async () => {
      const mainSlice = await readSlicedBinFrame14({
        file: localFile,
        frameIndex,
        totalFrames: binDiagnostics.totalFrames,
        hypothesis: decoderHypothesis,
        targetW: W,
        targetH: H,
      });
      const past: Float32Array[] = [];
      for (let p = 1; p <= 3; p++) {
        if (frameIndex - p >= 0) {
          const pf = await readSlicedBinFrame14({
            file: localFile,
            frameIndex: frameIndex - p,
            totalFrames: binDiagnostics.totalFrames,
            hypothesis: decoderHypothesis,
            targetW: W,
            targetH: H,
          });
          past.push(Float32Array.from(pf));
        }
      }
      const future: Float32Array[] = [];
      if (frameIndex < 3) {
        for (
          let f = 1;
          f <= Math.min(4, binDiagnostics.totalFrames - 1 - frameIndex);
          f++
        ) {
          const ff = await readSlicedBinFrame14({
            file: localFile,
            frameIndex: frameIndex + f,
            totalFrames: binDiagnostics.totalFrames,
            hypothesis: decoderHypothesis,
            targetW: W,
            targetH: H,
          });
          future.push(Float32Array.from(ff));
        }
      }
      if (!cancelled) {
        setSlicedLocalFrame14(mainSlice);
        setPastSlicedFrames14(past);
        setFutureSlicedFrames14(future);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [
    sourceMode,
    localFile,
    binDiagnostics,
    frameIndex,
    decoderHypothesis,
    W,
    H,
  ]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLocalFile(file);
    setSourceMode("local_bin");
    setFrameIndex(0);
    setPrevFrameIndex(0);
    setConsecutiveCount(1);
    const diag = await inspectLocalBinHypothesis(file, decoderHypothesis);
    setBinDiagnostics(diag);
  };

  const handleFrameChange = (nextIdx: number) => {
    const isConsecutive = nextIdx === prevFrameIndex + 1;
    setConsecutiveCount((c) => (isConsecutive ? c + 1 : 1));
    setPrevFrameIndex(nextIdx);
    setFrameIndex(nextIdx);
  };

  // Generate or retrieve active 14-bit frame + past/future context
  const activeFrameBundle = useMemo(() => {
    if (sourceMode === "local_bin" && slicedLocalFrame14) {
      return {
        raw14Input: slicedLocalFrame14,
        pastFrames14: pastSlicedFrames14,
        futureFrames14: futureSlicedFrames14,
        isSynthetic: false,
        sourceTitle: `Local Streamed File: ${
          localFile?.name ?? "uploaded.bin"
        }`,
        groundTruth: undefined,
      };
    }

    const syn = generateSyntheticFrameBundle(
      syntheticScene,
      W,
      H,
      frameIndex,
      60
    );
    const past: Float32Array[] = [];
    for (let p = 1; p <= 3; p++) {
      if (frameIndex - p >= 0) {
        const pf = generateSyntheticFrameBundle(
          syntheticScene,
          W,
          H,
          frameIndex - p,
          60
        );
        past.push(Float32Array.from(pf.corrupted14));
      }
    }
    const future: Float32Array[] = [];
    if (frameIndex < 4) {
      for (let f = 1; f <= 4; f++) {
        const ff = generateSyntheticFrameBundle(
          syntheticScene,
          W,
          H,
          frameIndex + f,
          60
        );
        future.push(Float32Array.from(ff.corrupted14));
      }
    }

    return {
      raw14Input: syn.corrupted14,
      pastFrames14: past,
      futureFrames14: future,
      isSynthetic: true,
      sourceTitle: `Synthetic Simulation: ${syn.sceneLabel}`,
      groundTruth: {
        clean14: syn.clean14,
        cleanNoThin14: syn.cleanNoThin14,
        thinMask: syn.thinMask,
        animalRoi: rois.animal,
        bridgeRoi: rois.bridge,
      },
    };
  }, [
    sourceMode,
    slicedLocalFrame14,
    pastSlicedFrames14,
    futureSlicedFrames14,
    localFile,
    syntheticScene,
    W,
    H,
    frameIndex,
    rois.animal,
    rois.bridge,
  ]);

  const wasResetOnThisFrame = consecutiveCount === 1;

  // Execute Primary Pipeline
  const primaryOutput = useMemo(
    () =>
      executeThermalPipeline({
        methodId: primaryMethodId,
        raw14Input: activeFrameBundle.raw14Input,
        W,
        H,
        frameIndex,
        cfg,
        pastFrames14: activeFrameBundle.pastFrames14,
        futureFrames14: activeFrameBundle.futureFrames14,
        wasReset: wasResetOnThisFrame,
        consecutiveFramesProcessed: consecutiveCount,
        syntheticGroundTruth: activeFrameBundle.groundTruth,
      }),
    [
      primaryMethodId,
      activeFrameBundle,
      W,
      H,
      frameIndex,
      cfg,
      wasResetOnThisFrame,
      consecutiveCount,
    ]
  );

  // Execute Reference Pipeline (default: Argos 2 [User Visual Reference])
  const referenceOutput = useMemo(
    () =>
      executeThermalPipeline({
        methodId: referenceMethodId,
        raw14Input: activeFrameBundle.raw14Input,
        W,
        H,
        frameIndex,
        cfg,
        pastFrames14: activeFrameBundle.pastFrames14,
        futureFrames14: activeFrameBundle.futureFrames14,
        wasReset: wasResetOnThisFrame,
        consecutiveFramesProcessed: consecutiveCount,
        syntheticGroundTruth: activeFrameBundle.groundTruth,
      }),
    [
      referenceMethodId,
      activeFrameBundle,
      W,
      H,
      frameIndex,
      cfg,
      wasResetOnThisFrame,
      consecutiveCount,
    ]
  );

  // Multi-Plane ROI Reports for Primary and Reference Methods
  const primaryRoiReport = useMemo(
    () =>
      computeMultiPlaneRoiReport({
        raw14: primaryOutput.raw14,
        postLine14: primaryOutput.postLine14,
        display8: primaryOutput.display8,
        W,
        H,
        animalRoi: rois.animal,
        bridgeRoi: rois.bridge,
        backgroundRoi: rois.background,
        isGloballyMonotonicFrame: primaryOutput.isStrictlyMonotonicFrame,
      }),
    [primaryOutput, W, H, rois]
  );

  const referenceRoiReport = useMemo(
    () =>
      computeMultiPlaneRoiReport({
        raw14: referenceOutput.raw14,
        postLine14: referenceOutput.postLine14,
        display8: referenceOutput.display8,
        W,
        H,
        animalRoi: rois.animal,
        bridgeRoi: rois.bridge,
        backgroundRoi: rois.background,
        isGloballyMonotonicFrame: referenceOutput.isStrictlyMonotonicFrame,
      }),
    [referenceOutput, W, H, rois]
  );

  // Stage-by-Stage Ablation for Primary Method
  const ablationStages = useMemo(
    () =>
      runStageByStageAblation({
        methodId: primaryMethodId,
        raw14Input: activeFrameBundle.raw14Input,
        W,
        H,
        frameIndex,
        baseCfg: cfg,
        animalRoi: rois.animal,
        bridgeRoi: rois.bridge,
        backgroundRoi: rois.background,
      }),
    [primaryMethodId, activeFrameBundle.raw14Input, W, H, frameIndex, cfg, rois]
  );

  const configHash = useMemo(() => computeConfigHash(cfg), [cfg]);

  const primaryMeta =
    METHOD_CATALOG.find((m) => m.id === primaryMethodId) ?? METHOD_CATALOG[0];
  const referenceMeta =
    METHOD_CATALOG.find((m) => m.id === referenceMethodId) ?? METHOD_CATALOG[3];

  const handleUpdateRoi = (
    role: "animal" | "bridge" | "background",
    updated: RoiBox
  ) => {
    setRois((prev) => ({
      ...prev,
      [role]: updated,
    }));
  };

  const handleLogRoiToDb = async () => {
    setLoggingRoi(true);
    try {
      await fetch("/api/evaluation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "log_roi",
          sourceLabel: activeFrameBundle.sourceTitle,
          fileSha256:
            binDiagnostics?.fileSha256 ?? `synth-${syntheticScene}-v1`,
          frameIndex,
          resolution: `${W}×${H}`,
          methodId: primaryMethodId,
          animalRoiJson: rois.animal,
          bridgeRoiJson: rois.bridge,
          backgroundRoiJson: rois.background,
          animalRawMedianAdu: primaryRoiReport.raw14.animal.median,
          bridgeRawMedianAdu: primaryRoiReport.raw14.bridge.median,
          bgRawMedianAdu: primaryRoiReport.raw14.background.median,
          bgRawMadAdu: primaryRoiReport.raw14.background.mad,
          animalPostLineMedianAdu: primaryRoiReport.postLine14.animal.median,
          bridgePostLineMedianAdu: primaryRoiReport.postLine14.bridge.median,
          animalDisplayMedian8: primaryRoiReport.display8.animal.median,
          bridgeDisplayMedian8: primaryRoiReport.display8.bridge.median,
          bgDisplayMedian8: primaryRoiReport.display8.background.median,
          rawAnimalBridgeDeltaAdu:
            primaryRoiReport.raw14.animalVsBridgeDeltaAdu,
          displayAnimalBridgeDelta8:
            primaryRoiReport.display8.animalVsBridgeDelta8,
          rawCnrAnimalBg: primaryRoiReport.raw14.cnrAnimalVsBg,
          rawCnrBridgeBg: primaryRoiReport.raw14.cnrBridgeVsBg,
          rawSeparationIndex:
            primaryRoiReport.raw14.animalBridgeSeparationSigma,
          orderingPreserved: primaryRoiReport.orderingPreserved,
          diagnosticVerdict: primaryRoiReport.diagnosticExplanation,
          investigatorNotes:
            roiNoteInput ||
            `Compared ${primaryMeta.shortLabel} vs ${referenceMeta.shortLabel}`,
        }),
      });
      setRoiNoteInput("");
      await fetchDatabaseRecords();
    } finally {
      setLoggingRoi(false);
    }
  };

  const handleSaveAblationToDb = async (diagnosisText: string) => {
    await fetch("/api/evaluation", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "save_ablation",
        sourceLabel: activeFrameBundle.sourceTitle,
        frameIndex,
        methodId: primaryMethodId,
        rawSepAdu: primaryRoiReport.raw14.animalVsBridgeDeltaAdu,
        stage1SepAdu: primaryRoiReport.postLine14.animalVsBridgeDeltaAdu,
        toneOnlySep8: ablationStages[2]?.animalBridgeDelta8 ?? 0,
        detailOnlySep8: ablationStages[3]?.animalBridgeDelta8 ?? 0,
        combinedClassicalSep8: ablationStages[4]?.animalBridgeDelta8 ?? 0,
        combinedCnnSep8: ablationStages[5]?.animalBridgeDelta8 ?? 0,
        lowClipPct: primaryOutput.lowClipPct8,
        highClipPct: primaryOutput.highClipPct8,
        monotonicVerified: primaryOutput.isStrictlyMonotonicFrame,
        rootCauseDiagnosis: diagnosisText,
      }),
    });
    await fetchDatabaseRecords();
  };

  const handleRunFrozenEvaluation = async () => {
    setRunningFrozenEval(true);
    try {
      await fetch("/api/evaluation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "run_frozen_eval",
          width: W,
          height: H,
          config: cfg,
          runTitle: `Frozen Holdout Benchmark (${W}×${H}, Config #${configHash.slice(
            0,
            8
          )})`,
        }),
      });
      await fetchDatabaseRecords();
    } finally {
      setRunningFrozenEval(false);
    }
  };

  const handleSubmitBlindedAbVote = async (payload: {
    sceneLabel: string;
    frameIndex: number;
    methodLeftId: MethodId;
    methodRightId: MethodId;
    selectedOutcome: "left" | "right" | "tie";
    winningMethodId: string;
    criterion: string;
    reviewerId: string;
    notes: string;
    configHash: string;
  }) => {
    await fetch("/api/evaluation", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "submit_blind_ab",
        ...payload,
      }),
    });
    await fetchDatabaseRecords();
  };

  const timeBlockBadge =
    frameIndex <= 19
      ? {
          label: "DEV BLOCK [0..19]",
          cls: "bg-sky-500/15 text-sky-300 border-sky-500/30",
        }
      : frameIndex <= 24
      ? {
          label: "EXCLUSION GUARD [20..24] (No Eval)",
          cls: "bg-rose-500/15 text-rose-300 border-rose-500/30",
        }
      : {
          label: "FROZEN HOLDOUT BLOCK [25..59]",
          cls: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
        };

  const latestEvalRun = dbState.evalRuns[0] ?? null;

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100 flex flex-col">
      {/* Top Radiometric Governance & Provenance Bar */}
      <header className="border-b border-slate-800 bg-slate-950/90 sticky top-0 z-30 backdrop-blur">
        <div className="max-w-[1600px] mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm md:text-base font-bold tracking-tight text-slate-100">
                  ClearHot Independent Thermal Evaluation & Enhancement Workbench
                </h1>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  6 Original + 4 Phase-2 Candidates
                </span>
              </div>
              <p className="text-[11px] font-mono text-slate-400">
                Uncalibrated 14-Bit ADU Hypothesis • Display Intensity ≠ °C • Zero Remote Upload (Local File.slice Streaming)
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
            <span
              className={`px-2.5 py-1 rounded border font-semibold ${timeBlockBadge.cls}`}
            >
              {timeBlockBadge.label}
            </span>
            <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
              Config Hash: <strong className="text-sky-300">{configHash.slice(0, 8)}</strong>
            </span>
            <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
              Slice Heap:{" "}
              <strong className="text-emerald-300">
                {binDiagnostics
                  ? `${binDiagnostics.estimatedActiveHeapMb} MB`
                  : W === 640
                  ? "8.4 MB"
                  : "2.1 MB"}
              </strong>
            </span>
            <a
              href="/ClearHot_Six_Method_Workbench.html"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-amber-300 transition"
              title="Open untouched handoff HTML preview in a new tab"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Original Handoff Preview
            </a>
          </div>
        </div>

        {/* Navigation Tabs + Source/Frame Bar */}
        <div className="max-w-[1600px] mx-auto px-4 py-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 bg-slate-900/50">
          <div className="flex flex-wrap items-center gap-1.5">
            {(
              [
                {
                  id: "inspector",
                  label: "1. Multi-ROI & Dual Comparison (Phases 1–2)",
                  icon: Target,
                },
                {
                  id: "ablation",
                  label: "2. Stage-by-Stage Ablation Matrix",
                  icon: Layers,
                },
                {
                  id: "benchmark",
                  label: "3. Frozen Holdout Benchmark (12 Methods)",
                  icon: Database,
                },
                {
                  id: "blind_ab",
                  label: "4. Blinded Randomized A/B Review",
                  icon: Scale,
                },
                {
                  id: "cnn_and_docs",
                  label: "5. Honest CNN Audit & Verbatim Brief/Docs",
                  icon: ShieldCheck,
                },
              ] as const
            ).map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono transition border ${
                    active
                      ? "bg-amber-500/20 text-amber-200 border-amber-500/50 font-semibold"
                      : "bg-slate-950/70 text-slate-400 border-slate-800 hover:text-slate-200 hover:bg-slate-900"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Shared Frame & Resolution Controls */}
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
            <select
              value={
                sourceMode === "local_bin" ? "local_bin" : syntheticScene
              }
              onChange={(e) => {
                const v = e.target.value;
                if (v === "local_bin") {
                  setSourceMode("local_bin");
                } else {
                  setSourceMode("synthetic");
                  setSyntheticScene(v as SyntheticSceneId);
                }
              }}
              className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1 text-xs text-slate-200"
            >
              {SYNTHETIC_SCENE_CATALOG.map((s) => (
                <option key={s.id} value={s.id}>
                  [Synthetic] {s.shortTag}
                </option>
              ))}
              {localFile && (
                <option value="local_bin">
                  [Local Streamed .bin] {localFile.name}
                </option>
              )}
            </select>

            <label className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-sky-500/15 hover:bg-sky-500/25 text-sky-200 border border-sky-500/40 cursor-pointer transition">
              <FileUp className="w-3.5 h-3.5" />
              <span>Slice Local .bin</span>
              <input
                type="file"
                accept=".bin,.raw,application/octet-stream"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            <select
              value={resolution}
              onChange={(e) =>
                setResolution(e.target.value as "320x256" | "640x512")
              }
              className="rounded-lg bg-slate-950 border border-slate-700 px-2 py-1 text-xs text-slate-200"
            >
              <option value="320x256">320×256 (Fast)</option>
              <option value="640x512">640×512 (Full Sensor)</option>
            </select>

            <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-800 px-2.5 py-1 rounded-lg">
              <span className="text-slate-400">Frame:</span>
              <input
                type="range"
                min={0}
                max={
                  sourceMode === "local_bin" && binDiagnostics
                    ? Math.max(0, binDiagnostics.totalFrames - 1)
                    : 59
                }
                value={frameIndex}
                onChange={(e) => handleFrameChange(Number(e.target.value))}
                className="w-24 accent-amber-400"
              />
              <span className="text-amber-300 font-bold w-8 text-right">
                #{frameIndex}
              </span>
              <button
                type="button"
                onClick={() => handleFrameChange((frameIndex + 1) % 60)}
                className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200"
                title="Advance +1 consecutive frame (preserves causal temporal state)"
              >
                +1
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 py-5 space-y-6">
        {/* Local .bin Decoder Hypothesis Diagnostic Card (Shown when local file is loaded) */}
        {sourceMode === "local_bin" && binDiagnostics && (
          <div className="rounded-xl border border-sky-500/40 bg-sky-950/20 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-xs font-mono font-bold text-sky-300">
                LOCAL STREAMING DECODER HYPOTHESIS PROBE — {binDiagnostics.fileName} (
                {(binDiagnostics.fileSizeBytes / (1024 * 1024)).toFixed(2)} MiB)
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
                <select
                  value={decoderHypothesis.endianness}
                  onChange={(e) =>
                    setDecoderHypothesis((h) => ({
                      ...h,
                      endianness: e.target.value as "little" | "big",
                    }))
                  }
                  className="rounded bg-slate-950 border border-slate-700 px-2 py-1 text-slate-200"
                >
                  <option value="little">Little-Endian (Hypothesis)</option>
                  <option value="big">Big-Endian (Swap Bytes)</option>
                </select>
                <select
                  value={decoderHypothesis.bitMaskMode}
                  onChange={(e) =>
                    setDecoderHypothesis((h) => ({
                      ...h,
                      bitMaskMode: e.target.value as
                        | "low_14bit"
                        | "high_14bit"
                        | "full_16bit",
                    }))
                  }
                  className="rounded bg-slate-950 border border-slate-700 px-2 py-1 text-slate-200"
                >
                  <option value="low_14bit">Low 14-Bit (&amp; 0x3FFF)</option>
                  <option value="high_14bit">High 14-Bit (&gt;&gt; 2)</option>
                  <option value="full_16bit">Full 16-Bit Scaled</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-xs font-mono">
              <div className="bg-slate-950/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">
                  Frames @ 640×512
                </span>
                <strong>{binDiagnostics.totalFrames}</strong> (rem:{" "}
                {binDiagnostics.remainderBytes} B)
              </div>
              <div className="bg-slate-950/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">
                  Bits 14–15 Non-Zero
                </span>
                <strong>
                  {binDiagnostics.highBits14To15NonZeroPct.toFixed(2)}%
                </strong>
              </div>
              <div className="bg-slate-950/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">
                  LE vs BE P2–P98 Span
                </span>
                <strong>
                  {binDiagnostics.littleEndianSpanAdu} /{" "}
                  {binDiagnostics.bigEndianSpanAdu} ADU
                </strong>
              </div>
              <div className="bg-slate-950/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">
                  Active Slice Heap
                </span>
                <strong className="text-emerald-300">
                  {binDiagnostics.estimatedActiveHeapMb} MB (Zero Upload)
                </strong>
              </div>
              <div className="bg-slate-950/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">
                  Stream Fingerprint
                </span>
                <strong className="truncate block">
                  {binDiagnostics.fileSha256.slice(0, 18)}...
                </strong>
              </div>
            </div>
          </div>
        )}

        {/* TAB 1: DUAL COMPARISON & MANUAL MULTI-ROI INSPECTOR */}
        {activeTab === "inspector" && (
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">
            {/* Left/Center 8 Columns: Dual Side-by-Side Canvases + Multi-Plane ROI Table */}
            <div className="xl:col-span-8 space-y-5">
              {/* Method Selectors & Palette Bar */}
              <div className="rounded-xl border border-slate-800 bg-slate-900/75 p-3.5 flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-3">
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-amber-400">
                      Primary Candidate Pipeline (Left / Main)
                    </label>
                    <select
                      value={primaryMethodId}
                      onChange={(e) =>
                        setPrimaryMethodId(e.target.value as MethodId)
                      }
                      className="mt-0.5 rounded-lg bg-slate-950 border border-amber-500/40 px-2.5 py-1.5 text-xs font-mono text-amber-200 font-semibold"
                    >
                      {METHOD_CATALOG.map((m) => (
                        <option key={m.id} value={m.id}>
                          [{m.sourcePackage}] {m.shortLabel}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono uppercase text-sky-400">
                      Reference Baseline Pipeline (Right / Split-Wipe)
                    </label>
                    <select
                      value={referenceMethodId}
                      onChange={(e) =>
                        setReferenceMethodId(e.target.value as MethodId)
                      }
                      className="mt-0.5 rounded-lg bg-slate-950 border border-sky-500/40 px-2.5 py-1.5 text-xs font-mono text-sky-200 font-semibold"
                    >
                      {METHOD_CATALOG.map((m) => (
                        <option key={m.id} value={m.id}>
                          [{m.sourcePackage}] {m.shortLabel}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
                  <div>
                    <label className="block text-[10px] text-slate-400">
                      Display Palette
                    </label>
                    <select
                      value={palette}
                      onChange={(e) =>
                        setPalette(e.target.value as ThermalPalette)
                      }
                      className="mt-0.5 rounded-lg bg-slate-950 border border-slate-700 px-2 py-1.5 text-xs text-slate-200"
                    >
                      <option value="grayscale">
                        Monotonic Grayscale (Standard)
                      </option>
                      <option value="amber_hot">
                        Grayscale + Amber Highlight Alert
                      </option>
                      <option value="ironbow">
                        Ironbow (Interpretive Pseudo-Color)
                      </option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-400">
                      Split-Wipe vs Monotonic Ref ({splitWipePct}%)
                    </label>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={splitWipePct}
                      onChange={(e) => setSplitWipePct(Number(e.target.value))}
                      className="w-28 mt-1.5 accent-amber-400"
                    />
                  </div>
                </div>
              </div>

              {/* Dual Side-by-Side Thermal Viewports */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-xs font-mono font-bold text-amber-300">
                      PRIMARY: {primaryMeta.fullName}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {primaryOutput.executionTimeMs.toFixed(1)} ms
                    </span>
                  </div>
                  <ThermalCanvasRenderer
                    width={W}
                    height={H}
                    display8={primaryOutput.display8}
                    reference8={primaryOutput.monotonicReference8}
                    raw14={primaryOutput.raw14}
                    postLine14={primaryOutput.postLine14}
                    splitWipePct={splitWipePct}
                    leftLabel="Raw Monotonic"
                    rightLabel={primaryMeta.shortLabel}
                    palette={palette}
                    rois={rois}
                    activeRoiRole={activeRoiDragRole}
                    onUpdateRoi={handleUpdateRoi}
                    captionBadge={primaryMeta.shortLabel}
                    isMonotonicVerified={primaryOutput.isStrictlyMonotonicFrame}
                  />
                  <div className="grid grid-cols-4 gap-2 text-[11px] font-mono">
                    <div className="bg-slate-900/90 border border-slate-800 p-2 rounded">
                      <span className="text-slate-500 block text-[10px]">
                        Window [Lo..Hi]
                      </span>
                      <span>
                        {primaryOutput.pLowAdu.toFixed(0)}..
                        {primaryOutput.pHighAdu.toFixed(0)} ADU
                      </span>
                    </div>
                    <div className="bg-slate-900/90 border border-slate-800 p-2 rounded">
                      <span className="text-slate-500 block text-[10px]">
                        Col/Row Stripe Proxy
                      </span>
                      <span>
                        {primaryOutput.colStripeProxyAdu.toFixed(1)} /{" "}
                        {primaryOutput.rowStripeProxyAdu.toFixed(1)} ADU
                      </span>
                    </div>
                    <div className="bg-slate-900/90 border border-slate-800 p-2 rounded">
                      <span className="text-slate-500 block text-[10px]">
                        Empirical Edge Keep
                      </span>
                      <span className="text-emerald-300 font-semibold">
                        {(primaryOutput.edgeRetentionProxy * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="bg-slate-900/90 border border-slate-800 p-2 rounded">
                      <span className="text-slate-500 block text-[10px]">
                        1px Wire Retention
                      </span>
                      <span className="text-amber-300 font-semibold">
                        {primaryOutput.groundTruthMetrics
                          ? `${(
                              primaryOutput.groundTruthMetrics
                                .thinStructureRetentionRatio * 100
                            ).toFixed(1)}% (GT)`
                          : "N/A (Real File)"}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-xs font-mono font-bold text-sky-300">
                      REFERENCE: {referenceMeta.fullName}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {referenceOutput.executionTimeMs.toFixed(1)} ms
                    </span>
                  </div>
                  <ThermalCanvasRenderer
                    width={W}
                    height={H}
                    display8={referenceOutput.display8}
                    reference8={referenceOutput.monotonicReference8}
                    raw14={referenceOutput.raw14}
                    postLine14={referenceOutput.postLine14}
                    splitWipePct={splitWipePct}
                    leftLabel="Raw Monotonic"
                    rightLabel={referenceMeta.shortLabel}
                    palette={palette}
                    rois={rois}
                    activeRoiRole={activeRoiDragRole}
                    onUpdateRoi={handleUpdateRoi}
                    captionBadge={referenceMeta.shortLabel}
                    isMonotonicVerified={
                      referenceOutput.isStrictlyMonotonicFrame
                    }
                  />
                  <div className="grid grid-cols-4 gap-2 text-[11px] font-mono">
                    <div className="bg-slate-900/90 border border-slate-800 p-2 rounded">
                      <span className="text-slate-500 block text-[10px]">
                        Window [Lo..Hi]
                      </span>
                      <span>
                        {referenceOutput.pLowAdu.toFixed(0)}..
                        {referenceOutput.pHighAdu.toFixed(0)} ADU
                      </span>
                    </div>
                    <div className="bg-slate-900/90 border border-slate-800 p-2 rounded">
                      <span className="text-slate-500 block text-[10px]">
                        Col/Row Stripe Proxy
                      </span>
                      <span>
                        {referenceOutput.colStripeProxyAdu.toFixed(1)} /{" "}
                        {referenceOutput.rowStripeProxyAdu.toFixed(1)} ADU
                      </span>
                    </div>
                    <div className="bg-slate-900/90 border border-slate-800 p-2 rounded">
                      <span className="text-slate-500 block text-[10px]">
                        Empirical Edge Keep
                      </span>
                      <span className="text-sky-300 font-semibold">
                        {(referenceOutput.edgeRetentionProxy * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="bg-slate-900/90 border border-slate-800 p-2 rounded">
                      <span className="text-slate-500 block text-[10px]">
                        1px Wire Retention
                      </span>
                      <span className="text-sky-300 font-semibold">
                        {referenceOutput.groundTruthMetrics
                          ? `${(
                              referenceOutput.groundTruthMetrics
                                .thinStructureRetentionRatio * 100
                            ).toFixed(1)}% (GT)`
                          : "N/A (Real File)"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Phase 1 Req 3: Manual Multi-ROI Radiometric & Display Telemetry Panel */}
              <div className="rounded-xl border border-slate-800 bg-slate-900/75 p-4 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-400">
                      <Target className="w-4 h-4" />
                      Phase 1 Requirement 3 — Local Manual Multi-ROI Measurement Tool
                    </div>
                    <h3 className="text-sm font-semibold text-slate-100 mt-0.5">
                      Animal ROI vs. Bridge Structure ROI vs. Local Background across Raw 14-Bit, Post-Line 14-Bit, and Display 8-Bit Planes
                    </h3>
                  </div>

                  {/* Interactive ROI Drag Selector Buttons */}
                  <div className="flex flex-wrap items-center gap-1.5 text-xs font-mono">
                    {(
                      [
                        {
                          role: "animal",
                          label: "Drag Animal ROI",
                          color: "amber",
                        },
                        {
                          role: "bridge",
                          label: "Drag Bridge ROI",
                          color: "sky",
                        },
                        {
                          role: "background",
                          label: "Drag Background ROI",
                          color: "emerald",
                        },
                      ] as const
                    ).map((btn) => {
                      const active = activeRoiDragRole === btn.role;
                      return (
                        <button
                          key={btn.role}
                          type="button"
                          onClick={() =>
                            setActiveRoiDragRole(active ? null : btn.role)
                          }
                          className={`px-2.5 py-1 rounded border transition ${
                            active
                              ? "bg-amber-500 text-slate-950 font-bold border-amber-300"
                              : "bg-slate-950 text-slate-300 border-slate-700 hover:bg-slate-800"
                          }`}
                        >
                          {active ? `Dragging ${btn.role}...` : btn.label}
                        </button>
                      );
                    })}
                    <button
                      type="button"
                      onClick={() => setRois(getDefaultRoisForResolution(W, H))}
                      className="px-2 py-1 rounded bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200"
                      title="Reset ROI boxes to default coordinates"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Diagnostic Root-Cause Comparison Banner (Primary vs Reference) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="rounded-lg bg-slate-950/90 border border-amber-500/30 p-3 text-xs font-mono space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-amber-300 font-bold">
                        {primaryMeta.shortLabel} Diagnosis:
                      </span>
                      <span className="px-2 py-0.5 rounded bg-amber-500/15 text-amber-200 text-[10px]">
                        {primaryRoiReport.rootCauseCategory}
                      </span>
                    </div>
                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      {primaryRoiReport.diagnosticExplanation}
                    </p>
                  </div>

                  <div className="rounded-lg bg-slate-950/90 border border-sky-500/30 p-3 text-xs font-mono space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sky-300 font-bold">
                        {referenceMeta.shortLabel} Diagnosis:
                      </span>
                      <span className="px-2 py-0.5 rounded bg-sky-500/15 text-sky-200 text-[10px]">
                        {referenceRoiReport.rootCauseCategory}
                      </span>
                    </div>
                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      {referenceRoiReport.diagnosticExplanation}
                    </p>
                  </div>
                </div>

                {/* 3-Plane Quantitative Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs font-mono">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400">
                        <th className="py-2 pr-3">Measurement Plane & Metric</th>
                        <th className="py-2 px-3 text-amber-300">
                          Animal ROI ({rois.animal.w}×{rois.animal.h})
                        </th>
                        <th className="py-2 px-3 text-sky-300">
                          Bridge ROI ({rois.bridge.w}×{rois.bridge.h})
                        </th>
                        <th className="py-2 px-3 text-emerald-300">
                          Background ROI ({rois.background.w}×{rois.background.h})
                        </th>
                        <th className="py-2 px-3">
                          Animal − Bridge Separation
                        </th>
                        <th className="py-2 pl-3">
                          Contrast-to-Noise Proxy (CNR)
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-slate-200">
                      {/* Plane 1: Raw 14-Bit Sensor ADU */}
                      <tr className="bg-slate-950/40">
                        <td className="py-2 pr-3 font-semibold text-slate-100">
                          1. Raw Sensor Plane (14-Bit ADU, Uncalibrated)
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {primaryRoiReport.raw14.animal.median.toFixed(1)}
                          </strong>{" "}
                          ADU (IQR {primaryRoiReport.raw14.animal.iqr.toFixed(1)})
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {primaryRoiReport.raw14.bridge.median.toFixed(1)}
                          </strong>{" "}
                          ADU (IQR {primaryRoiReport.raw14.bridge.iqr.toFixed(1)})
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {primaryRoiReport.raw14.background.median.toFixed(1)}
                          </strong>{" "}
                          (σ_rob=
                          {primaryRoiReport.raw14.background.robustSigma.toFixed(
                            1
                          )}
                          )
                        </td>
                        <td className="py-2 px-3 font-bold text-amber-300">
                          {primaryRoiReport.raw14.animalVsBridgeDeltaAdu >= 0
                            ? "+"
                            : ""}
                          {primaryRoiReport.raw14.animalVsBridgeDeltaAdu.toFixed(
                            1
                          )}{" "}
                          ADU (
                          {primaryRoiReport.raw14.animalBridgeSeparationSigma.toFixed(
                            1
                          )}
                          σ)
                        </td>
                        <td className="py-2 pl-3">
                          Anim: {primaryRoiReport.raw14.cnrAnimalVsBg.toFixed(1)}
                          σ | Brdg:{" "}
                          {primaryRoiReport.raw14.cnrBridgeVsBg.toFixed(1)}σ
                        </td>
                      </tr>

                      {/* Plane 2: Post-Line-Correction 14-Bit ADU (Primary) */}
                      <tr>
                        <td className="py-2 pr-3 font-semibold text-amber-300">
                          2A. Post-Line 14-Bit ({primaryMeta.shortLabel})
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {primaryRoiReport.postLine14.animal.median.toFixed(
                              1
                            )}
                          </strong>{" "}
                          ADU
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {primaryRoiReport.postLine14.bridge.median.toFixed(
                              1
                            )}
                          </strong>{" "}
                          ADU
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {primaryRoiReport.postLine14.background.median.toFixed(
                              1
                            )}
                          </strong>{" "}
                          (σ=
                          {primaryRoiReport.postLine14.background.robustSigma.toFixed(
                            1
                          )}
                          )
                        </td>
                        <td className="py-2 px-3 font-bold text-amber-300">
                          {primaryRoiReport.postLine14.animalVsBridgeDeltaAdu >=
                          0
                            ? "+"
                            : ""}
                          {primaryRoiReport.postLine14.animalVsBridgeDeltaAdu.toFixed(
                            1
                          )}{" "}
                          ADU (
                          {primaryRoiReport.postLine14.animalBridgeSeparationSigma.toFixed(
                            1
                          )}
                          σ)
                        </td>
                        <td className="py-2 pl-3 text-slate-400">
                          Shift vs Raw:{" "}
                          {primaryRoiReport.postLine14.lineCorrectionDeltaShiftAdu.toFixed(
                            1
                          )}{" "}
                          ADU
                        </td>
                      </tr>

                      {/* Plane 3A: Display 8-Bit Intensity (Primary) */}
                      <tr className="bg-amber-500/5">
                        <td className="py-2 pr-3 font-semibold text-amber-300">
                          3A. Display 8-Bit ({primaryMeta.shortLabel}) [NOT °C]
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {primaryRoiReport.display8.animal.median.toFixed(1)}
                          </strong>{" "}
                          / 255
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {primaryRoiReport.display8.bridge.median.toFixed(1)}
                          </strong>{" "}
                          / 255
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {primaryRoiReport.display8.background.median.toFixed(
                              1
                            )}
                          </strong>{" "}
                          / 255
                        </td>
                        <td className="py-2 px-3 font-bold text-emerald-300">
                          {primaryRoiReport.display8.animalVsBridgeDelta8 >= 0
                            ? "+"
                            : ""}
                          {primaryRoiReport.display8.animalVsBridgeDelta8.toFixed(
                            1
                          )}{" "}
                          lvl (
                          {primaryRoiReport.display8.animalBridgeSeparationSigma8.toFixed(
                            1
                          )}
                          σ)
                        </td>
                        <td className="py-2 pl-3">
                          Order:{" "}
                          {primaryRoiReport.orderingPreserved
                            ? "PRESERVED"
                            : "INVERTED"}
                        </td>
                      </tr>

                      {/* Plane 3B: Display 8-Bit Intensity (Reference Method e.g. Argos 2) */}
                      <tr className="bg-sky-500/5">
                        <td className="py-2 pr-3 font-semibold text-sky-300">
                          3B. Display 8-Bit ({referenceMeta.shortLabel}) [NOT °C]
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {referenceRoiReport.display8.animal.median.toFixed(
                              1
                            )}
                          </strong>{" "}
                          / 255
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {referenceRoiReport.display8.bridge.median.toFixed(
                              1
                            )}
                          </strong>{" "}
                          / 255
                        </td>
                        <td className="py-2 px-3">
                          Med:{" "}
                          <strong>
                            {referenceRoiReport.display8.background.median.toFixed(
                              1
                            )}
                          </strong>{" "}
                          / 255
                        </td>
                        <td className="py-2 px-3 font-bold text-sky-300">
                          {referenceRoiReport.display8.animalVsBridgeDelta8 >= 0
                            ? "+"
                            : ""}
                          {referenceRoiReport.display8.animalVsBridgeDelta8.toFixed(
                            1
                          )}{" "}
                          lvl (
                          {referenceRoiReport.display8.animalBridgeSeparationSigma8.toFixed(
                            1
                          )}
                          σ)
                        </td>
                        <td className="py-2 pl-3">
                          Order:{" "}
                          {referenceRoiReport.orderingPreserved
                            ? "PRESERVED"
                            : "INVERTED"}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Log ROI Measurement to PostgreSQL */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800">
                  <input
                    type="text"
                    value={roiNoteInput}
                    onChange={(e) => setRoiNoteInput(e.target.value)}
                    placeholder="Add investigator note for this ROI measurement..."
                    className="flex-1 min-w-[240px] rounded-lg bg-slate-950 border border-slate-800 px-3 py-1.5 text-xs font-mono text-slate-200"
                  />
                  <button
                    type="button"
                    disabled={loggingRoi}
                    onClick={handleLogRoiToDb}
                    className="px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 transition disabled:opacity-50"
                  >
                    {loggingRoi
                      ? "Saving to PostgreSQL..."
                      : "Log Multi-Plane ROI Evidence to DB"}
                  </button>
                </div>
              </div>
            </div>

            {/* Right 4 Columns: Phase 2 Independent Knobs, Locked Window, & Causal Controls */}
            <div className="xl:col-span-4 space-y-5">
              {/* Quick Preset Switcher for Phase 2 Hypotheses */}
              <div className="rounded-xl border border-slate-800 bg-slate-900/75 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    Phase 2 Candidate Quick-Select
                  </span>
                  <button
                    type="button"
                    onClick={() => setCfg(DEFAULT_UNIFIED_CONFIG)}
                    className="text-[11px] font-mono text-slate-400 hover:text-slate-200 flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" /> Reset Knobs
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-2 text-xs font-mono">
                  {(
                    [
                      {
                        id: "exp1_argos2_radiometric",
                        title:
                          "Exp-1: Argos 2 Evolved (Guided Base/Detail + Knee)",
                        desc: "Fixes Argos 2 p97.5 highlight crush & ±150 ADU stripe gate; keeps >84% 1px bridge cables.",
                      },
                      {
                        id: "exp2_global_monotonic_locked",
                        title:
                          "Exp-2: Strict Global Monotonic Window (Ordering Ref)",
                        desc: "Guarantees 0 spatial ordering inversions across frame; lockable ADU scale eliminates flicker.",
                      },
                      {
                        id: "exp3_blended_clahe_monotonic",
                        title:
                          "Exp-3: Monotonic Anchor + Bounded CL-Hist Blend",
                        desc: "Adjustable tile grid & clip limit blended with monotonic anchor (interpretive view).",
                      },
                      {
                        id: "exp4_causal_temporal_stabilized",
                        title:
                          "Exp-4: Causal Motion-Gated Temporal Stabilization",
                        desc: "Past frames only (0 look-ahead), 8-frame warmup, motion gate prevents animal ghosting.",
                      },
                      {
                        id: "argos_2",
                        title:
                          "Original Argos 2 (Untouched User Visual Reference)",
                        desc: "Retained unmodified to demonstrate p97.5 highlight compression on bridge + animal.",
                      },
                    ] as const
                  ).map((cand) => (
                    <button
                      key={cand.id}
                      type="button"
                      onClick={() => setPrimaryMethodId(cand.id)}
                      className={`text-left p-2.5 rounded-lg border transition ${
                        primaryMethodId === cand.id
                          ? "bg-amber-500/15 border-amber-500/50 text-slate-100"
                          : "bg-slate-950/70 border-slate-800 text-slate-300 hover:bg-slate-900"
                      }`}
                    >
                      <div className="font-bold text-amber-300">
                        {cand.title}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                        {cand.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Independent Labeled Knobs & Safe Stage Bypasses */}
              <div className="rounded-xl border border-slate-800 bg-slate-900/75 p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono uppercase tracking-wider text-sky-400 flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5" />
                    Independent Stage Bypasses & Knobs
                  </span>
                </div>

                {/* Stage Bypass Toggles */}
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <label className="flex items-center gap-2 p-2 rounded bg-slate-950 border border-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={cfg.enableStage1LineCorrection}
                      onChange={(e) =>
                        setCfg((c) => ({
                          ...c,
                          enableStage1LineCorrection: e.target.checked,
                        }))
                      }
                      className="accent-amber-400"
                    />
                    <span>Stage 1: Destripe</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 rounded bg-slate-950 border border-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={cfg.enableStage2And3ToneMap}
                      onChange={(e) =>
                        setCfg((c) => ({
                          ...c,
                          enableStage2And3ToneMap: e.target.checked,
                        }))
                      }
                      className="accent-amber-400"
                    />
                    <span>Stage 2/3: Tone Map</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 rounded bg-slate-950 border border-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={cfg.enableStage4DetailEnhancement}
                      onChange={(e) =>
                        setCfg((c) => ({
                          ...c,
                          enableStage4DetailEnhancement: e.target.checked,
                        }))
                      }
                      className="accent-amber-400"
                    />
                    <span>Stage 4: Detail Boost</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 rounded bg-slate-950 border border-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={cfg.enableCnnResidual}
                      onChange={(e) =>
                        setCfg((c) => ({
                          ...c,
                          enableCnnResidual: e.target.checked,
                        }))
                      }
                      className="accent-amber-400"
                    />
                    <span>Stage 1.5: CNN (Exp)</span>
                  </label>
                </div>

                {/* Window Lock Mode (Auto Percentile vs Locked Manual ADU Window) */}
                <div className="space-y-2 pt-2 border-t border-slate-800 text-xs font-mono">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300 font-semibold">
                      Radiometric Window Mode
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setCfg((c) => ({
                          ...c,
                          fixedWindowMode:
                            c.fixedWindowMode === "auto_percentile"
                              ? "locked_manual_adu"
                              : "auto_percentile",
                          manualWindowLowAdu: Math.round(primaryOutput.pLowAdu),
                          manualWindowHighAdu: Math.round(
                            primaryOutput.pHighAdu
                          ),
                        }))
                      }
                      className={`flex items-center gap-1 px-2.5 py-1 rounded border ${
                        cfg.fixedWindowMode === "locked_manual_adu"
                          ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                          : "bg-slate-950 text-slate-300 border-slate-700"
                      }`}
                    >
                      {cfg.fixedWindowMode === "locked_manual_adu" ? (
                        <>
                          <Lock className="w-3 h-3" /> Scale Locked (ADU)
                        </>
                      ) : (
                        <>
                          <Unlock className="w-3 h-3" /> Auto Percentile
                        </>
                      )}
                    </button>
                  </div>

                  {cfg.fixedWindowMode === "locked_manual_adu" ? (
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] text-slate-400 block">
                          Manual Low ({cfg.manualWindowLowAdu} ADU)
                        </label>
                        <input
                          type="range"
                          min={6500}
                          max={7800}
                          step={10}
                          value={cfg.manualWindowLowAdu}
                          onChange={(e) =>
                            setCfg((c) => ({
                              ...c,
                              manualWindowLowAdu: Number(e.target.value),
                            }))
                          }
                          className="w-full accent-emerald-400"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block">
                          Manual High ({cfg.manualWindowHighAdu} ADU)
                        </label>
                        <input
                          type="range"
                          min={7400}
                          max={9500}
                          step={10}
                          value={cfg.manualWindowHighAdu}
                          onChange={(e) =>
                            setCfg((c) => ({
                              ...c,
                              manualWindowHighAdu: Number(e.target.value),
                            }))
                          }
                          className="w-full accent-emerald-400"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] text-slate-400 block">
                          Upper Quantile (p{(cfg.percentileHigh * 100).toFixed(1)})
                        </label>
                        <input
                          type="range"
                          min={0.96}
                          max={0.999}
                          step={0.002}
                          value={cfg.percentileHigh}
                          onChange={(e) =>
                            setCfg((c) => ({
                              ...c,
                              percentileHigh: Number(e.target.value),
                            }))
                          }
                          className="w-full accent-amber-400"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block">
                          Highlight Knee ({cfg.highlightKneeStrength.toFixed(2)})
                        </label>
                        <input
                          type="range"
                          min={0}
                          max={0.9}
                          step={0.05}
                          value={cfg.highlightKneeStrength}
                          onChange={(e) =>
                            setCfg((c) => ({
                              ...c,
                              highlightKneeStrength: Number(e.target.value),
                            }))
                          }
                          className="w-full accent-amber-400"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Line Suppression & Guided Detail Sliders */}
                <div className="space-y-2.5 pt-2 border-t border-slate-800 text-xs font-mono">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-slate-400 block">
                        Vert Stripe Str ({cfg.verticalStripeStrength.toFixed(2)})
                      </label>
                      <input
                        type="range"
                        min={0}
                        max={1.2}
                        step={0.05}
                        value={cfg.verticalStripeStrength}
                        onChange={(e) =>
                          setCfg((c) => ({
                            ...c,
                            verticalStripeStrength: Number(e.target.value),
                          }))
                        }
                        className="w-full accent-amber-400"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 block">
                        Horiz Stripe Str ({cfg.horizontalStripeStrength.toFixed(2)})
                      </label>
                      <input
                        type="range"
                        min={0}
                        max={1.2}
                        step={0.05}
                        value={cfg.horizontalStripeStrength}
                        onChange={(e) =>
                          setCfg((c) => ({
                            ...c,
                            horizontalStripeStrength: Number(e.target.value),
                          }))
                        }
                        className="w-full accent-amber-400"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-slate-400 block">
                        Guided Detail Gain ({cfg.detailGain.toFixed(2)}×)
                      </label>
                      <input
                        type="range"
                        min={0.8}
                        max={2.6}
                        step={0.05}
                        value={cfg.detailGain}
                        onChange={(e) =>
                          setCfg((c) => ({
                            ...c,
                            detailGain: Number(e.target.value),
                          }))
                        }
                        className="w-full accent-sky-400"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 block">
                        Noise Coring ({cfg.noiseCoringSigmaMult.toFixed(1)}× σ)
                      </label>
                      <input
                        type="range"
                        min={0}
                        max={3.5}
                        step={0.1}
                        value={cfg.noiseCoringSigmaMult}
                        onChange={(e) =>
                          setCfg((c) => ({
                            ...c,
                            noiseCoringSigmaMult: Number(e.target.value),
                          }))
                        }
                        className="w-full accent-sky-400"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-slate-400 block">
                        CLAHE Clip ({cfg.claheClipLimit.toFixed(1)}) / Tiles ({cfg.claheTileCount}×{cfg.claheTileCount})
                      </label>
                      <input
                        type="range"
                        min={1.2}
                        max={4.5}
                        step={0.2}
                        value={cfg.claheClipLimit}
                        onChange={(e) =>
                          setCfg((c) => ({
                            ...c,
                            claheClipLimit: Number(e.target.value),
                          }))
                        }
                        className="w-full accent-sky-400"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 block">
                        Local Contrast Blend α ({cfg.localContrastBlend.toFixed(2)})
                      </label>
                      <input
                        type="range"
                        min={0}
                        max={0.8}
                        step={0.05}
                        value={cfg.localContrastBlend}
                        onChange={(e) =>
                          setCfg((c) => ({
                            ...c,
                            localContrastBlend: Number(e.target.value),
                          }))
                        }
                        className="w-full accent-sky-400"
                      />
                    </div>
                  </div>
                </div>

                {/* Causal Temporal & Claude B Look-Ahead Audit Controls */}
                <div className="space-y-2 pt-2 border-t border-slate-800 text-xs font-mono">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300 font-semibold">
                      Temporal Context & Causality Audit
                    </span>
                    <span className="text-[10px] text-slate-400">
                      Warm-up: {consecutiveCount}/{cfg.declaredWarmupFrames} frames
                    </span>
                  </div>

                  <label className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800 cursor-pointer">
                    <span className="text-[11px] text-slate-300">
                      Claude B Strict Causal Override (Block Frame-0 Look-Ahead)
                    </span>
                    <input
                      type="checkbox"
                      checked={cfg.claudeBCausalOverride}
                      onChange={(e) =>
                        setCfg((c) => ({
                          ...c,
                          claudeBCausalOverride: e.target.checked,
                        }))
                      }
                      className="accent-emerald-400"
                    />
                  </label>

                  <div className="p-2 rounded bg-slate-950 border border-slate-800 text-[11px] text-slate-400 space-y-1">
                    <div>
                      Past Frames Used:{" "}
                      <strong className="text-slate-200">
                        {primaryOutput.temporalContextInfo.usedPastFrames
                          .length > 0
                          ? primaryOutput.temporalContextInfo.usedPastFrames.join(
                              ", "
                            )
                          : "0 (Pure Spatial)"}
                      </strong>
                    </div>
                    <div>
                      Future Frames Used (Look-Ahead):{" "}
                      <strong
                        className={
                          primaryOutput.temporalContextInfo.usedFutureFrames
                            .length > 0
                            ? "text-rose-400"
                            : "text-emerald-400"
                        }
                      >
                        {primaryOutput.temporalContextInfo.usedFutureFrames
                          .length > 0
                          ? `YES (${primaryOutput.temporalContextInfo.usedFutureFrames.join(
                              ", "
                            )}) — Offline Look-Ahead`
                          : "NONE (Strictly Causal)"}
                      </strong>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: STAGE-BY-STAGE ABLATION MATRIX */}
        {activeTab === "ablation" && (
          <StageAblationMatrixView
            width={W}
            height={H}
            methodLabel={primaryMeta.fullName}
            methodId={primaryMethodId}
            frameIndex={frameIndex}
            sourceLabel={activeFrameBundle.sourceTitle}
            rawAnimalBridgeDeltaAdu={
              primaryRoiReport.raw14.animalVsBridgeDeltaAdu
            }
            postLineAnimalBridgeDeltaAdu={
              primaryRoiReport.postLine14.animalVsBridgeDeltaAdu
            }
            stages={ablationStages}
            savedSnapshots={dbState.ablations}
            onSaveSnapshot={handleSaveAblationToDb}
          />
        )}

        {/* TAB 3: FROZEN HOLDOUT BENCHMARK & 12-METHOD MATRIX */}
        {activeTab === "benchmark" && (
          <div className="space-y-6">
            <div className="rounded-xl border border-slate-800 bg-slate-900/75 p-4 flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-400">
                  <Database className="w-4 h-4" />
                  Phase 3 — Defensible Independent Evaluation & Contiguous Block Holdout
                </div>
                <h3 className="text-base font-semibold text-slate-100 mt-1">
                  12-Method Frozen Benchmark Suite (Synthetic Ground-Truth vs. Reference-Free Metrics Separated)
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Development Block <code>[0..19]</code> is separated from Frozen Holdout Block{" "}
                  <code>[25..29]</code> by a 5-frame Exclusion Guard <code>[20..24]</code>. Ground-truth PSNR/SSIM are computed strictly on synthetic fixtures with known clean targets—never on unlabeled real recordings.
                </p>
              </div>

              <button
                type="button"
                disabled={runningFrozenEval}
                onClick={handleRunFrozenEvaluation}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-200 border border-emerald-500/40 transition disabled:opacity-50"
              >
                <Play className="w-4 h-4" />
                {runningFrozenEval
                  ? "Running 12-Method Holdout Suite..."
                  : `Execute & Freeze Holdout Run (${W}×${H})`}
              </button>
            </div>

            {latestEvalRun && (
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-amber-300 font-bold">
                      {latestEvalRun.runTitle}
                    </span>
                    <span className="text-slate-400 ml-3">
                      Config Hash: <code>{latestEvalRun.configHash}</code>
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-slate-300">
                    <span>
                      p50 Latency:{" "}
                      <strong>{latestEvalRun.p50LatencyMs} ms</strong>
                    </span>
                    <span>
                      p95 Latency:{" "}
                      <strong>{latestEvalRun.p95LatencyMs} ms</strong>
                    </span>
                    <span>
                      Peak Slice Memory:{" "}
                      <strong className="text-emerald-300">
                        {latestEvalRun.peakMemoryMb} MB
                      </strong>
                    </span>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs font-mono">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400">
                        <th className="py-2 pr-3">Method</th>
                        <th className="py-2 px-2">Source</th>
                        <th className="py-2 px-2">
                          [GT] Mean PSNR / SSIM
                        </th>
                        <th className="py-2 px-2">
                          [GT] 1px Wire Ret.
                        </th>
                        <th className="py-2 px-2">
                          [GT] ±150 ADU Probe RMSE
                        </th>
                        <th className="py-2 px-2">
                          [Bridge Scene] Anim−Brdg Δ8
                        </th>
                        <th className="py-2 px-2">
                          [No-Ref] Edge Keep / Halo
                        </th>
                        <th className="py-2 px-2">Monotonic?</th>
                        <th className="py-2 px-2">p50 / p95 (ms)</th>
                        <th className="py-2 pl-2">
                          Documented Failure Cases / Trade-Offs
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-slate-200">
                      {(latestEvalRun.metricsTableJson ?? []).map((row) => (
                        <tr
                          key={row.methodId}
                          className={`hover:bg-slate-800/30 ${
                            row.methodId === "exp1_argos2_radiometric" ||
                            row.methodId === "exp2_global_monotonic_locked"
                              ? "bg-amber-500/5"
                              : ""
                          }`}
                        >
                          <td className="py-2.5 pr-3 font-bold text-amber-300">
                            {row.shortLabel}
                          </td>
                          <td className="py-2.5 px-2 text-slate-400">
                            {row.sourcePackage}
                          </td>
                          <td className="py-2.5 px-2">
                            <strong>{row.meanPsnrDb.toFixed(2)} dB</strong> /{" "}
                            {row.meanSsim.toFixed(3)}
                          </td>
                          <td className="py-2.5 px-2">
                            <span
                              className={
                                row.thinWireRetentionPct >= 80
                                  ? "text-emerald-300 font-semibold"
                                  : "text-rose-300"
                              }
                            >
                              {row.thinWireRetentionPct.toFixed(1)}%
                            </span>
                          </td>
                          <td className="py-2.5 px-2">
                            <span
                              className={
                                row.strong150AduStripeAfterRms < 25
                                  ? "text-emerald-300 font-semibold"
                                  : "text-rose-300 font-semibold"
                              }
                            >
                              {row.strong150AduStripeAfterRms.toFixed(1)} ADU
                            </span>
                          </td>
                          <td className="py-2.5 px-2">
                            <span
                              className={
                                Math.abs(row.bridgeAnimalDisplayDelta8) >= 5
                                  ? "text-emerald-300 font-bold"
                                  : "text-amber-300"
                              }
                            >
                              {row.bridgeAnimalDisplayDelta8 >= 0 ? "+" : ""}
                              {row.bridgeAnimalDisplayDelta8.toFixed(1)} lvl
                            </span>
                          </td>
                          <td className="py-2.5 px-2">
                            {row.empiricalEdgeKeepPct.toFixed(1)}% /{" "}
                            {row.haloOvershootIndex.toFixed(2)}
                          </td>
                          <td className="py-2.5 px-2">
                            {row.isGloballyMonotonic ? (
                              <span className="text-emerald-300 font-semibold">
                                YES (0 inv)
                              </span>
                            ) : (
                              <span className="text-slate-400">
                                Local ({row.monotonicViolationsMean.toFixed(0)} inv)
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-2">
                            {row.p50LatencyMs.toFixed(1)} /{" "}
                            {row.p95LatencyMs.toFixed(1)}
                          </td>
                          <td className="py-2.5 pl-2 text-[11px] text-slate-400 max-w-xs">
                            {row.honestFailureCases[0]}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-slate-300 flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-emerald-300">
                      Benchmark Verdict Summary:
                    </strong>{" "}
                    {latestEvalRun.verdictSummary}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: BLINDED RANDOMIZED A/B PREFERENCE STUDIO */}
        {activeTab === "blind_ab" && (
          <BlindedAbReviewModalAndTab
            width={W}
            height={H}
            raw14Input={activeFrameBundle.raw14Input}
            frameIndex={frameIndex}
            sceneLabel={activeFrameBundle.sourceTitle}
            cfg={cfg}
            configHash={configHash}
            rois={rois}
            persistedReviews={dbState.abReviews}
            onSubmitVote={handleSubmitBlindedAbVote}
          />
        )}

        {/* TAB 5: HONEST CNN AUDIT & VERBATIM REPOSITORY DOCS */}
        {activeTab === "cnn_and_docs" && <CnnHonestyAndAuditPanel />}
      </main>

      {/* Footer Physics & Operational Caveat Bar */}
      <footer className="border-t border-slate-800 bg-slate-950 py-3 px-4 text-[11px] font-mono text-slate-400">
        <div className="max-w-[1600px] mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>
              Non-Negotiable Rule: Apparent brightness in 8-bit display space is Display Intensity, NOT calibrated temperature (°C). Local contrast methods alter global intensity ordering.
            </span>
          </div>
          <div>
            Original Archives SHA-256 Verified: Argos{" "}
            <code>fa73ac86...</code> | Claude <code>1ccaf596...</code>
          </div>
        </div>
      </footer>
    </div>
  );
}
