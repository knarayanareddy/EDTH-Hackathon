# ClearHot: Independent Evaluation, Stage-by-Stage Audit, and Candidate Enhancement Report

## 1. Scope & Non-Negotiable Data/Physics Compliance

- **Real Sample Status**: We have **not** seen or transmitted the user's ~180 MB sample file. All real-data guidance in this workbench operates strictly locally in the browser via `File.slice()` frame-on-demand streaming (~4.2 MB active heap footprint regardless of file size), and all numerical benchmarks shipped in this report are explicitly labeled **Synthetic Simulation**.
- **Format as Hypothesis**: `640×512` headerless `uint16`, little-endian byte order, and low 14-bit (`& 0x3fff`) alignment are treated as testable hypotheses in `src/lib/thermal/streamingBinDecoder.ts`. Exact file-size divisibility by `640 × 512 × 2` (`655,360` bytes) does not prove absence of headers/metadata or radiometric calibration. Raw ADU values are never labeled as temperature (°C/K).
- **Bridge vs. Animal Apparent Brightness Physics**:
  - An animal is **not** guaranteed to produce a higher raw sensor ADU than a bridge structure.
  - Solar thermal loading of concrete/steel bridge decks, thermal inertia, surface emissivity ($\varepsilon_{\text{fur}} \approx 0.96\text{–}0.98$ with outer pelage insulation near ambient air temperature vs. solar-warmed bridge deck), reflected sky/ground longwave radiation, atmospheric path radiance, and optical PSF blur on small distant animals can cause raw sensor ADU distributions of animals and bridges to overlap or invert.
  - **Rule enforced**: No object detector or semantic brightening is permitted. If raw sensor ADU values do not separate Animal and Bridge ROIs above local background noise ($\text{CNR} < 1.5\sigma$), the ROI tool reports `RAW_OVERLAP_PHYSICAL`. Conversely, when raw ADU values *do* separate the animal from the bridge ($>2.5\sigma$) and separation disappears in the 8-bit image, our Stage-by-Stage Ablation isolates which display stage caused the loss.

---

## 2. Concise Audit: Implemented Code vs. Tested Behavior vs. Untested Claims

| Component / Claim | Implemented Code in Original Packages | Independently Tested Behavior | Untested Claims / Caveats & How to Disable |
|---|---|---|---|
| **Argos 1** (`instance1`) | Edge-gated Huber adjacent-column/row difference integration; 8-neighbor rank spike gate; Dual-Plateau Histogram Equalization (DPHE); DoG coring. | Preserves 2×2+ hot targets while removing 1px spikes. However, on the **±150 ADU alternating-column stripe probe**, `Math.abs(dx) < edgeThresh` (`135 ADU`) rejects the stripes as "scene edges", leaving ~150.0 ADU stripe RMSE intact. | Original UI's "98.5% thin retention" and "1.2 halo index" on flat frames were hardcoded fallback constants in `thermalPipelineEngine.ts`. Replaced with empirical gradient projection in `roiAndMetrics.ts`. Disable via method selector or Stage 1–4 toggles. |
| **Argos 2** (`instance2` — *User Visual Reference*) | 1D multi-scale Haar wavelet non-negative Garrote shrinkage + spectral comb; 14-bit subsampled Guided Filter base/detail + S-curve + `[p2, p97.5]` quantile tone map. | **Why Animals and Bridges Look Equally Bright in Argos 2**: When `stage3DualPlateauCompression` is enabled (default `true`), Argos 2 sets the main upper window `pHigh` to the **97.5th percentile** (`0.975`) and maps all pixels above `pHigh` into a compressed 23-level shoulder (`232 + ((v - pHigh)/7000) * 23`). When both a solar-warmed bridge (`~7765 ADU`) and an animal (`~7905 ADU`) lie in the top 2.5% of frame intensities above a cool river/sky background, their **140 ADU raw separation is crushed to < 1.2 gray levels** in 8-bit display space! Also fails the ±150 ADU stripe probe (`localDiff < 180` gate). | Original UI claims FPGA streaming / 1 line buffer; no HDL, synthesis, or timing closure exists. Retain unmodified `argos_2` as visual reference, or switch to `exp1_argos2_radiometric` / uncheck Stage 2/3 to restore highlight separation. |
| **Argos 3** (`instance3`) | Per-pixel 3-row coherent 1D cross-bilateral strip filter + 14-bit motion-gated temporal Kalman + Summed-Area Table 13×13 local variance ACE. | Reduces moderate static grain and partial stripes (~142.7 ADU on ±150 probe), but 13×13 Local ACE is non-monotonic (~14–28 ordering inversions per sampled frame) and alters relative brightness between distant bridge and animal ROIs. | Original Argos kept AGC/Kalman refs across file changes and non-consecutive seeks (~62 gray-level drift). Fixed via explicit seek/source reset in our unified engine. |
| **Claude A** (`A`) | Iterated 4-segment local-neighbor median profile (`alongGate` gradient gating) + isolation-aware bad-pixel filter + 8×8 tile CLAHE blend. | Because `alongGate` gates along the stripe direction rather than across it, Claude A suppresses the ±150 ADU alternating stripe probe down to **< 4.5 ADU RMSE**. However, on a genuine **full-height 1px vertical wire/cable**, segment medians treat the wire as a stripe and attenuate it (~66% retention). | CLAHE (`claheAmount = 0.5`) alters global brightness ordering across tiles. Disable CLAHE via `localContrastBlend = 0` or select `exp2_global_monotonic_locked`. |
| **Claude B** (`B`) | 12-frame clipped mean constant-statistics profile + motion-confidence FPN residual + 2-frame temporal denoise + 512-bin Plateau EQ + He et al. Guided Detail. | Highest synthetic PSNR on multi-frame sequences, **but** at frame `idx = 0`, `i0 = Math.max(0, Math.min(total - K, idx - K + 1))` evaluates to `0` and averages **future frames `1..11`**, and temporal denoise requests frame `1`. | Not causal at sequence start unless future frames are buffered (adding 11 frames / 440 ms latency at 25 fps). Use the **`claudeBCausalOverride`** toggle in the workbench to enforce strict past-only causality. |
| **Claude C** (`C`) | Wide-reference profile + radix-2 FFT broadband high-pass & periodic spectral peak notch + 5×5 bilateral filter + 3-scale box-blur detail with base compression. | Removes periodic frequency peaks cleanly, but spectral notch + bilateral smoothing yields the lowest 1px thin-wire retention (~62%) and multiscale base compression (`baseCompress = 0.15`) violates global monotonicity. | Bypass bilateral or multiscale base compression via Stage toggles. |
| **Argos & Claude CNNs** | Argos: hand-crafted directional/wavelet filters where `trainCnnInBrowser` perturbs 4 scalar `mixWeights` via finite differences on 64×64 synthetic patches (convolution kernels `kHoriz`/`kVert`/`kSpatial` are cloned and never updated). Claude: real TF.js ConvNets (A: 1,905 params, B: **9,041** actual params vs "~3k" UI label, C: 3,167 params) trained on synthetic noise only. | Neither package has a model trained or validated on real challenge-owner thermal recordings. | **Default OFF (`enableCnnResidual = false`)**. When toggled on for ablation, the UI displays dataset provenance (synthetic only), exact parameter count, and applies an uncertainty-gated classical fallback around strong structural gradients. |

---

## 3. Phase 2 Candidate Enhancements Implemented (Isolated in `unifiedEngine.ts`)

1. **`exp1_argos2_radiometric` (Argos 2 Evolved — Edge-Aware Guided Base/Detail + Highlight Knee + Wire Protection)**:
   - **Stage 1 Fix**: Replaces Argos 2's cross-column `< 180 ADU` gate with **along-stripe gradient gating + 4-segment sign-consistency** followed by Haar Garrote wavelet profile shrinkage and short-span thin-feature protection. Suppresses the ±150 ADU stripe probe while preserving >84% contrast on 1px bridge suspension cables.
   - **Stage 2/3 Fix**: Expands the upper quantile window from `p97.5` to `p99.2` and replaces the flat `7000 ADU` linear crush shoulder with a **logarithmic highlight knee** (`computeMonotonicGlobalDisplay8`), restoring **~16–20 gray levels** of display separation between the warm Animal ROI and solar-heated Bridge ROI.
   - **Stage 4 Fix**: Uses true $O(1)$ separable box-filter He et al. self-guided base/detail decomposition in 14-bit space with noise-adaptive deadzone coring ($\tau = k \cdot \hat{\sigma}_{\text{noise}}$) and soft-limited detail gain (`±22` display levels max) to prevent boundary halos.
2. **`exp2_global_monotonic_locked` (Strict Global Monotonic Percentile / Locked-Scale Window)**:
   - Guarantees **0 spatial monotonicity violations** ($I_1 > I_2 \implies D(I_1) \ge D(I_2)$ across the entire frame) so intensity ordering between any Animal ROI and Bridge ROI is strictly faithful to the post-line-correction 14-bit signal.
   - Supports **Locked Manual ADU Scale (`[W_low, W_high]`)** across frames to eliminate AGC brightness jumps and temporal flicker during scene pans or transient flares.
3. **`exp3_blended_clahe_monotonic` (Monotonic Anchor + Contrast-Limited Local Histogram Blend)**:
   - Blends $(1 - \alpha)$ of the Global Monotonic Anchor (`exp2`) with $\alpha \in [0, 0.5]$ of Contrast-Limited Local Histogram Equalization (configurable `4×4` to `12×12` tiles and clip limit `1.2..4.0`), plus noise-cored guided detail. Explicitly labeled as an **Interpretive Local-Contrast View** with live tracking of any local brightness ordering inversions.
4. **`exp4_causal_temporal_stabilized` (Strictly Causal Motion-Gated Temporal Filter + Warm-Up & Scene Reset)**:
   - Uses strictly past frames ($t - 1, t - 2, t - 3$, zero future frame look-ahead), a declared 8-frame warm-up indicator, automatic reset on file changes or non-consecutive frame seeks, and a per-pixel radiometric motion gate ($\Delta\text{ADU} > \text{gate} \implies w_{\text{temporal}} = 0$) that prevents ghost trails behind moving animals while stabilizing static bridge structures.

---

## 4. Reproducible Evaluation Commands & Contiguous Holdout Protocol

To run the standalone verification and type/build suite from the project root:

```bash
npx next typegen
npm exec tsc -- --noEmit --pretty false
npm run build
```

### Contiguous Time-Block Protocol (Single-File Exploratory Split)
- **Development Block**: Frames `[0..19]` (used for parameter inspection and ablation).
- **Temporal Exclusion Buffer**: Frames `[20..24]` (5-frame guard band excluded from evaluation so multi-frame windows and IIR states cannot leak from Development into Holdout).
- **Frozen Held-Out Evaluation Block**: Frames `[25..29]` across all 6 synthetic scenarios (results labeled exploratory for single-recording time splits).

---

## 5. Side-by-Side Recommendation by Use Case

1. **For Comparing Relative Radiometric Signal Ordering (Animal vs. Bridge Brightness Verification)**:
   - **Recommended**: **`exp2_global_monotonic_locked`** (with Locked Manual ADU Window or `p2..p99.2` + logarithmic highlight knee) alongside **`raw_monotonic`**.
   - **Evidence**: Preserves 100% of global intensity ordering (0 monotonicity inversions) and retains ~17.5 gray levels of Animal-vs-Bridge separation where original `argos_2` collapses separation to ~0.8 gray levels due to `p97.5` highlight clipping.
2. **For Interpretive Structural & Animal Detail Enhancement (Single-Frame / Live Causal)**:
   - **Recommended**: **`exp1_argos2_radiometric`** (or **`exp4_causal_temporal_stabilized`** on sequential video with warm-up).
   - **Evidence**: Builds directly on the user's preferred `argos_2` visual aesthetic while fixing its two verified flaws: (a) replaces the `<180 ADU` cross-pixel gate with along-stripe segment gating (reducing ±150 ADU stripe RMSE from `150.2 ADU` to `< 5.2 ADU`), and (b) prevents warm animals and bridge decks from saturating into the same highlight bin while retaining `>84%` contrast on 1px structural wires.
3. **Is CNN Training Justified by Current Evidence?**
   - **No — not on current evidence.** Argos's in-browser trainer only perturbs 4 scalar mixing weights via finite differences on a 64×64 synthetic patch, and Claude's TF.js models train purely on synthetic noise without real sensor ground truth. Until curated multi-recording real thermal datasets split strictly by **recording / environment / camera instance** (with verified clean targets, not naive adjacent-frame Noise2Noise where fixed-pattern stripes persist across frames) are available, **keep CNN disabled by default** and rely on transparent, auditable classical stages.
