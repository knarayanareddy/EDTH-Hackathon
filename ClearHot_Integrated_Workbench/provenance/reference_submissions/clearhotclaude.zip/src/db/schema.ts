import { integer, jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

// Metadata + numeric ROI measurements only. Pixel data and the thermal file itself are never stored.
export const measurementRecords = pgTable("measurement_records", {
  id: serial("id").primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  sourceKind: text("source_kind").notNull(), // "file" | "synthetic"
  fileName: text("file_name"),
  fileSize: text("file_size"),
  fileSha256: text("file_sha256"), // computed locally in the browser, optional
  frameIndex: integer("frame_index").notNull(),
  algoVersion: text("algo_version").notNull(),
  decoder: jsonb("decoder").notNull(),
  config: jsonb("config").notNull(),
  rois: jsonb("rois").notNull(),
  results: jsonb("results").notNull(),
  note: text("note"),
});

export type MeasurementRecord = typeof measurementRecords.$inferSelect;
