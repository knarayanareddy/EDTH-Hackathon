"use client";

import Link from "next/link";
import { useCallback, useDeferredValue, useEffect, useMemo, useRef, useState } from "react";
import {
  DEFAULT_DECODE,
  diagnoseFormat,
  frameCountFor,
  maxCode as maxCodeOf,
  readFrame,
  sha256File,
  type DecodeConfig,
  type FormatDiagnostic,
} from "@/lib/clearhot/decode";
import { cloneTemporal, freshTemporal, type TemporalState } from "@/lib/clearhot/dsp";
import {
  ALGO_VERSION,
  DEFAULT_CONFIG,
  cloneConfig,
  frameStats,
  referenceDisplay,
  runPipeline,
  type PipelineConfig,
  type PipelineResult,
} from "@/lib/clearhot/pipeline";
import { computeRows, type Roi, type RoiRole } from "@/lib/clearhot/roi";
import { SCENARIOS, generateScene } from "@/lib/clearhot/synth";
import { AblationPanel } from "./AblationPanel";
import { BenchPanel } from "./BenchPanel";
import { CanvasPane } from "./CanvasPane";
import { Controls } from "./Controls";
import { RoiPanel } from "./RoiPanel";
import { Badge, Btn, Check, NumInput, Panel, Select, fmt } from "./ui";

type Source = { kind: "file"; file: File } | { kind: "synthetic" };
type Tab = "viewer" | "ablation" | "bench" | "latency";

interface RawFrame {
  data: Uint16Array;
  index: number;
  sourceKey: string;
  w: number;
  h: number;
}

interface ViewState {
  res: PipelineResult;
  ref8: Uint8Array;
  raw: RawFrame;
  resetReason: string | null;
}

interface TRef {
  state: TemporalState;
  snapshot: TemporalState | null;
  lastIdx: number;
}

const SYN_FRAMES = 32;

export default function Lab() {
  const [source, setSource] = useState<Source>({ kind: "synthetic" });
  const [decode, setDecode] = useState<DecodeConfig>(DEFAULT_DECODE);
  const [scenarioId, setScenarioId] = useState(SCENARIOS[5].id);
  const [seed, setSeed] = useState(1);
  const [frameIdx, setFrameIdx] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [fps, setFps] = useState(5);
  const [rawFrame, setRawFrame] = useState<RawFrame | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [cfg, setCfg] = useState<PipelineConfig>(() => ({ ...cloneConfig(DEFAULT_CONFIG), tone: { ...DEFAULT_CONFIG.tone, fixedLo: 5200, fixedHi: 7600 } }));
  const deferredCfg = useDeferredValue(cfg);
  const [view, setView] = useState<ViewState | null>(null);
  const [rois, setRois] = useState<Roi[]>([]);
  const [activeRole, setActiveRole] = useState<RoiRole>("animal");
  const [invert, setInvert] = useState(false);
  const [showDiff, setShowDiff] = useState(false);
  const [tab, setTab] = useState<Tab>("viewer");
  const [sha, setSha] = useState<string | null>(null);
  const [shaProg, setShaProg] = useState<number | null>(null);
  const [diag, setDiag] = useState<FormatDiagnostic | null>(null);
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState<string | null>(null);
  const [lat, setLat] = useState<{ stage: string; p50: number; p95: number }[] | null>(null);
  const [latBusy, setLatBusy] = useState(false);

  const roiCounter = useRef(0);
  const tRef = useRef<TRef>({ state: freshTemporal(), snapshot: null, lastIdx: -1 });
  const autoWindow = useRef(true);
  const synthTruth = useRef<Roi[]>([]);

  const dims = source.kind === "file" ? { w: decode.width, h: decode.height } : { w: 640, h: 512 };
  const maxCode = maxCodeOf(decode);
  const decodeKey = JSON.stringify(decode);
  const sourceKey = source.kind === "file" ? `file:${source.file.name}:${source.file.size}:${source.file.lastModified}` : `synthetic:${scenarioId}:${seed}`;
  const { frames, remainder } = source.kind === "file" ? frameCountFor(source.file.size, decode) : { frames: SYN_FRAMES, remainder: 0 };
  const safeIdx = Math.min(frameIdx, Math.max(0, frames - 1));

  // ---------- load frame ----------
  useEffect(() => {
    let dead = false;
    (async () => {
      try {
        if (frames <= 0) {
          setRawFrame(null);
          setError(source.kind === "file" ? "File is smaller than one frame with the current decoder settings." : null);
          return;
        }
        let data: Uint16Array;
        if (source.kind === "file") {
          data = await readFrame(source.file, decode, safeIdx);
        } else {
          const sc = SCENARIOS.find((s) => s.id === scenarioId) ?? SCENARIOS[0];
          const scene = generateScene(sc, seed + safeIdx * 101, 640, 512);
          synthTruth.current = scene.rois;
          data = scene.noisy;
        }
        if (dead) return;
        setError(null);
        setRawFrame({ data, index: safeIdx, sourceKey: sourceKey + "|" + decodeKey, w: dims.w, h: dims.h });
      } catch (e) {
        if (!dead) setError(e instanceof Error ? e.message : String(e));
      }
    })();
    return () => {
      dead = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [source, decodeKey, safeIdx, scenarioId, seed, frames]);

  const stats = useMemo(() => (rawFrame ? frameStats(rawFrame.data) : null), [rawFrame]);

  // auto-suggest a fixed window ONCE per newly loaded source (user can change/lock it afterwards)
  useEffect(() => {
    if (stats && autoWindow.current) {
      autoWindow.current = false;
      const pad = Math.max(50, Math.round((stats.p99 - stats.p1) * 0.1));
      setCfg((c) => {
        const n = cloneConfig(c);
        n.tone.fixedLo = Math.max(0, stats.p1 - pad);
        n.tone.fixedHi = Math.min(16383, Math.max(stats.p99 + pad, n.tone.fixedLo + 20));
        return n;
      });
    }
  }, [stats]);

  // ---------- process ----------
  useEffect(() => {
    if (!rawFrame) return;
    const t = tRef.current;
    const tKey = JSON.stringify({ s: rawFrame.sourceKey, line: deferredCfg.line, tp: deferredCfg.temporal });
    let reason: string | null = null;
    if (t.state.key !== tKey) {
      t.state = freshTemporal(tKey);
      t.snapshot = freshTemporal(tKey);
      t.lastIdx = -1;
      reason = "source/decoder/line/temporal settings changed";
    }
    if (rawFrame.index === t.lastIdx && t.snapshot) {
      t.state = cloneTemporal(t.snapshot);
    } else if (rawFrame.index === t.lastIdx + 1) {
      t.snapshot = cloneTemporal(t.state);
    } else {
      if (t.lastIdx >= 0 && !reason) reason = "non-consecutive seek";
      t.state = freshTemporal(tKey);
      t.snapshot = freshTemporal(tKey);
    }
    const res = runPipeline(rawFrame.data, rawFrame.w, rawFrame.h, deferredCfg, t.state);
    t.lastIdx = rawFrame.index;
    const ref8 = referenceDisplay(rawFrame.data, deferredCfg);
    setView({ res, ref8, raw: rawFrame, resetReason: reason });
  }, [rawFrame, deferredCfg]);

  // ---------- playback ----------
  useEffect(() => {
    if (!playing || frames <= 1) return;
    const id = setInterval(() => setFrameIdx((i) => (i + 1 >= frames ? 0 : i + 1)), 1000 / fps);
    return () => clearInterval(id);
  }, [playing, fps, frames]);

  // ---------- derived ----------
  const metrics = useMemo(() => {
    if (!view) return { rows: [], pairs: [] };
    return computeRows(rois, view.raw.w, view.raw.h, view.raw.data, view.res.corrected, view.ref8, view.res.display, maxCode);
  }, [view, rois, maxCode]);

  const diffImg = useMemo(() => {
    if (!view) return null;
    const d = new Uint8Array(view.res.display.length);
    for (let i = 0; i < d.length; i++) d[i] = Math.max(0, Math.min(255, 128 + 4 * (view.res.display[i] - view.ref8[i])));
    return d;
  }, [view]);

  // ---------- actions ----------
  const chooseFile = (f: File | null) => {
    if (!f) return;
    setSource({ kind: "file", file: f });
    setFrameIdx(0);
    setPlaying(false);
    setSha(null);
    setDiag(null);
    setRois([]);
    autoWindow.current = true;
  };

  const useSynthetic = () => {
    setSource({ kind: "synthetic" });
    setFrameIdx(0);
    setPlaying(false);
    setSha(null);
    setDiag(null);
    autoWindow.current = true;
  };

  const addRoi = (r: { x: number; y: number; w: number; h: number }) => {
    roiCounter.current++;
    setRois((prev) => {
      const n = prev.filter((q) => q.role === activeRole).length + 1;
      return [...prev, { id: `r${roiCounter.current}`, role: activeRole, label: `${activeRole} ${n}`, ...r }];
    });
  };

  const setWindowFromFrame = () => {
    if (!stats) return;
    const pad = Math.max(50, Math.round((stats.p99 - stats.p1) * 0.1));
    setCfg((c) => {
      const n = cloneConfig(c);
      n.tone.mode = "fixed";
      n.tone.fixedLo = Math.max(0, stats.p1 - pad);
      n.tone.fixedHi = Math.min(16383, Math.max(stats.p99 + pad, n.tone.fixedLo + 20));
      return n;
    });
  };

  const computeSha = async () => {
    if (source.kind !== "file") return;
    setShaProg(0);
    try {
      setSha(await sha256File(source.file, setShaProg));
    } finally {
      setShaProg(null);
    }
  };

  const runDiag = async () => {
    if (source.kind !== "file") return;
    setDiag(await diagnoseFormat(source.file, decode, safeIdx));
  };

  const saveRecord = async () => {
    if (!view) return;
    setSaving(true);
    setSaveMsg(null);
    try {
      const results = {
        units: "raw/corrected values are sensor ADU counts (NOT temperature); disp values are 8-bit display levels",
        frameStats: stats,
        tone: view.res.tone,
        clip: { adu_below_window: view.res.clipLowFrac, adu_above_window: view.res.clipHighFrac, disp0: view.res.sat0Frac, disp255: view.res.sat255Frac },
        noiseSigmaAdu: view.res.noiseSigma,
        rows: metrics.rows.map((r) => ({
          label: r.roi.label,
          role: r.roi.role,
          background: r.bg?.label ?? null,
          size: { w: r.roi.w, h: r.roi.h, pixels: r.raw.n },
          raw: r.raw,
          corrected: r.corrected,
          refDisplay: r.refDisp,
          procDisplay: r.procDisp,
          cnr: { raw: r.cnrRaw, corrected: r.cnrCorrected, ref: r.cnrRef, proc: r.cnrProc },
        })),
        pairs: metrics.pairs.map((p) => ({ animal: p.animal.label, bridge: p.bridge.label, rawDelta: p.rawDelta, rawSpread: p.rawSpread, rawRatio: p.rawRatio, refDelta: p.refDelta, procDelta: p.procDelta, verdict: p.verdict })),
      };
      const res = await fetch("/api/records", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sourceKind: source.kind,
          fileName: source.kind === "file" ? source.file.name : `synthetic:${scenarioId}:seed${seed}`,
          fileSize: source.kind === "file" ? String(source.file.size) : null,
          fileSha256: sha,
          frameIndex: safeIdx,
          algoVersion: ALGO_VERSION,
          decoder: source.kind === "file" ? decode : { synthetic: true, width: 640, height: 512 },
          config: cfg,
          rois,
          results,
          note: note || null,
        }),
      });
      setSaveMsg(res.ok ? "Saved. See Records." : `Save failed (${res.status})`);
    } catch (e) {
      setSaveMsg(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const measureLatency = useCallback(() => {
    if (!rawFrame) return;
    setLatBusy(true);
    setLat(null);
    setTimeout(() => {
      const N = 20;
      const samples: Record<string, number[]> = { line: [], detail: [], tone: [], clahe: [], total: [] };
      runPipeline(rawFrame.data, rawFrame.w, rawFrame.h, cfg); // warm-up
      for (let i = 0; i < N; i++) {
        const r = runPipeline(rawFrame.data, rawFrame.w, rawFrame.h, cfg);
        for (const k of Object.keys(samples)) samples[k].push(r.timingsMs[k as keyof typeof r.timingsMs]);
      }
      const q = (a: number[], p: number) => [...a].sort((x, y) => x - y)[Math.min(a.length - 1, Math.floor(p * a.length))];
      setLat(Object.entries(samples).map(([stage, a]) => ({ stage, p50: q(a, 0.5), p95: q(a, 0.95) })));
      setLatBusy(false);
    }, 30);
  }, [rawFrame, cfg]);

  const heap = typeof performance !== "undefined" ? (performance as unknown as { memory?: { usedJSHeapSize: number; jsHeapSizeLimit: number } }).memory : undefined;

  const downloadSession = () => {
    const payload = {
      algoVersion: ALGO_VERSION,
      source: source.kind === "file" ? { name: source.file.name, size: source.file.size, sha256: sha } : { synthetic: true, scenarioId, seed },
      decoder: decode,
      frameIndex: safeIdx,
      config: cfg,
      rois,
      note: "Decoder parameters are hypotheses until confirmed against the sensor/file spec.",
    };
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "clearhot_session.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const res = view?.res;
  const temporalMsg = !cfg.temporal.on
    ? "off"
    : res?.temporal.used
      ? `${res.temporal.frames} frame(s) accumulated · ${(res.temporal.movingFrac * 100).toFixed(1)}% pixels gated as moving${view?.resetReason ? ` · reset: ${view.resetReason}` : ""}`
      : "waiting for a frame";

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-200">
      <header className="sticky top-0 z-20 border-b border-zinc-800 bg-zinc-950/95 px-4 py-2 backdrop-blur">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center gap-3">
          <h1 className="text-sm font-bold tracking-tight text-white">
            ClearHot Lab <span className="font-normal text-zinc-500">· experimental · {ALGO_VERSION}</span>
          </h1>
          <Badge tone="emerald">local only — files never leave this browser</Badge>
          <Badge tone="amber">display intensity ≠ temperature</Badge>
          <Badge>CNN: not implemented (off)</Badge>
          <nav className="ml-auto flex gap-3 text-xs">
            <Link href="/audit" className="text-zinc-400 hover:text-white">
              Audit &amp; limits
            </Link>
            <Link href="/records" className="text-zinc-400 hover:text-white">
              Records
            </Link>
          </nav>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1600px] gap-4 p-4 lg:grid-cols-[340px_1fr]">
        {/* ---------------- left column ---------------- */}
        <aside className="space-y-3">
          <Panel title="Source (local)">
            <div className="space-y-2">
              <label className="block text-xs text-zinc-400">
                Headerless uint16 thermal file
                <input type="file" className="mt-1 block w-full text-xs file:mr-2 file:rounded file:border-0 file:bg-zinc-700 file:px-2 file:py-1 file:text-zinc-100" onChange={(e) => chooseFile(e.target.files?.[0] ?? null)} />
              </label>
              <p className="text-[10px] text-zinc-500">Read frame-by-frame with File.slice(); never uploaded. Only one frame (~{((decode.width * decode.height * 2) / 1048576).toFixed(2)} MiB) plus working buffers is held at a time.</p>

              <div className="rounded border border-zinc-800 p-2">
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-zinc-300">Decoder (hypotheses)</span>
                  <Badge tone="amber">unconfirmed</Badge>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <NumInput label="Width" value={decode.width} min={1} onChange={(v) => setDecode((d) => ({ ...d, width: Math.max(1, Math.round(v)) }))} />
                  <NumInput label="Height" value={decode.height} min={1} onChange={(v) => setDecode((d) => ({ ...d, height: Math.max(1, Math.round(v)) }))} />
                  <NumInput label="Header bytes" value={decode.headerBytes} min={0} onChange={(v) => setDecode((d) => ({ ...d, headerBytes: Math.max(0, Math.round(v)) }))} />
                  <NumInput label="Bits kept" value={decode.bits} min={8} max={16} onChange={(v) => setDecode((d) => ({ ...d, bits: Math.min(16, Math.max(8, Math.round(v))) }))} />
                  <NumInput label="Right shift" value={decode.shift} min={0} max={8} onChange={(v) => setDecode((d) => ({ ...d, shift: Math.min(8, Math.max(0, Math.round(v))) }))} />
                  <div className="flex items-end pb-1">
                    <Check label="Little-endian" checked={decode.littleEndian} onChange={(v) => setDecode((d) => ({ ...d, littleEndian: v }))} />
                  </div>
                </div>
                {source.kind === "file" && (
                  <p className="mt-2 text-[10px] text-zinc-400">
                    {source.file.size.toLocaleString()} bytes → {frames} frame(s)
                    {remainder ? <span className="text-amber-300"> + {remainder.toLocaleString()} leftover bytes (size does not divide evenly: format suspect)</span> : null}. A matching size does not prove the format.
                  </p>
                )}
                {source.kind === "file" && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Btn onClick={runDiag}>Format hints (this frame)</Btn>
                    <Btn onClick={computeSha} disabled={shaProg !== null}>
                      {shaProg !== null ? `SHA-256 ${(shaProg * 100).toFixed(0)}%` : "SHA-256 (local)"}
                    </Btn>
                  </div>
                )}
                {diag && (
                  <div className="mt-2 rounded bg-zinc-950 p-2 font-mono text-[10px] leading-relaxed text-zinc-400">
                    <div>LE: bits≥{decode.bits} set in {(diag.littleEndian.highBitFraction * 100).toFixed(1)}% · neighbour Δ {diag.littleEndian.meanAbsNeighbourDiff.toFixed(0)}</div>
                    <div>BE: bits≥{decode.bits} set in {(diag.bigEndian.highBitFraction * 100).toFixed(1)}% · neighbour Δ {diag.bigEndian.meanAbsNeighbourDiff.toFixed(0)}</div>
                    <div className="mt-1 font-sans text-zinc-500">{diag.note}</div>
                  </div>
                )}
                {sha && <div className="mt-2 break-all font-mono text-[10px] text-zinc-500">sha256 {sha}</div>}
              </div>

              <div className="rounded border border-zinc-800 p-2">
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-zinc-300">Synthetic scene (known truth)</span>
                  <Badge tone="amber">synthetic</Badge>
                </div>
                <Select value={scenarioId} label="Scenario" options={SCENARIOS.map((s) => ({ value: s.id, label: s.name }))} onChange={(v) => { setScenarioId(v); autoWindow.current = true; }} />
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <NumInput label="Seed" value={seed} onChange={(v) => setSeed(Math.max(1, Math.round(v)))} />
                  <div className="flex items-end gap-1 pb-0.5">
                    <Btn onClick={useSynthetic} tone={source.kind === "synthetic" ? "primary" : "default"}>
                      {source.kind === "synthetic" ? "In use" : "Use synthetic"}
                    </Btn>
                  </div>
                </div>
                {source.kind === "synthetic" && (
                  <div className="mt-2">
                    <Btn onClick={() => setRois(synthTruth.current.map((r) => ({ ...r, id: `${r.id}-${Date.now()}` })))}>Load truth ROIs</Btn>
                  </div>
                )}
              </div>
            </div>
          </Panel>

          <Controls cfg={cfg} setCfg={(f) => setCfg((c) => f(c))} frameStats={stats} toneReport={res?.toneReport ?? null} onWindowFromFrame={setWindowFromFrame} />
        </aside>

        {/* ---------------- right column ---------------- */}
        <main className="min-w-0 space-y-4">
          <div className="flex flex-wrap items-center gap-2 rounded-lg border border-zinc-800 bg-zinc-900/70 px-3 py-2">
            <Btn onClick={() => setPlaying((p) => !p)} disabled={frames <= 1}>
              {playing ? "❚❚ Pause" : "▶ Play"}
            </Btn>
            <Btn onClick={() => setFrameIdx(Math.max(0, safeIdx - 1))} disabled={safeIdx <= 0}>
              ◀
            </Btn>
            <Btn onClick={() => setFrameIdx(Math.min(frames - 1, safeIdx + 1))} disabled={safeIdx >= frames - 1}>
              ▶
            </Btn>
            <input type="range" className="min-w-[160px] flex-1 accent-emerald-500" min={0} max={Math.max(0, frames - 1)} value={safeIdx} onChange={(e) => { setPlaying(false); setFrameIdx(Number(e.target.value)); }} />
            <span className="font-mono text-xs text-zinc-300">
              frame {safeIdx} / {Math.max(0, frames - 1)}
            </span>
            <label className="text-xs text-zinc-400">
              fps{" "}
              <select className="rounded border border-zinc-700 bg-zinc-950 px-1 py-0.5" value={fps} onChange={(e) => setFps(Number(e.target.value))}>
                {[1, 2, 5, 10, 25].map((n) => (
                  <option key={n}>{n}</option>
                ))}
              </select>
            </label>
            <Check label="Invert (black-hot)" checked={invert} onChange={setInvert} />
            <Check label="Difference view" checked={showDiff} onChange={setShowDiff} />
            <Btn onClick={downloadSession}>Export session JSON</Btn>
          </div>
          {error && <div className="rounded border border-red-800 bg-red-950/50 p-2 text-xs text-red-200">{error}</div>}

          <div className="flex gap-1 border-b border-zinc-800">
            {(
              [
                ["viewer", "Viewer & ROI"],
                ["ablation", "Ablation"],
                ["bench", "Synthetic benchmark"],
                ["latency", "Latency & memory"],
              ] as [Tab, string][]
            ).map(([id, label]) => (
              <button key={id} onClick={() => setTab(id)} className={`rounded-t px-3 py-1.5 text-xs font-medium ${tab === id ? "bg-zinc-800 text-white" : "text-zinc-400 hover:text-white"}`}>
                {label}
              </button>
            ))}
          </div>

          {tab === "viewer" && (
            <>
              <div className={`grid gap-3 ${showDiff ? "xl:grid-cols-3" : "md:grid-cols-2"}`}>
                <CanvasPane
                  title="A · Reference: raw ADU, fixed window"
                  subtitle={`Global linear monotone map, ${cfg.tone.fixedLo}–${cfg.tone.fixedHi} ADU → 0–255. No spatial processing. Display level, not temperature.`}
                  data={view?.ref8 ?? null}
                  w={dims.w}
                  h={dims.h}
                  invert={invert}
                  rois={rois}
                  onDraw={addRoi}
                  badge="raw"
                />
                <CanvasPane
                  title="B · Processed (interpretive)"
                  subtitle={`Line: ${cfg.line.mode} · detail: ${cfg.detail.on ? "on" : "off"} · CLAHE: ${cfg.clahe.on ? "on" : "off"} · temporal: ${temporalMsg}`}
                  data={res?.display ?? null}
                  w={dims.w}
                  h={dims.h}
                  invert={invert}
                  rois={rois}
                  onDraw={addRoi}
                  badge={res ? `${res.tone.lo.toFixed(0)}–${res.tone.hi.toFixed(0)} ADU` : undefined}
                />
                {showDiff && (
                  <CanvasPane title="C · Processed − reference (×4)" subtitle="Mid-grey = no change. Brighter/darker = processing raised/lowered the display level. Shows halos, overshoot, over-correction." data={diffImg} w={dims.w} h={dims.h} invert={false} rois={rois} onDraw={addRoi} />
                )}
              </div>

              {res && (
                <div className="grid grid-cols-2 gap-2 text-[11px] md:grid-cols-4">
                  {[
                    ["ADU below window", `${fmt(res.clipLowFrac * 100, 1)}%`],
                    ["ADU above window", `${fmt(res.clipHighFrac * 100, 1)}%`],
                    ["Display 0 / 255", `${fmt(res.sat0Frac * 100, 1)}% / ${fmt(res.sat255Frac * 100, 1)}%`],
                    ["Noise σ (robust est.)", `${fmt(res.noiseSigma, 1)} ADU`],
                    ["Pipeline time", `${fmt(res.timingsMs.total, 0)} ms (this run)`],
                    ["Temporal", temporalMsg],
                    ["Col profile range", res.profiles.col ? `${fmt(Math.min(...res.profiles.col), 0)}…${fmt(Math.max(...res.profiles.col), 0)} ADU` : "—"],
                    ["Row profile range", res.profiles.row ? `${fmt(Math.min(...res.profiles.row), 0)}…${fmt(Math.max(...res.profiles.row), 0)} ADU` : "—"],
                  ].map(([k, v]) => (
                    <div key={k} className="rounded border border-zinc-800 bg-zinc-900/60 px-2 py-1">
                      <div className="text-zinc-500">{k}</div>
                      <div className="font-mono text-zinc-200">{v}</div>
                    </div>
                  ))}
                </div>
              )}

              <RoiPanel
                rows={metrics.rows}
                pairs={metrics.pairs}
                rois={rois}
                activeRole={activeRole}
                setActiveRole={setActiveRole}
                onDelete={(id) => setRois((p) => p.filter((r) => r.id !== id))}
                onClear={() => setRois([])}
                onSave={saveRecord}
                saving={saving}
                saveMsg={saveMsg}
                note={note}
                setNote={setNote}
              />
            </>
          )}

          {tab === "ablation" && (
            <>
              <AblationPanel
                raw={rawFrame?.data ?? null}
                w={dims.w}
                h={dims.h}
                cfg={cfg}
                rois={rois}
                invert={invert}
                rawKey={rawFrame ? `${rawFrame.sourceKey}#${rawFrame.index}` : ""}
                satHigh={maxCode}
              />
              <p className="text-[11px] text-zinc-500">Draw animal/bridge ROIs in the Viewer tab first. ROIs are shared across tabs.</p>
            </>
          )}

          {tab === "bench" && <BenchPanel />}

          {tab === "latency" && (
            <Panel title="Latency & memory (this device, this build)" right={<Btn tone="primary" onClick={measureLatency} disabled={!rawFrame || latBusy}>{latBusy ? "Measuring…" : "Measure 20 runs"}</Btn>}>
              <p className="mb-2 text-[11px] leading-relaxed text-zinc-400">
                Times the JavaScript pipeline on the current {dims.w}×{dims.h} frame with current settings (temporal stage excluded; main thread; no decode/IO/draw). 25 fps requires the whole system to
                sustain a 40 ms frame budget — this is only one step of it, and says nothing about FPGA feasibility.
              </p>
              {lat && (
                <table className="mb-2 text-xs">
                  <thead className="text-zinc-500">
                    <tr>
                      <th className="pr-6 text-left">Stage</th>
                      <th className="pr-6 text-left">p50 ms</th>
                      <th className="text-left">p95 ms</th>
                    </tr>
                  </thead>
                  <tbody className="font-mono">
                    {lat.map((r) => (
                      <tr key={r.stage}>
                        <td className="pr-6">{r.stage}</td>
                        <td className="pr-6">{fmt(r.p50, 1)}</td>
                        <td>{fmt(r.p95, 1)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
              <div className="space-y-0.5 font-mono text-[11px] text-zinc-400">
                <div>logical cores: {typeof navigator !== "undefined" ? navigator.hardwareConcurrency : "?"}</div>
                <div>JS heap now: {heap ? `${(heap.usedJSHeapSize / 1048576).toFixed(0)} MiB (limit ${(heap.jsHeapSizeLimit / 1048576).toFixed(0)} MiB)` : "not exposed by this browser"}</div>
                <div>bytes read per frame: {(dims.w * dims.h * 2).toLocaleString()} (file is sliced, never fully loaded)</div>
                <div className="break-all">user agent: {typeof navigator !== "undefined" ? navigator.userAgent : "?"}</div>
              </div>
            </Panel>
          )}
        </main>
      </div>
    </div>
  );
}
