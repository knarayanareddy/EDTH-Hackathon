"use client";

import { useState } from "react";
import { runBenchmark, type BenchReport } from "@/lib/clearhot/bench";
import { Badge, Btn, Panel, fmt } from "./ui";

function download(name: string, text: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

export function BenchPanel() {
  const [seeds, setSeeds] = useState(3);
  const [size, setSize] = useState<"640x512" | "320x256">("320x256");
  const [busy, setBusy] = useState(false);
  const [prog, setProg] = useState(0);
  const [rep, setRep] = useState<BenchReport | null>(null);
  const [split, setSplit] = useState<"development" | "held-out">("held-out");

  const run = async () => {
    setBusy(true);
    setProg(0);
    const [w, h] = size.split("x").map(Number);
    const r = await runBenchmark(seeds, { w, h }, setProg);
    setRep(r);
    setBusy(false);
  };

  const rows = rep?.rows.filter((r) => r.split === split) ?? [];
  const scenarios = Array.from(new Set(rows.map((r) => r.scenarioId)));

  const csv = () => {
    if (!rep) return;
    const head = "split,scenario,variant,n,psnr_mean,psnr_sd,stripeRms_mean,stripeRms_sd,thinRetention_mean,thinRetention_sd,changeRms_mean,changeRms_sd";
    const lines = rep.rows.map((r) =>
      [r.split, r.scenarioId, r.variantId, r.n, r.mean.psnr, r.sd.psnr, r.mean.stripeRms, r.sd.stripeRms, r.mean.thinRetention, r.sd.thinRetention, r.mean.changeRms, r.sd.changeRms].join(","),
    );
    download("clearhot_synthetic_benchmark.csv", [head, ...lines].join("\n"), "text/csv");
  };

  return (
    <Panel title="Synthetic benchmark (known ground truth)" right={<Badge tone="amber">synthetic only</Badge>}>
      <p className="mb-3 text-[11px] leading-relaxed text-zinc-400">
        Frozen configurations are scored on generated scenes with disjoint seed blocks (development: 1…n, held-out: 1001…). Because generator, layout and noise model are shared, held-out here means
        <i> unseen seeds</i>, not unseen scenes or devices. No ground-truth PSNR is ever computed for your real file. Only ADU-domain stages are scored; display transforms are excluded.
      </p>
      <div className="mb-3 flex flex-wrap items-end gap-3">
        <label className="text-xs text-zinc-400">
          Seeds per split
          <select className="ml-2 rounded border border-zinc-700 bg-zinc-950 px-1 py-0.5 text-zinc-100" value={seeds} onChange={(e) => setSeeds(Number(e.target.value))}>
            {[2, 3, 5, 8].map((n) => (
              <option key={n}>{n}</option>
            ))}
          </select>
        </label>
        <label className="text-xs text-zinc-400">
          Size
          <select className="ml-2 rounded border border-zinc-700 bg-zinc-950 px-1 py-0.5 text-zinc-100" value={size} onChange={(e) => setSize(e.target.value as "640x512" | "320x256")}>
            <option>320x256</option>
            <option>640x512</option>
          </select>
        </label>
        <Btn tone="primary" onClick={run} disabled={busy}>
          {busy ? `Running ${(prog * 100).toFixed(0)}%` : "Run benchmark"}
        </Btn>
        {rep && (
          <>
            <Btn onClick={() => download("clearhot_synthetic_benchmark.json", JSON.stringify(rep, null, 2), "application/json")}>Download JSON</Btn>
            <Btn onClick={csv}>Download CSV</Btn>
          </>
        )}
      </div>

      {rep && (
        <>
          <div className="mb-2 flex gap-2">
            {(["development", "held-out"] as const).map((s) => (
              <button key={s} onClick={() => setSplit(s)} className={`rounded px-2 py-1 text-xs ${split === s ? "bg-zinc-700 text-white" : "bg-zinc-900 text-zinc-400 hover:bg-zinc-800"}`}>
                {s}
              </button>
            ))}
            <span className="self-center text-[10px] text-zinc-500">
              {rep.algoVersion} · {rep.size.w}×{rep.size.h} · n={rows[0]?.n ?? 0} per cell · mean ± sd
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-[11px]">
              <thead className="text-zinc-500">
                <tr className="border-b border-zinc-800">
                  <th className="py-1 pr-2">Scenario</th>
                  <th className="pr-2">Variant</th>
                  <th className="pr-2">PSNR dB ↑</th>
                  <th className="pr-2">Stripe RMS ADU ↓</th>
                  <th className="pr-2">Thin retention (1 = kept)</th>
                  <th className="pr-2">Change vs input RMS</th>
                </tr>
              </thead>
              <tbody className="font-mono text-zinc-200">
                {scenarios.flatMap((sc) =>
                  rows
                    .filter((r) => r.scenarioId === sc)
                    .map((r, i) => (
                      <tr key={sc + r.variantId} className={`${i === 0 ? "border-t border-zinc-700" : ""}`}>
                        <td className="py-0.5 pr-2 font-sans text-zinc-400">{i === 0 ? r.scenarioName : ""}</td>
                        <td className="pr-2 font-sans">{r.variantLabel}</td>
                        <td className="pr-2">
                          {fmt(r.mean.psnr, 1)} ± {fmt(r.sd.psnr, 1)}
                        </td>
                        <td className="pr-2">
                          {fmt(r.mean.stripeRms, 1)} ± {fmt(r.sd.stripeRms, 1)}
                        </td>
                        <td className={`pr-2 ${r.mean.thinRetention < 0.95 ? "text-amber-300" : ""}`}>
                          {fmt(r.mean.thinRetention, 2)} ± {fmt(r.sd.thinRetention, 2)}
                        </td>
                        <td className="pr-2">{fmt(r.mean.changeRms, 1)}</td>
                      </tr>
                    )),
                )}
              </tbody>
            </table>
          </div>
          <ul className="mt-3 list-disc space-y-0.5 pl-4 text-[10px] text-zinc-500">
            {rep.caveats.map((c) => (
              <li key={c}>{c}</li>
            ))}
          </ul>
        </>
      )}
    </Panel>
  );
}
