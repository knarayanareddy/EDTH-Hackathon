"use client";

import { useEffect, useRef, useState } from "react";
import { ablationStages, runPipeline, type PipelineConfig, type PipelineResult } from "@/lib/clearhot/pipeline";
import { roiStats, type Roi } from "@/lib/clearhot/roi";
import { drawGray } from "./CanvasPane";
import { Btn, Check, Panel, fmt } from "./ui";

interface StageOut {
  id: string;
  label: string;
  note: string;
  res: PipelineResult;
  meanAbsDiff: number;
  pctDiff8: number;
  pairDisp: number | null;
  pairAduRatio: number | null;
  diffImg: Uint8Array;
}

function Thumb({ data, w, h, invert }: { data: Uint8Array; w: number; h: number; invert: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (ref.current) drawGray(ref.current, data, w, h, invert);
  }, [data, w, h, invert]);
  return <canvas ref={ref} className="block w-full rounded border border-zinc-700" style={{ aspectRatio: `${w}/${h}`, imageRendering: "pixelated" }} />;
}

export function AblationPanel({
  raw,
  w,
  h,
  cfg,
  rois,
  invert,
  rawKey,
  satHigh,
}: {
  raw: Uint16Array | null;
  w: number;
  h: number;
  cfg: PipelineConfig;
  rois: Roi[];
  invert: boolean;
  rawKey: string;
  satHigh: number;
}) {
  const [out, setOut] = useState<{ key: string; stages: StageOut[]; rawRatio: number | null } | null>(null);
  const [busy, setBusy] = useState(false);
  const [showDiff, setShowDiff] = useState(false);

  const run = () => {
    if (!raw) return;
    setBusy(true);
    setTimeout(() => {
      const stages = ablationStages(cfg);
      const results = stages.map((s) => ({ s, res: runPipeline(raw, w, h, s.cfg) }));
      const ref = results[0].res.display;
      const animal = rois.find((r) => r.role === "animal");
      const bridge = rois.find((r) => r.role === "bridge");
      let rawRatio: number | null = null;
      if (animal && bridge) {
        const a = roiStats(raw, w, h, animal, satHigh);
        const b = roiStats(raw, w, h, bridge, satHigh);
        const sp = Math.sqrt((a.sigma ** 2 + b.sigma ** 2) / 2);
        rawRatio = sp > 1e-6 ? Math.abs(a.median - b.median) / sp : null;
      }
      const stageOut: StageOut[] = results.map(({ s, res }) => {
        let sum = 0;
        let cnt = 0;
        const diffImg = new Uint8Array(res.display.length);
        for (let i = 0; i < res.display.length; i++) {
          const d = res.display[i] - ref[i];
          sum += Math.abs(d);
          if (Math.abs(d) > 8) cnt++;
          diffImg[i] = Math.max(0, Math.min(255, 128 + 4 * d));
        }
        let pairDisp: number | null = null;
        let pairAduRatio: number | null = null;
        if (animal && bridge) {
          pairDisp = roiStats(res.display, w, h, animal, 255).median - roiStats(res.display, w, h, bridge, 255).median;
          const a = roiStats(res.enhanced, w, h, animal, satHigh);
          const b = roiStats(res.enhanced, w, h, bridge, satHigh);
          const sp = Math.sqrt((a.sigma ** 2 + b.sigma ** 2) / 2);
          pairAduRatio = sp > 1e-6 ? Math.abs(a.median - b.median) / sp : null;
        }
        return { id: s.id, label: s.label, note: s.note, res, meanAbsDiff: sum / res.display.length, pctDiff8: cnt / res.display.length, pairDisp, pairAduRatio, diffImg };
      });
      setOut({ key: rawKey, stages: stageOut, rawRatio });
      setBusy(false);
    }, 20);
  };

  const stale = out && out.key !== rawKey;
  const refStage = out?.stages[0];
  const combined = out?.stages[out.stages.length - 1];

  return (
    <Panel
      title="Stage-by-stage ablation (current frame, temporal off)"
      right={
        <div className="flex items-center gap-3">
          <Check label="Show difference vs reference (×4, grey=0)" checked={showDiff} onChange={setShowDiff} />
          <Btn tone="primary" onClick={run} disabled={!raw || busy}>
            {busy ? "Running…" : "Run ablation"}
          </Btn>
        </div>
      }
    >
      {!out && <p className="text-xs text-zinc-500">Runs raw fixed-window → line only → tone only → detail only → CLAHE only → combined, using the current settings. CNN stages: none implemented in this build.</p>}
      {stale && <p className="mb-2 text-xs text-amber-300">Frame or source changed since this run — re-run for current numbers.</p>}
      {out && (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
            {out.stages.map((s) => (
              <div key={s.id}>
                <div className="mb-1 text-[11px] font-semibold text-zinc-200">{s.label}</div>
                <Thumb data={showDiff ? s.diffImg : s.res.display} w={w} h={h} invert={showDiff ? false : invert} />
                <div className="mt-0.5 text-[10px] text-zinc-500">{s.note}</div>
              </div>
            ))}
          </div>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full min-w-[760px] text-left text-[11px]">
              <thead className="text-zinc-500">
                <tr className="border-b border-zinc-800">
                  <th className="py-1 pr-2">Stage</th>
                  <th className="pr-2">ADU &lt; window %</th>
                  <th className="pr-2">ADU &gt; window %</th>
                  <th className="pr-2">disp 0 %</th>
                  <th className="pr-2">disp 255 %</th>
                  <th className="pr-2">mean |Δ| vs ref (levels)</th>
                  <th className="pr-2">px Δ&gt;8 %</th>
                  <th className="pr-2">animal−bridge disp Δ</th>
                  <th className="pr-2">animal−bridge ADU ratio</th>
                  <th className="pr-2">noise σ (ADU)</th>
                </tr>
              </thead>
              <tbody className="font-mono text-zinc-200">
                {out.stages.map((s) => (
                  <tr key={s.id} className="border-b border-zinc-900">
                    <td className="py-1 pr-2 font-sans">{s.label}</td>
                    <td className="pr-2">{fmt(s.res.clipLowFrac * 100, 1)}</td>
                    <td className="pr-2">{fmt(s.res.clipHighFrac * 100, 1)}</td>
                    <td className="pr-2">{fmt(s.res.sat0Frac * 100, 1)}</td>
                    <td className="pr-2">{fmt(s.res.sat255Frac * 100, 1)}</td>
                    <td className="pr-2">{fmt(s.meanAbsDiff, 1)}</td>
                    <td className="pr-2">{fmt(s.pctDiff8 * 100, 1)}</td>
                    <td className="pr-2">{fmt(s.pairDisp, 0)}</td>
                    <td className="pr-2">{fmt(s.pairAduRatio, 1)}×</td>
                    <td className="pr-2">{fmt(s.res.noiseSigma, 1)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-3 rounded border border-zinc-800 bg-zinc-950 p-2 text-[11px] leading-relaxed text-zinc-400">
            {out.rawRatio === null ? (
              <>Add at least one <b>animal</b> and one <b>bridge</b> ROI to see whether their separation exists in the raw data and where (if anywhere) it is lost.</>
            ) : (
              <>
                Raw-ADU separation of the first animal/bridge ROI pair: <b className="text-zinc-200">{fmt(out.rawRatio, 1)}×</b> pooled ROI spread. Reference (fixed-window) display difference:{" "}
                <b className="text-zinc-200">{fmt(refStage?.pairDisp ?? null, 0)}</b> levels; combined pipeline display difference: <b className="text-zinc-200">{fmt(combined?.pairDisp ?? null, 0)}</b> levels; ADU-domain ratio after
                combined: <b className="text-zinc-200">{fmt(combined?.pairAduRatio ?? null, 1)}×</b>.{" "}
                {out.rawRatio < 3
                  ? "The raw data already do not separate these ROIs above their own spread; no display processing can restore a trustworthy difference."
                  : Math.abs(refStage?.pairDisp ?? 0) < 2
                    ? "Raw data separate them but the fixed window collapses the difference — a window/quantisation limit, fixable by narrowing the window."
                    : "Raw data separate them and the monotone display keeps them apart; check later stages above for any reduction."}
              </>
            )}
          </div>
        </>
      )}
    </Panel>
  );
}
