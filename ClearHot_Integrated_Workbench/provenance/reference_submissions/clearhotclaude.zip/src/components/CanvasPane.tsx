"use client";

import { useEffect, useRef, useState } from "react";
import type { Roi, RoiRole } from "@/lib/clearhot/roi";

export const ROLE_COLOR: Record<RoiRole, string> = {
  animal: "#f59e0b",
  background: "#38bdf8",
  bridge: "#e879f9",
};

export function drawGray(canvas: HTMLCanvasElement, data: Uint8Array, w: number, h: number, invert: boolean) {
  if (canvas.width !== w) canvas.width = w;
  if (canvas.height !== h) canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const img = ctx.createImageData(w, h);
  const px = img.data;
  for (let i = 0; i < data.length; i++) {
    const v = invert ? 255 - data[i] : data[i];
    px[4 * i] = v;
    px[4 * i + 1] = v;
    px[4 * i + 2] = v;
    px[4 * i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
}

export function CanvasPane({
  title,
  subtitle,
  data,
  w,
  h,
  invert,
  rois,
  onDraw,
  badge,
}: {
  title: string;
  subtitle: string;
  data: Uint8Array | null;
  w: number;
  h: number;
  invert: boolean;
  rois: Roi[];
  onDraw?: (r: { x: number; y: number; w: number; h: number }) => void;
  badge?: string;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  const box = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null);

  useEffect(() => {
    if (ref.current && data) drawGray(ref.current, data, w, h, invert);
  }, [data, w, h, invert]);

  const toPix = (e: React.PointerEvent) => {
    const r = box.current!.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(w, ((e.clientX - r.left) / r.width) * w)),
      y: Math.max(0, Math.min(h, ((e.clientY - r.top) / r.height) * h)),
    };
  };

  return (
    <figure className="min-w-0">
      <figcaption className="mb-1 flex items-baseline justify-between gap-2">
        <span className="text-xs font-semibold text-zinc-200">{title}</span>
        {badge && <span className="rounded bg-zinc-800 px-1.5 py-0.5 text-[10px] text-zinc-300">{badge}</span>}
      </figcaption>
      <div
        ref={box}
        className={`relative w-full overflow-hidden rounded border border-zinc-700 bg-black ${onDraw ? "cursor-crosshair" : ""}`}
        style={{ aspectRatio: `${w} / ${h}`, touchAction: "none" }}
        onPointerDown={(e) => {
          if (!onDraw) return;
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          const p = toPix(e);
          setDrag({ x0: p.x, y0: p.y, x1: p.x, y1: p.y });
        }}
        onPointerMove={(e) => {
          if (!drag) return;
          const p = toPix(e);
          setDrag({ ...drag, x1: p.x, y1: p.y });
        }}
        onPointerUp={() => {
          if (!drag || !onDraw) return;
          const x = Math.min(drag.x0, drag.x1);
          const y = Math.min(drag.y0, drag.y1);
          const rw = Math.abs(drag.x1 - drag.x0);
          const rh = Math.abs(drag.y1 - drag.y0);
          setDrag(null);
          if (rw >= 2 && rh >= 2) onDraw({ x: Math.round(x), y: Math.round(y), w: Math.round(rw), h: Math.round(rh) });
        }}
      >
        <canvas ref={ref} className="block h-full w-full" style={{ imageRendering: "pixelated" }} />
        <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
          {rois.map((r) => (
            <rect
              key={r.id}
              x={r.x}
              y={r.y}
              width={r.w}
              height={r.h}
              fill="none"
              stroke={ROLE_COLOR[r.role]}
              strokeWidth={1.5}
              vectorEffect="non-scaling-stroke"
            />
          ))}
          {drag && (
            <rect
              x={Math.min(drag.x0, drag.x1)}
              y={Math.min(drag.y0, drag.y1)}
              width={Math.abs(drag.x1 - drag.x0)}
              height={Math.abs(drag.y1 - drag.y0)}
              fill="rgba(255,255,255,0.12)"
              stroke="#fff"
              strokeDasharray="4 3"
              strokeWidth={1}
              vectorEffect="non-scaling-stroke"
            />
          )}
        </svg>
        {!data && <div className="absolute inset-0 flex items-center justify-center text-xs text-zinc-500">no frame</div>}
      </div>
      <p className="mt-1 text-[10px] leading-snug text-zinc-500">{subtitle}</p>
    </figure>
  );
}
