"use client";

import type { ReactNode } from "react";

export function Panel({ title, children, right, className = "" }: { title: string; children: ReactNode; right?: ReactNode; className?: string }) {
  return (
    <section className={`rounded-lg border border-zinc-800 bg-zinc-900/70 ${className}`}>
      <header className="flex items-center justify-between border-b border-zinc-800 px-3 py-2">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-zinc-300">{title}</h3>
        {right}
      </header>
      <div className="p-3">{children}</div>
    </section>
  );
}

export function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
  unit = "",
  hint,
  disabled,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  unit?: string;
  hint?: string;
  disabled?: boolean;
}) {
  return (
    <label className={`block text-xs ${disabled ? "opacity-40" : ""}`} title={hint}>
      <div className="mb-0.5 flex justify-between text-zinc-400">
        <span>{label}</span>
        <span className="font-mono text-zinc-200">
          {Number.isInteger(step) ? value : value.toFixed(2)}
          {unit}
        </span>
      </div>
      <input
        type="range"
        className="w-full accent-emerald-500"
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </label>
  );
}

export function Check({ label, checked, onChange, hint }: { label: string; checked: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <label className="flex cursor-pointer items-center gap-2 text-xs text-zinc-200" title={hint}>
      <input type="checkbox" className="accent-emerald-500" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      {label}
    </label>
  );
}

export function Select<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <label className="block text-xs text-zinc-400">
      <span className="mb-0.5 block">{label}</span>
      <select
        className="w-full rounded border border-zinc-700 bg-zinc-950 px-2 py-1 text-zinc-100"
        value={value}
        onChange={(e) => onChange(e.target.value as T)}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}

export function NumInput({ label, value, onChange, min, max }: { label: string; value: number; onChange: (v: number) => void; min?: number; max?: number }) {
  return (
    <label className="block text-xs text-zinc-400">
      <span className="mb-0.5 block">{label}</span>
      <input
        type="number"
        className="w-full rounded border border-zinc-700 bg-zinc-950 px-2 py-1 font-mono text-zinc-100"
        value={value}
        min={min}
        max={max}
        onChange={(e) => {
          const v = Number(e.target.value);
          if (Number.isFinite(v)) onChange(v);
        }}
      />
    </label>
  );
}

export function Btn({
  children,
  onClick,
  disabled,
  tone = "default",
  title,
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  tone?: "default" | "primary" | "danger";
  title?: string;
}) {
  const t =
    tone === "primary"
      ? "bg-emerald-600 hover:bg-emerald-500 text-white"
      : tone === "danger"
        ? "bg-red-900/60 hover:bg-red-800 text-red-100"
        : "bg-zinc-800 hover:bg-zinc-700 text-zinc-100";
  return (
    <button
      type="button"
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={`rounded px-2.5 py-1 text-xs font-medium transition disabled:cursor-not-allowed disabled:opacity-40 ${t}`}
    >
      {children}
    </button>
  );
}

export function Badge({ children, tone = "zinc" }: { children: ReactNode; tone?: "zinc" | "amber" | "emerald" | "red" }) {
  const c = {
    zinc: "bg-zinc-800 text-zinc-300",
    amber: "bg-amber-900/50 text-amber-200",
    emerald: "bg-emerald-900/50 text-emerald-200",
    red: "bg-red-900/50 text-red-200",
  }[tone];
  return <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${c}`}>{children}</span>;
}

export const fmt = (v: number | null | undefined, d = 1) => (v === null || v === undefined || !isFinite(v) ? "—" : v.toFixed(d));
