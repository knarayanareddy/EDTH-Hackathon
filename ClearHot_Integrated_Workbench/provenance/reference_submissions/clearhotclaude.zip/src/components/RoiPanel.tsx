"use client";

import type { PairRow, Roi, RoiRole, RoiRow } from "@/lib/clearhot/roi";
import { ROLE_COLOR } from "./CanvasPane";
import { Btn, Panel, fmt } from "./ui";

const ROLES: { id: RoiRole; label: string }[] = [
  { id: "animal", label: "Animal" },
  { id: "background", label: "Background" },
  { id: "bridge", label: "Bridge" },
];

export function RoiPanel({
  rows,
  pairs,
  rois,
  activeRole,
  setActiveRole,
  onDelete,
  onClear,
  onSave,
  saving,
  saveMsg,
  note,
  setNote,
}: {
  rows: RoiRow[];
  pairs: PairRow[];
  rois: Roi[];
  activeRole: RoiRole;
  setActiveRole: (r: RoiRole) => void;
  onDelete: (id: string) => void;
  onClear: () => void;
  onSave: () => void;
  saving: boolean;
  saveMsg: string | null;
  note: string;
  setNote: (s: string) => void;
}) {
  const counts = ROLES.map((r) => ({ ...r, n: rois.filter((x) => x.role === r.id).length }));
  return (
    <Panel
      title="Manual ROI measurement"
      right={
        <div className="flex gap-1">
          <Btn onClick={onClear} disabled={!rois.length} tone="danger">
            Clear ROIs
          </Btn>
        </div>
      }
    >
      <p className="mb-2 text-[11px] leading-relaxed text-zinc-400">
        Pick a role, then drag a rectangle on any image. Add several examples of each (mixed pixels, motion and texture inflate spread). Statistics are on <b>raw ADU</b>, <b>line-corrected ADU</b>
        and <b>8-bit display levels</b> separately. ADU are sensor counts — not °C and not calibrated radiance.
      </p>
      <div className="mb-3 flex flex-wrap gap-2">
        {counts.map((r) => (
          <button
            key={r.id}
            onClick={() => setActiveRole(r.id)}
            className={`flex items-center gap-1.5 rounded border px-2 py-1 text-xs ${activeRole === r.id ? "border-white bg-zinc-800 text-white" : "border-zinc-700 text-zinc-300 hover:bg-zinc-800"}`}
          >
            <span className="inline-block h-2.5 w-2.5 rounded-sm" style={{ background: ROLE_COLOR[r.id] }} />
            {r.label} <span className="text-zinc-500">({r.n})</span>
          </button>
        ))}
      </div>

      {rows.length === 0 ? (
        <p className="text-xs text-zinc-500">No ROIs yet.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-left text-[11px]">
            <thead className="text-zinc-500">
              <tr className="border-b border-zinc-800">
                <th className="py-1 pr-2">ROI</th>
                <th className="pr-2">px (w×h)</th>
                <th className="pr-2">raw med ADU</th>
                <th className="pr-2">raw σ</th>
                <th className="pr-2">valid %</th>
                <th className="pr-2">sat %</th>
                <th className="pr-2">corr. med ADU</th>
                <th className="pr-2">ref disp</th>
                <th className="pr-2">proc disp</th>
                <th className="pr-2" title="|median(ROI)-median(bg)| / robust σ(bg). Proxy only.">CNR raw</th>
                <th className="pr-2">CNR corr.</th>
                <th className="pr-2">CNR ref</th>
                <th className="pr-2">CNR proc</th>
                <th />
              </tr>
            </thead>
            <tbody className="font-mono text-zinc-200">
              {rows.map((r) => (
                <tr key={r.roi.id} className="border-b border-zinc-900">
                  <td className="py-1 pr-2 font-sans">
                    <span className="mr-1 inline-block h-2 w-2 rounded-sm" style={{ background: ROLE_COLOR[r.roi.role] }} />
                    {r.roi.label}
                    {r.bg && <span className="text-zinc-500"> vs {r.bg.label}</span>}
                  </td>
                  <td className="pr-2">
                    {r.raw.n} ({Math.round(r.roi.w)}×{Math.round(r.roi.h)})
                  </td>
                  <td className="pr-2">{fmt(r.raw.median, 0)}</td>
                  <td className="pr-2">{fmt(r.raw.sigma, 1)}</td>
                  <td className="pr-2">{fmt(r.raw.validFrac * 100, 0)}</td>
                  <td className="pr-2">{fmt(r.raw.satFrac * 100, 0)}</td>
                  <td className="pr-2">{fmt(r.corrected.median, 0)}</td>
                  <td className="pr-2">{fmt(r.refDisp.median, 0)}</td>
                  <td className="pr-2">{fmt(r.procDisp.median, 0)}</td>
                  <td className="pr-2">{fmt(r.cnrRaw, 1)}</td>
                  <td className="pr-2">{fmt(r.cnrCorrected, 1)}</td>
                  <td className="pr-2">{fmt(r.cnrRef, 1)}</td>
                  <td className="pr-2">{fmt(r.cnrProc, 1)}</td>
                  <td>
                    <button className="text-zinc-500 hover:text-red-400" onClick={() => onDelete(r.roi.id)} aria-label="delete ROI">
                      ✕
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {pairs.length > 0 && (
        <div className="mt-4">
          <h4 className="mb-1 text-xs font-semibold text-zinc-300">Animal vs bridge separation</h4>
          <div className="space-y-2">
            {pairs.map((p) => (
              <div key={p.animal.id + p.bridge.id} className="rounded border border-zinc-800 bg-zinc-950 p-2 text-[11px]">
                <div className="font-mono text-zinc-200">
                  {p.animal.label} − {p.bridge.label}: raw Δ {fmt(p.rawDelta, 0)} ADU · pooled spread {fmt(p.rawSpread, 1)} · ratio {fmt(p.rawRatio, 1)}× · ref-display Δ {fmt(p.refDelta, 0)} · processed-display Δ{" "}
                  {fmt(p.procDelta, 0)} levels
                </div>
                <div className="mt-0.5 text-zinc-400">{p.verdict}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mt-4 flex flex-wrap items-end gap-2 border-t border-zinc-800 pt-3">
        <label className="min-w-[200px] flex-1 text-xs text-zinc-400">
          <span className="mb-0.5 block">Note (optional)</span>
          <input
            className="w-full rounded border border-zinc-700 bg-zinc-950 px-2 py-1 text-zinc-100"
            value={note}
            maxLength={400}
            onChange={(e) => setNote(e.target.value)}
            placeholder="e.g. frame range confirmed by user, bridge segment A"
          />
        </label>
        <Btn tone="primary" onClick={onSave} disabled={saving || rows.length === 0} title="Stores ROI rectangles, config, decoder and numeric results in the local database. No pixel data.">
          {saving ? "Saving…" : "Save measurement to local DB"}
        </Btn>
        {saveMsg && <span className="text-xs text-zinc-400">{saveMsg}</span>}
      </div>
    </Panel>
  );
}
