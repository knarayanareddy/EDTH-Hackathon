"use client";

import { DEFAULT_CONFIG, cloneConfig, type LineMode, type MonotonicReport, type PipelineConfig, type ToneMode } from "@/lib/clearhot/pipeline";
import { Badge, Btn, Check, Panel, Select, Slider } from "./ui";

export function Controls({
  cfg,
  setCfg,
  frameStats,
  toneReport,
  onWindowFromFrame,
}: {
  cfg: PipelineConfig;
  setCfg: (f: (c: PipelineConfig) => PipelineConfig) => void;
  frameStats: { min: number; max: number; p1: number; p50: number; p99: number } | null;
  toneReport: MonotonicReport | null;
  onWindowFromFrame: () => void;
}) {
  const upd = (fn: (c: PipelineConfig) => void) =>
    setCfg((prev) => {
      const c = cloneConfig(prev);
      fn(c);
      return c;
    });

  return (
    <div className="space-y-3">
      <Panel
        title="1 · Line correction"
        right={<Badge tone="amber">spatially varying</Badge>}
      >
        <div className="space-y-2">
          <Select<LineMode>
            label="Mode"
            value={cfg.line.mode}
            options={[
              { value: "off", label: "Off (bypass)" },
              { value: "columns", label: "Column offsets" },
              { value: "rows", label: "Row offsets" },
              { value: "both", label: "Columns then rows" },
            ]}
            onChange={(v) => upd((c) => (c.line.mode = v))}
          />
          <Slider label="Strength" value={cfg.line.strength} min={0} max={1} step={0.05} onChange={(v) => upd((c) => (c.line.strength = v))} />
          <Slider label="Max correction" value={cfg.line.clampAdu} min={10} max={2000} step={10} unit=" ADU" onChange={(v) => upd((c) => (c.line.clampAdu = v))} hint="Bounds the offset removed from any one line." />
          <Slider label="High-pass half-width" value={cfg.line.halfWidth} min={4} max={128} onChange={(v) => upd((c) => (c.line.halfWidth = v))} unit=" lines" hint="Slower variations across lines than this are left alone (can't be told from scene)." />
          <Slider label="Edge gate" value={cfg.line.gateK} min={1} max={6} step={0.5} unit="σ" onChange={(v) => upd((c) => (c.line.gateK = v))} hint="Per-line differences beyond this many robust sigmas are ignored (scene edges)." />
          <p className="text-[10px] text-amber-300/80">A genuine full-length line in the scene looks identical to a stripe and may be reduced.</p>
        </div>
      </Panel>

      <Panel title="2 · Global tone map" right={<Badge tone="emerald">monotone · global</Badge>}>
        <div className="space-y-2">
          <Select<ToneMode>
            label="Window"
            value={cfg.tone.mode}
            options={[
              { value: "fixed", label: "Fixed (locked) window — use for ordering comparisons" },
              { value: "percentile", label: "Per-frame percentile (scene-adaptive, may flicker)" },
            ]}
            onChange={(v) => upd((c) => (c.tone.mode = v))}
          />
          <Slider label="Window low" value={cfg.tone.fixedLo} min={0} max={16383} step={10} unit=" ADU" onChange={(v) => upd((c) => (c.tone.fixedLo = Math.min(v, c.tone.fixedHi - 10)))} />
          <Slider label="Window high" value={cfg.tone.fixedHi} min={0} max={16383} step={10} unit=" ADU" onChange={(v) => upd((c) => (c.tone.fixedHi = Math.max(v, c.tone.fixedLo + 10)))} />
          <div className="flex items-center gap-2">
            <Btn onClick={onWindowFromFrame} disabled={!frameStats} title="Sets the fixed window to this frame's 1st–99th percentile, then you can lock it">
              Set fixed window from this frame (p1–p99)
            </Btn>
          </div>
          {frameStats && (
            <p className="font-mono text-[10px] text-zinc-500">
              frame ADU min {frameStats.min} · p1 {frameStats.p1} · p50 {frameStats.p50} · p99 {frameStats.p99} · max {frameStats.max}
            </p>
          )}
          {cfg.tone.mode === "percentile" && (
            <>
              <Slider label="Percentile low" value={cfg.tone.pLo} min={0} max={20} step={0.5} unit="%" onChange={(v) => upd((c) => (c.tone.pLo = v))} />
              <Slider label="Percentile high" value={cfg.tone.pHi} min={80} max={100} step={0.5} unit="%" onChange={(v) => upd((c) => (c.tone.pHi = v))} />
            </>
          )}
          <Slider label="Gamma" value={cfg.tone.gamma} min={0.4} max={2.5} step={0.05} onChange={(v) => upd((c) => (c.tone.gamma = v))} />
          <Slider label="Highlight knee" value={cfg.tone.knee} min={0.3} max={1} step={0.05} onChange={(v) => upd((c) => (c.tone.knee = v))} hint="1 = hard clip at window high. <1 compresses highlights smoothly above the knee." />
          {toneReport && (
            <div className="rounded border border-zinc-800 bg-zinc-950 p-2 text-[10px] leading-relaxed text-zinc-400">
              <div>
                Mapping check:{" "}
                <span className={toneReport.nonDecreasing ? "text-emerald-400" : "text-red-400"}>
                  {toneReport.nonDecreasing ? "non-decreasing" : "NOT monotone"}
                </span>{" "}
                · {toneReport.distinctLevels} distinct levels
              </div>
              <div>
                ≈ {toneReport.aduPerLevel.toFixed(1)} ADU per display level. Codes ≤ {toneReport.lowClipBelow} → black, ≥ {toneReport.highClipFrom} → white (
                {(toneReport.clippedFractionOfRange * 100).toFixed(0)}% of the 14-bit range clipped).
              </div>
              <div>Equal display levels do not mean equal signal; differences below one level can vanish (quantisation / clipping).</div>
            </div>
          )}
        </div>
      </Panel>

      <Panel title="3 · Detail enhancement (guided base/detail)" right={<Badge tone="amber">local</Badge>}>
        <div className="space-y-2">
          <Check label="Enabled" checked={cfg.detail.on} onChange={(v) => upd((c) => (c.detail.on = v))} />
          <Slider label="Radius" value={cfg.detail.radius} min={2} max={20} unit=" px" onChange={(v) => upd((c) => (c.detail.radius = v))} disabled={!cfg.detail.on} />
          <Slider label="Edge threshold" value={cfg.detail.edgeAdu} min={10} max={600} step={5} unit=" ADU" onChange={(v) => upd((c) => (c.detail.edgeAdu = v))} disabled={!cfg.detail.on} hint="Contrast above this is treated as an edge and left mostly untouched (limits halos)." />
          <Slider label="Gain" value={cfg.detail.gain} min={1} max={5} step={0.1} onChange={(v) => upd((c) => (c.detail.gain = v))} disabled={!cfg.detail.on} />
          <Slider label="Noise coring" value={cfg.detail.coringK} min={0} max={5} step={0.25} unit="σ" onChange={(v) => upd((c) => (c.detail.coringK = v))} disabled={!cfg.detail.on} hint="Only detail above this many noise sigmas is amplified; smaller detail passes unchanged." />
          <Slider label="Max boost" value={cfg.detail.maxBoostAdu} min={10} max={1000} step={10} unit=" ADU" onChange={(v) => upd((c) => (c.detail.maxBoostAdu = v))} disabled={!cfg.detail.on} />
        </div>
      </Panel>

      <Panel title="4 · CLAHE (display domain)" right={<Badge tone="red">non-monotone · interpretive</Badge>}>
        <div className="space-y-2">
          <Check label="Enabled" checked={cfg.clahe.on} onChange={(v) => upd((c) => (c.clahe.on = v))} />
          <Slider label="Tiles across" value={cfg.clahe.tiles} min={2} max={16} onChange={(v) => upd((c) => (c.clahe.tiles = v))} disabled={!cfg.clahe.on} />
          <Slider label="Clip limit" value={cfg.clahe.clip} min={1} max={10} step={0.5} onChange={(v) => upd((c) => (c.clahe.clip = v))} disabled={!cfg.clahe.on} />
          <Slider label="Blend with global" value={cfg.clahe.blend} min={0} max={1} step={0.05} onChange={(v) => upd((c) => (c.clahe.blend = v))} disabled={!cfg.clahe.on} />
          <p className="text-[10px] text-red-300/80">Changes relative brightness between locations. Display intensity only — never a temperature.</p>
        </div>
      </Panel>

      <Panel title="5 · Causal temporal stabilisation" right={<Badge tone="amber">uses past frames only</Badge>}>
        <div className="space-y-2">
          <Check label="Enabled (sequential playback / stepping)" checked={cfg.temporal.on} onChange={(v) => upd((c) => (c.temporal.on = v))} />
          <Slider label="Blend α" value={cfg.temporal.alpha} min={0.05} max={1} step={0.05} onChange={(v) => upd((c) => (c.temporal.alpha = v))} disabled={!cfg.temporal.on} hint="Effective memory ≈ 1/α frames." />
          <Slider label="Motion gate" value={cfg.temporal.gateK} min={1} max={10} step={0.5} unit="σ" onChange={(v) => upd((c) => (c.temporal.gateK = v))} disabled={!cfg.temporal.on} />
          <p className="text-[10px] text-zinc-500">State resets on non-consecutive seeks, source/decoder changes and edits to line or temporal settings. First frame is passed through. Zero look-ahead.</p>
        </div>
      </Panel>

      <div className="flex gap-2">
        <Btn onClick={() => setCfg((c) => ({ ...cloneConfig(DEFAULT_CONFIG), tone: { ...DEFAULT_CONFIG.tone, fixedLo: c.tone.fixedLo, fixedHi: c.tone.fixedHi } }))}>Reset settings (keep window)</Btn>
        <Btn
          onClick={() =>
            setCfg((c) => {
              const n = cloneConfig(c);
              n.line.mode = "off";
              n.detail.on = false;
              n.clahe.on = false;
              n.temporal.on = false;
              n.tone.mode = "fixed";
              n.tone.gamma = 1;
              n.tone.knee = 1;
              return n;
            })
          }
          title="Turns every stage off: processed view equals the raw fixed-window reference"
        >
          Safe bypass
        </Btn>
      </div>
    </div>
  );
}
