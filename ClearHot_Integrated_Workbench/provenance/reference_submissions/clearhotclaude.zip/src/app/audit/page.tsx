import Link from "next/link";
import type { ReactNode } from "react";

export const metadata = { title: "Audit & limits — ClearHot Lab" };

const REPO = "https://github.com/knarayanareddy/EDTH-Hackathon/tree/main/ClearHot_Six_Agent_Package";

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mb-8">
      <h2 className="mb-2 border-b border-zinc-800 pb-1 text-base font-semibold text-white">{title}</h2>
      <div className="space-y-2 text-sm leading-relaxed text-zinc-300">{children}</div>
    </section>
  );
}

function Table({ head, rows }: { head: string[]; rows: ReactNode[][] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] text-left text-xs">
        <thead className="text-zinc-500">
          <tr className="border-b border-zinc-800">
            {head.map((h) => (
              <th key={h} className="py-1 pr-3">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-zinc-900 align-top">
              {r.map((c, j) => (
                <td key={j} className="py-1.5 pr-3">
                  {c}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function AuditPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-bold text-white">ClearHot Lab — audit, changes and limits</h1>
        <Link href="/" className="text-sm text-emerald-400 hover:underline">
          ← Back to Lab
        </Link>
      </div>
      <p className="mb-6 rounded border border-amber-800 bg-amber-950/40 p-3 text-sm text-amber-100">
        Everything below separates <b>implemented code</b>, <b>what was actually tested</b>, <b>assumptions</b> and <b>untested claims</b>. No real challenge data, sensor calibration, trained model or
        user sample was available to this build. Nothing here is validated for operational use. Outputs are display intensities, not temperatures.
      </p>

      <Section title="0 · Relationship to the six-method package">
        <p>
          Source brief and review:{" "}
          <a className="text-emerald-400 underline" href={REPO}>
            ClearHot_Six_Agent_Package
          </a>{" "}
          (the Independent Evaluation Brief, the Six-Method Independent Review and its README were read in full).
        </p>
        <p>
          <b>Honest scope statement:</b> this is a <i>new, separate</i> experimental implementation written from scratch to the brief&apos;s rules. The six original variants (Argos 1–3, Claude A–C),
          including <b>Argos 2, the user&apos;s visual reference</b>, are <b>not ported or re-run here</b>: Argos&apos; engine alone is ~1,300 lines and re-implementing it by hand would risk silently altering it,
          which the brief forbids. They remain untouched in the package and its combined workbench. As a result this app <u>cannot</u> say how it compares with Argos 2; the shared ROI/ablation method
          here is designed so the same frame can later be exported and compared against it.
        </p>
      </Section>

      <Section title="1 · Brief requirements → status">
        <Table
          head={["Requirement", "Status", "Where"]}
          rows={[
            ["Decoder assumptions treated as hypotheses; no ADU→°C claims", <b key="a" className="text-emerald-400">Implemented</b>, "Source panel (width/height/header/endianness/bits/shift editable, labelled unconfirmed), unit labels everywhere"],
            ["Raw/linear reference path; fixed user window; no spatial processing", <b key="b" className="text-emerald-400">Implemented</b>, "View A; tone mapping check reports monotonicity, distinct levels, clipped range"],
            ["Local-only handling, slice/stream, memory reporting", <b key="c" className="text-emerald-400">Implemented</b>, "File.slice per frame, streaming SHA-256; heap shown only where the browser exposes it"],
            ["Manual ROI tool (animal / background / bridge): raw ADU, spread, sat/valid fraction, CNR; corrected and 8-bit reported separately", <b key="d" className="text-emerald-400">Implemented</b>, "Viewer tab; multiple ROIs; pair verdict explains whether separation exists in raw data"],
            ["Stage-by-stage ablation with clip fractions and difference images", <b key="e" className="text-emerald-400">Implemented (CNN stages: none exist)</b>, "Ablation tab"],
            ["Guided base/detail with bounded gain and noise-aware coring", <b key="f" className="text-emerald-400">Implemented</b>, "Stage 3"],
            ["Global percentile/window map, highlight knee, locked scale", <b key="g" className="text-emerald-400">Implemented</b>, "Stage 2"],
            ["Blended, contrast-limited local histogram", <b key="h" className="text-emerald-400">Implemented</b>, "Stage 4 (labelled non-monotone/interpretive)"],
            ["Causal temporal stabilisation with warm-up, reset, motion gate", <b key="i" className="text-emerald-400">Implemented</b>, "Stage 5; resets on seek / source / setting change; zero look-ahead"],
            ["Selectable unmodified baseline and safe bypass", <b key="j" className="text-emerald-400">Implemented (identity baseline)</b>, "View A and \u201CSafe bypass\u201D. The original Argos/Claude baselines are NOT included."],
            ["Synthetic known-truth benchmark with development vs held-out blocks, frozen configs", <b key="k" className="text-emerald-400">Implemented</b>, "Benchmark tab, JSON/CSV export"],
            ["Latency p50/p95, memory, device", <b key="l" className="text-emerald-400">Implemented</b>, "Latency tab (JS pipeline step only)"],
            ["Re-run of the original six methods", <b key="m" className="text-red-400">Not done</b>, "See section 0"],
            ["Blinded randomized A/B review UI", <b key="n" className="text-red-400">Not done</b>, "Needs reviewers and a frozen frame sample"],
            ["Official file spec, frame ranges, user's sample", <b key="o" className="text-amber-400">Not available</b>, "Must come from the user; ask before any analysis of their file"],
          ]}
        />
      </Section>

      <Section title="2 · Implemented algorithms (exact behaviour)">
        <ul className="list-disc space-y-1 pl-5">
          <li>
            <b>Line correction</b> — per column (or row): trimmed mean over the line of the difference to the adjacent line, trimmed at gate×robust-σ around the median to exclude scene edges; differences are integrated
            and a moving-average (half-width setting) is subtracted, so only variations faster than that window are removed. Bounded by a max correction and a strength factor. <u>Known limit:</u> a genuine full-length
            vertical/horizontal feature looks like a stripe and is reduced (synthetic &ldquo;full-height line&rdquo; scenario shows thin retention ≈0.92).
          </li>
          <li>
            <b>Tone map</b> — one global function ADU→0..255: linear window, optional gamma, optional smooth highlight knee (tanh). Non-decreasing by construction; clipping and 8-bit quantisation make it <i>not strictly</i> increasing, which the check panel quantifies.
          </li>
          <li>
            <b>Detail</b> — self-guided filter base; detail = signal − base. Only the part of |detail| above coring×noise-σ is amplified by (gain−1), capped by max-boost; sub-threshold detail passes unchanged (never suppressed). Strong edges (≫ edge threshold) are barely changed, which limits halos but also limits enhancement of high-contrast edges.
          </li>
          <li>
            <b>CLAHE</b> — tile histograms with clip limit and bilinear interpolation on the 8-bit display, blended with the global result.
          </li>
          <li>
            <b>Temporal</b> — exponential average of line-corrected frames with per-pixel motion gate (restart if change &gt; gate×σ). Cannot guarantee freedom from ghosting.
          </li>
          <li>
            <b>Noise σ</b> — robust estimate from the residual to a 4-neighbour mean; includes some real texture, so it is an upper-ish bound.
          </li>
        </ul>
      </Section>

      <Section title="3 · What was actually tested (in this build session)">
        <Table
          head={["Test", "Result", "Limits"]}
          rows={[
            ["Streaming SHA-256 vs Node crypto on random buffers (0–100 000 bytes, odd chunking)", "Matched for all lengths", "Not run on a 180 MB file in a browser"],
            ["Synthetic 640×512 scenes, 6 scenarios, line-correction variants", "Strong-stripe residual in a flat region 81 → ≈11 ADU RMS; no-stripe scene altered by ≈1 ADU RMS; thin retention 0.99–1.00 except genuine full-height line ≈0.92", "Seed 1 only for that probe; synthetic generator written by the same author as the algorithm (optimistic)"],
            ["Detail parameter probe (edge threshold 40/150/300/600 ADU)", "Edge 40 changed almost nothing; ≥150 boosts thin-structure contrast ×1.5–1.85 (this is intended boost, not recovery)", "One synthetic scene; defaults are provisional"],
            ["Tone mapping check", "Non-decreasing for tested settings", "Only default + percentile + CLAHE config"],
            ["Type-check and production build", "See final validation of this build", "—"],
          ]}
        />
        <p className="text-amber-200">
          <b>Not tested:</b> any real thermal file; Safari/Firefox; very large files; multi-hour playback; CLAHE/temporal on real motion; memory above the heap indicator; blind human preference; GPU/WebGL paths (none used).
        </p>
      </Section>

      <Section title="4 · Assumptions that remain hypotheses">
        <ul className="list-disc space-y-1 pl-5">
          <li>640×512, headerless, uint16 little-endian, low 14 bits, frame-contiguous. The &ldquo;format hints&rdquo; button only compares statistics for LE vs BE; it does not establish format.</li>
          <li>Stripe model: additive per-column (or per-row) offsets constant along the line. Real fixed-pattern noise may be gain-dependent or scene-dependent.</li>
          <li>Saturation is treated as value ≥ 2^bits−1 or 0; the sensor may use other sentinel codes.</li>
          <li>The ROI CNR is a proxy; it depends on texture inside the ROIs and is not evidence of real temperature difference.</li>
          <li>Animal vs bridge: an animal is <i>not</i> assumed hotter. Nothing in this app brightens a region because of what it is.</li>
        </ul>
      </Section>

      <Section title="5 · Every change and how to turn it off">
        <Table
          head={["Change", "Off switch"]}
          rows={[
            ["Line correction", "Stage 1 mode → Off, or Strength 0"],
            ["Tone map beyond raw window", "Window = Fixed, Gamma 1, Knee 1"],
            ["Detail enhancement", "Stage 3 → Enabled off, or Gain 1"],
            ["CLAHE", "Stage 4 → Enabled off, or Blend 0"],
            ["Temporal", "Stage 5 → Enabled off"],
            ["Everything at once", "\u201CSafe bypass\u201D button (processed view = reference view)"],
            ["Auto-suggested window on load", "Edit/lock the Window sliders any time; it is suggested once per loaded source"],
            ["Database logging", "Nothing is stored unless you press \u201CSave measurement\u201D; delete in Records"],
          ]}
        />
      </Section>

      <Section title="6 · CNN status and proposed feedback loop">
        <p>
          <b>No CNN exists in this app and none is applied.</b> The UI badge reads &ldquo;CNN: not implemented (off)&rdquo;. Nothing trains in the background, no weights are loaded, and the classical pipeline is
          never silently replaced. The CNN-on/off ablation step is therefore intentionally absent rather than faked.
        </p>
        <p>
          Evidence-based recommendation: do <u>not</u> train a CNN yet. Line correction on synthetic stripes is already addressed by a transparent classical method, and there is no real data, spec or held-out
          recording to justify a learned model. Revisit if the held-out classical results show systematic failures that a learned model could plausibly fix.
        </p>
        <p>Proposed loop (not built): curated recordings plus trusted targets or validated simulated corruption → split by recording/scene/device → train → tune on validation → evaluate once on an untouched test set → inspect failure cases (harmful feature removal as well as noise reduction) → version/checkpoint with weight identity and dataset provenance → opt-in deployment with rollback and classical fallback. Adjacent frames are not valid Noise2Noise targets when fixed-pattern stripes persist across frames. With a single recording, independence cannot be claimed. Confirm challenge data-use rules first.</p>
      </Section>

      <Section title="7 · Evaluation protocol for the user's own file (not yet performed)">
        <ol className="list-decimal space-y-1 pl-5">
          <li>Confirm the file spec (size, header, endianness, bit alignment, NUC state). Ask for frame ranges that contain animals and bridges.</li>
          <li>Freeze configuration, record code version ({"clearhot-lab-0.1.0"}) and file SHA-256 locally (Source panel).</li>
          <li>Split contiguous time blocks into development and held-out, excluding boundary frames to avoid temporal leakage; label all results exploratory (correlated neighbouring frames, one recording).</li>
          <li>On several frames, draw multiple animal, bridge and nearby background ROIs; save measurements; check the pair verdict for whether separation exists in raw ADU before judging any enhancement.</li>
          <li>Run the ablation on a random, repeatable frame sample including low contrast, motion, bright/dark scenes, hard negatives (no stripes, genuine lines).</li>
          <li>Blind A/B review with neutral labels and predefined criteria; report ties and disagreements. The user&apos;s Argos 2 preference is an observation, not a blind result.</li>
          <li>Measure latency on the target Mac end-to-end; JS step timing alone does not establish 25 fps or FPGA feasibility.</li>
        </ol>
      </Section>

      <Section title="8 · Questions only the user can answer">
        <ul className="list-disc space-y-1 pl-5">
          <li>Which frame ranges contain the animals and the bridge, and is there any independent temperature/scene reference?</li>
          <li>Is the official file specification available, and may the sample be used for training or only for evaluation?</li>
          <li>Mac model, memory and display/latency constraints; is FPGA deployment still required?</li>
          <li>Permission to run the original six methods on identical frames and compare against this app&apos;s reference path.</li>
        </ul>
      </Section>
    </div>
  );
}
