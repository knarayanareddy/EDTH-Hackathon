import { eq } from "drizzle-orm";
import { db } from "@/db";
import { measurementRecords } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const n = Number(id);
  if (!Number.isInteger(n)) return Response.json({ error: "Bad id" }, { status: 400 });
  await db.delete(measurementRecords).where(eq(measurementRecords.id, n));
  return Response.json({ ok: true });
}
