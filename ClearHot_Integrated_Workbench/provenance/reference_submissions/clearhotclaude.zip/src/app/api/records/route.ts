import { desc } from "drizzle-orm";
import { db } from "@/db";
import { measurementRecords } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(measurementRecords).orderBy(desc(measurementRecords.createdAt)).limit(200);
  return Response.json({ records: rows });
}

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }
  const frameIndex = Number(body.frameIndex);
  if (!Number.isInteger(frameIndex) || frameIndex < 0) {
    return Response.json({ error: "frameIndex must be a non-negative integer" }, { status: 400 });
  }
  if (typeof body.algoVersion !== "string" || !body.decoder || !body.config || !Array.isArray(body.rois) || !body.results) {
    return Response.json({ error: "Missing required fields" }, { status: 400 });
  }
  if (JSON.stringify(body).length > 2_000_000) {
    return Response.json({ error: "Payload too large (pixel data must not be sent)" }, { status: 413 });
  }
  const str = (v: unknown) => (typeof v === "string" ? v.slice(0, 500) : null);
  const [row] = await db
    .insert(measurementRecords)
    .values({
      sourceKind: body.sourceKind === "file" ? "file" : "synthetic",
      fileName: str(body.fileName),
      fileSize: str(body.fileSize),
      fileSha256: str(body.fileSha256),
      frameIndex,
      algoVersion: body.algoVersion,
      decoder: body.decoder,
      config: body.config,
      rois: body.rois,
      results: body.results,
      note: str(body.note),
    })
    .returning();
  return Response.json({ record: row }, { status: 201 });
}
