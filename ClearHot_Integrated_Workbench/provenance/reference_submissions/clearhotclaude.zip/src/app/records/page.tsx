"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";

interface Rec {
  id: number;
  createdAt: string;
  sourceKind: string;
  fileName: string | null;
  fileSize: string | null;
  fileSha256: string | null;
  frameIndex: number;
  algoVersion: string;
  rois: { label: string; role: string; w: number; h: number }[];
  results: { pairs?: { animal: string; bridge: string; rawDelta: number; rawRatio: number | null; refDelta: number; procDelta: number; verdict: string }[] };
  note: string | null;
}

export default function RecordsPage() {
  const [recs, setRecs] = useState<Rec[] | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/records");
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      setRecs(((await r.json()) as { records: Rec[] }).records);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "load failed");
    }
  }, []);

  useEffect(() => {
    let dead = false;
    fetch("/api/records")
      .then((r) => (r.ok ? (r.json() as Promise<{ records: Rec[] }>) : Promise.reject(new Error(`HTTP ${r.status}`))))
      .then((d) => {
        if (!dead) setRecs(d.records);
      })
      .catch((e) => {
        if (!dead) setErr(e instanceof Error ? e.message : "load failed");
      });
    return () => {
      dead = true;
    };
  }, []);

  const del = async (id: number) => {
    await fetch(`/api/records/${id}`, { method: "DELETE" });
    void load();
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold text-white">Saved ROI measurements</h1>
        <Link href="/" className="text-sm text-emerald-400 hover:underline">
          ← Back to Lab
        </Link>
      </div>
      <p className="mb-4 text-xs text-zinc-500">Stored in the local database: ROI rectangles, settings, decoder, file name/size/optional hash and numeric statistics only. No pixel data and no copy of the thermal file.</p>
      {err && <div className="rounded border border-red-800 bg-red-950/50 p-2 text-sm text-red-200">{err}</div>}
      {recs && recs.length === 0 && <p className="text-sm text-zinc-400">No records yet. Draw ROIs in the Lab and press “Save measurement”.</p>}
      <div className="space-y-3">
        {recs?.map((r) => (
          <article key={r.id} className="rounded-lg border border-zinc-800 bg-zinc-900/70 p-3 text-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="font-semibold text-white">#{r.id}</span> <span className="text-zinc-300">{r.fileName ?? "—"}</span>{" "}
                <span className="rounded bg-zinc-800 px-1.5 py-0.5 text-[10px] uppercase text-zinc-400">{r.sourceKind}</span>
              </div>
              <button onClick={() => del(r.id)} className="text-xs text-zinc-500 hover:text-red-400">
                Delete
              </button>
            </div>
            <div className="mt-1 font-mono text-[11px] text-zinc-500">
              {new Date(r.createdAt).toLocaleString()} · frame {r.frameIndex} · {r.algoVersion}
              {r.fileSize ? ` · ${Number(r.fileSize).toLocaleString()} bytes` : ""}
            </div>
            {r.fileSha256 && <div className="break-all font-mono text-[10px] text-zinc-600">sha256 {r.fileSha256}</div>}
            <div className="mt-1 text-xs text-zinc-400">
              ROIs: {r.rois.map((x) => `${x.label} (${Math.round(x.w)}×${Math.round(x.h)})`).join(", ") || "none"}
            </div>
            {r.results.pairs?.map((p) => (
              <div key={p.animal + p.bridge} className="mt-1 rounded bg-zinc-950 p-2 text-[11px] text-zinc-400">
                <span className="font-mono text-zinc-200">
                  {p.animal} − {p.bridge}: raw Δ {p.rawDelta.toFixed(0)} ADU · {p.rawRatio === null ? "—" : p.rawRatio.toFixed(1)}× spread · ref Δ {p.refDelta.toFixed(0)} · proc Δ {p.procDelta.toFixed(0)}
                </span>
                <div>{p.verdict}</div>
              </div>
            ))}
            {r.note && <div className="mt-1 text-xs italic text-zinc-400">“{r.note}”</div>}
          </article>
        ))}
      </div>
    </div>
  );
}
