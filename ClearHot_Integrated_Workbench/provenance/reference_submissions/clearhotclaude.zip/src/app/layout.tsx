import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "ClearHot Lab — local thermal enhancement evaluation",
  description: "Experimental, local-only workbench for evaluating thermal line correction, tone mapping and detail enhancement without inventing thermal differences.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-zinc-950 text-zinc-200 antialiased">{children}</body>
    </html>
  );
}
