export default function Home() {
  return (
    <main className="mx-auto max-w-3xl p-8 text-slate-100">
      <h1 className="text-3xl font-bold">ClearHot v2.0.0 — local thermal workbench + controlled offline CNN loop</h1>
      <p className="mt-4 text-slate-300">
        This page only hosts the deliverables. The real tool is local-first: it runs on your Mac with no upload, no cloud account and no
        telemetry. Nothing on this page processes your recording.
      </p>
      <ul className="mt-6 list-disc space-y-3 pl-6">
        <li>
          <a className="text-sky-400 underline" href="/ClearHot_v2.0.0.zip" download>
            ClearHot_v2.0.0.zip
          </a>{" "}
          — full source, Mac setup (<code>README_MAC.md</code>), tests, demo commands, real test logs and{" "}
          <code>RESULTS_AND_LIMITATIONS.md</code>.
        </li>
        <li>
          <a className="text-sky-400 underline" href="/ClearHot_Local.html">
            ClearHot_Local.html
          </a>{" "}
          — the standalone viewer (also inside the ZIP). Download it and open it from disk for real use; its CSP blocks all network connections.
        </li>
      </ul>
      <p className="mt-6 rounded border border-amber-500/50 p-4 text-amber-200">
        Not tested on your ~180 MB recording, on macOS, or in a real browser UI. CNN results are from generated synthetic data only and are
        not evidence of improvement on real footage.
      </p>
    </main>
  );
}
