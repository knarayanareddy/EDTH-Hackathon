# RESULTS AND LIMITATIONS — ClearHot v2.0.0

No recording from the user was available. **Nothing here was tested on the user's ~180 MB recording, on a Mac, on Apple Silicon/MPS, or in a real browser.** No claim is made that a CNN improves any real footage. All CNN numbers are from generated SYNTHETIC scenes.

## Environment of the recorded runs
Linux x86_64 sandbox, 4 cores, Node v22.23.4, npm 10.9.9, Python 3.11.2, numpy 2.4.6, torch 2.5.1+cpu (see `test_results/environment.txt`). Training used CPU, 1 thread. Logs: `test_results/{build_typecheck,python_tests,node_tests,demo_output}.log|txt`, `overall.txt` (exit 0).

## Actual test results (`bash scripts/run_all_tests.sh`, final run)
| Suite | Result |
|---|---|
| `npm run build` + `tsc --noEmit` | PASS |
| Python `unittest` (10 tests, 47 s) | **10 / 10 PASS** |
| Node `npm test` (18 tests, ~1 s) | **18 / 18 PASS, 0 skipped** (10 inherited from v1.1.0 + 8 new) |
| `scripts/demo.sh` (≈2.5 min) | exit 0; output in `test_results/demo_output.txt` |
| Playwright / real-browser UI tests | **NOT RUN** (Playwright/Chromium not installed; inherited `tests/*browser-check.cjs` untouched) |
| macOS / Apple Silicon / MPS | **NOT RUN** |
| Full-resolution 640×512 generated-file test | **NOT RUN** (tests use 64×64; the code is size-generic, 640×512 timing is unmeasured) |

## Demonstrated loop (generated synthetic data; from `demo_output.txt`, validation split = 8 scenes × 8 frames, 64×64)
Count-domain mean MAE: raw 25.47 · **original Argos 2 stage-1 counts 15.72** · candidate A (1500 steps, 3 train scenes/kind) 9.81 · candidate B (3000 steps, 12 train scenes/kind) 8.21. PSNR/SSIM/stripe/motion columns are in the report CSV/JSON.
* **Cycle 1.** Candidate A trained (real autograd/Adam), evaluated with the *product default gates*: **FAILED** (thin-line retention min 0.117 < 0.70; small-target retention min 0.533 < 0.70). Under DEMO/TEST-ONLY relaxed thresholds it was `validated`, then explicitly approved (typed confirmation) → active.
* **Cycle 2.** Dataset v2 (more curated scenes; identical frozen validation and reserved test files, checked by hash). B compared against raw, Argos 2 **and the promoted A**; validated under the same demo thresholds; approved → active (A retired). *(B's weights hash `d4a530d7…` matches an earlier development run in which B failed the default thin-line gate, min 0.196; that run is not in the saved logs.)*
* **Failing candidate C** (targets corrupted by +150 counts, `--demo-fault bias`, labelled SIMULATED/DEMO): 8 mandatory gates FAILED, approval refused, rejected.
* **Rollback** B→A; a fresh `Registry` object (restart) restores A with the identical weights hash (asserted in the Python test). Event log has every transition.
* **Final test**: refused without the confirmation phrase (no ledger written); with it, one invocation logged. It was run once on A for demonstration only.
* **Inference cache + viewer logic**: active model processed a generated 90-frame recording; cache frame 75 equals independent re-inference; the Node test re-verifies source SHA-256/geometry/frame count, reads frames 0/61/89, runs Argos 2 over all 90 frames and checks each cache frame matches its own source frame (not another).
**Honest reading:** with default gates *no* model I trained passed; the dominant failure is a real, thin, full-height vertical line being treated as a stripe and smoothed away (when a −39-count stripe lies under a +200 wire the line is nearly indistinguishable from a strong stripe). Hard-example sampling, more scenes and more steps reduced but did not remove it. These toy models are a functional demonstration, not evidence for real footage.

## Requirement status (01_IMPLEMENTATION_REQUIREMENTS.md)
| # | Requirement | Status | Why |
|---|---|---|---|
| 1.1 | Local launch, raw reference, play/pause/seek/restart/step, no 60-frame cap, file frames vs target fps distinguished | **PASS (logic) / PARTIAL (UI)** | Inherited player kept; >60-frame playback and seek reset tested at function level (75 frames); UI clicks not exercised in a browser. |
| 1.2 | Original Argos 2 + other originals selectable, same decoded frame, originals untouched | **PASS** | `src/argos/*`, adapters byte-identical; Argos 2 engine hash = archived zip; 8-bit output parity with the *archived* engine on 5 frames incl. reset/seek (max diff 0); all original six + lab run. Archives in `provenance/`. |
| 1.3 | Reproducible comparison; native vs common-tone distinguished | **PARTIAL** | Existing blind/ROI/session machinery kept; wording corrected; new CNN view adds a controlled common fixed-window for Argos 2 stage-1 counts and CNN counts. Other methods have no common-tone remap (not fairly possible for their native AGC) — stated, not invented. |
| 1.4 | Per-method temporal state, resets, stale-state tests | **PASS (Argos 2/runner) ; Claude B causal variant NOT IMPLEMENTED** | Reset test exists; original Claude B is still offline/look-ahead and no causal variant or train/val boundary handling for its window was built (the CNN is single-frame, split by scene). |
| 1.5 | Local-only, loopback/token if a service, offline verification | **PASS** | No service exists. CSP `connect-src 'none'`; static scan of viewer/baseline; Python no-socket test. A packet-level/offline-browser capture was **not** done. |
| 2 | Decoder integrity, full streaming SHA-256, provenance | **PARTIAL** | Fixed: short reads/out-of-file indices now throw (previously zero-padded); endian/shift/mask/header/remainder tests. Full SHA-256 + progress exist in viewer; hash *cancellation* not verified; **16-bit/other layouts NOT IMPLEMENTED** (14-bit only, stated). Observation records are the inherited session export. |
| 3 | New classical variant, true stage ablation, ROI measurement, hard-negative evaluation | **PARTIAL** | Hard-negative synthetic evaluation with known truth, PSNR/SSIM, stripe, line/target retention, halo/overshoot, clipping, motion: **PASS** (CNN path). **NOT IMPLEMENTED:** a new classical (guided/bilateral) Argos-2 variant and a truly isolated detail-only/tone-only ablation (the inherited “stage 1 bypass” still also disables bad-pixel handling). ROI measurement/blind review inherited unchanged. |
| 4.1 | Data ingestion, splits, leakage checks, real-pair path | **PASS** | Synthetic generator (8 hard-negative kinds, scene-seed splits), manifest, hash/scene/recording leakage checks, tamper detection, gated reserved test, real-pair importer with attestation. Real importer tested only on generated fixtures. |
| 4.2 | Actual trainable CNN, checkpoints, reproducibility | **PASS** | 5-conv-layer residual CNN, 7409 trainable parameters (`model.py`), backprop/Adam, finite checks, optimizer state saved, weights/arch/code hashes, seed reproducibility test. CPU only tested. |
| 4.3 | Evaluation, gates, registry, human approval, promotion, rollback, two-cycle test | **PASS** | As demonstrated above and in `LoopE2E`. Test-only thresholds are used in the automated test and demo and are labelled. |
| 4.4 | Use the model in video review | **PARTIAL** | Local precomputed cache (permitted by the brief) + viewer attach/compare/bypass code + Node tests of validation/frame identity. The browser interaction (attach, play, bypass button) was **not** run in a browser here. |
| 5 | Acceptance tests | **PARTIAL** | Items 1–4 mostly covered at logic level; browser, full-resolution and Mac runs missing. |
| 6 | Deliverables (source, tests, demo commands, results, workflow) | **PASS** | This ZIP; `README_MAC.md` has setup, loading your recording, approved-CNN comparison, workflow, rollback, final test. |

## Known limitations / traps
* Argos 2 is a preferred reference, not a proven winner. In the CNN evaluation it is represented by its **stage-1 cleaned counts** (destripe + bad pixel) because only that is in the count domain; its AGC/detail stages are display-domain and shown separately in the viewer.
* The CNN is single-frame, count-domain (clip(counts + 500·residual)); no temporal model; integer rounding in caches; not a temperature; no safety-critical claim.
* Gate thresholds are engineering defaults, unvalidated on real data; real datasets lack masks so line/target/halo gates cannot pass until you provide labelled evidence.
* Different file hashes ≠ independent scenes/devices; one recording ⇒ exploratory time-block results only. The final test must not be used to choose models (every use is logged, repeats are counted, not blocked).
* Viewer exports (inherited) may contain file names, hashes, ROIs, notes.
* Timing numbers in reports are for this sandbox only, not a 25-fps or real-time claim.

## Changes by path
* **New:** `src/cnncache.ts`, `tools/baseline.mjs`, `training/clearhot_cnn/*.py`, `training/tests/test_loop.py`, `tests/clearhot.test.mjs`, `scripts/{demo,run_all_tests}.sh`, `examples/*`, `requirements.txt`, `README_MAC.md`, this file, `provenance/` (the four reference ZIPs and brief checksums), `test_results/`.
* **Modified:** `src/lab/decode.ts` (strict reads), `src/core.ts` (exports cache helpers; VERSION 2.0.0), `src/app.ts` (CNN cache section, compare mode, bypass, detach-on-change, wording), regenerated `ClearHot_Local.html`, `tests/core.cjs`.
* **Unchanged (provenance):** `src/argos/*`, `src/claude/*`, `src/lab/{dsp,synth,bench,roi,pipeline}.ts`, `src/types/*`, original `*.md` of v1.1.0 (those documents describe v1.1.0 and are superseded here where they say “no CNN”).
