# ClearHot v2.0.0 — local thermal workbench + controlled offline CNN loop (Mac guide)

Everything runs on your Mac. **No upload, no cloud account, no telemetry, no server.** The viewer is one HTML file (its Content-Security-Policy is `connect-src 'none'`). The trainer is a command-line tool that never opens a network socket (this is tested). Your recording is only ever *read*.

Start point was `starting_point/` v1.1.0 (kept: `ClearHot_Local.html` player, original Argos 1/2/3, Claude A/B/C, new Claude lab, ROI review, blind labels, session export). The original archives are in `provenance/reference_submissions/` untouched. Argos engine files in `src/argos/` are byte-identical to the archived originals (tested).

## 1. Install (one time)

Requirements: macOS with **Node 20+** and **Python 3.11 or 3.12** (the macOS system Python 3.9 is too old for the pinned numpy). Apple-Silicon Mac recommended: the pinned PyTorch 2.5.1 has no Intel-Mac wheels.
These steps download software (disclosed): npm dev packages (esbuild, typescript) and Python `numpy`+`torch` from PyPI (roughly 100–250 MB download, ~0.5–1 GB disk; approximate, not measured on a Mac). After installation, normal use is offline.

```sh
brew install node python@3.12            # skip if already installed
cd ClearHot_v2.0.0
npm ci && npm run build                  # rebuilds ClearHot_Local.html and tests/core.cjs (needed by the evaluator)
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt          # numpy==2.4.6, torch==2.5.1
export PYTHONPATH="$PWD/training"        # every command below: python3 -m clearhot_cnn ...
python3 -m clearhot_cnn --help           # CLI help (also: <command> --help)
```
Tested here only on Linux x86_64 / Python 3.11.2 (see `RESULTS_AND_LIMITATIONS.md`). **macOS, Apple Silicon and MPS were not tested.** `--device mps` fails visibly if unavailable; the default is CPU.

## 2. Look at your recording now (no CNN needed)

1. Double-click `ClearHot_Local.html` (Chrome/Edge/Firefox). It works without any install.
2. Section 1: *Local uint16 file* → choose your ~180 MB recording. Set width/height (default 640×512), header bytes, shift, byte order, then **Apply decoder & window**. These are *hypotheses* until you confirm the sensor format; the viewer shows whole-frame count and leftover bytes (leftover bytes = format suspect). Only 14-bit-in-uint16 is supported (16-bit is NOT implemented).
3. *Calculate SHA-256 locally* (full-file streaming hash; needed later for CNN caches).
4. Playback box: *Display method* = Argos 2 (original default) or raw; pick *target fps* (the file has no verified frame rate), press **Play**. It plays every whole frame from the current one to the end, with pause, seek slider, **Start over**, and method switching. It never skips frames; if processing is slower than the target it says so.
5. Mark ROIs (animal / bridge / background / thin feature / stripe area) in section 3 and compare all methods on one frame in sections 3–5 (blind labels first, reveal after scoring). Export the session JSON/CSV only if you want (these files can contain file name, hash, ROI coordinates, notes — treat as sensitive; delete them like any file).

## 3. See an *approved* CNN beside Argos 2 on your recording

A CNN can only be shown after a human has approved it in the registry (or, clearly labelled, as UNAPPROVED).

```sh
# (a) the registry must have an ACTIVE approved model:
python3 -m clearhot_cnn status --registry my_registry
# (b) process YOUR recording into a local cache (never modifies the recording). It prints the predicted size
#     (≈ the size of the processed frame range, e.g. ~180 MB for the whole file) and asks before writing:
python3 -m clearhot_cnn infer --registry my_registry --source /path/to/recording.bin \
        --width 640 --height 512 --out my_cache          # add --start/--end for a frame range; --yes to skip the prompt
# (c) in ClearHot_Local.html: load the same recording (same decoder settings, hash calculated),
#     section "CNN cache": choose my_cache/manifest.json and my_cache/frames.u16 → Verify & attach cache.
# (d) Playback → Display method = "Compare: raw | Argos 2 (native + common window) | CNN cache" → Play / seek.
```
The viewer shows: raw fixed-window · Argos 2 original, **native** display · Argos 2 stage-1 counts in the shared fixed window · CNN counts in the same fixed window, with the model ID, approved/UNAPPROVED state, "trained on SYNTHETIC data" and the source frame / cache entry number. It **refuses** the cache if the recording's full SHA-256, size, decoder, frame count or the cache file's hash differ, and shows a red "no cached frame" tile instead of any neighbouring frame. **Bypass CNN (classical only)** hides the CNN tile at once; **rollback** (below) changes which model future caches use. Applying a new decoder or a new file detaches the cache.

Not claimed: that the CNN is better on your recording, that its output is a temperature, or any frame rate. Values are 14-bit counts after a single-frame restoration.

## 4. Full improvement loop (commands)

```sh
R=my_registry
# 4.1 DATA — either synthetic (demo) or your curated real pairs (section 5)
python3 -m clearhot_cnn make-synth --out data/synth-v1 --version synth-v1 --train-seeds 0,1,2
python3 -m clearhot_cnn validate-data data/synth-v1          # leakage + hash checks
# 4.2 TRAIN a candidate (never promotes)
python3 -m clearhot_cnn train --dataset data/synth-v1 --registry $R --steps 1500 --seed 1
# 4.3 EVALUATE on the VALIDATION split vs raw, original Argos 2 and the promoted model; gates must pass
python3 -m clearhot_cnn evaluate --registry $R --dataset data/synth-v1 --id ckpt-XXXX
#     inspect $R/candidates/ckpt-XXXX/validation_report.json and .csv (per-scene metrics, failures, provenance)
# 4.4 HUMAN DECISION
python3 -m clearhot_cnn approve --registry $R --id ckpt-XXXX --reviewer you --confirm-approve ckpt-XXXX --note "why"
python3 -m clearhot_cnn reject  --registry $R --id ckpt-XXXX --reviewer you --note "why"
# 4.5 USE: python3 -m clearhot_cnn infer ... (section 3)
# 4.6 ROLLBACK (restores the previous active model, or "classical only"); state is on disk and survives restarts
python3 -m clearhot_cnn rollback --registry $R --reviewer you --note "why"
# 4.7 NEXT CYCLE: curate more pairs → new dataset directory/version → train → evaluate (the promoted model is compared automatically)
# 4.8 FINAL TEST, separately gated, only when you are done choosing; every call is appended to $R/final_test_ledger.jsonl
python3 -m clearhot_cnn final-test --registry $R --dataset data/synth-v1 --id ckpt-XXXX --reviewer you --confirm-final-test "RUN FINAL TEST ONCE"
```
A candidate that fails any mandatory gate can never be approved (no override). Passing gates is necessary, never sufficient: a person must type the approval. Default gate thresholds are declared in `training/clearhot_cnn/evaluate.py` (`DEFAULT_GATES`); override with `--gates file.json` (mark `--test-only-thresholds`; the report records that). They are engineering checks, not scientific constants.

**One-command demo** (generated synthetic data, two cycles, a rejected failing candidate, rollback, cache, gated final test; ≈2.5 min on 4 CPU cores):
```sh
bash scripts/demo.sh demo_out        # output captured in test_results/demo_output.txt
open ClearHot_Local.html             # load demo_out/recording_synthetic.u16 with width=64 height=64, attach demo_out/cache/*
```
The demo promotes models using **DEMO/TEST-ONLY relaxed thresholds** (`examples/gates_demo_relaxed.json`) because under the product defaults the tiny synthetic models fail the thin-line gate — the first `evaluate` in the demo shows that failure.

## 5. Your own trusted training pairs (real-data path)

You need pairs of (noisy input frame, **separately obtained trusted reference of the same scene, aligned, same 14-bit count domain**), e.g. a verified long-exposure/multi-frame average from a static camera. The tool cannot prove a target is clean; **you attest it** in the manifest. Not accepted as targets (rejected by code): an adjacent noisy frame, a blurred frame, a model/classical output, a preference or ROI label.

1. Copy `examples/real_pairs_manifest.example.json`, fill in decoder, attestation, recording IDs, splits (`train`/`val`, optionally `test`), file paths and **full-file SHA-256** (`shasum -a 256 FILE`), frame indices.
2. `python3 -m clearhot_cnn import-real --manifest my_pairs.json --out data/real-v1`
   It rejects: hash mismatch, missing/short files, bad frame indices, target = input, target decoder ≠ input decoder, unattested pairs, a recording or file hash in two splits, bit-identical frames.
3. Train/evaluate as in section 4 using `--dataset data/real-v1`. Real datasets have no thin-line/target masks, so the line/target/halo gates **cannot pass** (they report "no masks available") — this deliberately blocks automatic promotion; extend the gates with your own labelled evidence and review the per-scene output yourself before approving.
Different file hashes do not prove independent scenes/devices; one recording gives only exploratory time-block results. Not tested on any real footage.

## 6. Mark difficult frames → curate (workflow)

Use the viewer's ROI/notes/session export to find hard frames; those are *review aids only*. Turning them into training data requires you to obtain a trusted reference and write the manifest (section 5). Evaluator/viewer feedback never becomes a label automatically.

## 7. Privacy, files and deletion

* Recording: read-only. Cache = new folder you name (never overwritten). Registry/datasets/reports = folders you name (`my_registry`, `data/…`).
* Sensitive: dataset `.npz` (contains frames), checkpoints (trained on your frames), reports (frame hashes, scene IDs), session exports (names/ROIs/notes). Delete by deleting those folders/files; nothing exists elsewhere.
* `build/`, `demo_out/`, `node_modules/` are generated and can be deleted.

## 8. Tests

`bash scripts/run_all_tests.sh` (build, typecheck, Python tests, Node tests; real logs in `test_results/`). The optional Playwright browser checks inherited from v1.1.0 (`tests/*browser-check.cjs`) need `npm i -D playwright` + Chromium and were **not run**.
