import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const c = require("./core.cjs");

const baseSettings = {
  width: 64,
  height: 64,
  headerBytes: 0,
  shift: 0,
  littleEndian: true,
  lo: 5500,
  hi: 7500,
};

// ============================================================================
// 1. ORIGINAL ENGINE PROVENANCE & ARGOS 2 / SIX-METHOD PARITY
// ============================================================================

test("1.1 untouched original adapter files match starting_point SHA-256 checksums", () => {
  const expectedHashes = {
    "src/argos/cnnPrototypeEngine.ts":
      "728e957cc333ac365f32e1fe26973bd461ae2ca7811786f6a8d4d8a7f8d65763",
    "src/argos/thermalPipelineEngine.ts":
      "c9ab6e860ac069af19dd3d80498761f4133aa30b1345a8f76e1af8db789cb072",
    "src/claude/cnn-disabled.ts":
      "5f019c602a4d1c8255ac3617ed47e6e6c328dcea7da5919cc19762353dc01bf7",
    "src/claude/dsp.ts":
      "e88fc29e24896b6e060c88602d37cfaca6cc8ed20a37e703df66d4c8b0cb75f2",
    "src/claude/pipeline.ts":
      "a1cc8361ffe49285b82749d648a00a1b66cea91580c4ceb257664e4c675c1a49",
    "src/types/thermal.ts":
      "b26206f43c2ade05a267fd72d501da4c9a7d86122d1ffb41ffe4c27e60fc8c44",
  };

  for (const [relPath, expected] of Object.entries(expectedHashes)) {
    const abs = path.resolve(process.cwd(), relPath);
    assert.ok(fs.existsSync(abs), `Missing original file: ${relPath}`);
    const actual = crypto.createHash("sha256").update(fs.readFileSync(abs)).digest("hex");
    assert.equal(actual, expected, `File ${relPath} was modified from starting_point!`);
  }
});

test("1.2 sequential temporal state vs seek reset on Argos 2 and all original six methods", async () => {
  const get = async (i) => c.synthetic(64, 64, i);
  const runner = c.createMethodRunner("argos2", baseSettings, 30, get);

  const f0 = await runner(await get(0), 0);
  const f1 = await runner(await get(1), 1);
  const f2Sequential = await runner(await get(2), 2);
  assert.equal(f2Sequential.pixels.length, 64 * 64);

  // Non-consecutive seek to frame 10 must reset temporal AGC state and match fresh single-frame run on frame 10
  const f10AfterSeek = await runner(await get(10), 10);
  const f10Fresh = await c.runMethod("argos2", await get(10), baseSettings, 10, 30, get);
  assert.deepEqual(f10AfterSeek.pixels, f10Fresh.pixels);
  assert.deepEqual(f10AfterSeek.restored, f10Fresh.restored);
  assert.ok(f0.pixels.some((v, idx) => v !== f1.pixels[idx]));
});

test("1.3 causal Claude B variant never accesses future frames at sequence start or across split boundaries", async () => {
  const accessedOrig = [];
  const accessedCausal = [];
  const getOrig = async (i) => {
    accessedOrig.push(i);
    return c.synthetic(64, 64, i);
  };
  const getCausal = async (i) => {
    accessedCausal.push(i);
    return c.synthetic(64, 64, i);
  };

  // Original Claude B looks ahead at frame 0
  await c.runMethod("claudeB", c.synthetic(64, 64, 0), baseSettings, 0, 20, getOrig);
  assert.ok(accessedOrig.some((i) => i > 0), "Original Claude B should request future frames at idx=0");

  // Causal Claude B at frame 0 must NEVER request i > 0
  const res0 = await c.runMethod("claudeB-causal", c.synthetic(64, 64, 0), baseSettings, 0, 20, getCausal);
  assert.ok(res0.requestedFrameIndices.every((i) => i === 0), `Causal Claude B requested future frames at idx=0: ${res0.requestedFrameIndices}`);
  assert.ok(accessedCausal.every((i) => i <= 0));

  // Causal Claude B with splitStartIndex=10 evaluated at frame 12 must NEVER request frames < 10 or > 12
  const accessedSplit = [];
  const res12 = await c.runMethod(
    "claudeB-causal",
    c.synthetic(64, 64, 12),
    { ...baseSettings, splitStartIndex: 10 },
    12,
    30,
    async (i) => {
      accessedSplit.push(i);
      return c.synthetic(64, 64, i);
    }
  );
  assert.ok(
    res12.requestedFrameIndices.every((i) => i >= 10 && i <= 12),
    `Split boundary violated: ${res12.requestedFrameIndices}`
  );
  assert.ok(accessedSplit.every((i) => i >= 10 && i <= 12));
});

// ============================================================================
// 2. DECODER INTEGRITY, SHORT/REMAINDER FILES, WIDER-BIT & FULL SHA-256
// ============================================================================

test("2.1 decoder rejects short buffers, short files, negative and out-of-bounds frame indices without zero-padding", async () => {
  const conf = c.decodeConfig(baseSettings);
  const oneFrameBytes = 64 * 64 * 2;

  // Buffer smaller than 1 frame must throw
  const shortBuf = new ArrayBuffer(oneFrameBytes - 2);
  assert.throws(() => c.decodeBuffer(shortBuf, conf), /smaller than one complete frame/);

  // File smaller than 1 frame must throw on readFrame
  const shortBlob = new Blob([new Uint8Array(oneFrameBytes - 10)]);
  assert.deepEqual(c.frameCountFor(shortBlob.size, conf), { frames: 0, remainder: oneFrameBytes - 10 });
  await assert.rejects(() => c.readFrame(shortBlob, conf, 0), /smaller than one complete frame/);

  // Two frames + 7 remainder bytes
  const twoPlusRem = new Uint8Array(2 * oneFrameBytes + 7);
  const dv = new DataView(twoPlusRem.buffer);
  dv.setUint16(0, 6123, true);
  dv.setUint16(oneFrameBytes, 6789, true);
  const blob2 = new Blob([twoPlusRem]);
  assert.deepEqual(c.frameCountFor(blob2.size, conf), { frames: 2, remainder: 7 });

  const f0 = await c.readFrame(blob2, conf, 0);
  const f1 = await c.readFrame(blob2, conf, 1);
  assert.equal(f0[0], 6123);
  assert.equal(f1[0], 6789);

  // Out-of-bounds indices (-1, 2, 99) must throw
  await assert.rejects(() => c.readFrame(blob2, conf, -1), /Invalid frame index/);
  await assert.rejects(() => c.readFrame(blob2, conf, 2), /out of bounds/);
});

test("2.2 full-file streaming SHA-256 matches Node crypto across multi-megabyte files and supports cancellation", async () => {
  // Create a 5.2 MiB buffer (spans multiple 4 MiB streaming chunks)
  const size = 5 * 1024 * 1024 + 12345;
  const buf = new Uint8Array(size);
  for (let i = 0; i < size; i += 4096) buf[i] = (i * 37) & 0xff;
  buf[size - 1] = 0xfe; // byte at the very end outside any initial sample

  const expected = crypto.createHash("sha256").update(buf).digest("hex");
  const progresses = [];
  const actual = await c.sha256File(new Blob([buf]), (p) => progresses.push(p));
  assert.equal(actual, expected);
  assert.ok(progresses.length >= 2, "Should report progress across multiple chunks");
  assert.equal(progresses.at(-1), 1);

  // Modifying a single byte at the end of a >5 MiB file MUST change the full SHA-256
  buf[size - 1] = 0xff;
  const actualModified = await c.sha256File(new Blob([buf]));
  assert.notEqual(actualModified, actual, "Full-file SHA-256 must detect single-byte changes anywhere in file");

  // Cancellation via AbortController
  const ac = new AbortController();
  ac.abort();
  await assert.rejects(() => c.sha256File(new Blob([buf]), undefined, ac.signal), /cancelled/);
});

test("2.3 wider-bit (16-bit) support preserves true range in frameStats/percentileWindow and requires explicit consent for 14-bit legacy methods", async () => {
  // Regression test for Claude review issue #1: [20000, 30000, 20000, 30000] at 16-bit must NOT clip to 16383
  const wideArr = Uint16Array.from([20000, 30000, 20000, 30000]);
  const st16 = c.frameStats(wideArr, 65535);
  assert.equal(st16.min, 20000);
  assert.equal(st16.max, 30000);
  assert.equal(st16.p1, 20000);
  assert.equal(st16.p50, 20000);
  assert.equal(st16.p99, 30000);

  const pw16 = c.percentileWindow(wideArr, 1, 99, 65535);
  assert.equal(pw16.lo, 20000);
  assert.equal(pw16.hi, 30000);

  // Legacy 14-bit methods must refuse 16-bit input unless allow14BitCompatibilityScaling=true
  const raw16 = new Uint16Array(64 * 64).fill(28000);
  const s16Unapproved = { ...baseSettings, bits: 16, lo: 15000, hi: 45000, allow14BitCompatibilityScaling: false };
  await assert.rejects(
    () => c.runMethod("argos2", raw16, s16Unapproved, 0, 1, async () => raw16),
    /explicitly enable user-approved 14-bit compatibility scaling/
  );

  // With explicit approval, compatibility scaling succeeds and attaches a non-silent warning
  const s16Approved = { ...s16Unapproved, allow14BitCompatibilityScaling: true };
  const resApproved = await c.runMethod("argos2", raw16, s16Approved, 0, 1, async () => raw16);
  assert.equal(resApproved.pixels.length, 64 * 64);
  assert.match(resApproved.compatibilityWarning, /User-approved compatibility scaling applied/);
});

// ============================================================================
// 3. STALE INVALIDATION, ROI MAPPING & NON-CATEGORICAL ORDERING CHECKS
// ============================================================================

test("3.1 ablation context key invalidates when source, frame, decoder, window, ROI, or CNN state changes", () => {
  const baseCtx = {
    sourceKey: "file:a.raw:1000:hash1",
    frameIndex: 0,
    width: 64,
    height: 64,
    headerBytes: 0,
    shift: 0,
    littleEndian: true,
    lo: 5500,
    hi: 7500,
    rois: [{ id: "r1", role: "animal", label: "animal 1", x: 10, y: 10, w: 8, h: 8 }],
    cnnCheckpointId: "ckpt-1",
    cnnBypassed: false,
  };
  const k0 = c.computeAblationContextKey(baseCtx);
  assert.notEqual(k0, c.computeAblationContextKey({ ...baseCtx, frameIndex: 1 }));
  assert.notEqual(k0, c.computeAblationContextKey({ ...baseCtx, lo: 5600 }));
  assert.notEqual(k0, c.computeAblationContextKey({ ...baseCtx, rois: [] }));
  assert.notEqual(k0, c.computeAblationContextKey({ ...baseCtx, cnnBypassed: true }));
  assert.notEqual(k0, c.computeAblationContextKey({ ...baseCtx, cnnCheckpointId: "ckpt-2" }));
});

test("3.2 computeRows detects spatial intensity ordering reversal without categorical 3-sigma verdicts", () => {
  const W = 16,
    H = 16;
  const raw = new Uint16Array(W * H).fill(6000);
  const refDisp = new Uint8Array(W * H).fill(100);
  const procDisp = new Uint8Array(W * H).fill(100);

  // Animal ROI (x:2..6, y:2..6) has raw=6120, ref=140, but local operator made procDisp=90
  // Bridge ROI (x:8..12, y:8..12) has raw=6100, ref=130, but local operator made procDisp=150
  for (let y = 2; y < 6; y++)
    for (let x = 2; x < 6; x++) {
      raw[y * W + x] = 6120;
      refDisp[y * W + x] = 140;
      procDisp[y * W + x] = 90;
    }
  for (let y = 8; y < 12; y++)
    for (let x = 8; x < 12; x++) {
      raw[y * W + x] = 6100;
      refDisp[y * W + x] = 130;
      procDisp[y * W + x] = 150;
    }

  const rois = [
    { id: "a1", role: "animal", label: "Animal 1", x: 2, y: 2, w: 4, h: 4 },
    { id: "b1", role: "bridge", label: "Bridge 1", x: 8, y: 8, w: 4, h: 4 },
    { id: "bg1", role: "background", label: "BG 1", x: 0, y: 12, w: 4, h: 4 },
  ];

  const { rows, pairs } = c.computeRows(rois, W, H, raw, raw, refDisp, procDisp, 16383);
  assert.equal(rows.length, 3);
  assert.equal(pairs.length, 1);
  assert.ok(pairs[0].rawDelta > 0);
  assert.ok(pairs[0].procDelta < 0);
  assert.equal(pairs[0].orderingChangedInProc, true);
  assert.match(pairs[0].verdict, /reversed the median display ordering/);
  assert.doesNotMatch(pairs[0].verdict, /NOT separable/);
});

// ============================================================================
// 4. PLAYBACK >60 FRAMES, FULL-RESOLUTION 640x512 FILE TEST & CNN PLAYBACK
// ============================================================================

test("4.1 sequential playback over 75 frames (>60 frames) with raw, Argos 2, and active CNN + seek and bypass", async () => {
  const numFrames = 75;
  const W = 64,
    H = 64;
  const fb = W * H * 2;
  const rawBytes = new Uint8Array(numFrames * fb);
  for (let i = 0; i < numFrames; i++) {
    const f = c.synthetic(W, H, i);
    rawBytes.set(c.encodeUint16LeBytes(f), i * fb);
  }
  const blob = new Blob([rawBytes]);
  const conf = c.decodeConfig(baseSettings);
  const counts = c.frameCountFor(blob.size, conf);
  assert.equal(counts.frames, 75, "Must decode all 75 frames without any 60-frame limit");

  // Train a tiny CNN checkpoint and build a 75-frame local inference cache
  const ds = c.buildSyntheticDataset({ version: 1, width: W, height: H });
  const ckpt = c.trainCnnCandidate({
    checkpointId: "ckpt-playback-75",
    cycleNumber: 1,
    manifest: ds.manifest,
    pairs: ds.pairs,
    steps: 12,
  });

  const cache = c.buildLocalInferenceCache({
    sourceFileName: "seventyfive.raw",
    sourceBytes: rawBytes,
    decoder: conf,
    checkpoint: ckpt,
    isApprovedActiveModel: true,
  });
  assert.equal(cache.manifest.frameCount, 75);

  const getFrame = async (i) => c.readFrame(blob, conf, i);
  const argosRunner = c.createMethodRunner("argos2", baseSettings, numFrames, getFrame);
  const cnnRunner = c.createMethodRunner("cnn-active", baseSettings, numFrames, getFrame, {
    checkpoint: ckpt,
    bypassCnn: false,
  });
  const cnnBypassedRunner = c.createMethodRunner("cnn-active", baseSettings, numFrames, getFrame, {
    checkpoint: ckpt,
    bypassCnn: true,
  });

  // Play frames 58..74 sequentially (crossing frame 60 boundary!)
  const seenIndices = [];
  for (let i = 58; i < numFrames; i++) {
    const f = await getFrame(i);
    const aOut = await argosRunner(f, i);
    const cOut = await cnnRunner(f, i);
    assert.equal(aOut.pixels.length, W * H);
    assert.equal(cOut.pixels.length, W * H);
    seenIndices.push(i);
  }
  assert.equal(seenIndices[0], 58);
  assert.equal(seenIndices.at(-1), 74);
  assert.equal(seenIndices.length, 17);

  // Verify frame 68 active CNN differs from bypassed CNN, and bypassed CNN matches classical Stage 1 fixed-window
  const f68 = await getFrame(68);
  const active68 = await cnnRunner(f68, 68);
  const bypassed68 = await cnnBypassedRunner(f68, 68);
  const expectedStage1 = c.map14BitToFixedWindow8(
    c.computeArgos2Stage1Clean14(f68, W, H).stage1Clean14,
    baseSettings.lo,
    baseSettings.hi
  );
  assert.deepEqual(bypassed68.pixels, expectedStage1, "Bypassing CNN must recover exact classical baseline");
  assert.ok(
    active68.pixels.some((v, idx) => v !== bypassed68.pixels[idx]),
    "Active CNN output must differ from bypassed baseline on structured frame 68"
  );
});

test("4.2 full-resolution 640x512 generated uint16 file decodes, hashes, and runs Argos 2 and CNN", async () => {
  const sFull = { ...baseSettings, width: 640, height: 512 };
  const conf = c.decodeConfig(sFull);
  const fb = c.frameBytes(conf);
  const totalBytes = new Uint8Array(2 * fb);
  for (let i = 0; i < 2; i++) {
    const frame = c.synthetic(640, 512, i);
    totalBytes.set(c.encodeUint16LeBytes(frame), i * fb);
  }
  const blob = new Blob([totalBytes]);
  assert.deepEqual(c.frameCountFor(blob.size, conf), { frames: 2, remainder: 0 });

  const f1 = await c.readFrame(blob, conf, 1);
  assert.equal(f1.length, 640 * 512);
  const argosRes = await c.runMethod("argos2", f1, sFull, 1, 2, async (idx) => c.readFrame(blob, conf, idx));
  assert.equal(argosRes.pixels.length, 640 * 512);
});

// ============================================================================
// 5. GENUINE STAGE ABLATION & 8-SCENARIO HARD-NEGATIVE BENCHMARK
// ============================================================================

test("5.1 genuine stage ablation isolates line-only and detail-only under a single locked reference window", () => {
  const frame = c.synthetic(64, 64, 2);
  const report = c.runGenuineStageAblation({
    sourceKey: "synth",
    raw14: frame,
    width: 64,
    height: 64,
    frameIndex: 2,
    lo: 5500,
    hi: 7500,
    rois: [{ id: "r1", role: "animal", label: "animal 1", x: 12, y: 38, w: 12, h: 10 }],
  });

  assert.equal(report.views.length, 7);
  const byId = Object.fromEntries(report.views.map((v) => [v.id, v]));

  // Verify raw, line_only, detail_only, and combined_classical all use locked_fixed_window
  assert.equal(byId.raw_fixed_window.toneDomain, "locked_fixed_window");
  assert.equal(byId.line_only_fixed_window.toneDomain, "locked_fixed_window");
  assert.equal(byId.detail_only_fixed_window.toneDomain, "locked_fixed_window");
  assert.equal(byId.combined_classical_fixed_window.toneDomain, "locked_fixed_window");

  // Regression test for Argon review issue #5: detail_only_fixed_window MUST differ from raw_fixed_window!
  assert.ok(
    byId.detail_only_fixed_window.rmsDiffFromRaw8 > 0.5,
    `Detail-only ablation must change structured pixels (got rmsDiff=${byId.detail_only_fixed_window.rmsDiffFromRaw8})`
  );
  assert.ok(
    byId.line_only_fixed_window.rmsDiffFromRaw8 > 0.5,
    `Line-only ablation must change striped pixels (got rmsDiff=${byId.line_only_fixed_window.rmsDiffFromRaw8})`
  );
  assert.ok(
    byId.detail_only_fixed_window.pixels8.some((v, i) => v !== byId.line_only_fixed_window.pixels8[i]),
    "Detail-only and Line-only ablations must be distinct"
  );
});

test("5.2 8-scenario synthetic hard-negative suite and real-footage no-reference proxy separation", async () => {
  const suite = await c.runHardNegativeBenchmarkSuite({ width: 64, height: 64 });
  assert.equal(suite.syntheticOnly, true);
  assert.equal(suite.cases.length, 8 * suite.methodsCompared.length);

  // Verify that alternating strong ±150 ADU stripe limitation of Original Argos 2 is honestly exposed
  const argos2Alt = suite.cases.find(
    (x) => x.scenarioId === "alternating_strong_stripes" && x.methodId === "argos2"
  );
  assert.ok(argos2Alt.colStripeRmsAdu > 100, "Original Argos 2 default retains strong alternating Nyquist stripes");
  assert.match(argos2Alt.failureOrTradeoffNote, /Tradeoff\/Failure/);

  // Verify real-footage no-reference helper explicitly returns null for PSNR, SSIM, and temperature
  const raw = c.synthetic(64, 64, 0);
  const noRef = c.computeNoReferenceRealFootageProxies(raw, raw, new Uint8Array(64 * 64), 64, 64);
  assert.equal(noRef.cleanTruthAvailable, false);
  assert.equal(noRef.psnrDb, null);
  assert.equal(noRef.ssim, null);
  assert.equal(noRef.calibratedTemperatureCelsius, null);
  assert.match(noRef.warning, /NO-REFERENCE PROXY ONLY/);
});

// ============================================================================
// 6. CONTROLLED OFFLINE CNN LOOP: VALIDATION, TRAINING, GATES, PROMOTION, ROLLBACK & OFFLINE CSP
// ============================================================================

test("6.1 dataset manifest validator rejects missing attestation, adjacent frames, blurred/model targets, and cross-split leakage", () => {
  const validDs = c.buildSyntheticDataset({ version: 1, width: 64, height: 64 });
  assert.equal(validDs.validation.valid, true);

  // Load the deliberately invalid manifest from examples/invalid_leakage_manifest_example.json
  const badManifest = JSON.parse(
    fs.readFileSync(path.resolve(process.cwd(), "examples/invalid_leakage_manifest_example.json"), "utf8")
  );
  const badRes = c.validateDatasetManifest(badManifest);
  assert.equal(badRes.valid, false);
  assert.ok(badRes.errors.some((e) => /notAdjacentFrameNoise2Noise/.test(e)));
  assert.ok(badRes.errors.some((e) => /notModelPredictionOrBlur/.test(e)));
  assert.ok(badRes.errors.some((e) => /adjacent\/nearby frames/.test(e)));
  assert.ok(badRes.errors.some((e) => /Content SHA-256.*multiple splits/.test(e)));
  assert.ok(badRes.errors.some((e) => /Recording.*multiple splits/.test(e)));
});

test("6.2 two-cycle offline CNN loop updates conv weights, enforces safety gates, blocks failing candidate, promotes, rolls back, and audits final_test", () => {
  const demo = c.runTwoCycleSyntheticDemo({
    width: 64,
    height: 64,
    stepsCycle1: 20,
    stepsCycle2: 20,
    leaveCycle1ActiveAfterRollback: true,
  });

  // 1) Actual conv weight update and finite parameters
  assert.ok(demo.cycle1Checkpoint.totalWeightUpdateL2 > 0.01, "Conv weights must update during training");
  assert.notEqual(demo.cycle1Checkpoint.initialWeightsSha256, demo.cycle1Checkpoint.weightsSha256);
  assert.ok(
    demo.cycle1Checkpoint.stepHistory.at(-1).trainLoss < demo.cycle1Checkpoint.stepHistory[0].trainLoss,
    "Training loss must decrease"
  );
  assert.equal(c.verifyCheckpointIntegrity(demo.cycle1Checkpoint), true);

  // 2) Cycle 1 passed all 7 mandatory safety gates
  assert.equal(demo.cycle1Report.allMandatoryGatesPassed, true);
  assert.equal(demo.cycle1Report.failedGates.length, 0);

  // 3) Cycle 2 failing candidate failed gates, was rejected, and promotion was blocked
  assert.equal(demo.cycle2FailingReport.allMandatoryGatesPassed, false);
  assert.ok(demo.cycle2FailingReport.failedGates.length >= 2);
  assert.equal(demo.cycle2FailingCheckpoint.status, "rejected");
  assert.match(demo.promotionBlockedError, /Cannot promote 'ckpt-cycle2-regressing-cand'/);

  // 4) Cycle 2 passing candidate passed all gates, was promoted, and rollback restored exact Cycle 1 checkpoint
  assert.equal(demo.cycle2PassingReport.allMandatoryGatesPassed, true);
  assert.equal(demo.rollbackResult.rolledBackCheckpointId, "ckpt-cycle2-synth-v2");
  assert.equal(demo.rollbackResult.restoredCheckpointId, "ckpt-cycle1-synth-v1");
  assert.equal(demo.registry.activeCheckpointId, "ckpt-cycle1-synth-v1");

  // 5) Untouched final_test split is locked unless unlockFinalTest=true, and every invocation is audited
  const ds2 = c.buildSyntheticDataset({ version: 2, width: 64, height: 64 });
  assert.throws(
    () =>
      c.invokeUntouchedFinalTest(demo.registry, {
        checkpointId: "ckpt-cycle1-synth-v1",
        reviewer: "Auditor",
        reason: "Locked check",
        pairs: ds2.pairs,
        unlockFinalTest: false,
      }),
    /locked by default/
  );
  const finalRep = c.invokeUntouchedFinalTest(demo.registry, {
    checkpointId: "ckpt-cycle1-synth-v1",
    reviewer: "Auditor",
    reason: "Final untouched test evaluation",
    pairs: ds2.pairs,
    unlockFinalTest: true,
  });
  assert.equal(finalRep.splitEvaluated, "final_test");
  assert.equal(demo.registry.finalTestInvocations.length, 1);
  assert.equal(demo.registry.finalTestInvocations[0].checkpointId, "ckpt-cycle1-synth-v1");
});

test("6.3 local inference cache verifies source SHA-256 and rejects mismatched source/frame/decoder", () => {
  const ds = c.buildSyntheticDataset({ version: 1, width: 64, height: 64 });
  const ckpt = c.trainCnnCandidate({
    checkpointId: "ckpt-cache-test",
    cycleNumber: 1,
    manifest: ds.manifest,
    pairs: ds.pairs,
    steps: 8,
  });
  const decoder = c.decodeConfig(baseSettings);
  const fb = c.frameBytes(decoder);
  const rawBytes = new Uint8Array(3 * fb);
  for (let i = 0; i < 3; i++) {
    rawBytes.set(c.encodeUint16LeBytes(c.synthetic(64, 64, i)), i * fb);
  }

  const { manifest, cacheBytes } = c.buildLocalInferenceCache({
    sourceFileName: "three.raw",
    sourceBytes: rawBytes,
    decoder,
    checkpoint: ckpt,
    isApprovedActiveModel: true,
  });
  assert.equal(cacheBytes.byteLength, 3 * fb);

  // Matching source passes verification
  const okCheck = c.verifyCacheAgainstSource({
    manifest,
    sourceByteLength: rawBytes.byteLength,
    sourceSha256: manifest.sourceSha256,
    expectedFrames: 3,
    decoder,
  });
  assert.equal(okCheck.valid, true);

  // Mismatched SHA-256 or frame count is rejected
  const badHashCheck = c.verifyCacheAgainstSource({
    manifest,
    sourceByteLength: rawBytes.byteLength,
    sourceSha256: "0000000000000000000000000000000000000000000000000000000000000000",
    expectedFrames: 3,
    decoder,
  });
  assert.equal(badHashCheck.valid, false);
  assert.match(badHashCheck.error, /SHA-256 mismatch/);

  const badCountCheck = c.verifyCacheAgainstSource({
    manifest,
    sourceByteLength: rawBytes.byteLength,
    sourceSha256: manifest.sourceSha256,
    expectedFrames: 4,
    decoder,
  });
  assert.equal(badCountCheck.valid, false);
});

test("6.4 built ClearHot_Local.html enforces offline CSP (connect-src 'none') and contains zero external network URLs", () => {
  const htmlPath = path.resolve(process.cwd(), "ClearHot_Local.html");
  assert.ok(fs.existsSync(htmlPath), "ClearHot_Local.html must exist");
  const html = fs.readFileSync(htmlPath, "utf8");
  assert.match(html, /connect-src 'none'/, "CSP must block all network connections (connect-src 'none')");
  assert.doesNotMatch(html, /https?:\/\//i, "Self-contained HTML must not reference any external http/https URLs");
});
