"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/core.ts
var core_exports = {};
__export(core_exports, {
  ALL_LABELS: () => ALL_LABELS,
  CNN_ARCHITECTURE_ID: () => CNN_ARCHITECTURE_ID,
  CONTROLLED_VARIANT_METHODS: () => CONTROLLED_VARIANT_METHODS,
  DEFAULT_CNN_HYPERPARAMS: () => DEFAULT_CNN_HYPERPARAMS,
  DEFAULT_SAFETY_THRESHOLDS: () => DEFAULT_SAFETY_THRESHOLDS,
  LABELS: () => LABELS,
  METHODS: () => METHODS,
  PLAYABLE_METHODS: () => PLAYABLE_METHODS,
  VARIANT_LABELS: () => VARIANT_LABELS,
  VERSION: () => VERSION,
  allParametersFinite: () => allParametersFinite,
  applyAdamStep: () => applyAdamStep,
  approveAndPromoteCandidate: () => approveAndPromoteCandidate,
  argos2SeparatedGuidedDetail14: () => argos2SeparatedGuidedDetail14,
  argos2SeparatedLineOnly14: () => argos2SeparatedLineOnly14,
  buildLocalInferenceCache: () => buildLocalInferenceCache,
  buildSyntheticDataset: () => buildSyntheticDataset,
  checkMonotonic: () => checkMonotonic,
  cnr: () => cnr,
  computeAblationContextKey: () => computeAblationContextKey,
  computeArchitectureHash: () => computeArchitectureHash,
  computeArgos2Stage1Clean14: () => computeArgos2Stage1Clean14,
  computeFlatStripeRmsAdu: () => computeFlatStripeRmsAdu,
  computeHaloOvershootAdu: () => computeHaloOvershootAdu,
  computeNoReferenceRealFootageProxies: () => computeNoReferenceRealFootageProxies,
  computePsnr14Bit: () => computePsnr14Bit,
  computeRows: () => computeRows,
  computeSsim14Bit: () => computeSsim14Bit,
  computeThinFeatureRetention: () => computeThinFeatureRetention,
  computeWeightsSha256: () => computeWeightsSha256,
  configFor: () => configFor,
  countParameters: () => countParameters,
  createAdamState: () => createAdamState,
  createEmptyRegistry: () => createEmptyRegistry,
  createInitialParameters: () => createInitialParameters,
  createMethodRunner: () => createMethodRunner,
  decodeBuffer: () => decodeBuffer,
  decodeConfig: () => decodeConfig,
  deserializeParameters: () => deserializeParameters,
  diagnoseFormat: () => diagnoseFormat,
  encodeUint16LeBytes: () => encodeUint16LeBytes,
  estimateInferenceCacheDiskBytes: () => estimateInferenceCacheDiskBytes,
  evaluateCnnCandidate: () => evaluateCnnCandidate,
  forwardAndBackward: () => forwardAndBackward,
  frameBytes: () => frameBytes,
  frameCountFor: () => frameCountFor,
  frameStats: () => frameStats,
  generateHardNegativeFixtures: () => generateHardNegativeFixtures,
  generateSyntheticPair: () => generateSyntheticPair,
  inferCnn14: () => inferCnn14,
  invokeUntouchedFinalTest: () => invokeUntouchedFinalTest,
  map14BitThroughArgos2NativeStages: () => map14BitThroughArgos2NativeStages,
  map14BitToFixedWindow8: () => map14BitToFixedWindow8,
  maxCode: () => maxCode,
  medianGap: () => medianGap,
  nearestBackground: () => nearestBackground,
  parameterL2Distance: () => parameterL2Distance,
  percentileWindow: () => percentileWindow,
  readFrame: () => readFrame,
  reference: () => reference,
  registerCandidateCheckpoint: () => registerCandidateCheckpoint,
  rejectCandidateByHuman: () => rejectCandidateByHuman,
  roiStats: () => roiStats,
  rollbackActiveModel: () => rollbackActiveModel,
  runArgos2CausalTemporalCandidate: () => runArgos2CausalTemporalCandidate,
  runArgos2GuidedCoredCandidate: () => runArgos2GuidedCoredCandidate,
  runClaudeBCausalCandidate: () => runClaudeBCausalCandidate,
  runGenuineStageAblation: () => runGenuineStageAblation,
  runHardNegativeBenchmarkSuite: () => runHardNegativeBenchmarkSuite,
  runMethod: () => runMethod,
  runTwoCycleSyntheticDemo: () => runTwoCycleSyntheticDemo,
  serializeParameters: () => serializeParameters,
  sha256Bytes: () => sha256Bytes,
  sha256File: () => sha256File,
  stats: () => stats,
  synthetic: () => synthetic,
  temporalDifference: () => temporalDifference,
  to14BitForLegacyMethods: () => to14BitForLegacyMethods,
  toneFn: () => toneFn,
  trainCnnCandidate: () => trainCnnCandidate,
  validSettings: () => validSettings,
  validateDatasetManifest: () => validateDatasetManifest,
  validateRegisteredCandidate: () => validateRegisteredCandidate,
  verifyAndDecodeCuratedPair: () => verifyAndDecodeCuratedPair,
  verifyCacheAgainstSource: () => verifyCacheAgainstSource,
  verifyCheckpointIntegrity: () => verifyCheckpointIntegrity
});
module.exports = __toCommonJS(core_exports);

// src/argos/cnnPrototypeEngine.ts
function createInitialCnnState(methodology) {
  if (methodology === "instance1") {
    return {
      methodology: "instance1",
      architectureName: "StripeResNet-1D2D (Separable 1\xD77 / 7\xD71 + 3\xD73 Residual CNN)",
      trainedEpochs: 0,
      isTrained: false,
      initialLoss: 0,
      currentLoss: 0,
      valLoss: 0,
      lossHistory: [],
      paramCount: 148,
      lastTrainTimeMs: 0,
      kHoriz: new Float32Array([-0.02, -0.04, -0.08, 0.28, -0.08, -0.04, -0.02]),
      kVert: new Float32Array([0.05, 0.1, 0.2, 0.3, 0.2, 0.1, 0.05]),
      kSpatial: new Float32Array([
        -0.02,
        -0.03,
        -0.02,
        -0.03,
        0.2,
        -0.03,
        -0.02,
        -0.03,
        -0.02
      ]),
      mixWeights: new Float32Array([0.15, 0.12, 0.1, 45]),
      // [wVertStripe, wHorizStripe, wStatic, edgeGateScale]
      bias: 0
    };
  }
  if (methodology === "instance2") {
    return {
      methodology: "instance2",
      architectureName: "HaarWaveletCNN (2D DWT Subband HL/LH/HH Learned Shrinkage Net)",
      trainedEpochs: 0,
      isTrained: false,
      initialLoss: 0,
      currentLoss: 0,
      valLoss: 0,
      lossHistory: [],
      paramCount: 192,
      lastTrainTimeMs: 0,
      kHoriz: new Float32Array([0.1, 0.2, 0.4, 0.2, 0.1, 0, 0]),
      // HL vertical-stripe subband smoother along y
      kVert: new Float32Array([0.1, 0.2, 0.4, 0.2, 0.1, 0, 0]),
      // LH horizontal-stripe subband smoother along x
      kSpatial: new Float32Array([
        0.05,
        0.1,
        0.05,
        0.1,
        0.4,
        0.1,
        0.05,
        0.1,
        0.05
      ]),
      // [hlShrinkGain, lhShrinkGain, hhStaticGain, softThresholdADU]
      mixWeights: new Float32Array([0.15, 0.15, 0.12, 18]),
      bias: 0
    };
  }
  return {
    methodology: "instance3",
    architectureName: "BurstTempCNN (Self-Supervised Orthogonal Projection + Temporal Gate CNN)",
    trainedEpochs: 0,
    isTrained: false,
    initialLoss: 0,
    currentLoss: 0,
    valLoss: 0,
    lossHistory: [],
    paramCount: 224,
    lastTrainTimeMs: 0,
    kHoriz: new Float32Array([-0.03, -0.06, -0.1, 0.38, -0.1, -0.06, -0.03]),
    kVert: new Float32Array([0.08, 0.14, 0.2, 0.16, 0.2, 0.14, 0.08]),
    kSpatial: new Float32Array([
      -0.02,
      -0.04,
      -0.02,
      -0.04,
      0.24,
      -0.04,
      -0.02,
      -0.04,
      -0.02
    ]),
    // [wColNull, wRowNull, wTemporalStatic, motionProtectSigma]
    mixWeights: new Float32Array([0.14, 0.14, 0.12, 65]),
    bias: 0
  };
}
function applyLiveCnnResidual14(input14, W, H, cnn, blendStrength = 1) {
  const N = W * H;
  const out = new Float32Array(input14);
  if (blendStrength <= 1e-3) return out;
  const [w1, w2, w3, gateScale] = cnn.mixWeights;
  const kH = cnn.kHoriz;
  const kV = cnn.kVert;
  const kS = cnn.kSpatial;
  if (cnn.methodology === "instance1") {
    const horizHP = new Float32Array(N);
    const vertHP = new Float32Array(N);
    for (let y = 3; y < H - 3; y++) {
      const rowOff = y * W;
      for (let x = 3; x < W - 3; x++) {
        const idx = rowOff + x;
        const c = input14[idx];
        let hConv = 0;
        for (let k = -3; k <= 3; k++) {
          const diff = c - input14[rowOff + x + k];
          const clamped = Math.max(-gateScale, Math.min(gateScale, diff));
          hConv += clamped * (k === 0 ? 0 : -kH[k + 3]);
        }
        horizHP[idx] = hConv;
        let vConv = 0;
        for (let k = -3; k <= 3; k++) {
          const diff = c - input14[(y + k) * W + x];
          const clamped = Math.max(-gateScale, Math.min(gateScale, diff));
          vConv += clamped * (k === 0 ? 0 : -kH[k + 3]);
        }
        vertHP[idx] = vConv;
      }
    }
    for (let y = 3; y < H - 3; y++) {
      const rowOff = y * W;
      for (let x = 3; x < W - 3; x++) {
        const idx = rowOff + x;
        let colStripeEst = 0;
        let rowStripeEst = 0;
        for (let k = -3; k <= 3; k++) {
          colStripeEst += horizHP[(y + k) * W + x] * kV[k + 3];
          rowStripeEst += vertHP[rowOff + x + k] * kV[k + 3];
        }
        const c = input14[idx];
        const l = input14[idx - 1];
        const r = input14[idx + 1];
        const u = input14[idx - W];
        const d = input14[idx + W];
        const localLap = c - 0.25 * (l + r + u + d);
        const edgeGate = Math.exp(-(localLap * localLap) / (2 * gateScale * gateScale));
        const staticRes = localLap * edgeGate * kS[4];
        const predictedNoise = (w1 * colStripeEst + w2 * rowStripeEst + w3 * staticRes + cnn.bias) * blendStrength;
        out[idx] = c - predictedNoise;
      }
    }
    return out;
  }
  if (cnn.methodology === "instance2") {
    const halfW = Math.floor(W / 2);
    const halfH = Math.floor(H / 2);
    const thresh = Math.max(4, gateScale);
    const LL = new Float32Array(halfW * halfH);
    const HL = new Float32Array(halfW * halfH);
    const LH = new Float32Array(halfW * halfH);
    const HH = new Float32Array(halfW * halfH);
    for (let hy = 0; hy < halfH; hy++) {
      const y0 = hy * 2;
      const y1 = y0 + 1;
      for (let hx = 0; hx < halfW; hx++) {
        const x0 = hx * 2;
        const x1 = x0 + 1;
        const a = input14[y0 * W + x0];
        const b = input14[y0 * W + x1];
        const c = input14[y1 * W + x0];
        const d = input14[y1 * W + x1];
        const hIdx = hy * halfW + hx;
        LL[hIdx] = 0.25 * (a + b + c + d);
        HL[hIdx] = 0.25 * (a - b + c - d);
        LH[hIdx] = 0.25 * (a + b - c - d);
        HH[hIdx] = 0.25 * (a - b - c + d);
      }
    }
    for (let hy = 2; hy < halfH - 2; hy++) {
      for (let hx = 2; hx < halfW - 2; hx++) {
        const hIdx = hy * halfW + hx;
        let hlCoherent = 0;
        for (let k = -2; k <= 2; k++) {
          hlCoherent += HL[(hy + k) * halfW + hx] * kH[k + 2];
        }
        let lhCoherent = 0;
        for (let k = -2; k <= 2; k++) {
          lhCoherent += LH[hy * halfW + (hx + k)] * kV[k + 2];
        }
        const hlGate = Math.exp(-(hlCoherent * hlCoherent) / (2 * thresh * thresh * 4));
        const lhGate = Math.exp(-(lhCoherent * lhCoherent) / (2 * thresh * thresh * 4));
        const hhVal = HH[hIdx];
        const hhGate = Math.exp(-(hhVal * hhVal) / (2 * thresh * thresh));
        HL[hIdx] -= hlCoherent * Math.min(0.95, w1) * hlGate * blendStrength;
        LH[hIdx] -= lhCoherent * Math.min(0.95, w2) * lhGate * blendStrength;
        HH[hIdx] -= hhVal * Math.min(0.9, w3) * hhGate * blendStrength;
      }
    }
    for (let hy = 0; hy < halfH; hy++) {
      const y0 = hy * 2;
      const y1 = y0 + 1;
      for (let hx = 0; hx < halfW; hx++) {
        const x0 = hx * 2;
        const x1 = x0 + 1;
        const hIdx = hy * halfW + hx;
        const ll = LL[hIdx];
        const hl = HL[hIdx];
        const lh = LH[hIdx];
        const hh = HH[hIdx];
        out[y0 * W + x0] = ll + hl + lh + hh;
        out[y0 * W + x1] = ll - hl + lh - hh;
        out[y1 * W + x0] = ll + hl - lh - hh;
        out[y1 * W + x1] = ll - hl - lh + hh;
      }
    }
    return out;
  }
  const colRes = new Float32Array(W);
  const rowRes = new Float32Array(H);
  for (let x = 1; x < W - 1; x++) {
    let sumDiff = 0;
    let weightSum = 0;
    for (let y = 4; y < H - 4; y += 2) {
      const idx = y * W + x;
      const dx = input14[idx] - 0.5 * (input14[idx - 1] + input14[idx + 1]);
      const dy = input14[idx + W] - input14[idx - W];
      const w = Math.exp(-(dx * dx + 0.5 * dy * dy) / (2 * gateScale * gateScale));
      sumDiff += dx * w;
      weightSum += w;
    }
    colRes[x] = weightSum > 1e-3 ? sumDiff / weightSum : 0;
  }
  for (let y = 1; y < H - 1; y++) {
    let sumDiff = 0;
    let weightSum = 0;
    const rowOff = y * W;
    for (let x = 4; x < W - 4; x += 2) {
      const idx = rowOff + x;
      const dy = input14[idx] - 0.5 * (input14[idx - W] + input14[idx + W]);
      const dx = input14[idx + 1] - input14[idx - 1];
      const w = Math.exp(-(dy * dy + 0.5 * dx * dx) / (2 * gateScale * gateScale));
      sumDiff += dy * w;
      weightSum += w;
    }
    rowRes[y] = weightSum > 1e-3 ? sumDiff / weightSum : 0;
  }
  for (let y = 1; y < H - 1; y++) {
    const rowOff = y * W;
    for (let x = 1; x < W - 1; x++) {
      const idx = rowOff + x;
      const c = input14[idx];
      const avg4 = 0.25 * (input14[idx - 1] + input14[idx + 1] + input14[idx - W] + input14[idx + W]);
      const diff = c - avg4;
      const staticGate = Math.exp(-(diff * diff) / (2 * gateScale * gateScale));
      const corr = (w1 * colRes[x] + w2 * rowRes[y] + w3 * diff * staticGate + cnn.bias) * blendStrength;
      out[idx] = c - corr;
    }
  }
  return out;
}

// src/argos/thermalPipelineEngine.ts
var DEFAULT_ISP_CONFIGS = {
  instance1: {
    stage1DestripeAndBadPx: true,
    stage2TemporalQuantileAgc: true,
    stage3DualPlateauCompression: true,
    stage4EdgePreservingDetail: true,
    antiGhostingPureSpatial: true,
    splitWipePct: 50,
    agcSlewLimitADU: 18,
    detailGain: 1.5,
    verticalStrength: 0.75,
    horizontalStrength: 0.55,
    leftBaselineMode: "naive_minmax",
    enableMethodologyDestripe: true,
    enableMethodologyEnhancement: true,
    enableLiveCnnResidual: false,
    edgeGateThresholdADU: 135,
    rankImpulseProtection: true,
    dualPlateauBlend: 0.45,
    dogNoiseCoring: 3.5,
    waveletShrinkThreshold: 42,
    spectralCombNotch: 0.5,
    guidedFilterRadius: 3,
    guidedFilterEps: 1800,
    sCurveContrast: 0.38,
    bilateralRangeSigmaADU: 110,
    kalmanMotionGateADU: 95,
    kalmanTemporalAlpha: 0.55,
    localAceStrength: 0.48,
    cnnBlendStrength: 0.75
  },
  instance2: {
    stage1DestripeAndBadPx: true,
    stage2TemporalQuantileAgc: true,
    stage3DualPlateauCompression: true,
    stage4EdgePreservingDetail: true,
    antiGhostingPureSpatial: true,
    splitWipePct: 50,
    agcSlewLimitADU: 18,
    detailGain: 1.55,
    verticalStrength: 0.75,
    horizontalStrength: 0.55,
    leftBaselineMode: "naive_minmax",
    enableMethodologyDestripe: true,
    enableMethodologyEnhancement: true,
    enableLiveCnnResidual: false,
    edgeGateThresholdADU: 135,
    rankImpulseProtection: true,
    dualPlateauBlend: 0.4,
    dogNoiseCoring: 3,
    waveletShrinkThreshold: 46,
    spectralCombNotch: 0.55,
    guidedFilterRadius: 3,
    guidedFilterEps: 2200,
    sCurveContrast: 0.42,
    bilateralRangeSigmaADU: 110,
    kalmanMotionGateADU: 95,
    kalmanTemporalAlpha: 0.55,
    localAceStrength: 0.45,
    cnnBlendStrength: 0.75
  },
  instance3: {
    stage1DestripeAndBadPx: true,
    stage2TemporalQuantileAgc: true,
    stage3DualPlateauCompression: true,
    stage4EdgePreservingDetail: true,
    antiGhostingPureSpatial: true,
    splitWipePct: 50,
    agcSlewLimitADU: 18,
    detailGain: 1.5,
    verticalStrength: 0.75,
    horizontalStrength: 0.55,
    leftBaselineMode: "naive_minmax",
    enableMethodologyDestripe: true,
    enableMethodologyEnhancement: true,
    enableLiveCnnResidual: false,
    edgeGateThresholdADU: 135,
    rankImpulseProtection: true,
    dualPlateauBlend: 0.4,
    dogNoiseCoring: 3,
    waveletShrinkThreshold: 42,
    spectralCombNotch: 0.5,
    guidedFilterRadius: 3,
    guidedFilterEps: 2e3,
    sCurveContrast: 0.35,
    bilateralRangeSigmaADU: 115,
    kalmanMotionGateADU: 90,
    kalmanTemporalAlpha: 0.58,
    localAceStrength: 0.52,
    cnnBlendStrength: 0.75
  }
};
function smooth1DProfile(profile, radius) {
  const len = profile.length;
  const out = new Float32Array(len);
  const sigma = Math.max(1, radius * 0.5);
  const weights = new Float32Array(radius * 2 + 1);
  let wSum = 0;
  for (let k = -radius; k <= radius; k++) {
    const w = Math.exp(-(k * k) / (2 * sigma * sigma));
    weights[k + radius] = w;
    wSum += w;
  }
  for (let k = 0; k < weights.length; k++) weights[k] /= wSum;
  for (let i = 0; i < len; i++) {
    let acc = 0;
    for (let k = -radius; k <= radius; k++) {
      const idx = Math.max(0, Math.min(len - 1, i + k));
      acc += profile[idx] * weights[k + radius];
    }
    out[i] = acc;
  }
  return out;
}
function runOriginalClearHotBaseline8(raw14, W, H, cfg, pLow, pHigh) {
  const N = W * H;
  const stage1Buf = Float32Array.from(raw14);
  if (cfg.stage1DestripeAndBadPx) {
    const colBias = new Float32Array(W);
    let globalMed = 0;
    for (let x = 0; x < W; x++) {
      let sum = 0;
      let cnt = 0;
      for (let y = 16; y < H - 16; y += 4) {
        const v = raw14[y * W + x];
        if (v > 1e3 && v < 12e3) {
          sum += v;
          cnt++;
        }
      }
      colBias[x] = cnt > 0 ? sum / cnt : 7200;
      globalMed += colBias[x];
    }
    globalMed /= W;
    const rowMean = new Float32Array(H);
    for (let y = 0; y < H; y++) {
      let sum = 0;
      for (let x = 0; x < W; x += 4) sum += raw14[y * W + x];
      rowMean[y] = sum / Math.ceil(W / 4);
    }
    const rowBias = new Float32Array(H);
    for (let y = 0; y < H; y++) {
      let sum = 0, count = 0;
      for (let k = -4; k <= 4; k++) {
        const j = y + k;
        if (j >= 0 && j < H) {
          sum += rowMean[j];
          count++;
        }
      }
      rowBias[y] = rowMean[y] - sum / count;
    }
    for (let y = 1; y < H - 1; y++) {
      for (let x = 1; x < W - 1; x++) {
        const idx = y * W + x;
        let v = raw14[idx] - (colBias[x] - globalMed) * cfg.verticalStrength - rowBias[y] * cfg.horizontalStrength;
        const avgN = (raw14[idx - 1] + raw14[idx + 1] + raw14[idx - W] + raw14[idx + W]) * 0.25;
        if (Math.abs(v - avgN) > 1800) v = avgN;
        stage1Buf[idx] = v;
      }
    }
  }
  const span = Math.max(80, pHigh - pLow);
  const normBuf = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    const v = stage1Buf[i];
    if (v <= pHigh) {
      normBuf[i] = Math.max(0, Math.min(232, (v - pLow) / span * 232));
    } else {
      const excess = Math.min(1, (v - pHigh) / 7e3);
      normBuf[i] = 232 + excess * 23;
    }
  }
  const out8 = new Uint8ClampedArray(N);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      let center = normBuf[idx];
      if (cfg.stage4EdgePreservingDetail && y > 0 && y < H - 1 && x > 0 && x < W - 1) {
        const localMean = (normBuf[idx - 1] + normBuf[idx + 1] + normBuf[idx - W] + normBuf[idx + W]) * 0.25;
        const diff = center - localMean;
        const clampedDiff = Math.max(-18, Math.min(18, diff));
        center = center + clampedDiff * (cfg.detailGain - 1) * 1.8;
      }
      out8[idx] = Math.max(0, Math.min(255, Math.round(center)));
    }
  }
  return out8;
}
function runThermalInstancePipeline(params) {
  const {
    methodology,
    raw14,
    W,
    H,
    cfg,
    cnnState,
    prevBlackRef,
    prevWhiteRef,
    lastFrameKeyRef,
    prevNormFrameRef,
    prevKalman14Ref,
    frameKey
  } = params;
  const t0 = performance.now();
  const N = W * H;
  let rMin = 16383;
  let rMax = 0;
  for (let i = 0; i < N; i++) {
    const v = raw14[i];
    if (v < rMin) rMin = v;
    if (v > rMax) rMax = v;
  }
  let stage1Buf = new Float32Array(raw14);
  if (cfg.stage1DestripeAndBadPx) {
    if (!cfg.enableMethodologyDestripe) {
      const colBias = new Float32Array(W);
      let globalMed = 0;
      for (let x = 0; x < W; x++) {
        let sum = 0, cnt = 0;
        for (let y = 16; y < H - 16; y += 4) {
          const v = raw14[y * W + x];
          if (v > 1e3 && v < 12e3) {
            sum += v;
            cnt++;
          }
        }
        colBias[x] = cnt > 0 ? sum / cnt : 7200;
        globalMed += colBias[x];
      }
      globalMed /= W;
      const rowMean = new Float32Array(H);
      for (let y = 0; y < H; y++) {
        let sum = 0;
        for (let x = 0; x < W; x += 4) sum += raw14[y * W + x];
        rowMean[y] = sum / Math.ceil(W / 4);
      }
      const rowBias = new Float32Array(H);
      for (let y = 0; y < H; y++) {
        let sum = 0, count = 0;
        for (let k = -4; k <= 4; k++) {
          const j = y + k;
          if (j >= 0 && j < H) {
            sum += rowMean[j];
            count++;
          }
        }
        rowBias[y] = rowMean[y] - sum / count;
      }
      for (let y = 1; y < H - 1; y++) {
        for (let x = 1; x < W - 1; x++) {
          const idx = y * W + x;
          let v = raw14[idx] - (colBias[x] - globalMed) * cfg.verticalStrength - rowBias[y] * cfg.horizontalStrength;
          const avgN = (raw14[idx - 1] + raw14[idx + 1] + raw14[idx - W] + raw14[idx + W]) * 0.25;
          if (Math.abs(v - avgN) > 1800) v = avgN;
          stage1Buf[idx] = v;
        }
      }
    } else if (methodology === "instance1") {
      const edgeThresh = Math.max(25, cfg.edgeGateThresholdADU);
      const colDiff = new Float32Array(W);
      const colIntegrated = new Float32Array(W);
      for (let x = 1; x < W; x++) {
        let sumDiff = 0;
        let weightSum = 0;
        for (let y = 4; y < H - 4; y += 2) {
          const idx = y * W + x;
          const dx = raw14[idx] - raw14[idx - 1];
          const dy = Math.abs(raw14[idx + W] - raw14[idx - W]);
          if (Math.abs(dx) < edgeThresh && dy < edgeThresh * 1.4) {
            const w = 1 / (1 + dx * dx / (edgeThresh * edgeThresh * 0.25));
            sumDiff += dx * w;
            weightSum += w;
          }
        }
        colDiff[x] = weightSum > 4 ? sumDiff / weightSum : 0;
        colIntegrated[x] = colIntegrated[x - 1] + colDiff[x];
      }
      const colLowPass = smooth1DProfile(colIntegrated, 9);
      const colStripeEst = new Float32Array(W);
      for (let x = 0; x < W; x++) {
        colStripeEst[x] = colIntegrated[x] - colLowPass[x];
      }
      const rowDiff = new Float32Array(H);
      const rowIntegrated = new Float32Array(H);
      for (let y = 1; y < H; y++) {
        let sumDiff = 0;
        let weightSum = 0;
        const rowOff = y * W;
        for (let x = 4; x < W - 4; x += 2) {
          const idx = rowOff + x;
          const dy = raw14[idx] - raw14[idx - W];
          const dx = Math.abs(raw14[idx + 1] - raw14[idx - 1]);
          if (Math.abs(dy) < edgeThresh && dx < edgeThresh * 1.4) {
            const w = 1 / (1 + dy * dy / (edgeThresh * edgeThresh * 0.25));
            sumDiff += dy * w;
            weightSum += w;
          }
        }
        rowDiff[y] = weightSum > 4 ? sumDiff / weightSum : 0;
        rowIntegrated[y] = rowIntegrated[y - 1] + rowDiff[y];
      }
      const rowLowPass = smooth1DProfile(rowIntegrated, 7);
      const rowStripeEst = new Float32Array(H);
      for (let y = 0; y < H; y++) {
        rowStripeEst[y] = rowIntegrated[y] - rowLowPass[y];
      }
      const nbrs = new Float32Array(8);
      for (let y = 1; y < H - 1; y++) {
        const rowOff = y * W;
        for (let x = 1; x < W - 1; x++) {
          const idx = rowOff + x;
          const rawV = raw14[idx];
          const localHorizGrad = Math.abs(rawV - 0.5 * (raw14[idx - 1] + raw14[idx + 1]));
          const localVertGrad = Math.abs(rawV - 0.5 * (raw14[idx - W] + raw14[idx + W]));
          const colProtect = localHorizGrad > edgeThresh * 1.35 ? 0.25 : 1;
          const rowProtect = localVertGrad > edgeThresh * 1.35 ? 0.25 : 1;
          let v = rawV - colStripeEst[x] * cfg.verticalStrength * colProtect - rowStripeEst[y] * cfg.horizontalStrength * rowProtect;
          if (cfg.rankImpulseProtection) {
            nbrs[0] = raw14[idx - W - 1];
            nbrs[1] = raw14[idx - W];
            nbrs[2] = raw14[idx - W + 1];
            nbrs[3] = raw14[idx - 1];
            nbrs[4] = raw14[idx + 1];
            nbrs[5] = raw14[idx + W - 1];
            nbrs[6] = raw14[idx + W];
            nbrs[7] = raw14[idx + W + 1];
            nbrs.sort();
            const med = 0.5 * (nbrs[3] + nbrs[4]);
            const secondHigh = nbrs[6];
            const secondLow = nbrs[1];
            if (v - secondHigh > 1600 || secondLow - v > 1600) {
              v = med;
            }
          } else {
            const avg4 = (raw14[idx - 1] + raw14[idx + 1] + raw14[idx - W] + raw14[idx + W]) * 0.25;
            if (Math.abs(v - avg4) > 1800) v = avg4;
          }
          stage1Buf[idx] = v;
        }
      }
    } else if (methodology === "instance2") {
      const shrinkT = Math.max(8, cfg.waveletShrinkThreshold);
      const colProf = new Float32Array(W);
      for (let x = 0; x < W; x++) {
        let sum = 0, cnt = 0;
        for (let y = 8; y < H - 8; y += 2) {
          const idx = y * W + x;
          const v = raw14[idx];
          const localDiff = Math.abs(v - raw14[idx - W]);
          if (localDiff < 180 && v > 400 && v < 13500) {
            sum += v;
            cnt++;
          }
        }
        colProf[x] = cnt > 0 ? sum / cnt : 7200;
      }
      const rowProf = new Float32Array(H);
      for (let y = 0; y < H; y++) {
        let sum = 0, cnt = 0;
        const rowOff = y * W;
        for (let x = 8; x < W - 8; x += 2) {
          const idx = rowOff + x;
          const v = raw14[idx];
          const localDiff = Math.abs(v - raw14[idx - 1]);
          if (localDiff < 180 && v > 400 && v < 13500) {
            sum += v;
            cnt++;
          }
        }
        rowProf[y] = cnt > 0 ? sum / cnt : 7200;
      }
      const colSmooth1 = smooth1DProfile(colProf, 1);
      const colSmooth2 = smooth1DProfile(colProf, 3);
      const colSmooth4 = smooth1DProfile(colProf, 8);
      const colWaveletStripe = new Float32Array(W);
      for (let x = 0; x < W; x++) {
        const d1 = colProf[x] - colSmooth1[x];
        const d2 = colSmooth1[x] - colSmooth2[x];
        const d3 = colSmooth2[x] - colSmooth4[x];
        const g1 = Math.abs(d1) < shrinkT ? d1 : d1 * (shrinkT * shrinkT / (d1 * d1));
        const g2 = Math.abs(d2) < shrinkT ? d2 : d2 * (shrinkT * shrinkT / (d2 * d2));
        const g3 = Math.abs(d3) < shrinkT * 0.8 ? d3 * cfg.spectralCombNotch : d3 * (shrinkT * shrinkT * 0.64 / (d3 * d3)) * cfg.spectralCombNotch;
        colWaveletStripe[x] = g1 + g2 + g3;
      }
      const rowSmooth1 = smooth1DProfile(rowProf, 1);
      const rowSmooth2 = smooth1DProfile(rowProf, 3);
      const rowSmooth4 = smooth1DProfile(rowProf, 7);
      const rowWaveletStripe = new Float32Array(H);
      for (let y = 0; y < H; y++) {
        const d1 = rowProf[y] - rowSmooth1[y];
        const d2 = rowSmooth1[y] - rowSmooth2[y];
        const d3 = rowSmooth2[y] - rowSmooth4[y];
        const g1 = Math.abs(d1) < shrinkT ? d1 : d1 * (shrinkT * shrinkT / (d1 * d1));
        const g2 = Math.abs(d2) < shrinkT ? d2 : d2 * (shrinkT * shrinkT / (d2 * d2));
        const g3 = Math.abs(d3) < shrinkT * 0.8 ? d3 * cfg.spectralCombNotch : d3 * (shrinkT * shrinkT * 0.64 / (d3 * d3)) * cfg.spectralCombNotch;
        rowWaveletStripe[y] = g1 + g2 + g3;
      }
      for (let y = 1; y < H - 1; y++) {
        const rowOff = y * W;
        for (let x = 1; x < W - 1; x++) {
          const idx = rowOff + x;
          const rawV = raw14[idx];
          const localDx = Math.abs(rawV - 0.5 * (raw14[idx - 1] + raw14[idx + 1]));
          const localDy = Math.abs(rawV - 0.5 * (raw14[idx - W] + raw14[idx + W]));
          const colGate = Math.exp(-(localDx * localDx) / (2 * 180 * 180));
          const rowGate = Math.exp(-(localDy * localDy) / (2 * 180 * 180));
          let v = rawV - colWaveletStripe[x] * cfg.verticalStrength * colGate - rowWaveletStripe[y] * cfg.horizontalStrength * rowGate;
          const n1 = raw14[idx - 1], n2 = raw14[idx + 1], n3 = raw14[idx - W], n4 = raw14[idx + W];
          const avg4 = (n1 + n2 + n3 + n4) * 0.25;
          if (Math.abs(v - avg4) > 1750) {
            v = avg4;
          } else if (cfg.spectralCombNotch > 0.1) {
            const grainDiff = v - avg4;
            if (Math.abs(grainDiff) < 24) {
              v -= grainDiff * 0.35 * cfg.spectralCombNotch;
            }
          }
          stage1Buf[idx] = v;
        }
      }
    } else {
      const sigmaR = Math.max(20, cfg.bilateralRangeSigmaADU);
      const twoSigmaRSq = 2 * sigmaR * sigmaR;
      const prevKalman = prevKalman14Ref.current;
      const hasValidPrev = prevKalman !== null && prevKalman.length === N;
      const nextKalman = new Float32Array(N);
      const motionGate = Math.max(15, cfg.kalmanMotionGateADU);
      const tempAlpha = cfg.kalmanTemporalAlpha;
      for (let y = 2; y < H - 2; y++) {
        const rowOff = y * W;
        for (let x = 2; x < W - 2; x++) {
          const idx = rowOff + x;
          let c = raw14[idx];
          const avg4 = (raw14[idx - 1] + raw14[idx + 1] + raw14[idx - W] + raw14[idx + W]) * 0.25;
          if (Math.abs(c - avg4) > 1750) {
            c = avg4;
          }
          const dLeft0 = c - raw14[idx - 1];
          const dRight0 = c - raw14[idx + 1];
          const dLeftU = raw14[idx - W] - raw14[idx - W - 1];
          const dRightU = raw14[idx - W] - raw14[idx - W + 1];
          const dLeftD = raw14[idx + W] - raw14[idx + W - 1];
          const dRightD = raw14[idx + W] - raw14[idx + W + 1];
          const coherentColResidual = (dLeft0 + dRight0) * 0.25 + (dLeftU + dRightU) * 0.125 + (dLeftD + dRightD) * 0.125;
          const wCol = Math.exp(
            -(coherentColResidual * coherentColResidual) / twoSigmaRSq
          );
          const colCorr = coherentColResidual * wCol * cfg.verticalStrength;
          const dUp0 = c - raw14[idx - W];
          const dDown0 = c - raw14[idx + W];
          const dUpL = raw14[idx - 1] - raw14[idx - W - 1];
          const dDownL = raw14[idx - 1] - raw14[idx + W - 1];
          const dUpR = raw14[idx + 1] - raw14[idx - W + 1];
          const dDownR = raw14[idx + 1] - raw14[idx + W + 1];
          const coherentRowResidual = (dUp0 + dDown0) * 0.25 + (dUpL + dDownL) * 0.125 + (dUpR + dDownR) * 0.125;
          const wRow = Math.exp(
            -(coherentRowResidual * coherentRowResidual) / twoSigmaRSq
          );
          const rowCorr = coherentRowResidual * wRow * cfg.horizontalStrength;
          let spatialClean = c - colCorr - rowCorr;
          if (hasValidPrev && tempAlpha > 0.01) {
            const prevV = prevKalman[idx];
            const innovation = Math.abs(spatialClean - prevV);
            if (innovation < motionGate) {
              const motionWeight = tempAlpha * Math.exp(-(innovation * innovation) / (2 * motionGate * motionGate * 0.35));
              spatialClean = (1 - motionWeight) * spatialClean + motionWeight * prevV;
            }
          }
          stage1Buf[idx] = spatialClean;
          nextKalman[idx] = spatialClean;
        }
      }
      if (lastFrameKeyRef.current !== frameKey) {
        prevKalman14Ref.current = nextKalman;
      }
    }
  }
  if (cfg.enableLiveCnnResidual) {
    stage1Buf = applyLiveCnnResidual14(
      stage1Buf,
      W,
      H,
      cnnState,
      cfg.cnnBlendStrength
    );
  }
  let pLow = rMin;
  let pHigh = rMax;
  if (cfg.stage2TemporalQuantileAgc) {
    const sortedSample = [];
    for (let i = 0; i < N; i += 11) {
      sortedSample.push(stage1Buf[i]);
    }
    sortedSample.sort((a, b) => a - b);
    const idxLow = Math.floor(sortedSample.length * 0.02);
    const idxHigh = Math.floor(
      sortedSample.length * (cfg.stage3DualPlateauCompression ? 0.975 : 0.999)
    );
    const rawPLow = sortedSample[idxLow] !== void 0 ? sortedSample[idxLow] : 7e3;
    const rawPHigh = sortedSample[idxHigh] !== void 0 ? sortedSample[idxHigh] : 8200;
    const maxDelta = cfg.agcSlewLimitADU;
    if (lastFrameKeyRef.current !== frameKey) {
      pLow = lastFrameKeyRef.current === "" ? rawPLow : prevBlackRef.current + Math.max(
        -maxDelta,
        Math.min(maxDelta, rawPLow - prevBlackRef.current)
      );
      pHigh = lastFrameKeyRef.current === "" ? rawPHigh : prevWhiteRef.current + Math.max(
        -maxDelta,
        Math.min(maxDelta, rawPHigh - prevWhiteRef.current)
      );
      prevBlackRef.current = pLow;
      prevWhiteRef.current = pHigh;
      lastFrameKeyRef.current = frameKey;
    } else {
      pLow = prevBlackRef.current;
      pHigh = prevWhiteRef.current;
    }
  }
  const span = Math.max(80, pHigh - pLow);
  const normBuf = new Float32Array(N);
  if (cfg.enableMethodologyEnhancement && methodology === "instance2") {
    const r = Math.max(1, Math.min(5, Math.round(cfg.guidedFilterRadius)));
    const eps = Math.max(100, cfg.guidedFilterEps);
    const sContrast = cfg.sCurveContrast;
    for (let y = 0; y < H; y++) {
      const y0 = Math.max(0, y - r);
      const y1 = Math.min(H - 1, y + r);
      for (let x = 0; x < W; x++) {
        const x0 = Math.max(0, x - r);
        const x1 = Math.min(W - 1, x + r);
        let sum = 0, sumSq = 0, cnt = 0;
        for (let wy = y0; wy <= y1; wy += 2) {
          const rOff = wy * W;
          for (let wx = x0; wx <= x1; wx += 2) {
            const val = stage1Buf[rOff + wx];
            sum += val;
            sumSq += val * val;
            cnt++;
          }
        }
        const mean = sum / cnt;
        const variance = Math.max(0, sumSq / cnt - mean * mean);
        const a_k = variance / (variance + eps);
        const v = stage1Buf[y * W + x];
        const base14 = (1 - a_k * 0.35) * mean + a_k * 0.35 * v;
        const detail14 = v - base14;
        let t = Math.max(0, Math.min(1, (base14 - pLow) / span));
        if (sContrast > 0.01) {
          const sCurve = t + sContrast * 1.4 * t * (1 - t) * (2 * t - 1);
          t = Math.max(0, Math.min(1, sCurve));
        }
        let mapped = t * 232;
        if (v > pHigh) {
          const excess = Math.min(1, (v - pHigh) / 7e3);
          mapped = 232 + excess * 23;
        }
        const detail8 = detail14 / span * 232 * (0.85 + cfg.detailGain * 0.55);
        normBuf[y * W + x] = Math.max(0, Math.min(255, mapped + detail8));
      }
    }
  } else {
    for (let i = 0; i < N; i++) {
      const v = stage1Buf[i];
      if (v <= pHigh) {
        normBuf[i] = Math.max(0, Math.min(232, (v - pLow) / span * 232));
      } else {
        const excess = Math.min(1, (v - pHigh) / 7e3);
        normBuf[i] = 232 + excess * 23;
      }
    }
    if (cfg.enableMethodologyEnhancement && methodology === "instance1" && cfg.dualPlateauBlend > 0.01) {
      const hist = new Uint32Array(256);
      for (let i = 0; i < N; i++) {
        const b = Math.max(0, Math.min(255, Math.round(normBuf[i])));
        hist[b]++;
      }
      const upperPlateau = Math.max(12, Math.floor(N / 256 * 2.4));
      const lowerPlateau = Math.max(2, Math.floor(N / 256 * 0.18));
      const cdf = new Float32Array(256);
      let cum = 0;
      for (let b = 0; b < 256; b++) {
        let count = hist[b];
        if (count > upperPlateau) count = upperPlateau;
        else if (count > 0 && count < lowerPlateau) count = lowerPlateau;
        cum += count;
        cdf[b] = cum;
      }
      const cdfMax = Math.max(1, cdf[255]);
      const blend = cfg.dualPlateauBlend;
      for (let i = 0; i < N; i++) {
        const orig8 = normBuf[i];
        const bin = Math.max(0, Math.min(255, Math.round(orig8)));
        const eq8 = cdf[bin] / cdfMax * 246;
        normBuf[i] = (1 - blend) * orig8 + blend * eq8;
      }
    } else if (cfg.enableMethodologyEnhancement && methodology === "instance3" && cfg.localAceStrength > 0.01) {
      const sat = new Float64Array((W + 1) * (H + 1));
      const satSq = new Float64Array((W + 1) * (H + 1));
      const stride = W + 1;
      for (let y = 1; y <= H; y++) {
        let rowSum = 0;
        let rowSumSq = 0;
        const srcRow = (y - 1) * W;
        const dstRow = y * stride;
        const prevRow = (y - 1) * stride;
        for (let x = 1; x <= W; x++) {
          const val = normBuf[srcRow + (x - 1)];
          rowSum += val;
          rowSumSq += val * val;
          sat[dstRow + x] = sat[prevRow + x] + rowSum;
          satSq[dstRow + x] = satSq[prevRow + x] + rowSumSq;
        }
      }
      const winR = 6;
      const aceGain = cfg.localAceStrength;
      const tempAce = new Float32Array(N);
      for (let y = 0; y < H; y++) {
        const y0 = Math.max(0, y - winR);
        const y1 = Math.min(H, y + winR + 1);
        for (let x = 0; x < W; x++) {
          const x0 = Math.max(0, x - winR);
          const x1 = Math.min(W, x + winR + 1);
          const area = (y1 - y0) * (x1 - x0);
          const sum = sat[y1 * stride + x1] - sat[y0 * stride + x1] - sat[y1 * stride + x0] + sat[y0 * stride + x0];
          const sumSq = satSq[y1 * stride + x1] - satSq[y0 * stride + x1] - satSq[y1 * stride + x0] + satSq[y0 * stride + x0];
          const mean = sum / area;
          const std = Math.sqrt(Math.max(0, sumSq / area - mean * mean));
          const center = normBuf[y * W + x];
          const localDev = center - mean;
          const adaptiveFactor = 1 + aceGain * Math.min(2.2, 14 / Math.max(5.5, std));
          const clampedDev = Math.max(-28, Math.min(28, localDev * adaptiveFactor));
          tempAce[y * W + x] = Math.max(0, Math.min(255, mean + clampedDev));
        }
      }
      for (let i = 0; i < N; i++) normBuf[i] = tempAce[i];
    }
  }
  if (!cfg.antiGhostingPureSpatial && prevNormFrameRef.current?.length === N) {
    for (let i = 0; i < N; i++) {
      normBuf[i] = 0.25 * normBuf[i] + 0.75 * prevNormFrameRef.current[i];
    }
  }
  prevNormFrameRef.current = normBuf.slice();
  const processed8 = new Uint8ClampedArray(N);
  const coring = cfg.enableMethodologyEnhancement && methodology === "instance1" ? cfg.dogNoiseCoring : 0;
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      let center = normBuf[idx];
      if (cfg.stage4EdgePreservingDetail && y > 1 && y < H - 2 && x > 1 && x < W - 2) {
        const l = normBuf[idx - 1];
        const r = normBuf[idx + 1];
        const u = normBuf[idx - W];
        const d = normBuf[idx + W];
        const localMean1 = (l + r + u + d) * 0.25;
        let diff = center - localMean1;
        if (cfg.enableMethodologyEnhancement && methodology === "instance1") {
          const outerMean = (normBuf[idx - 2] + normBuf[idx + 2] + normBuf[idx - 2 * W] + normBuf[idx + 2 * W]) * 0.25;
          const mediumDetail = localMean1 - outerMean;
          const coredFine = Math.abs(diff) <= coring ? 0 : Math.sign(diff) * (Math.abs(diff) - coring);
          diff = coredFine + 0.45 * mediumDetail;
        }
        const clampedDiff = Math.max(-18, Math.min(18, diff));
        center = center + clampedDiff * (cfg.detailGain - 1) * 1.8;
      }
      processed8[idx] = Math.max(0, Math.min(255, Math.round(center)));
    }
  }
  const leftBaseline8 = new Uint8ClampedArray(N);
  if (cfg.leftBaselineMode === "original_clearhot") {
    const orig = runOriginalClearHotBaseline8(raw14, W, H, cfg, pLow, pHigh);
    leftBaseline8.set(orig);
  } else {
    const naiveSpan = Math.max(1, rMax - rMin);
    for (let i = 0; i < N; i++) {
      leftBaseline8[i] = Math.round((raw14[i] - rMin) / naiveSpan * 255);
    }
  }
  const dt = performance.now() - t0;
  const telemetry = computeFrameTelemetry(
    raw14,
    stage1Buf,
    processed8,
    W,
    H,
    rMin,
    rMax,
    span,
    dt
  );
  return {
    processed8,
    leftBaseline8,
    stage1Clean14: stage1Buf,
    telemetry
  };
}
function computeFrameTelemetry(raw14, stage1Clean14, processed8, W, H, rMin, rMax, span, dtMs) {
  const yStart = 8;
  const yEnd = Math.min(H - 8, 44);
  const xStart = Math.floor(W * 0.45);
  const xEnd = W - 12;
  const colMeansClean = [];
  const colProfileRaw = [];
  const colProfileProc = [];
  for (let x = xStart; x < xEnd; x++) {
    let sClean = 0;
    let sRaw = 0;
    let cnt = 0;
    for (let y = yStart; y < yEnd; y++) {
      sClean += stage1Clean14[y * W + x];
      sRaw += raw14[y * W + x];
      cnt++;
    }
    colMeansClean.push(sClean / Math.max(1, cnt));
    if (colProfileRaw.length < 48) {
      colProfileRaw.push(Number((sRaw / Math.max(1, cnt)).toFixed(1)));
      colProfileProc.push(Number((sClean / Math.max(1, cnt)).toFixed(1)));
    }
  }
  let colHpSq = 0;
  for (let i = 1; i < colMeansClean.length - 1; i++) {
    const hp = colMeansClean[i] - 0.5 * (colMeansClean[i - 1] + colMeansClean[i + 1]);
    colHpSq += hp * hp;
  }
  const colStripeResidual = Number(
    Math.sqrt(colHpSq / Math.max(1, colMeansClean.length - 2)).toFixed(2)
  );
  const rowMeansClean = [];
  const rowProfileRaw = [];
  const rowProfileProc = [];
  const rYEnd = Math.min(H - 8, 72);
  for (let y = 8; y < rYEnd; y++) {
    let sClean = 0;
    let sRaw = 0;
    let cnt = 0;
    for (let x = xStart; x < xEnd; x++) {
      sClean += stage1Clean14[y * W + x];
      sRaw += raw14[y * W + x];
      cnt++;
    }
    rowMeansClean.push(sClean / Math.max(1, cnt));
    if (rowProfileRaw.length < 48) {
      rowProfileRaw.push(Number((sRaw / Math.max(1, cnt)).toFixed(1)));
      rowProfileProc.push(Number((sClean / Math.max(1, cnt)).toFixed(1)));
    }
  }
  let rowHpSq = 0;
  for (let i = 1; i < rowMeansClean.length - 1; i++) {
    const hp = rowMeansClean[i] - 0.5 * (rowMeansClean[i - 1] + rowMeansClean[i + 1]);
    rowHpSq += hp * hp;
  }
  const rowStripeResidual = Number(
    Math.sqrt(rowHpSq / Math.max(1, rowMeansClean.length - 2)).toFixed(2)
  );
  let madSum = 0;
  let madCnt = 0;
  for (let y = yStart + 1; y < yEnd - 1; y += 2) {
    for (let x = xStart + 1; x < xEnd - 1; x += 2) {
      const idx = y * W + x;
      const c = stage1Clean14[idx];
      const avg4 = 0.25 * (stage1Clean14[idx - 1] + stage1Clean14[idx + 1] + stage1Clean14[idx - W] + stage1Clean14[idx + W]);
      madSum += Math.abs(c - avg4);
      madCnt++;
    }
  }
  const staticGrainMad = Number((madSum / Math.max(1, madCnt)).toFixed(2));
  let rawEdgeEnergy = 0;
  let cleanEdgeEnergy = 0;
  for (let y = Math.floor(H * 0.2); y < Math.floor(H * 0.8); y += 4) {
    for (let x = Math.floor(W * 0.15); x < Math.floor(W * 0.85); x += 4) {
      const idx = y * W + x;
      const rDx = Math.abs(raw14[idx + 1] - raw14[idx - 1]);
      const rDy = Math.abs(raw14[idx + W] - raw14[idx - W]);
      if (rDx > 160 && rDx < 1200 || rDy > 160 && rDy < 1200) {
        const cDx = Math.abs(stage1Clean14[idx + 1] - stage1Clean14[idx - 1]);
        const cDy = Math.abs(stage1Clean14[idx + W] - stage1Clean14[idx - W]);
        rawEdgeEnergy += rDx + rDy;
        cleanEdgeEnergy += cDx + cDy;
      }
    }
  }
  const thinFeatureRetentionPct = Number(
    Math.min(
      100,
      rawEdgeEnergy > 10 ? cleanEdgeEnergy / rawEdgeEnergy * 100 : 98.5
    ).toFixed(1)
  );
  let maxProc8 = 0;
  for (let i = 0; i < processed8.length; i += 3) {
    if (processed8[i] > maxProc8) maxProc8 = processed8[i];
  }
  const hotTargetPeakPct = Number((maxProc8 / 255 * 100).toFixed(1));
  let haloSum = 0;
  let haloCnt = 0;
  for (let y = 4; y < H - 4; y += 6) {
    for (let x = 4; x < W - 4; x += 6) {
      const idx = y * W + x;
      const lap8 = processed8[idx] - 0.25 * (processed8[idx - 1] + processed8[idx + 1] + processed8[idx - W] + processed8[idx + W]);
      if (Math.abs(lap8) > 22) {
        haloSum += Math.abs(lap8) - 22;
        haloCnt++;
      }
    }
  }
  const haloOvershootIndex = Number(
    (haloCnt > 0 ? haloSum / haloCnt : 1.2).toFixed(2)
  );
  return {
    rawMin14: rMin,
    rawMax14: rMax,
    sceneSpanADU: Math.round(span),
    frameTimeMs: Number(dtMs.toFixed(1)),
    colStripeResidual,
    rowStripeResidual,
    staticGrainMad,
    thinFeatureRetentionPct,
    hotTargetPeakPct,
    haloOvershootIndex,
    colProfileRaw,
    colProfileProc,
    rowProfileRaw,
    rowProfileProc
  };
}

// src/claude/dsp.ts
function quickselect(a, n, k) {
  let l = 0, r = n - 1;
  while (l < r) {
    const pivot = a[l + r >> 1];
    let i = l, j = r;
    while (i <= j) {
      while (a[i] < pivot) i++;
      while (a[j] > pivot) j--;
      if (i <= j) {
        const t = a[i];
        a[i] = a[j];
        a[j] = t;
        i++;
        j--;
      }
    }
    if (k <= j) r = j;
    else if (k >= i) l = i;
    else return a[k];
  }
  return a[k];
}
function medianOf(a, n) {
  return n === 0 ? 0 : quickselect(a, n, n >> 1);
}
function percentileSample(src, q, step = 7) {
  const n = Math.ceil(src.length / step);
  const buf = new Float32Array(n);
  let m = 0;
  for (let i = 0; i < src.length; i += step) buf[m++] = src[i];
  return quickselect(buf, m, Math.min(m - 1, Math.floor(q * m)));
}
function boxBlur(src, W, H, rx, ry = rx) {
  const tmp = new Float32Array(W * H), out = new Float32Array(W * H);
  for (let y = 0; y < H; y++) {
    const o = y * W;
    let sum = 0;
    for (let x = 0; x <= Math.min(rx, W - 1); x++) sum += src[o + x];
    for (let x = 0; x < W; x++) {
      if (x > 0) {
        if (x + rx < W) sum += src[o + x + rx];
        if (x - rx - 1 >= 0) sum -= src[o + x - rx - 1];
      }
      tmp[o + x] = sum / (Math.min(W - 1, x + rx) - Math.max(0, x - rx) + 1);
    }
  }
  for (let x = 0; x < W; x++) {
    let sum = 0;
    for (let y = 0; y <= Math.min(ry, H - 1); y++) sum += tmp[y * W + x];
    for (let y = 0; y < H; y++) {
      if (y > 0) {
        if (y + ry < H) sum += tmp[(y + ry) * W + x];
        if (y - ry - 1 >= 0) sum -= tmp[(y - ry - 1) * W + x];
      }
      out[y * W + x] = sum / (Math.min(H - 1, y + ry) - Math.max(0, y - ry) + 1);
    }
  }
  return out;
}
function guidedSelf(I, W, H, r, eps) {
  const m = boxBlur(I, W, H, r);
  const sq = new Float32Array(I.length);
  for (let i = 0; i < I.length; i++) sq[i] = I[i] * I[i];
  const mm = boxBlur(sq, W, H, r);
  const a = new Float32Array(I.length), b = new Float32Array(I.length);
  for (let i = 0; i < I.length; i++) {
    const v = Math.max(0, mm[i] - m[i] * m[i]);
    a[i] = v / (v + eps);
    b[i] = m[i] - a[i] * m[i];
  }
  const ma = boxBlur(a, W, H, r), mb = boxBlur(b, W, H, r);
  const out = new Float32Array(I.length);
  for (let i = 0; i < I.length; i++) out[i] = ma[i] * I[i] + mb[i];
  return out;
}
function noiseSigma(I, W, H) {
  const bins = new Uint32Array(2048);
  let n = 0;
  for (let y = 1; y < H - 1; y += 2) for (let x = 1; x < W - 1; x += 2) {
    const i = y * W + x;
    const r = I[i - W - 1] - 2 * I[i - W] + I[i - W + 1] - 2 * I[i - 1] + 4 * I[i] - 2 * I[i + 1] + I[i + W - 1] - 2 * I[i + W] + I[i + W + 1];
    const b = Math.min(2047, Math.floor(Math.abs(r) * 4));
    bins[b]++;
    n++;
  }
  let c = 0, k = 0;
  while (k < 2048 && c < n / 2) {
    c += bins[k];
    k++;
  }
  return Math.max(0.3, k / 4 / 4.047);
}
function fft(re, im, inverse = false) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      let t = re[i];
      re[i] = re[j];
      re[j] = t;
      t = im[i];
      im[i] = im[j];
      im[j] = t;
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (inverse ? 2 : -2) * Math.PI / len;
    const wr = Math.cos(ang), wi = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let cr = 1, ci = 0;
      for (let k = 0; k < len / 2; k++) {
        const a = i + k, b = i + k + len / 2;
        const tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
        re[b] = re[a] - tr;
        im[b] = im[a] - ti;
        re[a] += tr;
        im[a] += ti;
        const ncr = cr * wr - ci * wi;
        ci = cr * wi + ci * wr;
        cr = ncr;
      }
    }
  }
  if (inverse) for (let i = 0; i < n; i++) {
    re[i] /= n;
    im[i] /= n;
  }
}
function lineGeom(o, W, H) {
  return o === "col" ? { nL: W, nA: H, ls: 1, as: W } : { nL: H, nA: W, ls: W, as: 1 };
}
function alongGate(img, W, H, o, pct) {
  const { nL, nA, ls, as } = lineGeom(o, W, H);
  const samp = [];
  for (let l = 0; l < nL; l += 3) for (let t = 1; t < nA - 1; t += 3) samp.push(Math.abs(img[l * ls + (t + 1) * as] - img[l * ls + (t - 1) * as]));
  const a = Float32Array.from(samp);
  return quickselect(a, a.length, Math.floor(pct * (a.length - 1)));
}
function stepThreshold(img, W, H, o, kg, pct) {
  const { nL, nA, ls, as } = lineGeom(o, W, H);
  const samp = [];
  for (let l = kg; l < nL - kg; l += 3) for (let t = 1; t < nA - 1; t += 3) {
    let a = 0, b = 0;
    for (let j = 1; j <= kg; j++) {
      a += img[(l - j) * ls + t * as];
      b += img[(l + j) * ls + t * as];
    }
    samp.push(Math.abs(a - b) / kg);
  }
  const arr = Float32Array.from(samp);
  return quickselect(arr, arr.length, Math.floor(pct * (arr.length - 1)));
}
function lineSweep(img, W, H, o, off, op) {
  const { nL, nA, ls, as } = lineGeom(o, W, H);
  const out = new Float32Array(nL);
  const segLen = Math.ceil(nA / op.segs);
  const bufs = Array.from({ length: op.segs }, () => new Float32Array(segLen));
  const cnt = new Int32Array(op.segs), med = new Float32Array(op.segs);
  for (let l = 0; l < nL; l++) {
    cnt.fill(0);
    const j0 = Math.max(0, l - op.k), j1 = Math.min(nL - 1, l + op.k);
    const haveBoth = l - op.kg >= 0 && l + op.kg <= nL - 1;
    for (let t = 1; t < nA - 1; t++) {
      const p = t * as;
      if (Math.abs(img[l * ls + p + as] - img[l * ls + p - as]) > op.thrAlong) continue;
      let s = 0, c = 0, sl = 0, sr = 0;
      for (let j = j0; j <= j1; j++) {
        if (j === l) continue;
        const v = img[j * ls + p] - (off ? off[j] : 0);
        s += v;
        c++;
        if (j < l && l - j <= op.kg) sl += v;
        else if (j > l && j - l <= op.kg) sr += v;
      }
      if (haveBoth && Math.abs(sl - sr) / op.kg > op.thrStep) continue;
      const e = img[l * ls + p] - (off ? off[l] : 0) - s / c;
      if (Math.abs(e) > op.clipE) continue;
      const sg = Math.min(op.segs - 1, Math.floor(t / segLen));
      bufs[sg][cnt[sg]++] = e;
    }
    let nv = 0, pos = 0, neg = 0, minAbs = Infinity;
    for (let g = 0; g < op.segs; g++) {
      if (cnt[g] < segLen * 0.12) continue;
      const m = medianOf(bufs[g], cnt[g]);
      med[nv++] = m;
      if (m > 0) pos++;
      else if (m < 0) neg++;
      minAbs = Math.min(minAbs, Math.abs(m));
    }
    if (nv < Math.min(2, op.segs) || pos > 0 && neg > 0 && Math.min(pos, neg) > 0 && Math.min(pos, neg) >= 1 && minAbs < Infinity && pos !== nv && neg !== nv) {
      out[l] = 0;
      continue;
    }
    const sign = pos >= neg ? 1 : -1;
    out[l] = sign * minAbs;
  }
  return out;
}
function estimateLineOffsetsLocal(img, W, H, o, k = 4, iters = 3, gatePct = 0.75, clipE = 300, segs = 4) {
  const { nL } = lineGeom(o, W, H);
  const op = { k, kg: Math.min(4, k), segs, clipE, thrAlong: alongGate(img, W, H, o, gatePct) + 1e-3, thrStep: stepThreshold(img, W, H, o, Math.min(4, k), 0.7) + 1e-3 };
  const off = new Float32Array(nL);
  for (let it = 0; it < iters; it++) {
    const d = lineSweep(img, W, H, o, off, op);
    for (let l = 0; l < nL; l++) off[l] += d[l];
  }
  let m = 0;
  for (let l = 0; l < nL; l++) m += off[l];
  m /= nL;
  for (let l = 0; l < nL; l++) off[l] -= m;
  return off;
}
function estimateLineOffsetsSpectral(img, W, H, o, cutoff, peakK, mode, R = 8, clipE = 300, iters = 3) {
  const { nL } = lineGeom(o, W, H);
  const op = { k: R, kg: 4, segs: 4, clipE, thrAlong: alongGate(img, W, H, o, 0.75) + 1e-3, thrStep: stepThreshold(img, W, H, o, 4, 0.7) + 1e-3 };
  const off = new Float32Array(nL);
  let n = 1;
  while (n < nL * 2) n <<= 1;
  const win = (l) => 0.3 + 0.7 * (0.5 - 0.5 * Math.cos(2 * Math.PI * (l + 0.5) / nL));
  for (let it = 0; it < iters; it++) {
    const prof = lineSweep(img, W, H, o, off, op);
    const re = new Float64Array(n), im = new Float64Array(n);
    let mean = 0;
    for (let l = 0; l < nL; l++) mean += prof[l];
    mean /= nL;
    for (let l = 0; l < nL; l++) re[l] = (prof[l] - mean) * win(l);
    fft(re, im);
    const half = n / 2, amp = new Float64Array(half + 1);
    for (let f = 0; f <= half; f++) amp[f] = Math.hypot(re[f], im[f]);
    const mask = new Float64Array(half + 1);
    for (let f = 1; f <= half; f++) {
      const hp = 1 - Math.exp(-((f / n / Math.max(1e-4, cutoff)) ** 2));
      const w0 = Math.max(1, f - 12), w1 = Math.min(half, f + 12);
      const loc = new Float32Array(w1 - w0 + 1);
      for (let q = w0; q <= w1; q++) loc[q - w0] = amp[q];
      const peak = amp[f] > peakK * (medianOf(loc, loc.length) + 1e-9) ? 1 : 0;
      mask[f] = mode === "broadband" ? hp : mode === "peaks" ? peak : Math.max(hp, peak);
    }
    for (let f = 0; f <= half; f++) {
      const g = mask[f];
      re[f] *= g;
      im[f] *= g;
      if (f > 0 && f < half) {
        re[n - f] *= g;
        im[n - f] *= g;
      }
    }
    fft(re, im, true);
    for (let l = 0; l < nL; l++) off[l] += re[l] / win(l);
  }
  let m2 = 0;
  for (let l = 0; l < nL; l++) m2 += off[l];
  m2 /= nL;
  for (let l = 0; l < nL; l++) off[l] -= m2;
  return off;
}
function applyLineOffsets(img, W, H, o, off, strength) {
  if (strength === 0) return;
  if (o === "col") {
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) img[y * W + x] -= off[x] * strength;
  } else {
    for (let y = 0; y < H; y++) {
      const v = off[y] * strength;
      for (let x = 0; x < W; x++) img[y * W + x] -= v;
    }
  }
}
function robustBadPixels(img, W, H, sigma) {
  const out = Float32Array.from(img);
  const thr = Math.max(8 * sigma, 150);
  const nb = new Float32Array(8);
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    const i = y * W + x, v = img[i];
    const m4 = (img[i - 1] + img[i + 1] + img[i - W] + img[i + W]) * 0.25;
    if (Math.abs(v - m4) <= thr) continue;
    nb[0] = img[i - W - 1];
    nb[1] = img[i - W];
    nb[2] = img[i - W + 1];
    nb[3] = img[i - 1];
    nb[4] = img[i + 1];
    nb[5] = img[i + W - 1];
    nb[6] = img[i + W];
    nb[7] = img[i + W + 1];
    const med = (quickselect(nb, 8, 3) + quickselect(nb, 8, 4)) * 0.5;
    const dev = v - med;
    if (Math.abs(dev) <= thr) continue;
    let close = 0;
    for (let k = 0; k < 8; k++) if (Math.abs(nb[k] - v) < Math.abs(dev) * 0.5) close++;
    if (close === 0) out[i] = med;
  }
  return out;
}
function bilateral5(img, W, H, sigmaR, mix) {
  const out = Float32Array.from(img);
  const sw = [1, 0.8, 0.45];
  const lut = new Float32Array(4096);
  for (let i = 0; i < 4096; i++) {
    const d = i / 8;
    lut[i] = Math.exp(-(d * d) / (2 * sigmaR * sigmaR));
  }
  for (let y = 2; y < H - 2; y++) for (let x = 2; x < W - 2; x++) {
    const i = y * W + x, c = img[i];
    let sum = 0, ws = 0;
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
      const v = img[i + dy * W + dx];
      const d = Math.min(4095, Math.round(Math.abs(v - c) * 8));
      const w = lut[d] * sw[Math.max(Math.abs(dx), Math.abs(dy))];
      sum += w * v;
      ws += w;
    }
    out[i] = c + (sum / ws - c) * mix;
  }
  return out;
}
function clahe(img, W, H, tilesX, tilesY, clip) {
  const tw = W / tilesX, th = H / tilesY;
  const luts = new Float32Array(tilesX * tilesY * 256);
  for (let ty = 0; ty < tilesY; ty++) for (let tx = 0; tx < tilesX; tx++) {
    const x0 = Math.floor(tx * tw), x1 = Math.floor((tx + 1) * tw), y0 = Math.floor(ty * th), y1 = Math.floor((ty + 1) * th);
    const hist = new Float64Array(256);
    let n = 0;
    for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
      hist[Math.max(0, Math.min(255, Math.round(img[y * W + x])))]++;
      n++;
    }
    const limit = Math.max(1, clip * n / 256);
    let excess = 0;
    for (let b = 0; b < 256; b++) if (hist[b] > limit) {
      excess += hist[b] - limit;
      hist[b] = limit;
    }
    const add = excess / 256;
    let cum = 0;
    const base = (ty * tilesX + tx) * 256;
    for (let b = 0; b < 256; b++) {
      hist[b] += add;
      cum += hist[b];
      luts[base + b] = cum / n * 255;
    }
  }
  const out = new Float32Array(W * H);
  for (let y = 0; y < H; y++) {
    const fy = Math.max(0, Math.min(tilesY - 1, (y + 0.5) / th - 0.5));
    const ty0 = Math.floor(fy), ty1 = Math.min(tilesY - 1, ty0 + 1), wy = fy - ty0;
    for (let x = 0; x < W; x++) {
      const fx = Math.max(0, Math.min(tilesX - 1, (x + 0.5) / tw - 0.5));
      const tx0 = Math.floor(fx), tx1 = Math.min(tilesX - 1, tx0 + 1), wx = fx - tx0;
      const v = Math.max(0, Math.min(255, Math.round(img[y * W + x])));
      const a = luts[(ty0 * tilesX + tx0) * 256 + v], b = luts[(ty0 * tilesX + tx1) * 256 + v];
      const c = luts[(ty1 * tilesX + tx0) * 256 + v], d = luts[(ty1 * tilesX + tx1) * 256 + v];
      out[y * W + x] = (a * (1 - wx) + b * wx) * (1 - wy) + (c * (1 - wx) + d * wx) * wy;
    }
  }
  return out;
}

// src/claude/cnn-disabled.ts
function getCnn(_v) {
  return null;
}
async function cnnRestore(_m, _x, _w, _h, _strength) {
  throw new Error("CNN is disabled in this evaluator");
}

// src/claude/pipeline.ts
var BASE = {
  stage1: true,
  stage2: true,
  stage3: true,
  stage4: true,
  spatialOnly: true,
  split: 50,
  agcSlew: 18,
  detailGain: 1.4,
  vStr: 0.65,
  hStr: 0,
  lineMethod: "orig",
  badPixel: "orig",
  detailMethod: "orig",
  toneMode: "quantile",
  cnn: false,
  cnnStrength: 1,
  clahe: false,
  claheClip: 3,
  claheAmount: 0.5,
  fpnPixel: 0.5,
  window: 12,
  tdenoise: false,
  tdStrength: 0.5,
  pheAmount: 0.6,
  plateau: 6,
  coring: 1.5,
  specMode: "both",
  specCutoff: 0.02,
  specPeak: 4,
  bilateral: false,
  bilStrength: 0.6,
  baseCompress: 0.15
};
function defaultCfg(v) {
  if (v === "O") return { ...BASE };
  const shared = { ...BASE, lineMethod: "new", badPixel: "robust", vStr: 1, hStr: 1 };
  if (v === "A") return { ...shared, clahe: true };
  if (v === "B") return { ...shared, detailMethod: "guided", toneMode: "plateau", tdenoise: true };
  return { ...shared, detailMethod: "multiscale", bilateral: true };
}
var newState = () => ({ lastKey: "", hasPrev: false, hasPrevB: false, lo: 7100, hi: 7950, loB: 7100, hiB: 7950, prevNorm: null, prevNormB: null, lut: null, lutB: null });
function origStage1(raw, W, H, vS, hS) {
  const out = Float32Array.from(raw);
  const colBias = new Float32Array(W);
  let globalMed = 0;
  for (let x = 0; x < W; x++) {
    let sum = 0, cnt = 0;
    for (let y = 16; y < H - 16; y += 4) {
      const v = raw[y * W + x];
      if (v > 1e3 && v < 12e3) {
        sum += v;
        cnt++;
      }
    }
    colBias[x] = cnt > 0 ? sum / cnt : 7200;
    globalMed += colBias[x];
  }
  globalMed /= W;
  const rowMean = new Float32Array(H);
  for (let y = 0; y < H; y++) {
    let s = 0;
    for (let x = 0; x < W; x += 4) s += raw[y * W + x];
    rowMean[y] = s / Math.ceil(W / 4);
  }
  const rowBias = new Float32Array(H);
  for (let y = 0; y < H; y++) {
    let s = 0, c = 0;
    for (let k = -4; k <= 4; k++) {
      const j = y + k;
      if (j >= 0 && j < H) {
        s += rowMean[j];
        c++;
      }
    }
    rowBias[y] = rowMean[y] - s / c;
  }
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    const idx = y * W + x;
    let v = raw[idx] - (colBias[x] - globalMed) * vS - rowBias[y] * hS;
    const avgN = (raw[idx - 1] + raw[idx + 1] + raw[idx - W] + raw[idx + W]) * 0.25;
    if (Math.abs(v - avgN) > 1800) v = avgN;
    out[idx] = v;
  }
  return out;
}
function origDetail(norm, W, H, gain) {
  const out = Float32Array.from(norm);
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    const i = y * W + x, c = norm[i];
    const lm = (norm[i - 1] + norm[i + 1] + norm[i - W] + norm[i + W]) * 0.25;
    const d = Math.max(-18, Math.min(18, c - lm));
    out[i] = c + d * (gain - 1) * 1.8;
  }
  return out;
}
var softLimit = (d, m) => Math.abs(d) <= m ? d : Math.sign(d) * (m + (Math.abs(d) - m) * 0.2);
var coringFn = (d, tau) => tau <= 0 ? d : d * (d * d / (d * d + tau * tau));
function guidedDetail(norm, W, H, gain, tau) {
  const base = guidedSelf(norm, W, H, 4, 100);
  const g = 1 + (gain - 1) * 1.8;
  const out = new Float32Array(norm.length);
  for (let i = 0; i < out.length; i++) out[i] = base[i] + g * softLimit(coringFn(norm[i] - base[i], tau), 30);
  return out;
}
function multiscaleDetail(norm, W, H, gain, tau, compress) {
  const b1 = boxBlur(norm, W, H, 1), b2 = boxBlur(norm, W, H, 3), b3 = boxBlur(boxBlur(norm, W, H, 8), W, H, 8);
  const g = 1 + (gain - 1) * 1.8;
  const out = new Float32Array(norm.length);
  for (let i = 0; i < out.length; i++) {
    const d1 = coringFn(norm[i] - b1[i], tau), d2 = b1[i] - b2[i], d3 = b2[i] - b3[i];
    const base = 128 + (b3[i] - 128) * (1 - compress);
    out[i] = base + g * (softLimit(d1, 24) * 1 + softLimit(d2, 28) * 0.8 + softLimit(d3, 30) * 0.5) * 0.9;
  }
  return out;
}
function toneMap(x, rMin, rMax, cfg, st, key, reset, mode) {
  const N = x.length;
  let pLow = rMin, pHigh = rMax;
  const isNew = st.lastKey !== key;
  if (isNew) {
    st.loB = st.lo;
    st.hiB = st.hi;
    st.prevNormB = st.prevNorm;
    st.lutB = st.lut;
    st.hasPrevB = st.hasPrev && !reset;
    st.lastKey = key;
  }
  if (cfg.stage2) {
    const rawLo = percentileSample(x, 0.02, 11), rawHi = percentileSample(x, cfg.stage3 ? 0.975 : 0.999, 11);
    const m = cfg.agcSlew;
    pLow = st.hasPrevB ? st.loB + Math.max(-m, Math.min(m, rawLo - st.loB)) : rawLo;
    pHigh = st.hasPrevB ? st.hiB + Math.max(-m, Math.min(m, rawHi - st.hiB)) : rawHi;
    st.lo = pLow;
    st.hi = pHigh;
  }
  const span = Math.max(80, pHigh - pLow);
  const norm = new Float32Array(N);
  let lut = null;
  if (mode === "plateau") {
    const BINS = 512, hist = new Float64Array(BINS);
    let n = 0;
    for (let i = 0; i < N; i += 2) {
      const v = x[i];
      if (v >= pLow && v <= pHigh) {
        hist[Math.min(BINS - 1, Math.floor((v - pLow) / span * BINS))]++;
        n++;
      }
    }
    const T = Math.max(1, n / BINS * cfg.plateau);
    const floor = Math.max(0.05 * T, 0.5);
    let cum = 0;
    const l = new Float32Array(BINS);
    for (let b = 0; b < BINS; b++) {
      cum += Math.max(floor, Math.min(T, hist[b]));
      l[b] = cum;
    }
    for (let b = 0; b < BINS; b++) l[b] /= cum;
    lut = st.hasPrevB && st.lutB && st.lutB.length === BINS ? l.map((v, i) => 0.7 * st.lutB[i] + 0.3 * v) : l;
    st.lut = lut;
  }
  for (let i = 0; i < N; i++) {
    const v = x[i];
    if (v <= pHigh) {
      const lin = Math.max(0, Math.min(232, (v - pLow) / span * 232));
      if (lut) {
        const eq = v <= pLow ? 0 : lut[Math.min(lut.length - 1, Math.floor((v - pLow) / span * lut.length))] * 232;
        norm[i] = lin * (1 - cfg.pheAmount) + eq * cfg.pheAmount;
      } else norm[i] = lin;
    } else norm[i] = 232 + Math.min(1, (v - pHigh) / 7e3) * 23;
  }
  if (!cfg.spatialOnly && st.hasPrevB && st.prevNormB && st.prevNormB.length === N) for (let i = 0; i < N; i++) norm[i] = 0.25 * norm[i] + 0.75 * st.prevNormB[i];
  st.prevNorm = norm.slice();
  st.hasPrev = true;
  return { norm, pLow, pHigh, span };
}
async function destripeB(ctx, x, cfg, sigma) {
  const { W, H } = ctx, N = W * H;
  const K = Math.max(1, Math.min(cfg.window, ctx.total));
  const i0 = Math.max(0, Math.min(ctx.total - K, ctx.idx - K + 1));
  const med = percentileSample(x, 0.5, 5);
  const M = new Float32Array(N);
  let used = 0;
  let first = null, last = null;
  for (let k = 0; k < K; k++) {
    const f = k + i0 === ctx.idx ? ctx.raw : await ctx.getFrame(i0 + k);
    if (!f) continue;
    const c = new Float32Array(N);
    for (let i = 0; i < N; i++) c[i] = Math.max(med - 1e3, Math.min(med + 1e3, f[i] & 16383));
    for (let i = 0; i < N; i++) M[i] += c[i];
    if (!first) first = c;
    last = c;
    used++;
  }
  if (used === 0) return { col: new Float32Array(W), row: new Float32Array(H), fpn: null, conf: 0 };
  for (let i = 0; i < N; i++) M[i] /= used;
  let conf = 0;
  if (used >= 4 && first && last) {
    let s = 0;
    for (let i = 0; i < N; i += 3) s += Math.abs(last[i] - first[i]);
    s /= N / 3;
    conf = Math.max(0, Math.min(1, (s - 1.3 * sigma) / (4 * sigma)));
  }
  const col = cfg.vStr > 0 ? estimateLineOffsetsLocal(M, W, H, "col", 4, 3) : new Float32Array(W);
  applyLineOffsets(M, W, H, "col", col, 1);
  const row = cfg.hStr > 0 ? estimateLineOffsetsLocal(M, W, H, "row", 4, 3) : new Float32Array(H);
  applyLineOffsets(M, W, H, "row", row, 1);
  let fpn = null;
  if (cfg.fpnPixel > 0 && conf > 0) {
    const bl = boxBlur(M, W, H, 6);
    fpn = new Float32Array(N);
    const g = conf * cfg.fpnPixel;
    for (let i = 0; i < N; i++) fpn[i] = Math.max(-40, Math.min(40, M[i] - bl[i])) * g;
  }
  return { col, row, fpn, conf };
}
function applyB(img, W, H, c, cfg) {
  applyLineOffsets(img, W, H, "col", c.col, cfg.vStr);
  applyLineOffsets(img, W, H, "row", c.row, cfg.hStr);
  if (c.fpn) for (let i = 0; i < img.length; i++) img[i] -= c.fpn[i];
}
async function runPipeline(v, ctx, cfg, st) {
  const T0 = performance.now();
  const { W, H, raw } = ctx, N = W * H;
  const notes = [];
  const tm = { lines: 0, cnn: 0, denoise: 0, tone: 0, detail: 0, total: 0 };
  const raw14 = new Float32Array(N);
  let rMin = 16383, rMax = 0;
  for (let i = 0; i < N; i++) {
    const q = raw[i] & 16383;
    raw14[i] = q;
    if (q < rMin) rMin = q;
    if (q > rMax) rMax = q;
  }
  const base8 = new Uint8ClampedArray(N), nspan = Math.max(1, rMax - rMin);
  for (let i = 0; i < N; i++) base8[i] = Math.round((raw14[i] - rMin) / nspan * 255);
  let t = performance.now();
  let x = raw14;
  let sigma = noiseSigma(raw14, W, H), conf = 0;
  let bcorr = null;
  if (cfg.stage1) {
    if (cfg.badPixel === "robust") x = robustBadPixels(x, W, H, sigma);
    if (cfg.lineMethod === "orig") x = origStage1(x, W, H, cfg.vStr, cfg.hStr);
    else if (cfg.lineMethod === "new") {
      x = Float32Array.from(x);
      if (v === "B") {
        bcorr = await destripeB(ctx, x, cfg, sigma);
        conf = bcorr.conf;
        applyB(x, W, H, bcorr, cfg);
      } else if (v === "C") {
        if (cfg.vStr > 0) applyLineOffsets(x, W, H, "col", estimateLineOffsetsSpectral(x, W, H, "col", cfg.specCutoff, cfg.specPeak, cfg.specMode), cfg.vStr);
        if (cfg.hStr > 0) applyLineOffsets(x, W, H, "row", estimateLineOffsetsSpectral(x, W, H, "row", cfg.specCutoff, cfg.specPeak, cfg.specMode), cfg.hStr);
      } else {
        if (cfg.vStr > 0) applyLineOffsets(x, W, H, "col", estimateLineOffsetsLocal(x, W, H, "col", 4, 3), cfg.vStr);
        if (cfg.hStr > 0) applyLineOffsets(x, W, H, "row", estimateLineOffsetsLocal(x, W, H, "row", 4, 3), cfg.hStr);
      }
    }
    if (cfg.badPixel === "orig" && cfg.lineMethod !== "orig") x = origStage1(x, W, H, 0, 0);
  }
  tm.lines = performance.now() - t;
  let usedCnn = false;
  if (cfg.cnn && v !== "O") {
    const m = getCnn(v);
    if (m) {
      t = performance.now();
      try {
        x = await cnnRestore(m, x, W, H, cfg.cnnStrength);
        usedCnn = true;
      } catch (e2) {
        notes.push("CNN inference failed: " + (e2 instanceof Error ? e2.message : String(e2)));
      }
      tm.cnn = performance.now() - t;
    } else notes.push("CNN enabled but no model trained/loaded for this instance.");
  }
  t = performance.now();
  if (v === "B" && cfg.tdenoise && cfg.stage1) {
    const pi = ctx.idx > 0 ? ctx.idx - 1 : ctx.idx + 1;
    const prev = ctx.total > 1 ? await ctx.getFrame(pi) : null;
    if (prev) {
      const p = new Float32Array(N);
      for (let i = 0; i < N; i++) p[i] = prev[i] & 16383;
      if (bcorr) applyB(p, W, H, bcorr, cfg);
      const s = noiseSigma(x, W, H), k = 3.5 * s;
      const y = Float32Array.from(x);
      for (let i = 0; i < N; i++) {
        const d = Math.abs(x[i] - p[i]) / k;
        y[i] = x[i] + (p[i] - x[i]) * cfg.tdStrength * Math.exp(-d * d);
      }
      x = y;
    }
  }
  if (v === "C" && cfg.bilateral) {
    const s = noiseSigma(x, W, H);
    x = bilateral5(x, W, H, Math.max(4, 2.2 * s), cfg.bilStrength);
  }
  tm.denoise = performance.now() - t;
  sigma = noiseSigma(x, W, H);
  t = performance.now();
  const mode = v === "B" || cfg.toneMode === "plateau" ? cfg.toneMode : "quantile";
  const { norm, pLow, pHigh, span } = toneMap(x, rMin, rMax, cfg, st, ctx.key, ctx.reset, mode);
  tm.tone = performance.now() - t;
  t = performance.now();
  let e = norm;
  if (v === "A" && cfg.clahe) {
    const c = clahe(e, W, H, 8, 8, cfg.claheClip), a = cfg.claheAmount;
    e = new Float32Array(N);
    for (let i = 0; i < N; i++) e[i] = norm[i] * (1 - a) + c[i] * a;
  }
  if (cfg.stage4) {
    const sn = sigma * 232 / span;
    if (cfg.detailMethod === "guided") e = guidedDetail(e, W, H, cfg.detailGain, cfg.coring * sn);
    else if (cfg.detailMethod === "multiscale") e = multiscaleDetail(e, W, H, cfg.detailGain, cfg.coring * sn, cfg.baseCompress);
    else e = origDetail(e, W, H, cfg.detailGain);
  }
  const out8 = new Uint8ClampedArray(N);
  for (let i = 0; i < N; i++) out8[i] = Math.max(0, Math.min(255, Math.round(e[i])));
  tm.detail = performance.now() - t;
  tm.total = performance.now() - T0;
  return { out8, base8, restored: x, rMin, rMax, pLow, pHigh, sigma, conf, timings: tm, usedCnn, notes };
}

// src/lab/dsp.ts
function robustSigma(values, step = 1) {
  const n = Math.ceil(values.length / step);
  if (n === 0) return { median: 0, sigma: 0 };
  const tmp = new Float32Array(n);
  for (let i = 0, k = 0; i < values.length; i += step, k++) tmp[k] = values[i];
  tmp.sort();
  const med = tmp[n >> 1];
  for (let i = 0; i < n; i++) tmp[i] = Math.abs(tmp[i] - med);
  tmp.sort();
  return { median: med, sigma: 1.4826 * tmp[n >> 1] };
}
function estimateNoiseSigma(src, w, h) {
  const res = new Float32Array(Math.max(1, (w - 2) * (h - 2)));
  let k = 0;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      res[k++] = src[i] - 0.25 * (src[i - 1] + src[i + 1] + src[i - w] + src[i + w]);
    }
  }
  return robustSigma(res, 3).sigma / Math.sqrt(1.25);
}
function lineProfile(src, w, h, axis, hw, gateK) {
  const nLines = axis === "col" ? w : h;
  const nAlong = axis === "col" ? h : w;
  const lineStride = axis === "col" ? 1 : w;
  const alongStride = axis === "col" ? w : 1;
  const d = new Float32Array(nLines);
  const col = new Float32Array(nAlong);
  const dev = new Float32Array(nAlong);
  let sigSum = 0;
  for (let l = 0; l < nLines - 1; l++) {
    for (let t = 0; t < nAlong; t++) {
      col[t] = src[(l + 1) * lineStride + t * alongStride] - src[l * lineStride + t * alongStride];
    }
    const sorted = col.slice().sort();
    const med = sorted[nAlong >> 1];
    for (let t = 0; t < nAlong; t++) dev[t] = Math.abs(col[t] - med);
    dev.sort();
    const sg = Math.max(1e-3, 1.4826 * dev[nAlong >> 1]);
    sigSum += sg;
    const lim = gateK * sg;
    let s = 0;
    let k = 0;
    for (let t = 0; t < nAlong; t++) {
      if (Math.abs(col[t] - med) <= lim) {
        s += col[t];
        k++;
      }
    }
    d[l] = k > 0.2 * nAlong ? s / k : med;
  }
  const p = new Float64Array(nLines);
  for (let l = 1; l < nLines; l++) p[l] = p[l - 1] + d[l - 1];
  const ps = new Float64Array(nLines + 1);
  for (let l = 0; l < nLines; l++) ps[l + 1] = ps[l] + p[l];
  const profile = new Float32Array(nLines);
  for (let l = 0; l < nLines; l++) {
    const lo = Math.max(0, l - hw);
    const hi = Math.min(nLines - 1, l + hw);
    profile[l] = p[l] - (ps[hi + 1] - ps[lo]) / (hi - lo + 1);
  }
  return { profile, sigma: sigSum / Math.max(1, nLines - 1) };
}
function applyProfile(src, w, h, axis, profile, strength, clampAdu) {
  const out = new Float32Array(src.length);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const p = profile[axis === "col" ? x : y];
      const c = Math.max(-clampAdu, Math.min(clampAdu, p)) * strength;
      out[y * w + x] = src[y * w + x] - c;
    }
  }
  return out;
}
function boxFilter(src, w, h, r) {
  const tmp = new Float64Array(w * h);
  const out = new Float64Array(w * h);
  const ps = new Float64Array(Math.max(w, h) + 1);
  for (let y = 0; y < h; y++) {
    const b = y * w;
    ps[0] = 0;
    for (let x = 0; x < w; x++) ps[x + 1] = ps[x] + src[b + x];
    for (let x = 0; x < w; x++) {
      const lo = Math.max(0, x - r);
      const hi = Math.min(w - 1, x + r);
      tmp[b + x] = (ps[hi + 1] - ps[lo]) / (hi - lo + 1);
    }
  }
  for (let x = 0; x < w; x++) {
    ps[0] = 0;
    for (let y = 0; y < h; y++) ps[y + 1] = ps[y] + tmp[y * w + x];
    for (let y = 0; y < h; y++) {
      const lo = Math.max(0, y - r);
      const hi = Math.min(h - 1, y + r);
      out[y * w + x] = (ps[hi + 1] - ps[lo]) / (hi - lo + 1);
    }
  }
  return out;
}
function guidedFilter(src, w, h, r, eps) {
  const n = w * h;
  let mean = 0;
  for (let i = 0; i < n; i++) mean += src[i];
  mean /= n;
  const I = new Float64Array(n);
  const II = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const v = src[i] - mean;
    I[i] = v;
    II[i] = v * v;
  }
  const mI = boxFilter(I, w, h, r);
  const mII = boxFilter(II, w, h, r);
  const a = new Float64Array(n);
  const b = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const v = Math.max(0, mII[i] - mI[i] * mI[i]);
    a[i] = v / (v + eps);
    b[i] = mI[i] - a[i] * mI[i];
  }
  const ma = boxFilter(a, w, h, r);
  const mb = boxFilter(b, w, h, r);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) out[i] = ma[i] * I[i] + mb[i] + mean;
  return out;
}
function detailEnhance(src, w, h, p, noiseSigma2) {
  const base = guidedFilter(src, w, h, p.radius, p.edgeAdu * p.edgeAdu);
  const out = new Float32Array(src.length);
  const thr = p.coringK * noiseSigma2;
  const g = Math.max(1, p.gain) - 1;
  for (let i = 0; i < src.length; i++) {
    const d = src[i] - base[i];
    const ex = Math.max(0, Math.abs(d) - thr);
    let add = g * ex;
    if (add > p.maxBoostAdu) add = p.maxBoostAdu;
    out[i] = src[i] + (d < 0 ? -add : add);
  }
  return out;
}
function clahe2(src, w, h, tilesX, clip, blend) {
  const tilesY = Math.max(1, Math.round(tilesX * h / w));
  const luts = new Uint8Array(tilesX * tilesY * 256);
  const hist = new Float64Array(256);
  for (let ty = 0; ty < tilesY; ty++) {
    const y0 = Math.floor(ty * h / tilesY);
    const y1 = Math.floor((ty + 1) * h / tilesY);
    for (let tx = 0; tx < tilesX; tx++) {
      const x0 = Math.floor(tx * w / tilesX);
      const x1 = Math.floor((tx + 1) * w / tilesX);
      hist.fill(0);
      for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) hist[src[y * w + x]]++;
      const area = (y1 - y0) * (x1 - x0);
      const limit = Math.max(1, clip * area / 256);
      let excess = 0;
      for (let i = 0; i < 256; i++) {
        if (hist[i] > limit) {
          excess += hist[i] - limit;
          hist[i] = limit;
        }
      }
      const add = excess / 256;
      let cdf = 0;
      const base = (ty * tilesX + tx) * 256;
      for (let i = 0; i < 256; i++) {
        cdf += hist[i] + add;
        luts[base + i] = Math.min(255, Math.round(255 * cdf / area));
      }
    }
  }
  const out = new Uint8Array(src.length);
  for (let y = 0; y < h; y++) {
    const fy = Math.min(tilesY - 1, Math.max(0, (y + 0.5) / (h / tilesY) - 0.5));
    const ty0 = Math.floor(fy);
    const ty1 = Math.min(tilesY - 1, ty0 + 1);
    const wy = fy - ty0;
    for (let x = 0; x < w; x++) {
      const fx = Math.min(tilesX - 1, Math.max(0, (x + 0.5) / (w / tilesX) - 0.5));
      const tx0 = Math.floor(fx);
      const tx1 = Math.min(tilesX - 1, tx0 + 1);
      const wx = fx - tx0;
      const v = src[y * w + x];
      const a = luts[(ty0 * tilesX + tx0) * 256 + v];
      const b = luts[(ty0 * tilesX + tx1) * 256 + v];
      const c = luts[(ty1 * tilesX + tx0) * 256 + v];
      const d = luts[(ty1 * tilesX + tx1) * 256 + v];
      const eq = (1 - wy) * ((1 - wx) * a + wx * b) + wy * ((1 - wx) * c + wx * d);
      out[y * w + x] = Math.round((1 - blend) * v + blend * eq);
    }
  }
  return out;
}
function freshTemporal(key = "") {
  return { buf: null, frames: 0, key, lastIndex: -1 };
}
function temporalFilter(cur, st, alpha, gateK, noiseSigma2) {
  if (!st.buf || st.buf.length !== cur.length) {
    st.buf = new Float32Array(cur);
    st.frames = 1;
    return { out: new Float32Array(cur), movingFrac: 0 };
  }
  const buf = st.buf;
  const thr = gateK * Math.max(noiseSigma2, 1e-3);
  let moving = 0;
  for (let i = 0; i < cur.length; i++) {
    const d = cur[i] - buf[i];
    if (Math.abs(d) > thr) {
      buf[i] = cur[i];
      moving++;
    } else buf[i] += alpha * d;
  }
  st.frames++;
  return { out: new Float32Array(buf), movingFrac: moving / cur.length };
}

// src/lab/pipeline.ts
var MAX_CODE_14 = 16383;
var DEFAULT_CONFIG = {
  line: { mode: "columns", strength: 1, clampAdu: 400, halfWidth: 32, gateK: 3 },
  tone: { mode: "fixed", fixedLo: 4e3, fixedHi: 9e3, pLo: 1, pHi: 99, gamma: 1, knee: 1 },
  detail: { on: true, radius: 6, edgeAdu: 150, gain: 2.5, coringK: 2, maxBoostAdu: 250 },
  clahe: { on: false, tiles: 8, clip: 3, blend: 0.5 },
  temporal: { on: false, alpha: 0.4, gateK: 4 }
};
function cloneConfig(c) {
  return JSON.parse(JSON.stringify(c));
}
function toneFn(p) {
  const span = Math.max(1, p.hi - p.lo);
  const knee = Math.min(1, Math.max(0.05, p.knee));
  const g = Math.max(0.1, p.gamma);
  return (x) => {
    let t = (x - p.lo) / span;
    if (t <= 0) return 0;
    if (knee < 1 && t > knee) t = knee + (1 - knee) * Math.tanh((t - knee) / (1 - knee));
    if (t > 1) t = 1;
    if (g !== 1) t = Math.pow(t, 1 / g);
    return Math.round(255 * t);
  };
}
function checkMonotonic(fn, maxCode2 = MAX_CODE_14) {
  let prev = fn(0);
  const first = prev;
  let nonDecreasing = true;
  const levels = /* @__PURE__ */ new Set([prev]);
  let lowClip = 0;
  let last = prev;
  for (let c = 1; c <= maxCode2; c++) {
    const v = fn(c);
    if (v < prev) nonDecreasing = false;
    if (v === first) lowClip = c;
    levels.add(v);
    prev = v;
    last = v;
  }
  let highFrom = maxCode2;
  for (let c = maxCode2; c >= 0; c--) {
    if (fn(c) === last) highFrom = c;
    else break;
  }
  const active = Math.max(1, highFrom - lowClip);
  return {
    nonDecreasing,
    distinctLevels: levels.size,
    aduPerLevel: active / Math.max(1, levels.size - 1),
    lowClipBelow: lowClip,
    highClipFrom: highFrom,
    clippedFractionOfRange: (lowClip + (maxCode2 - highFrom)) / maxCode2
  };
}
function percentileWindow(data, pLo, pHi, maxCode2 = MAX_CODE_14) {
  const top = Math.max(255, Math.min(65535, Math.floor(maxCode2)));
  const hist = new Uint32Array(top + 1);
  for (let i = 0; i < data.length; i++) {
    const v = Math.min(top, Math.max(0, Math.round(data[i])));
    hist[v]++;
  }
  const n = data.length;
  const tLo = pLo / 100 * n;
  const tHi = pHi / 100 * n;
  let acc = 0;
  let lo = 0;
  let hi = top;
  let gotLo = false;
  for (let i = 0; i <= top; i++) {
    acc += hist[i];
    if (!gotLo && acc >= tLo) {
      lo = i;
      gotLo = true;
    }
    if (acc >= tHi) {
      hi = i;
      break;
    }
  }
  if (hi <= lo) hi = lo + 1;
  return { lo, hi };
}
function frameStats(raw, maxCode2 = MAX_CODE_14) {
  const top = Math.max(255, Math.min(65535, Math.floor(maxCode2)));
  const hist = new Uint32Array(top + 1);
  let min = Infinity;
  let max = -Infinity;
  for (let i = 0; i < raw.length; i++) {
    const v = raw[i];
    if (v < min) min = v;
    if (v > max) max = v;
    hist[Math.min(top, Math.max(0, Math.round(v)))]++;
  }
  const q = (p) => {
    const t = p * raw.length;
    let acc = 0;
    for (let i = 0; i <= top; i++) {
      acc += hist[i];
      if (acc >= t) return i;
    }
    return top;
  };
  return { min, max, p1: q(0.01), p50: q(0.5), p99: q(0.99) };
}
function applyTone(src, fn) {
  const out = new Uint8Array(src.length);
  for (let i = 0; i < src.length; i++) out[i] = fn(src[i]);
  return out;
}
function referenceDisplay(raw, cfg) {
  const fn = toneFn({ lo: cfg.tone.fixedLo, hi: cfg.tone.fixedHi, gamma: 1, knee: 1 });
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = fn(raw[i]);
  return out;
}
var now = () => typeof performance !== "undefined" ? performance.now() : Date.now();
function runPipeline2(raw, w, h, cfg, tstate, maxCode2 = MAX_CODE_14) {
  const t0 = now();
  let cur = new Float32Array(raw);
  const profiles = { col: null, row: null };
  const axes = cfg.line.mode === "columns" ? ["col"] : cfg.line.mode === "rows" ? ["row"] : cfg.line.mode === "both" ? ["col", "row"] : [];
  for (const ax of axes) {
    const { profile } = lineProfile(cur, w, h, ax, cfg.line.halfWidth, cfg.line.gateK);
    profiles[ax] = profile;
    cur = applyProfile(cur, w, h, ax, profile, cfg.line.strength, cfg.line.clampAdu);
  }
  const corrected = cur;
  const t1 = now();
  const noiseSigma2 = estimateNoiseSigma(corrected, w, h);
  let temporal = { used: false, frames: 0, movingFrac: 0 };
  if (cfg.temporal.on && tstate) {
    const r = temporalFilter(cur, tstate, cfg.temporal.alpha, cfg.temporal.gateK, noiseSigma2);
    cur = r.out;
    temporal = { used: true, frames: tstate.frames, movingFrac: r.movingFrac };
  }
  const t2 = now();
  if (cfg.detail.on) {
    const dp = {
      radius: cfg.detail.radius,
      edgeAdu: cfg.detail.edgeAdu,
      gain: cfg.detail.gain,
      coringK: cfg.detail.coringK,
      maxBoostAdu: cfg.detail.maxBoostAdu
    };
    cur = detailEnhance(cur, w, h, dp, noiseSigma2);
  }
  const enhanced = cur;
  const t3 = now();
  let lo = cfg.tone.fixedLo;
  let hi = cfg.tone.fixedHi;
  if (cfg.tone.mode === "percentile") {
    const pw = percentileWindow(enhanced, cfg.tone.pLo, cfg.tone.pHi, maxCode2);
    lo = pw.lo;
    hi = pw.hi;
  }
  const tone = { lo, hi, gamma: cfg.tone.gamma, knee: cfg.tone.knee };
  const fn = toneFn(tone);
  let display = applyTone(enhanced, fn);
  let below = 0;
  let above = 0;
  for (let i = 0; i < enhanced.length; i++) {
    if (enhanced[i] < lo) below++;
    else if (enhanced[i] > hi) above++;
  }
  const t4 = now();
  if (cfg.clahe.on) display = clahe2(display, w, h, cfg.clahe.tiles, cfg.clahe.clip, cfg.clahe.blend);
  const t5 = now();
  let s0 = 0;
  let s255 = 0;
  for (let i = 0; i < display.length; i++) {
    if (display[i] === 0) s0++;
    else if (display[i] === 255) s255++;
  }
  const n = display.length;
  return {
    corrected,
    enhanced,
    display,
    tone,
    toneReport: checkMonotonic(fn, maxCode2),
    clipLowFrac: below / n,
    clipHighFrac: above / n,
    sat0Frac: s0 / n,
    sat255Frac: s255 / n,
    noiseSigma: noiseSigma2,
    profiles,
    temporal,
    timingsMs: { line: t1 - t0, temporal: t2 - t1, detail: t3 - t2, tone: t4 - t3, clahe: t5 - t4, total: t5 - t0 }
  };
}
var FROZEN_VARIANTS = (() => {
  const base = cloneConfig(DEFAULT_CONFIG);
  base.clahe.on = false;
  base.temporal.on = false;
  const mk = (line, detail) => {
    const c = cloneConfig(base);
    c.line.mode = line;
    c.detail.on = detail;
    return c;
  };
  return [
    { id: "identity", label: "Identity (raw)", cfg: mk("off", false) },
    { id: "line", label: "Line correction (columns)", cfg: mk("columns", false) },
    { id: "detail", label: "Detail only", cfg: mk("off", true) },
    { id: "line+detail", label: "Line + detail", cfg: mk("columns", true) }
  ];
})();

// src/lab/decode.ts
function frameBytes(c) {
  return c.width * c.height * 2;
}
function maxCode(c) {
  return (1 << c.bits) - 1;
}
function frameCountFor(size, c) {
  if (!Number.isFinite(size) || size < 0) return { frames: 0, remainder: 0 };
  if (size < c.headerBytes) return { frames: 0, remainder: size };
  const usable = size - c.headerBytes;
  const fb = frameBytes(c);
  if (fb <= 0) return { frames: 0, remainder: usable };
  return { frames: Math.floor(usable / fb), remainder: usable % fb };
}
function decodeBuffer(buf, c) {
  if (!Number.isInteger(c.width) || !Number.isInteger(c.height) || c.width < 2 || c.height < 2) {
    throw new Error("Invalid frame dimensions for decodeBuffer.");
  }
  if (!Number.isInteger(c.bits) || c.bits < 8 || c.bits > 16) {
    throw new Error("Bit depth must be an integer between 8 and 16.");
  }
  if (!Number.isInteger(c.shift) || c.shift < 0 || c.shift > 16 - c.bits) {
    throw new Error(`Right shift must be between 0 and ${16 - c.bits} for ${c.bits}-bit decoding.`);
  }
  const n = c.width * c.height;
  const expectedBytes = n * 2;
  if (buf.byteLength < expectedBytes) {
    throw new Error(
      `Source buffer (${buf.byteLength} bytes) is smaller than one complete frame (${expectedBytes} bytes); refusing to silently zero-pad or wrap.`
    );
  }
  const out = new Uint16Array(n);
  const dv = new DataView(buf);
  const mask = maxCode(c);
  for (let i = 0; i < n; i++) {
    out[i] = dv.getUint16(i * 2, c.littleEndian) >>> c.shift & mask;
  }
  return out;
}
async function readFrame(file, c, index) {
  if (!Number.isInteger(index) || index < 0) {
    throw new Error(`Invalid frame index (${index}): index must be a non-negative integer.`);
  }
  const fb = frameBytes(c);
  const { frames } = frameCountFor(file.size, c);
  if (frames < 1) {
    throw new Error(
      `Source size (${file.size} bytes) after ${c.headerBytes} header bytes is smaller than one complete frame (${fb} bytes).`
    );
  }
  if (index >= frames) {
    throw new Error(`Frame index ${index} is out of bounds for source with ${frames} whole frame(s).`);
  }
  const start = c.headerBytes + index * fb;
  const end = start + fb;
  if (end > file.size) {
    throw new Error(`Incomplete frame slice at index ${index}.`);
  }
  const buf = await file.slice(start, end).arrayBuffer();
  return decodeBuffer(buf, c);
}
function to14BitForLegacyMethods(raw, bits, userApprovedScaling) {
  if (bits === 14) {
    return { data14: raw, scaled: false, scaleFactor: 1, warning: null };
  }
  if (bits < 14) {
    return {
      data14: raw,
      scaled: false,
      scaleFactor: 1,
      warning: `Input decoded as ${bits}-bit (0..${(1 << bits) - 1}); passed without rescaling into 14-bit legacy methods.`
    };
  }
  if (!userApprovedScaling) {
    throw new Error(
      `Original classical algorithms are hardcoded for 14-bit (0..16383) ADU. To run them on ${bits}-bit data, explicitly enable user-approved 14-bit compatibility scaling.`
    );
  }
  const srcMax = (1 << bits) - 1;
  const scaleFactor = 16383 / srcMax;
  const out = new Uint16Array(raw.length);
  for (let i = 0; i < raw.length; i++) {
    out[i] = Math.min(16383, Math.max(0, Math.round(raw[i] * scaleFactor)));
  }
  return {
    data14: out,
    scaled: true,
    scaleFactor,
    warning: `User-approved compatibility scaling applied: ${bits}-bit (0..${srcMax}) linearly scaled by ${scaleFactor.toFixed(4)} to 14-bit (0..16383) for legacy 14-bit algorithms. Raw reference and raw ROI counts retain true ${bits}-bit values.`
  };
}
async function diagnoseFormat(file, c, index) {
  const fb = frameBytes(c);
  const { frames } = frameCountFor(file.size, c);
  if (frames < 1 || index < 0 || index >= frames) {
    throw new Error("Cannot diagnose format: source has no complete frame at the requested index.");
  }
  const start = c.headerBytes + index * fb;
  const buf = await file.slice(start, start + fb).arrayBuffer();
  const dv = new DataView(buf);
  const n = Math.floor(buf.byteLength / 2);
  const evalOrder = (le) => {
    let high = 0;
    let diff = 0;
    let cnt = 0;
    let prev = 0;
    for (let i = 0; i < n; i++) {
      const v = dv.getUint16(i * 2, le);
      if (v >>> c.bits !== 0) high++;
      if (i % c.width !== 0) {
        diff += Math.abs(v - prev);
        cnt++;
      }
      prev = v;
    }
    return { highBitFraction: n ? high / n : 0, meanAbsNeighbourDiff: cnt ? diff / cnt : 0 };
  };
  return {
    littleEndian: evalOrder(true),
    bigEndian: evalOrder(false),
    note: "Heuristic only: file size matching and these statistics do not establish format, bit alignment, headers or radiometric calibration."
  };
}
var PRIMES = [];
for (let p = 2; PRIMES.length < 64; p++) {
  let ok = true;
  for (let d = 2; d * d <= p; d++) if (p % d === 0) ok = false;
  if (ok) PRIMES.push(p);
}
var frac32 = (x) => Math.floor((x - Math.floor(x)) * 4294967296) >>> 0;
var K256 = new Uint32Array(PRIMES.map((p) => frac32(Math.cbrt(p))));
var H256 = new Uint32Array(PRIMES.slice(0, 8).map((p) => frac32(Math.sqrt(p))));
var rotr = (x, n) => x >>> n | x << 32 - n;
var Sha256 = class {
  constructor() {
    this.h = new Uint32Array(H256);
    this.buf = new Uint8Array(64);
    this.bl = 0;
    this.total = 0;
    this.w = new Uint32Array(64);
  }
  block(b, o) {
    const w = this.w;
    for (let t = 0; t < 16; t++) {
      w[t] = (b[o + 4 * t] << 24 | b[o + 4 * t + 1] << 16 | b[o + 4 * t + 2] << 8 | b[o + 4 * t + 3]) >>> 0;
    }
    for (let t = 16; t < 64; t++) {
      const s0 = rotr(w[t - 15], 7) ^ rotr(w[t - 15], 18) ^ w[t - 15] >>> 3;
      const s1 = rotr(w[t - 2], 17) ^ rotr(w[t - 2], 19) ^ w[t - 2] >>> 10;
      w[t] = w[t - 16] + s0 + w[t - 7] + s1 >>> 0;
    }
    let [a, b2, c, d, e, f, g, hh] = this.h;
    for (let t = 0; t < 64; t++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = e & f ^ ~e & g;
      const t1 = hh + S1 + ch + K256[t] + w[t] >>> 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = a & b2 ^ a & c ^ b2 & c;
      const t2 = S0 + maj >>> 0;
      hh = g;
      g = f;
      f = e;
      e = d + t1 >>> 0;
      d = c;
      c = b2;
      b2 = a;
      a = t1 + t2 >>> 0;
    }
    const h = this.h;
    h[0] = h[0] + a >>> 0;
    h[1] = h[1] + b2 >>> 0;
    h[2] = h[2] + c >>> 0;
    h[3] = h[3] + d >>> 0;
    h[4] = h[4] + e >>> 0;
    h[5] = h[5] + f >>> 0;
    h[6] = h[6] + g >>> 0;
    h[7] = h[7] + hh >>> 0;
  }
  update(d) {
    this.total += d.length;
    let i = 0;
    if (this.bl > 0) {
      while (i < d.length && this.bl < 64) this.buf[this.bl++] = d[i++];
      if (this.bl === 64) {
        this.block(this.buf, 0);
        this.bl = 0;
      }
    }
    while (i + 64 <= d.length) {
      this.block(d, i);
      i += 64;
    }
    while (i < d.length) this.buf[this.bl++] = d[i++];
  }
  digestHex() {
    const totalBits = this.total * 8;
    const hi = Math.floor(totalBits / 4294967296) >>> 0;
    const lo = totalBits >>> 0;
    const pad = [128];
    while ((this.bl + pad.length) % 64 !== 56) pad.push(0);
    pad.push(hi >>> 24 & 255, hi >>> 16 & 255, hi >>> 8 & 255, hi & 255);
    pad.push(lo >>> 24 & 255, lo >>> 16 & 255, lo >>> 8 & 255, lo & 255);
    const savedTotal = this.total;
    this.update(new Uint8Array(pad));
    this.total = savedTotal;
    return Array.from(this.h).map((x) => x.toString(16).padStart(8, "0")).join("");
  }
};
function sha256Bytes(bytes) {
  const sha = new Sha256();
  sha.update(bytes);
  return sha.digestHex();
}
async function sha256File(file, onProgress, signal) {
  const sha = new Sha256();
  if (file.size === 0) {
    onProgress?.(1);
    return sha.digestHex();
  }
  const chunk = 4 * 1024 * 1024;
  for (let off = 0; off < file.size; off += chunk) {
    if (signal?.aborted) {
      throw new Error("SHA-256 calculation cancelled by user.");
    }
    const ab = await file.slice(off, Math.min(file.size, off + chunk)).arrayBuffer();
    if (signal?.aborted) {
      throw new Error("SHA-256 calculation cancelled by user.");
    }
    sha.update(new Uint8Array(ab));
    onProgress?.(Math.min(1, (off + chunk) / file.size));
    await new Promise((r) => setTimeout(r, 0));
  }
  return sha.digestHex();
}

// src/lab/roi.ts
function roiStats(data, W, H, r, satHigh) {
  const x0 = Math.max(0, Math.floor(r.x));
  const y0 = Math.max(0, Math.floor(r.y));
  const x1 = Math.min(W, Math.ceil(r.x + r.w));
  const y1 = Math.min(H, Math.ceil(r.y + r.h));
  const n = Math.max(0, x1 - x0) * Math.max(0, y1 - y0);
  if (n === 0) {
    return {
      n: 0,
      median: NaN,
      sigma: NaN,
      min: NaN,
      max: NaN,
      lowClipFrac: 0,
      highClipFrac: 0,
      satFrac: 0,
      validFrac: 0
    };
  }
  const vals = new Float32Array(n);
  let k = 0;
  let lowClip = 0;
  let highClip = 0;
  let min = Infinity;
  let max = -Infinity;
  for (let y = y0; y < y1; y++) {
    for (let x = x0; x < x1; x++) {
      const v = data[y * W + x];
      vals[k++] = v;
      if (v <= 0) lowClip++;
      if (v >= satHigh) highClip++;
      if (v < min) min = v;
      if (v > max) max = v;
    }
  }
  const sat = lowClip + highClip;
  const { median, sigma } = robustSigma(vals);
  return {
    n,
    median,
    sigma,
    min,
    max,
    lowClipFrac: lowClip / n,
    highClipFrac: highClip / n,
    satFrac: Math.min(1, sat / n),
    validFrac: Math.max(0, 1 - sat / n)
  };
}
function cnr(roi, bg) {
  if (!isFinite(roi.median) || !isFinite(bg.median) || !(bg.sigma > 1e-6)) return null;
  return Math.abs(roi.median - bg.median) / bg.sigma;
}
function nearestBackground(r, rois) {
  const bgs = rois.filter((q) => q.role === "background");
  if (!bgs.length) return null;
  const cx = r.x + r.w / 2;
  const cy = r.y + r.h / 2;
  let best = bgs[0];
  let bd = Infinity;
  for (const b of bgs) {
    const d = Math.hypot(b.x + b.w / 2 - cx, b.y + b.h / 2 - cy);
    if (d < bd) {
      bd = d;
      best = b;
    }
  }
  return best;
}
function computeRows(rois, W, H, raw, corrected, refDisp, procDisp, satHigh) {
  const stats2 = /* @__PURE__ */ new Map();
  for (const r of rois) {
    stats2.set(r.id, {
      raw: roiStats(raw, W, H, r, satHigh),
      corrected: roiStats(corrected, W, H, r, satHigh),
      refDisp: roiStats(refDisp, W, H, r, 255),
      procDisp: roiStats(procDisp, W, H, r, 255)
    });
  }
  const rows = rois.map((r) => {
    const s = stats2.get(r.id);
    const bg = r.role === "background" ? null : nearestBackground(r, rois);
    const b = bg ? stats2.get(bg.id) : null;
    return {
      roi: r,
      bg,
      ...s,
      localBgDeltaRaw: b ? s.raw.median - b.raw.median : null,
      localBgDeltaProc: b ? s.procDisp.median - b.procDisp.median : null,
      cnrRaw: b ? cnr(s.raw, b.raw) : null,
      cnrCorrected: b ? cnr(s.corrected, b.corrected) : null,
      cnrRef: b ? cnr(s.refDisp, b.refDisp) : null,
      cnrProc: b ? cnr(s.procDisp, b.procDisp) : null
    };
  });
  const pairs = [];
  for (const a of rois.filter((r) => r.role === "animal")) {
    for (const br of rois.filter((r) => r.role === "bridge")) {
      const sa = stats2.get(a.id);
      const sb = stats2.get(br.id);
      const rawDelta = sa.raw.median - sb.raw.median;
      const spread = Math.sqrt((sa.raw.sigma ** 2 + sb.raw.sigma ** 2) / 2);
      const ratio = spread > 1e-6 ? Math.abs(rawDelta) / spread : null;
      const refDelta = sa.refDisp.median - sb.refDisp.median;
      const procDelta = sa.procDisp.median - sb.procDisp.median;
      const orderingChangedInProc = Math.abs(rawDelta) > 1e-3 && Math.abs(procDelta) >= 1 && Math.sign(procDelta) !== Math.sign(rawDelta);
      let verdict;
      if (orderingChangedInProc) {
        verdict = "Descriptive note: spatial/local processing reversed the median display ordering relative to raw sensor counts. Display intensity is not physical temperature.";
      } else if (Math.abs(rawDelta) > 1 && Math.abs(refDelta) < 1) {
        verdict = "Descriptive note: raw medians differ in ADU, but the current fixed reference window compresses or clips them to <1 display level difference.";
      } else {
        verdict = "Descriptive ROI statistics only (median difference and pooled MAD spread). No universal separability threshold or calibrated temperature conclusion is implied.";
      }
      pairs.push({
        animal: a,
        bridge: br,
        rawDelta,
        rawSpread: spread,
        rawRatio: ratio,
        refDelta,
        procDelta,
        orderingChangedInProc,
        verdict
      });
    }
  }
  return { rows, pairs };
}

// src/cnn/model.ts
var CNN_ARCHITECTURE_ID = "ClearHotResidualCNN14-v1";
var ADU_NORM_SCALE = 100;
var DEFAULT_CNN_HYPERPARAMS = {
  spatialChannels: 6,
  profileChannels: 4,
  maxResidualAdu: 240,
  insertionMode: "post_stage1_14bit",
  learningRate: 6e-3,
  weightDecay: 1e-4,
  gradClipNorm: 5,
  tileSize: 0,
  tileOverlap: 16
};
var PARAM_KEYS = [
  "conv1W",
  "conv1B",
  "conv2W",
  "conv2B",
  "conv3W",
  "conv3B",
  "col1W",
  "col1B",
  "col2W",
  "col2B",
  "row1W",
  "row1B",
  "row2W",
  "row2B",
  "branchScales"
];
function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = a + 1831565813 >>> 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function createInitialParameters(seed = 1337, hp = DEFAULT_CNN_HYPERPARAMS) {
  const rng = mulberry32(seed);
  const randn = () => {
    const u1 = Math.max(1e-7, rng());
    const u2 = rng();
    return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  };
  const C = hp.spatialChannels;
  const P = hp.profileChannels;
  const init = (n, scale) => {
    const out = new Float32Array(n);
    for (let i = 0; i < n; i++) out[i] = randn() * scale;
    return out;
  };
  const conv1W = init(C * 9, 0.2);
  const conv1B = new Float32Array(C);
  if (C >= 2) {
    conv1W.set([0, -0.25, 0, -0.25, 1, -0.25, 0, -0.25, 0], 0);
    conv1W.set([0, 0.25, 0, 0.25, -1, 0.25, 0, 0.25, 0], 9);
  }
  const conv2W = init(C * C * 9, 0.15);
  const conv2B = new Float32Array(C);
  for (let c = 0; c < C; c++) {
    conv2W[(c * C + c) * 9 + 4] = 0.8;
  }
  const conv3W = init(C * 9, 0.01);
  const conv3B = new Float32Array(1);
  const col1W = init(P * 5, 0.1);
  const col1B = new Float32Array(P);
  if (P >= 4) {
    col1W.set([0, 0, 1, 0, 0], 0);
    col1W.set([0, 0, -1, 0, 0], 5);
    col1W.set([-0.25, 0.5, 0.5, 0.5, -0.25], 10);
    col1W.set([0.25, -0.5, -0.5, -0.5, 0.25], 15);
  }
  const col2W = init(P * 5, 0.01);
  if (P >= 2) {
    col2W[0 * 5 + 2] = 0.5;
    col2W[1 * 5 + 2] = -0.5;
  }
  const col2B = new Float32Array(1);
  const row1W = init(P * 5, 0.1);
  const row1B = new Float32Array(P);
  if (P >= 4) {
    row1W.set([0, 0, 1, 0, 0], 0);
    row1W.set([0, 0, -1, 0, 0], 5);
    row1W.set([-0.25, 0.5, 0.5, 0.5, -0.25], 10);
    row1W.set([0.25, -0.5, -0.5, -0.5, 0.25], 15);
  }
  const row2W = init(P * 5, 0.01);
  if (P >= 2) {
    row2W[0 * 5 + 2] = 0.5;
    row2W[1 * 5 + 2] = -0.5;
  }
  const row2B = new Float32Array(1);
  const branchScales = new Float32Array([0.15, 0.75, 0.75]);
  return {
    conv1W,
    conv1B,
    conv2W,
    conv2B,
    conv3W,
    conv3B,
    col1W,
    col1B,
    col2W,
    col2B,
    row1W,
    row1B,
    row2W,
    row2B,
    branchScales
  };
}
function createAdamState(params) {
  const m = {};
  const v = {};
  for (const k of PARAM_KEYS) {
    m[k] = new Array(params[k].length).fill(0);
    v[k] = new Array(params[k].length).fill(0);
  }
  return { step: 0, m, v };
}
function serializeParameters(p) {
  const out = {};
  for (const k of PARAM_KEYS) {
    out[k] = Array.from(p[k]).map((v) => Math.fround(v));
  }
  return out;
}
function deserializeParameters(s) {
  const out = {};
  for (const k of PARAM_KEYS) {
    if (!Array.isArray(s[k])) {
      throw new Error(`Missing or invalid parameter tensor '${k}' in serialized CNN weights.`);
    }
    out[k] = Float32Array.from(s[k]);
  }
  return out;
}
function countParameters(p) {
  let total = 0;
  for (const k of PARAM_KEYS) total += p[k].length;
  return total;
}
function allParametersFinite(p) {
  for (const k of PARAM_KEYS) {
    const arr = p[k];
    for (let i = 0; i < arr.length; i++) {
      if (!Number.isFinite(arr[i])) return false;
    }
  }
  return true;
}
function computeArchitectureHash(hp = DEFAULT_CNN_HYPERPARAMS) {
  const spec = JSON.stringify({
    arch: CNN_ARCHITECTURE_ID,
    spatialChannels: hp.spatialChannels,
    profileChannels: hp.profileChannels,
    maxResidualAdu: hp.maxResidualAdu,
    insertionMode: hp.insertionMode,
    normScale: ADU_NORM_SCALE
  });
  return sha256Bytes(new TextEncoder().encode(spec));
}
function computeWeightsSha256(p) {
  const totalFloats = countParameters(p);
  const buf = new ArrayBuffer(totalFloats * 4);
  const dv = new DataView(buf);
  let offset = 0;
  for (const k of PARAM_KEYS) {
    const arr = p[k];
    for (let i = 0; i < arr.length; i++) {
      dv.setFloat32(offset, Math.fround(arr[i]), true);
      offset += 4;
    }
  }
  return sha256Bytes(new Uint8Array(buf));
}
function parameterL2Distance(a, b) {
  let sumSq = 0;
  for (const k of PARAM_KEYS) {
    const tA = a[k];
    const tB = b[k];
    for (let i = 0; i < tA.length; i++) {
      const d = tA[i] - tB[i];
      sumSq += d * d;
    }
  }
  return Math.sqrt(sumSq);
}
function frameMedian14(x) {
  const n = x.length;
  if (n === 0) return 7e3;
  const stride = Math.max(1, Math.floor(n / 2048));
  const sample = [];
  for (let i = 0; i < n; i += stride) sample.push(x[i]);
  sample.sort((a, b) => a - b);
  return sample[Math.floor(sample.length / 2)];
}
function extractProfilesNorm(xNorm, W, H) {
  const colProf = new Float32Array(W);
  const rowProf = new Float32Array(H);
  const colProtect = new Float32Array(W * H);
  const rowProtect = new Float32Array(W * H);
  for (let x = 0; x < W; x++) {
    let sum = 0;
    let wSum = 0;
    const xL = Math.max(0, x - 1);
    const xR = Math.min(W - 1, x + 1);
    const xL2 = Math.max(0, x - 3);
    const xR2 = Math.min(W - 1, x + 3);
    for (let y = 0; y < H; y++) {
      const idx = y * W + x;
      const c = xNorm[idx];
      const bg = 0.5 * (xNorm[y * W + xL] + xNorm[y * W + xR]);
      const diff = c - bg;
      const yU = Math.max(0, y - 1);
      const yD = Math.min(H - 1, y + 1);
      const vGrad = Math.abs(xNorm[yD * W + x] - xNorm[yU * W + x]);
      const stepGrad = Math.abs(xNorm[y * W + xL] - xNorm[y * W + xR]);
      const w = stepGrad > 0.8 ? 0.02 : 1 / (1 + diff * diff / 1.5 + vGrad * vGrad / 1);
      sum += diff * w;
      wSum += w;
      const localSpike = Math.abs(c - bg);
      colProtect[idx] = localSpike > 1.8 && stepGrad < 0.4 || stepGrad > 1.2 ? 0.2 : 1;
    }
    colProf[x] = wSum > 1e-5 ? sum / wSum : 0;
  }
  for (let y = 0; y < H; y++) {
    let sum = 0;
    let wSum = 0;
    const yU = Math.max(0, y - 1);
    const yD = Math.min(H - 1, y + 1);
    const yU2 = Math.max(0, y - 3);
    const yD2 = Math.min(H - 1, y + 3);
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const c = xNorm[idx];
      const bg = 0.5 * (xNorm[yU * W + x] + xNorm[yD * W + x]);
      const diff = c - bg;
      const xL = Math.max(0, x - 1);
      const xR = Math.min(W - 1, x + 1);
      const hGrad = Math.abs(xNorm[y * W + xR] - xNorm[y * W + xL]);
      const stepGrad = Math.abs(xNorm[yU * W + x] - xNorm[yD * W + x]);
      const w = stepGrad > 0.8 ? 0.02 : 1 / (1 + diff * diff / 1.5 + hGrad * hGrad / 1);
      sum += diff * w;
      wSum += w;
      const localSpike = Math.abs(c - bg);
      rowProtect[idx] = localSpike > 1.8 && stepGrad < 0.4 || stepGrad > 1.2 ? 0.2 : 1;
    }
    rowProf[y] = wSum > 1e-5 ? sum / wSum : 0;
  }
  return { colProf, rowProf, colProtect, rowProtect };
}
var leakyRelu = (x) => x >= 0 ? x : 0.1 * x;
var dLeakyRelu = (pre) => pre >= 0 ? 1 : 0.1;
function forwardAndBackward(input14, cleanTarget14, W, H, params, hp = DEFAULT_CNN_HYPERPARAMS) {
  const N = W * H;
  const C = hp.spatialChannels;
  const P = hp.profileChannels;
  const med = frameMedian14(input14);
  const xNorm = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    const v = (input14[i] - med) / ADU_NORM_SCALE;
    xNorm[i] = Math.max(-8, Math.min(8, v));
  }
  const { colProf, rowProf, colProtect, rowProtect } = extractProfilesNorm(xNorm, W, H);
  const col1Pre = new Float32Array(P * W);
  const col1Act = new Float32Array(P * W);
  for (let p = 0; p < P; p++) {
    const b = params.col1B[p];
    const wOff = p * 5;
    for (let x = 0; x < W; x++) {
      let sum = b;
      for (let k = -2; k <= 2; k++) {
        const xk = Math.max(0, Math.min(W - 1, x + k));
        sum += colProf[xk] * params.col1W[wOff + (k + 2)];
      }
      col1Pre[p * W + x] = sum;
      col1Act[p * W + x] = leakyRelu(sum);
    }
  }
  const colOut = new Float32Array(W);
  for (let x = 0; x < W; x++) {
    let sum = params.col2B[0];
    for (let p = 0; p < P; p++) {
      const wOff = p * 5;
      for (let k = -2; k <= 2; k++) {
        const xk = Math.max(0, Math.min(W - 1, x + k));
        sum += col1Act[p * W + xk] * params.col2W[wOff + (k + 2)];
      }
    }
    colOut[x] = sum;
  }
  const row1Pre = new Float32Array(P * H);
  const row1Act = new Float32Array(P * H);
  for (let p = 0; p < P; p++) {
    const b = params.row1B[p];
    const wOff = p * 5;
    for (let y = 0; y < H; y++) {
      let sum = b;
      for (let k = -2; k <= 2; k++) {
        const yk = Math.max(0, Math.min(H - 1, y + k));
        sum += rowProf[yk] * params.row1W[wOff + (k + 2)];
      }
      row1Pre[p * H + y] = sum;
      row1Act[p * H + y] = leakyRelu(sum);
    }
  }
  const rowOut = new Float32Array(H);
  for (let y = 0; y < H; y++) {
    let sum = params.row2B[0];
    for (let p = 0; p < P; p++) {
      const wOff = p * 5;
      for (let k = -2; k <= 2; k++) {
        const yk = Math.max(0, Math.min(H - 1, y + k));
        sum += row1Act[p * H + yk] * params.row2W[wOff + (k + 2)];
      }
    }
    rowOut[y] = sum;
  }
  const conv1Pre = new Float32Array(C * N);
  const conv1Act = new Float32Array(C * N);
  for (let c = 0; c < C; c++) {
    const b = params.conv1B[c];
    const wOff = c * 9;
    const cOff = c * N;
    for (let y = 0; y < H; y++) {
      const yU = Math.max(0, y - 1) * W;
      const yC = y * W;
      const yD = Math.min(H - 1, y + 1) * W;
      for (let x = 0; x < W; x++) {
        const xL = Math.max(0, x - 1);
        const xR = Math.min(W - 1, x + 1);
        const sum = b + xNorm[yU + xL] * params.conv1W[wOff + 0] + xNorm[yU + x] * params.conv1W[wOff + 1] + xNorm[yU + xR] * params.conv1W[wOff + 2] + xNorm[yC + xL] * params.conv1W[wOff + 3] + xNorm[yC + x] * params.conv1W[wOff + 4] + xNorm[yC + xR] * params.conv1W[wOff + 5] + xNorm[yD + xL] * params.conv1W[wOff + 6] + xNorm[yD + x] * params.conv1W[wOff + 7] + xNorm[yD + xR] * params.conv1W[wOff + 8];
        conv1Pre[cOff + yC + x] = sum;
        conv1Act[cOff + yC + x] = leakyRelu(sum);
      }
    }
  }
  const conv2Pre = new Float32Array(C * N);
  const conv2Act = new Float32Array(C * N);
  for (let co = 0; co < C; co++) {
    const b = params.conv2B[co];
    const coOff = co * N;
    for (let i = 0; i < N; i++) conv2Pre[coOff + i] = b;
    for (let ci = 0; ci < C; ci++) {
      const ciOff = ci * N;
      const wOff = (co * C + ci) * 9;
      for (let y = 0; y < H; y++) {
        const yU = Math.max(0, y - 1) * W;
        const yC = y * W;
        const yD = Math.min(H - 1, y + 1) * W;
        for (let x = 0; x < W; x++) {
          const xL = Math.max(0, x - 1);
          const xR = Math.min(W - 1, x + 1);
          conv2Pre[coOff + yC + x] += conv1Act[ciOff + yU + xL] * params.conv2W[wOff + 0] + conv1Act[ciOff + yU + x] * params.conv2W[wOff + 1] + conv1Act[ciOff + yU + xR] * params.conv2W[wOff + 2] + conv1Act[ciOff + yC + xL] * params.conv2W[wOff + 3] + conv1Act[ciOff + yC + x] * params.conv2W[wOff + 4] + conv1Act[ciOff + yC + xR] * params.conv2W[wOff + 5] + conv1Act[ciOff + yD + xL] * params.conv2W[wOff + 6] + conv1Act[ciOff + yD + x] * params.conv2W[wOff + 7] + conv1Act[ciOff + yD + xR] * params.conv2W[wOff + 8];
        }
      }
    }
    for (let i = 0; i < N; i++) {
      conv2Act[coOff + i] = leakyRelu(conv2Pre[coOff + i]);
    }
  }
  const spatialOut = new Float32Array(N);
  const b3 = params.conv3B[0];
  for (let i = 0; i < N; i++) spatialOut[i] = b3;
  for (let ci = 0; ci < C; ci++) {
    const ciOff = ci * N;
    const wOff = ci * 9;
    for (let y = 0; y < H; y++) {
      const yU = Math.max(0, y - 1) * W;
      const yC = y * W;
      const yD = Math.min(H - 1, y + 1) * W;
      for (let x = 0; x < W; x++) {
        const xL = Math.max(0, x - 1);
        const xR = Math.min(W - 1, x + 1);
        spatialOut[yC + x] += conv2Act[ciOff + yU + xL] * params.conv3W[wOff + 0] + conv2Act[ciOff + yU + x] * params.conv3W[wOff + 1] + conv2Act[ciOff + yU + xR] * params.conv3W[wOff + 2] + conv2Act[ciOff + yC + xL] * params.conv3W[wOff + 3] + conv2Act[ciOff + yC + x] * params.conv3W[wOff + 4] + conv2Act[ciOff + yC + xR] * params.conv3W[wOff + 5] + conv2Act[ciOff + yD + xL] * params.conv3W[wOff + 6] + conv2Act[ciOff + yD + x] * params.conv3W[wOff + 7] + conv2Act[ciOff + yD + xR] * params.conv3W[wOff + 8];
      }
    }
  }
  const sSpatial = params.branchScales[0];
  const sCol = params.branchScales[1];
  const sRow = params.branchScales[2];
  const maxNorm = hp.maxResidualAdu / ADU_NORM_SCALE;
  const predNorm = new Float32Array(N);
  const clampedMask = new Uint8Array(N);
  const residualAdu = new Float32Array(N);
  const restored14 = new Float32Array(N);
  for (let y = 0; y < H; y++) {
    const rVal = rowOut[y];
    const yOff = y * W;
    for (let x = 0; x < W; x++) {
      const idx = yOff + x;
      const rawPred = sSpatial * spatialOut[idx] + sCol * colOut[x] * colProtect[idx] + sRow * rVal * rowProtect[idx];
      if (rawPred > maxNorm) {
        predNorm[idx] = maxNorm;
        clampedMask[idx] = 0;
      } else if (rawPred < -maxNorm) {
        predNorm[idx] = -maxNorm;
        clampedMask[idx] = 0;
      } else {
        predNorm[idx] = rawPred;
        clampedMask[idx] = 1;
      }
      const dAdu = predNorm[idx] * ADU_NORM_SCALE;
      residualAdu[idx] = dAdu;
      restored14[idx] = Math.max(0, Math.min(16383, input14[idx] - dAdu));
    }
  }
  if (!cleanTarget14) {
    return { restored14, residualAdu, loss: null, grads: null, gradNorm: 0 };
  }
  const dPredNorm = new Float32Array(N);
  let totalLoss = 0;
  const invN = 1 / N;
  const huberDelta = 1;
  for (let i = 0; i < N; i++) {
    const targetDeltaNorm = (input14[i] - cleanTarget14[i]) / ADU_NORM_SCALE;
    const err = predNorm[i] - targetDeltaNorm;
    const absErr = Math.abs(err);
    let l;
    let dErr;
    if (absErr <= huberDelta) {
      l = 0.5 * err * err;
      dErr = err;
    } else {
      l = huberDelta * (absErr - 0.5 * huberDelta);
      dErr = huberDelta * Math.sign(err);
    }
    totalLoss += l * invN;
    dPredNorm[i] = clampedMask[i] ? dErr * invN : 0;
  }
  const grads = {
    conv1W: new Float32Array(params.conv1W.length),
    conv1B: new Float32Array(params.conv1B.length),
    conv2W: new Float32Array(params.conv2W.length),
    conv2B: new Float32Array(params.conv2B.length),
    conv3W: new Float32Array(params.conv3W.length),
    conv3B: new Float32Array(params.conv3B.length),
    col1W: new Float32Array(params.col1W.length),
    col1B: new Float32Array(params.col1B.length),
    col2W: new Float32Array(params.col2W.length),
    col2B: new Float32Array(params.col2B.length),
    row1W: new Float32Array(params.row1W.length),
    row1B: new Float32Array(params.row1B.length),
    row2W: new Float32Array(params.row2W.length),
    row2B: new Float32Array(params.row2B.length),
    branchScales: new Float32Array(3)
  };
  const dSpatialOut = new Float32Array(N);
  const dColOut = new Float32Array(W);
  const dRowOut = new Float32Array(H);
  for (let y = 0; y < H; y++) {
    const yOff = y * W;
    const rVal = rowOut[y];
    for (let x = 0; x < W; x++) {
      const idx = yOff + x;
      const g = dPredNorm[idx];
      grads.branchScales[0] += g * spatialOut[idx];
      grads.branchScales[1] += g * colOut[x] * colProtect[idx];
      grads.branchScales[2] += g * rVal * rowProtect[idx];
      dSpatialOut[idx] = g * sSpatial;
      dColOut[x] += g * sCol * colProtect[idx];
      dRowOut[y] += g * sRow * rowProtect[idx];
    }
  }
  const dCol1Act = new Float32Array(P * W);
  for (let x = 0; x < W; x++) {
    const g = dColOut[x];
    grads.col2B[0] += g;
    for (let p = 0; p < P; p++) {
      const wOff = p * 5;
      for (let k = -2; k <= 2; k++) {
        const xk = Math.max(0, Math.min(W - 1, x + k));
        grads.col2W[wOff + (k + 2)] += g * col1Act[p * W + xk];
        dCol1Act[p * W + xk] += g * params.col2W[wOff + (k + 2)];
      }
    }
  }
  for (let p = 0; p < P; p++) {
    const wOff = p * 5;
    for (let x = 0; x < W; x++) {
      const g = dCol1Act[p * W + x] * dLeakyRelu(col1Pre[p * W + x]);
      grads.col1B[p] += g;
      for (let k = -2; k <= 2; k++) {
        const xk = Math.max(0, Math.min(W - 1, x + k));
        grads.col1W[wOff + (k + 2)] += g * colProf[xk];
      }
    }
  }
  const dRow1Act = new Float32Array(P * H);
  for (let y = 0; y < H; y++) {
    const g = dRowOut[y];
    grads.row2B[0] += g;
    for (let p = 0; p < P; p++) {
      const wOff = p * 5;
      for (let k = -2; k <= 2; k++) {
        const yk = Math.max(0, Math.min(H - 1, y + k));
        grads.row2W[wOff + (k + 2)] += g * row1Act[p * H + yk];
        dRow1Act[p * H + yk] += g * params.row2W[wOff + (k + 2)];
      }
    }
  }
  for (let p = 0; p < P; p++) {
    const wOff = p * 5;
    for (let y = 0; y < H; y++) {
      const g = dRow1Act[p * H + y] * dLeakyRelu(row1Pre[p * H + y]);
      grads.row1B[p] += g;
      for (let k = -2; k <= 2; k++) {
        const yk = Math.max(0, Math.min(H - 1, y + k));
        grads.row1W[wOff + (k + 2)] += g * rowProf[yk];
      }
    }
  }
  const dConv2Act = new Float32Array(C * N);
  for (let i = 0; i < N; i++) grads.conv3B[0] += dSpatialOut[i];
  for (let ci = 0; ci < C; ci++) {
    const ciOff = ci * N;
    const wOff = ci * 9;
    for (let y = 0; y < H; y++) {
      const yU = Math.max(0, y - 1) * W;
      const yC = y * W;
      const yD = Math.min(H - 1, y + 1) * W;
      for (let x = 0; x < W; x++) {
        const g = dSpatialOut[yC + x];
        if (g === 0) continue;
        const xL = Math.max(0, x - 1);
        const xR = Math.min(W - 1, x + 1);
        const i0 = ciOff + yU + xL, i1 = ciOff + yU + x, i2 = ciOff + yU + xR, i3 = ciOff + yC + xL, i4 = ciOff + yC + x, i5 = ciOff + yC + xR, i6 = ciOff + yD + xL, i7 = ciOff + yD + x, i8 = ciOff + yD + xR;
        grads.conv3W[wOff + 0] += g * conv2Act[i0];
        grads.conv3W[wOff + 1] += g * conv2Act[i1];
        grads.conv3W[wOff + 2] += g * conv2Act[i2];
        grads.conv3W[wOff + 3] += g * conv2Act[i3];
        grads.conv3W[wOff + 4] += g * conv2Act[i4];
        grads.conv3W[wOff + 5] += g * conv2Act[i5];
        grads.conv3W[wOff + 6] += g * conv2Act[i6];
        grads.conv3W[wOff + 7] += g * conv2Act[i7];
        grads.conv3W[wOff + 8] += g * conv2Act[i8];
        dConv2Act[i0] += g * params.conv3W[wOff + 0];
        dConv2Act[i1] += g * params.conv3W[wOff + 1];
        dConv2Act[i2] += g * params.conv3W[wOff + 2];
        dConv2Act[i3] += g * params.conv3W[wOff + 3];
        dConv2Act[i4] += g * params.conv3W[wOff + 4];
        dConv2Act[i5] += g * params.conv3W[wOff + 5];
        dConv2Act[i6] += g * params.conv3W[wOff + 6];
        dConv2Act[i7] += g * params.conv3W[wOff + 7];
        dConv2Act[i8] += g * params.conv3W[wOff + 8];
      }
    }
  }
  const dConv2Pre = new Float32Array(C * N);
  for (let i = 0; i < C * N; i++) {
    dConv2Pre[i] = dConv2Act[i] * dLeakyRelu(conv2Pre[i]);
  }
  const dConv1Act = new Float32Array(C * N);
  for (let co = 0; co < C; co++) {
    const coOff = co * N;
    for (let i = 0; i < N; i++) grads.conv2B[co] += dConv2Pre[coOff + i];
    for (let ci = 0; ci < C; ci++) {
      const ciOff = ci * N;
      const wOff = (co * C + ci) * 9;
      for (let y = 0; y < H; y++) {
        const yU = Math.max(0, y - 1) * W;
        const yC = y * W;
        const yD = Math.min(H - 1, y + 1) * W;
        for (let x = 0; x < W; x++) {
          const g = dConv2Pre[coOff + yC + x];
          if (g === 0) continue;
          const xL = Math.max(0, x - 1);
          const xR = Math.min(W - 1, x + 1);
          const i0 = ciOff + yU + xL, i1 = ciOff + yU + x, i2 = ciOff + yU + xR, i3 = ciOff + yC + xL, i4 = ciOff + yC + x, i5 = ciOff + yC + xR, i6 = ciOff + yD + xL, i7 = ciOff + yD + x, i8 = ciOff + yD + xR;
          grads.conv2W[wOff + 0] += g * conv1Act[i0];
          grads.conv2W[wOff + 1] += g * conv1Act[i1];
          grads.conv2W[wOff + 2] += g * conv1Act[i2];
          grads.conv2W[wOff + 3] += g * conv1Act[i3];
          grads.conv2W[wOff + 4] += g * conv1Act[i4];
          grads.conv2W[wOff + 5] += g * conv1Act[i5];
          grads.conv2W[wOff + 6] += g * conv1Act[i6];
          grads.conv2W[wOff + 7] += g * conv1Act[i7];
          grads.conv2W[wOff + 8] += g * conv1Act[i8];
          dConv1Act[i0] += g * params.conv2W[wOff + 0];
          dConv1Act[i1] += g * params.conv2W[wOff + 1];
          dConv1Act[i2] += g * params.conv2W[wOff + 2];
          dConv1Act[i3] += g * params.conv2W[wOff + 3];
          dConv1Act[i4] += g * params.conv2W[wOff + 4];
          dConv1Act[i5] += g * params.conv2W[wOff + 5];
          dConv1Act[i6] += g * params.conv2W[wOff + 6];
          dConv1Act[i7] += g * params.conv2W[wOff + 7];
          dConv1Act[i8] += g * params.conv2W[wOff + 8];
        }
      }
    }
  }
  for (let c = 0; c < C; c++) {
    const cOff = c * N;
    const wOff = c * 9;
    for (let y = 0; y < H; y++) {
      const yU = Math.max(0, y - 1) * W;
      const yC = y * W;
      const yD = Math.min(H - 1, y + 1) * W;
      for (let x = 0; x < W; x++) {
        const g = dConv1Act[cOff + yC + x] * dLeakyRelu(conv1Pre[cOff + yC + x]);
        if (g === 0) continue;
        grads.conv1B[c] += g;
        const xL = Math.max(0, x - 1);
        const xR = Math.min(W - 1, x + 1);
        grads.conv1W[wOff + 0] += g * xNorm[yU + xL];
        grads.conv1W[wOff + 1] += g * xNorm[yU + x];
        grads.conv1W[wOff + 2] += g * xNorm[yU + xR];
        grads.conv1W[wOff + 3] += g * xNorm[yC + xL];
        grads.conv1W[wOff + 4] += g * xNorm[yC + x];
        grads.conv1W[wOff + 5] += g * xNorm[yC + xR];
        grads.conv1W[wOff + 6] += g * xNorm[yD + xL];
        grads.conv1W[wOff + 7] += g * xNorm[yD + x];
        grads.conv1W[wOff + 8] += g * xNorm[yD + xR];
      }
    }
  }
  let normSq = 0;
  for (const k of PARAM_KEYS) {
    const gArr = grads[k];
    for (let i = 0; i < gArr.length; i++) normSq += gArr[i] * gArr[i];
  }
  const gradNorm = Math.sqrt(normSq);
  return { restored14, residualAdu, loss: totalLoss, grads, gradNorm };
}
function applyAdamStep(params, grads, opt, hp = DEFAULT_CNN_HYPERPARAMS) {
  let normSq = 0;
  for (const k of PARAM_KEYS) {
    const gArr = grads[k];
    for (let i = 0; i < gArr.length; i++) normSq += gArr[i] * gArr[i];
  }
  const gradNorm = Math.sqrt(normSq);
  const clipScale = gradNorm > hp.gradClipNorm ? hp.gradClipNorm / Math.max(1e-8, gradNorm) : 1;
  opt.step += 1;
  const beta1 = 0.9;
  const beta2 = 0.999;
  const eps = 1e-8;
  const bc1 = 1 - Math.pow(beta1, opt.step);
  const bc2 = 1 - Math.pow(beta2, opt.step);
  let deltaSq = 0;
  for (const k of PARAM_KEYS) {
    const pArr = params[k];
    const gArr = grads[k];
    const mArr = opt.m[k];
    const vArr = opt.v[k];
    const isWeight = k.endsWith("W");
    for (let i = 0; i < pArr.length; i++) {
      const g = gArr[i] * clipScale + (isWeight ? hp.weightDecay * pArr[i] : 0);
      mArr[i] = beta1 * mArr[i] + (1 - beta1) * g;
      vArr[i] = beta2 * vArr[i] + (1 - beta2) * g * g;
      const mHat = mArr[i] / bc1;
      const vHat = vArr[i] / bc2;
      const stepVal = hp.learningRate * mHat / (Math.sqrt(vHat) + eps);
      pArr[i] = Math.fround(pArr[i] - stepVal);
      deltaSq += stepVal * stepVal;
    }
  }
  return { gradNorm, weightsDeltaL2: Math.sqrt(deltaSq) };
}
function inferCnn14(input14, W, H, params, hp = DEFAULT_CNN_HYPERPARAMS, bypass = false) {
  const N = W * H;
  if (bypass || !params) {
    return {
      restored14: Float32Array.from(input14),
      residualAdu: new Float32Array(N),
      usedCnn: false
    };
  }
  if (hp.tileSize <= 0 || W <= hp.tileSize && H <= hp.tileSize) {
    const res = forwardAndBackward(input14, null, W, H, params, hp);
    return { restored14: res.restored14, residualAdu: res.residualAdu, usedCnn: true };
  }
  const T = Math.max(32, hp.tileSize);
  const O = Math.min(Math.floor(T / 4), Math.max(4, hp.tileOverlap));
  const step = T - O * 2;
  const accRestored = new Float32Array(N);
  const accResidual = new Float32Array(N);
  const accWeight = new Float32Array(N);
  for (let y0 = 0; y0 < H; y0 += step) {
    const ty0 = Math.max(0, Math.min(H - T, y0));
    const th = Math.min(T, H - ty0);
    for (let x0 = 0; x0 < W; x0 += step) {
      const tx0 = Math.max(0, Math.min(W - T, x0));
      const tw = Math.min(T, W - tx0);
      const tileIn = new Float32Array(tw * th);
      for (let ty = 0; ty < th; ty++) {
        for (let tx = 0; tx < tw; tx++) {
          tileIn[ty * tw + tx] = input14[(ty0 + ty) * W + (tx0 + tx)];
        }
      }
      const tileOut = forwardAndBackward(tileIn, null, tw, th, params, hp);
      for (let ty = 0; ty < th; ty++) {
        const wy = ty < O && ty0 > 0 ? (ty + 1) / (O + 1) : ty >= th - O && ty0 + th < H ? (th - ty) / (O + 1) : 1;
        for (let tx = 0; tx < tw; tx++) {
          const wx = tx < O && tx0 > 0 ? (tx + 1) / (O + 1) : tx >= tw - O && tx0 + tw < W ? (tw - tx) / (O + 1) : 1;
          const w = wx * wy;
          const dstIdx = (ty0 + ty) * W + (tx0 + tx);
          accRestored[dstIdx] += tileOut.restored14[ty * tw + tx] * w;
          accResidual[dstIdx] += tileOut.residualAdu[ty * tw + tx] * w;
          accWeight[dstIdx] += w;
        }
      }
      if (tx0 + tw >= W) break;
    }
    if (ty0 + th >= H) break;
  }
  const restored14 = new Float32Array(N);
  const residualAdu = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    const w = accWeight[i] > 1e-6 ? accWeight[i] : 1;
    restored14[i] = Math.max(0, Math.min(16383, accRestored[i] / w));
    residualAdu[i] = accResidual[i] / w;
  }
  return { restored14, residualAdu, usedCnn: true };
}

// src/lab/ablationAndCandidates.ts
function createCausalArgosState() {
  return {
    temporalState: freshTemporal(),
    lastIndex: -1
  };
}
function argos2SeparatedLineOnly14(raw14, W, H, verticalStrength = 0.85, horizontalStrength = 0.65) {
  const N = W * H;
  const out = new Float32Array(N);
  const colProf = new Float32Array(W);
  const rowProf = new Float32Array(H);
  let colGlobal = 0;
  for (let x = 0; x < W; x++) {
    let sum = 0;
    let cnt = 0;
    for (let y = 4; y < H - 4; y++) {
      const idx = y * W + x;
      const v = raw14[idx];
      const vDiff = Math.abs(v - raw14[idx - W]);
      if (vDiff < 160 && v > 200 && v < 15500) {
        sum += v;
        cnt++;
      }
    }
    colProf[x] = cnt > 0 ? sum / cnt : 7e3;
    colGlobal += colProf[x];
  }
  colGlobal /= Math.max(1, W);
  const colStripe = new Float32Array(W);
  for (let x = 0; x < W; x++) {
    let s = 0;
    let c = 0;
    for (let k = -4; k <= 4; k++) {
      const xk = Math.max(0, Math.min(W - 1, x + k));
      s += colProf[xk];
      c++;
    }
    const hp = colProf[x] - s / c;
    colStripe[x] = Math.abs(hp) > 180 ? Math.sign(hp) * 180 * 0.35 : hp;
  }
  for (let y = 0; y < H; y++) {
    let sum = 0;
    let cnt = 0;
    const yOff = y * W;
    for (let x = 4; x < W - 4; x++) {
      const idx = yOff + x;
      const v = raw14[idx];
      const hDiff = Math.abs(v - raw14[idx - 1]);
      if (hDiff < 160 && v > 200 && v < 15500) {
        sum += v;
        cnt++;
      }
    }
    rowProf[y] = cnt > 0 ? sum / cnt : colGlobal;
  }
  const rowStripe = new Float32Array(H);
  for (let y = 0; y < H; y++) {
    let s = 0;
    let c = 0;
    for (let k = -4; k <= 4; k++) {
      const yk = Math.max(0, Math.min(H - 1, y + k));
      s += rowProf[yk];
      c++;
    }
    const hp = rowProf[y] - s / c;
    rowStripe[y] = Math.abs(hp) > 180 ? Math.sign(hp) * 180 * 0.35 : hp;
  }
  for (let y = 0; y < H; y++) {
    const yOff = y * W;
    const rOff = rowStripe[y] * horizontalStrength;
    for (let x = 0; x < W; x++) {
      const idx = yOff + x;
      const v = raw14[idx];
      const xL = Math.max(0, x - 1);
      const xR = Math.min(W - 1, x + 1);
      const yU = Math.max(0, y - 1);
      const yD = Math.min(H - 1, y + 1);
      const hSpike = Math.abs(v - 0.5 * (raw14[yOff + xL] + raw14[yOff + xR]));
      const vSpike = Math.abs(v - 0.5 * (raw14[yU * W + x] + raw14[yD * W + x]));
      const cScale = hSpike > 220 ? 0.25 : 1;
      const rScale = vSpike > 220 ? 0.25 : 1;
      const clean = v - colStripe[x] * verticalStrength * cScale - rOff * rScale;
      out[idx] = Math.max(0, Math.min(16383, clean));
    }
  }
  return out;
}
function argos2SeparatedGuidedDetail14(input14, W, H, gain = 2.2, coringK = 1.6, maxBoostAdu = 220) {
  const sigma = Math.max(2, estimateNoiseSigma(input14, W, H));
  const enhanced = detailEnhance(
    input14,
    W,
    H,
    {
      radius: 3,
      edgeAdu: 140,
      gain,
      coringK,
      maxBoostAdu
    },
    sigma
  );
  const out = new Float32Array(enhanced.length);
  for (let i = 0; i < enhanced.length; i++) {
    out[i] = Math.max(0, Math.min(16383, enhanced[i]));
  }
  return out;
}
function runArgos2GuidedCoredCandidate(raw14, W, H, lo, hi) {
  const lineClean14 = argos2SeparatedLineOnly14(raw14, W, H, 0.85, 0.65);
  const enhanced14 = argos2SeparatedGuidedDetail14(lineClean14, W, H, 2.2, 1.6, 220);
  const fn = toneFn({ lo, hi, gamma: 1, knee: 0.92 });
  const pixels = new Uint8Array(W * H);
  for (let i = 0; i < pixels.length; i++) pixels[i] = fn(enhanced14[i]);
  return {
    pixels,
    restored14: enhanced14,
    config: {
      variant: "argos2-guided-cored",
      lineVerticalStrength: 0.85,
      lineHorizontalStrength: 0.65,
      guidedRadius: 3,
      edgeAdu: 140,
      detailGain: 2.2,
      coringK: 1.6,
      maxBoostAdu: 220,
      toneMode: "locked_monotone_window_soft_knee",
      lo,
      hi,
      knee: 0.92
    }
  };
}
function runArgos2CausalTemporalCandidate(raw14, W, H, lo, hi, index, state) {
  const isConsecutive = state.lastIndex >= 0 && index === state.lastIndex + 1;
  if (!isConsecutive) {
    state.temporalState = freshTemporal();
  }
  state.lastIndex = index;
  const lineClean14 = argos2SeparatedLineOnly14(raw14, W, H, 0.85, 0.65);
  const sigma = Math.max(2, estimateNoiseSigma(lineClean14, W, H));
  const tempRes = temporalFilter(lineClean14, state.temporalState, 0.4, 3.8, sigma);
  const enhanced14 = argos2SeparatedGuidedDetail14(tempRes.out, W, H, 2, 1.8, 200);
  const fn = toneFn({ lo, hi, gamma: 1, knee: 0.92 });
  const pixels = new Uint8Array(W * H);
  for (let i = 0; i < pixels.length; i++) pixels[i] = fn(enhanced14[i]);
  return {
    pixels,
    restored14: enhanced14,
    config: {
      variant: "argos2-causal-temporal",
      causalOnly: true,
      declaredWarmupFrames: 3,
      currentWarmupFrames: state.temporalState.frames,
      temporalAlpha: 0.4,
      motionGateK: 3.8,
      movingPixelFrac: Number(tempRes.movingFrac.toFixed(4)),
      lo,
      hi
    }
  };
}
async function runClaudeBCausalCandidate(raw14, W, H, index, reset, getFrame, claudeState, splitStartIndex = 0) {
  const requestedFrames = [];
  const causalGetFrame = async (reqIdx) => {
    const clampedIdx = Math.max(splitStartIndex, Math.min(index, reqIdx));
    requestedFrames.push(clampedIdx);
    if (clampedIdx === index) return raw14;
    return getFrame(clampedIdx);
  };
  const cfg = { ...defaultCfg("B"), cnn: false };
  const res = await runPipeline(
    "B",
    {
      raw: raw14,
      W,
      H,
      key: `causal-${index}`,
      idx: index,
      total: index + 1,
      reset,
      getFrame: causalGetFrame
    },
    cfg,
    claudeState
  );
  return {
    pixels: new Uint8Array(res.out8),
    restored14: res.restored,
    config: {
      ...cfg,
      variant: "claudeB-causal",
      causalEnforced: true,
      splitStartIndex,
      maxFrameAllowed: index
    },
    requestedFrames
  };
}
function computeAblationContextKey(params) {
  return JSON.stringify(params);
}
function runGenuineStageAblation(params) {
  const { raw14, width: W, height: H, frameIndex, lo, hi, rois } = params;
  const N = W * H;
  const lockedFn = toneFn({ lo, hi, gamma: 1, knee: 1 });
  const monoReport = checkMonotonic(lockedFn, 16383);
  const mapFixed = (arr14) => {
    const out = new Uint8Array(N);
    for (let i = 0; i < N; i++) out[i] = lockedFn(arr14[i]);
    return out;
  };
  const rawFloat14 = Float32Array.from(raw14);
  const rawFixed8 = mapFixed(rawFloat14);
  const lineOnly14 = argos2SeparatedLineOnly14(raw14, W, H, 0.85, 0.65);
  const lineOnly8 = mapFixed(lineOnly14);
  const toneOnlyCfg = {
    ...DEFAULT_ISP_CONFIGS.instance2,
    stage1DestripeAndBadPx: false,
    enableMethodologyEnhancement: false,
    stage4EdgePreservingDetail: false,
    enableLiveCnnResidual: false
  };
  const toneOnlyRes = runThermalInstancePipeline({
    methodology: "instance2",
    raw14,
    W,
    H,
    cfg: toneOnlyCfg,
    cnnState: createInitialCnnState("instance2"),
    prevBlackRef: { current: 7100 },
    prevWhiteRef: { current: 7950 },
    lastFrameKeyRef: { current: "" },
    prevNormFrameRef: { current: null },
    prevKalman14Ref: { current: null },
    frameKey: `${frameIndex}`
  });
  const toneOnly8 = new Uint8Array(toneOnlyRes.processed8);
  const detailOnly14 = argos2SeparatedGuidedDetail14(rawFloat14, W, H, 2.2, 1.5, 220);
  const detailOnly8 = mapFixed(detailOnly14);
  const combinedClassical14 = argos2SeparatedGuidedDetail14(lineOnly14, W, H, 2.2, 1.5, 220);
  const combinedClassical8 = mapFixed(combinedClassical14);
  const origArgos2Res = runThermalInstancePipeline({
    methodology: "instance2",
    raw14,
    W,
    H,
    cfg: { ...DEFAULT_ISP_CONFIGS.instance2, enableLiveCnnResidual: false },
    cnnState: createInitialCnnState("instance2"),
    prevBlackRef: { current: 7100 },
    prevWhiteRef: { current: 7950 },
    lastFrameKeyRef: { current: "" },
    prevNormFrameRef: { current: null },
    prevKalman14Ref: { current: null },
    frameKey: `${frameIndex}`
  });
  const origArgos2Pixels8 = new Uint8Array(origArgos2Res.processed8);
  const cnnBypassed = params.cnnBypassed ?? !params.cnnCheckpoint;
  let cnnRestored14;
  if (!cnnBypassed && params.cnnCheckpoint) {
    const weights = deserializeParameters(params.cnnCheckpoint.weights);
    const hp = params.cnnCheckpoint.hyperParams;
    const cnnIn = hp.insertionMode === "post_stage1_14bit" ? origArgos2Res.stage1Clean14 : rawFloat14;
    cnnRestored14 = inferCnn14(cnnIn, W, H, weights, hp, false).restored14;
  } else {
    cnnRestored14 = origArgos2Res.stage1Clean14;
  }
  const cnnFixed8 = mapFixed(cnnRestored14);
  const buildView = (id, title, isModifiedAblation, toneDomain, description, pixels8, intermediate14) => {
    let sq = 0;
    let c0 = 0;
    let c255 = 0;
    for (let i = 0; i < N; i++) {
      const d = pixels8[i] - rawFixed8[i];
      sq += d * d;
      if (pixels8[i] === 0) c0++;
      if (pixels8[i] === 255) c255++;
    }
    const roiStats8 = {};
    const roiStats14 = {};
    for (const r of rois) {
      roiStats8[r.id] = roiStats(pixels8, W, H, r, 255);
      roiStats14[r.id] = roiStats(intermediate14, W, H, r, 16383);
    }
    return {
      id,
      title,
      isModifiedAblation,
      toneDomain,
      description,
      pixels8,
      intermediate14,
      rmsDiffFromRaw8: Number(Math.sqrt(sq / Math.max(1, N)).toFixed(2)),
      lowClipFrac8: Number((c0 / Math.max(1, N)).toFixed(5)),
      highClipFrac8: Number((c255 / Math.max(1, N)).toFixed(5)),
      roiStats8,
      roiStats14
    };
  };
  const contextKey = computeAblationContextKey({
    sourceKey: params.sourceKey,
    frameIndex,
    width: W,
    height: H,
    headerBytes: params.headerBytes ?? 0,
    shift: params.shift ?? 0,
    littleEndian: params.littleEndian ?? true,
    lo,
    hi,
    rois,
    cnnCheckpointId: params.cnnCheckpoint?.checkpointId ?? null,
    cnnBypassed
  });
  const views = [
    buildView(
      "raw_fixed_window",
      "0 \xB7 Raw Fixed-Window Reference",
      false,
      "locked_fixed_window",
      `Unmodified 14-bit sensor counts mapped linearly through locked window [${lo}, ${hi}].`,
      rawFixed8,
      rawFloat14
    ),
    buildView(
      "line_only_fixed_window",
      "1 \xB7 Line Correction Only (Modified Ablation \xB7 Locked Window)",
      true,
      "locked_fixed_window",
      `Isolated 14-bit column/row stripe subtraction (separated from bad-pixel replacement and native AGC), mapped through locked window [${lo}, ${hi}].`,
      lineOnly8,
      lineOnly14
    ),
    buildView(
      "tone_only_ablation",
      "2 \xB7 Tone Curve Only (Modified Ablation \xB7 Native Quantile Window)",
      true,
      "native_argos2_agc_scurve",
      "Argos 2 Stage 2/3 quantile AGC window and soft-shoulder normalization applied to raw 14-bit with Stage 1 destriping and Stage 4 detail disabled.",
      toneOnly8,
      rawFloat14
    ),
    buildView(
      "detail_only_fixed_window",
      "3 \xB7 Detail Enhancement Only (Modified Ablation \xB7 Locked Window)",
      true,
      "locked_fixed_window",
      `Isolated 14-bit edge-aware guided filter base/detail boost with noise-aware coring (no line correction), mapped through locked window [${lo}, ${hi}]. Original Argos 2 fuses guided detail inside its tone-map loop, so this separated view is explicitly labeled a Modified Ablation.`,
      detailOnly8,
      detailOnly14
    ),
    buildView(
      "combined_classical_fixed_window",
      "4A \xB7 Combined Classical (Modified Ablation \xB7 Locked Window)",
      true,
      "locked_fixed_window",
      `Line correction + guided cored detail in 14-bit ADU, mapped through the shared locked window [${lo}, ${hi}].`,
      combinedClassical8,
      combinedClassical14
    ),
    buildView(
      "argos2_original_native",
      "4B \xB7 Original Argos 2 (Untouched Native AGC + Fused Detail)",
      false,
      "native_argos2_agc_scurve",
      "Exact untouched Original Argos 2 pipeline (Stage 1 Haar/comb + bad-pixel + Stage 2/3 quantile AGC + S-curve + fused guided detail + Stage 4 Laplacian).",
      origArgos2Pixels8,
      origArgos2Res.stage1Clean14
    ),
    buildView(
      "opt_in_cnn_fixed_window",
      cnnBypassed ? "5 \xB7 Opt-in CNN Residual (BYPASSED -> Classical Stage 1)" : `5 \xB7 Opt-in CNN Residual (${params.cnnCheckpoint?.checkpointId} \xB7 ${params.cnnCheckpoint?.status.toUpperCase()})`,
      true,
      "locked_fixed_window",
      cnnBypassed ? `CNN bypassed; showing classical Stage 1 14-bit output in locked window [${lo}, ${hi}].` : `Learned 14-bit CNN residual (${params.cnnCheckpoint?.checkpointId}, SHA-256 ${params.cnnCheckpoint?.weightsSha256.slice(0, 12)}\u2026) applied in 14-bit ADU and mapped through locked window [${lo}, ${hi}].`,
      cnnFixed8,
      cnnRestored14
    )
  ];
  return {
    contextKey,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    frameIndex,
    width: W,
    height: H,
    lockedWindow: { lo, hi },
    monotonicityOfLockedWindow: monoReport,
    activeCnnCheckpointId: params.cnnCheckpoint?.checkpointId ?? null,
    cnnBypassed,
    views,
    scientificNote: "Original Argos 2 fuses bad-pixel replacement with Stage 1 destriping and fuses 14-bit guided detail decomposition with its Stage 2/3 S-curve tone mapper. Views 1, 2, 3, and 4A are therefore explicitly labeled Modified Ablations constructed to isolate each stage under a single locked fixed window [lo, hi], while View 4B retains the untouched Original Argos 2."
  };
}

// src/cnn/dataset.ts
var FORBIDDEN_TARGET_PATTERNS = [
  /adjacent[_\s-]*frame/i,
  /noise2noise/i,
  /unlabeled/i,
  /single[_\s-]*frame/i,
  /gaussian[_\s-]*blur/i,
  /blurred/i,
  /model[_\s-]*prediction/i,
  /self[_\s-]*train/i,
  /pseudo[_\s-]*label/i
];
function validateDatasetManifest(manifest) {
  const errors = [];
  const warnings = [];
  if (!manifest || manifest.schema !== "clearhot-dataset-manifest-v1") {
    errors.push("Manifest schema must be 'clearhot-dataset-manifest-v1'.");
  }
  if (!manifest.datasetId || typeof manifest.datasetId !== "string") {
    errors.push("datasetId is required.");
  }
  if (!Number.isInteger(manifest.version) || manifest.version < 1) {
    errors.push("version must be a positive integer.");
  }
  const att = manifest.humanAttestation;
  if (!att) {
    errors.push("humanAttestation block is required.");
  } else {
    if (!att.attestedBy || att.attestedBy.trim().length < 2) {
      errors.push("humanAttestation.attestedBy must identify the human reviewer/curator.");
    }
    if (!att.targetProvenanceDescription || att.targetProvenanceDescription.trim().length < 8) {
      errors.push("humanAttestation.targetProvenanceDescription must document how clean targets were obtained.");
    }
    if (att.alignmentVerified !== true) {
      errors.push("humanAttestation.alignmentVerified must be true (source and target frames must be spatially/temporally aligned).");
    }
    if (att.notAdjacentFrameNoise2Noise !== true) {
      errors.push("humanAttestation.notAdjacentFrameNoise2Noise must be true (unlabeled adjacent video frames are rejected).");
    }
    if (att.notModelPredictionOrBlur !== true) {
      errors.push("humanAttestation.notModelPredictionOrBlur must be true (blurred frames or model predictions are rejected).");
    }
    if (att.countDomainConfirmed14Bit !== true) {
      errors.push("humanAttestation.countDomainConfirmed14Bit must be true (both input and target must be in the same 14-bit count domain).");
    }
    for (const pat of FORBIDDEN_TARGET_PATTERNS) {
      if (pat.test(att.targetType || "") || pat.test(att.targetProvenanceDescription || "")) {
        errors.push(
          `Rejected target provenance ('${att.targetType}'): single unlabeled frames, adjacent noisy frames, blurred images, and model predictions are not valid clean targets.`
        );
        break;
      }
    }
  }
  if (!Array.isArray(manifest.entries) || manifest.entries.length === 0) {
    errors.push("Manifest entries array must not be empty.");
  }
  const hashSplits = /* @__PURE__ */ new Map();
  const recordingSplits = /* @__PURE__ */ new Map();
  const recordingFramesBySplit = /* @__PURE__ */ new Map();
  const sceneSplits = /* @__PURE__ */ new Map();
  let trainCount = 0;
  let validationCount = 0;
  let finalTestCount = 0;
  for (const e of manifest.entries || []) {
    if (!["train", "validation", "final_test"].includes(e.split)) {
      errors.push(`Entry '${e.pairId}' has invalid split '${e.split}'.`);
      continue;
    }
    if (e.split === "train") trainCount++;
    else if (e.split === "validation") validationCount++;
    else if (e.split === "final_test") finalTestCount++;
    if (!/^[0-9a-f]{64}$/i.test(e.sourceSha256) || !/^[0-9a-f]{64}$/i.test(e.targetSha256)) {
      errors.push(`Entry '${e.pairId}' must provide full 64-hex SHA-256 digests for both sourceSha256 and targetSha256.`);
    }
    if (e.sourceSha256.toLowerCase() === e.targetSha256.toLowerCase()) {
      if (e.sourceFrameIndex === e.targetFrameIndex) {
        errors.push(`Entry '${e.pairId}' has identical source and target file hash and frame index (unlabeled identity target rejected).`);
      } else if (Math.abs(e.sourceFrameIndex - e.targetFrameIndex) <= 12) {
        errors.push(
          `Entry '${e.pairId}' uses adjacent/nearby frames (${e.sourceFrameIndex} vs ${e.targetFrameIndex}) from the same file hash as input/target. Adjacent noisy frames are rejected.`
        );
      } else {
        errors.push(
          `Entry '${e.pairId}' uses the same raw recording file hash for both noisy source and clean target. Supply a separately verified clean reference file.`
        );
      }
    }
    const d = e.decoder;
    if (!d || d.bits !== 14 || d.width < 32 || d.height < 32 || d.width % 2 !== 0 || d.height % 2 !== 0) {
      errors.push(`Entry '${e.pairId}' has invalid decoder settings (must be 14-bit with even width/height >= 32).`);
    }
    if (!Number.isInteger(e.sourceFrameIndex) || e.sourceFrameIndex < 0 || !Number.isInteger(e.targetFrameIndex) || e.targetFrameIndex < 0) {
      errors.push(`Entry '${e.pairId}' has negative or non-integer frame index.`);
    }
    for (const h of [e.sourceSha256.toLowerCase(), e.targetSha256.toLowerCase()]) {
      if (!hashSplits.has(h)) hashSplits.set(h, /* @__PURE__ */ new Set());
      hashSplits.get(h).add(e.split);
    }
    if (!recordingSplits.has(e.recordingId)) recordingSplits.set(e.recordingId, /* @__PURE__ */ new Set());
    recordingSplits.get(e.recordingId).add(e.split);
    if (!recordingFramesBySplit.has(e.recordingId)) recordingFramesBySplit.set(e.recordingId, /* @__PURE__ */ new Map());
    const splitMap = recordingFramesBySplit.get(e.recordingId);
    if (!splitMap.has(e.split)) splitMap.set(e.split, []);
    splitMap.get(e.split).push(e.sourceFrameIndex);
    if (!sceneSplits.has(e.sceneGroupId)) sceneSplits.set(e.sceneGroupId, /* @__PURE__ */ new Set());
    sceneSplits.get(e.sceneGroupId).add(e.split);
  }
  for (const [h, splits] of hashSplits.entries()) {
    if (splits.size > 1) {
      errors.push(
        `Content SHA-256 '${h.slice(0, 16)}...' is assigned to multiple splits (${Array.from(splits).join(", ")}). Exact content hash leakage is forbidden.`
      );
    }
  }
  for (const [sceneId, splits] of sceneSplits.entries()) {
    if (splits.size > 1) {
      errors.push(
        `Scene group '${sceneId}' appears in multiple splits (${Array.from(splits).join(", ")}). Disjoint scene groups are required.`
      );
    }
  }
  let exploratoryTimeBlockOnly = false;
  const minGap = manifest.minTemporalGapFrames ?? 25;
  for (const [recId, splits] of recordingSplits.entries()) {
    if (splits.size > 1) {
      if (!manifest.allowExploratoryTimeBlockSplit) {
        errors.push(
          `Recording '${recId}' appears across multiple splits (${Array.from(splits).join(", ")}). Separate recordings are required unless allowExploratoryTimeBlockSplit=true is explicitly set with a >=25-frame temporal buffer.`
        );
      } else {
        exploratoryTimeBlockOnly = true;
        warnings.push(
          `Recording '${recId}' is shared across splits via time-blocks: results are exploratory time-block estimates only and do not establish cross-recording generalization.`
        );
        const splitMap = recordingFramesBySplit.get(recId);
        const splitEntries = Array.from(splitMap.entries());
        for (let i = 0; i < splitEntries.length; i++) {
          for (let j = i + 1; j < splitEntries.length; j++) {
            const [sA, framesA] = splitEntries[i];
            const [sB, framesB] = splitEntries[j];
            for (const fA of framesA) {
              for (const fB of framesB) {
                if (Math.abs(fA - fB) < minGap) {
                  errors.push(
                    `Temporal context leakage in recording '${recId}': frame ${fA} (${sA}) and frame ${fB} (${sB}) are closer than the required ${minGap}-frame buffer (needed to prevent multi-frame context overlap such as Claude B's 12-frame window).`
                  );
                }
              }
            }
          }
        }
      }
    }
  }
  if (trainCount === 0) errors.push("Dataset must contain at least one 'train' pair.");
  if (validationCount === 0) errors.push("Dataset must contain at least one 'validation' pair.");
  warnings.push(
    "Scientific limitation: code validation confirms hash, dimension and split-rule compliance, but cannot independently prove that two distinct file hashes come from different physical cameras/scenes or that a user-supplied target is radiometrically calibrated."
  );
  return {
    valid: errors.length === 0,
    errors,
    warnings,
    summary: {
      trainCount,
      validationCount,
      finalTestCount,
      uniqueRecordings: recordingSplits.size,
      exploratoryTimeBlockOnly
    }
  };
}
function verifyAndDecodeCuratedPair(entry, sourceBytes, targetBytes) {
  const actualSourceHash = sha256Bytes(sourceBytes);
  if (actualSourceHash.toLowerCase() !== entry.sourceSha256.toLowerCase()) {
    throw new Error(
      `Source file SHA-256 mismatch for pair '${entry.pairId}': expected ${entry.sourceSha256}, got ${actualSourceHash}.`
    );
  }
  const actualTargetHash = sha256Bytes(targetBytes);
  if (actualTargetHash.toLowerCase() !== entry.targetSha256.toLowerCase()) {
    throw new Error(
      `Target file SHA-256 mismatch for pair '${entry.pairId}': expected ${entry.targetSha256}, got ${actualTargetHash}.`
    );
  }
  const fb = frameBytes(entry.decoder);
  const srcCounts = frameCountFor(sourceBytes.byteLength, entry.decoder);
  const tgtCounts = frameCountFor(targetBytes.byteLength, entry.decoder);
  if (srcCounts.frames < 1 || entry.sourceFrameIndex >= srcCounts.frames) {
    throw new Error(`Invalid source frame index ${entry.sourceFrameIndex} for pair '${entry.pairId}' (frames: ${srcCounts.frames}).`);
  }
  if (tgtCounts.frames < 1 || entry.targetFrameIndex >= tgtCounts.frames) {
    throw new Error(`Invalid target frame index ${entry.targetFrameIndex} for pair '${entry.pairId}' (frames: ${tgtCounts.frames}).`);
  }
  const srcStart = entry.decoder.headerBytes + entry.sourceFrameIndex * fb;
  const tgtStart = entry.decoder.headerBytes + entry.targetFrameIndex * fb;
  const srcSlice = sourceBytes.slice(srcStart, srcStart + fb);
  const tgtSlice = targetBytes.slice(tgtStart, tgtStart + fb);
  const noisy14 = decodeBuffer(srcSlice.buffer, entry.decoder);
  const clean14 = decodeBuffer(tgtSlice.buffer, entry.decoder);
  return {
    pairId: entry.pairId,
    split: entry.split,
    recordingId: entry.recordingId,
    sceneGroupId: entry.sceneGroupId,
    scenarioTag: entry.scenarioTag,
    synthetic: entry.synthetic,
    width: entry.decoder.width,
    height: entry.decoder.height,
    noisy14,
    clean14,
    sourceSha256: actualSourceHash,
    targetSha256: actualTargetHash
  };
}
function encodeUint16LeBytes(arr) {
  const buf = new ArrayBuffer(arr.length * 2);
  const dv = new DataView(buf);
  for (let i = 0; i < arr.length; i++) {
    dv.setUint16(i * 2, arr[i] & 16383, true);
  }
  return new Uint8Array(buf);
}
function generateSyntheticPair(params) {
  const { pairId, split, recordingId, sceneGroupId, scenarioTag, sceneSeed, width: W, height: H } = params;
  const rng = mulberry32(sceneSeed);
  const N = W * H;
  const clean14 = new Uint16Array(N);
  const noisy14 = new Uint16Array(N);
  const wireMask = new Uint8Array(N);
  const pointMask = new Uint8Array(N);
  const horizonY = Math.floor(H * (0.28 + 0.22 * rng()));
  const baseSky = 6100 + Math.round((rng() - 0.5) * 240);
  const baseGround = 6420 + Math.round((rng() - 0.5) * 260);
  const bridgeY = Math.floor(H * (0.44 + 0.14 * rng()));
  const bridgeHalfH = Math.max(2, Math.floor(H * 0.03));
  const bridgeDelta = 260 + Math.round(rng() * 90);
  const targetX = Math.floor(W * (0.22 + 0.55 * rng()));
  const targetY = Math.floor(H * (0.62 + 0.22 * rng()));
  const rx = Math.max(3, Math.floor(W * 0.055));
  const ry = Math.max(2, Math.floor(H * 0.04));
  const targetDelta = 310 + Math.round(rng() * 110);
  const mastX = Math.floor(W * (0.72 + 0.15 * rng()));
  const wireY = Math.floor(H * (0.2 + 0.12 * rng()));
  const includeWire = scenarioTag === "thin_wire_and_mast" || scenarioTag === "mixed_stripes_and_targets";
  for (let y = 0; y < H; y++) {
    const isSky = y < horizonY;
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      let v = isSky ? baseSky + Math.sin(x * 0.05 + sceneSeed) * 28 + y / Math.max(1, horizonY) * 45 : baseGround + Math.cos(x * 0.07 + sceneSeed * 0.5) * 55 + Math.sin((y - horizonY) * 0.11) * 48;
      if (Math.abs(y - bridgeY) <= bridgeHalfH) {
        v += bridgeDelta;
      }
      const dx = (x - targetX) / rx;
      const dy = (y - targetY) / ry;
      if (dx * dx + dy * dy <= 1) {
        v += targetDelta * (1 - 0.25 * (dx * dx + dy * dy));
      }
      if (includeWire) {
        if (x === mastX && y >= Math.floor(H * 0.15) && y <= Math.floor(H * 0.85)) {
          v += 320;
          wireMask[idx] = 1;
        }
        if (y === wireY && x >= Math.floor(W * 0.12) && x <= Math.floor(W * 0.88)) {
          v += 260;
          wireMask[idx] = 1;
        }
      }
      if (scenarioTag === "small_point_targets") {
        const py = Math.floor(H * 0.24);
        const p1x = Math.floor(W * 0.25);
        const p2x = Math.floor(W * 0.55);
        if (y === py && x === p1x) {
          v += 480;
          pointMask[idx] = 1;
        }
        if (Math.abs(y - py) <= 1 && Math.abs(x - p2x) <= 1) {
          v += 420;
          pointMask[idx] = 1;
        }
      }
      clean14[idx] = Math.max(0, Math.min(16383, Math.round(v)));
    }
  }
  const colStripe = new Float32Array(W);
  const rowStripe = new Float32Array(H);
  if (scenarioTag !== "no_stripe_clean_hard_negative") {
    const altAmp = scenarioTag === "strong_alternating_stripes" ? 95 : 42;
    for (let x = 0; x < W; x++) {
      const alt = (x % 2 === 0 ? 1 : -1) * altAmp;
      const randCol = (rng() - 0.5) * 56;
      colStripe[x] = alt + randCol;
    }
    for (let y = 0; y < H; y++) {
      const altR = (y % 3 === 0 ? 1 : -0.5) * (scenarioTag === "strong_alternating_stripes" ? 45 : 24);
      const randRow = (rng() - 0.5) * 32;
      rowStripe[y] = altR + randRow;
    }
    let cMean = 0;
    for (let x = 0; x < W; x++) cMean += colStripe[x];
    cMean /= W;
    for (let x = 0; x < W; x++) colStripe[x] -= cMean;
    let rMean = 0;
    for (let y = 0; y < H; y++) rMean += rowStripe[y];
    rMean /= H;
    for (let y = 0; y < H; y++) rowStripe[y] -= rMean;
  }
  const readNoiseAmp = scenarioTag === "no_stripe_clean_hard_negative" ? 2.5 : 8;
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const n = (rng() + rng() - 1) * readNoiseAmp;
      const corrupted = clean14[idx] + colStripe[x] + rowStripe[y] + n;
      noisy14[idx] = Math.max(0, Math.min(16383, Math.round(corrupted)));
    }
  }
  const sourceSha256 = sha256Bytes(encodeUint16LeBytes(noisy14));
  const targetSha256 = sha256Bytes(encodeUint16LeBytes(clean14));
  return {
    pairId,
    split,
    recordingId,
    sceneGroupId,
    scenarioTag,
    synthetic: true,
    width: W,
    height: H,
    noisy14,
    clean14,
    sourceSha256,
    targetSha256,
    wireMask,
    pointMask
  };
}
function buildSyntheticDataset(params) {
  const version = params?.version ?? 1;
  const width = params?.width ?? 64;
  const height = params?.height ?? 64;
  const specs = [
    // Train split: seeds 101..106, distinct recording group synth_rec_train_*
    {
      pairId: "synth_train_01",
      split: "train",
      recordingId: "synth_rec_train_A",
      sceneGroupId: "scene_train_A1",
      scenarioTag: "mixed_stripes_and_targets",
      sceneSeed: 101
    },
    {
      pairId: "synth_train_02",
      split: "train",
      recordingId: "synth_rec_train_A",
      sceneGroupId: "scene_train_A2",
      scenarioTag: "strong_alternating_stripes",
      sceneSeed: 102
    },
    {
      pairId: "synth_train_03",
      split: "train",
      recordingId: "synth_rec_train_B",
      sceneGroupId: "scene_train_B1",
      scenarioTag: "thin_wire_and_mast",
      sceneSeed: 103
    },
    {
      pairId: "synth_train_04",
      split: "train",
      recordingId: "synth_rec_train_B",
      sceneGroupId: "scene_train_B2",
      scenarioTag: "no_stripe_clean_hard_negative",
      sceneSeed: 104
    },
    // Validation split: seeds 201..204, strictly disjoint recording group synth_rec_val_*
    {
      pairId: "synth_val_01",
      split: "validation",
      recordingId: "synth_rec_val_A",
      sceneGroupId: "scene_val_A1",
      scenarioTag: "mixed_stripes_and_targets",
      sceneSeed: 201
    },
    {
      pairId: "synth_val_02",
      split: "validation",
      recordingId: "synth_rec_val_A",
      sceneGroupId: "scene_val_A2",
      scenarioTag: "strong_alternating_stripes",
      sceneSeed: 202
    },
    {
      pairId: "synth_val_03",
      split: "validation",
      recordingId: "synth_rec_val_B",
      sceneGroupId: "scene_val_B1",
      scenarioTag: "thin_wire_and_mast",
      sceneSeed: 203
    },
    {
      pairId: "synth_val_04",
      split: "validation",
      recordingId: "synth_rec_val_B",
      sceneGroupId: "scene_val_B2",
      scenarioTag: "no_stripe_clean_hard_negative",
      sceneSeed: 204
    },
    // Untouched Final Test split: seeds 901..903, strictly disjoint recording group synth_rec_test_*
    {
      pairId: "synth_test_01",
      split: "final_test",
      recordingId: "synth_rec_test_A",
      sceneGroupId: "scene_test_A1",
      scenarioTag: "mixed_stripes_and_targets",
      sceneSeed: 901
    },
    {
      pairId: "synth_test_02",
      split: "final_test",
      recordingId: "synth_rec_test_A",
      sceneGroupId: "scene_test_A2",
      scenarioTag: "thin_wire_and_mast",
      sceneSeed: 902
    },
    {
      pairId: "synth_test_03",
      split: "final_test",
      recordingId: "synth_rec_test_B",
      sceneGroupId: "scene_test_B1",
      scenarioTag: "no_stripe_clean_hard_negative",
      sceneSeed: 903
    }
  ];
  if (version === 2) {
    specs.push(
      {
        pairId: "synth_train_05_v2",
        split: "train",
        recordingId: "synth_rec_train_C",
        sceneGroupId: "scene_train_C1",
        scenarioTag: "small_point_targets",
        sceneSeed: 105
      },
      {
        pairId: "synth_train_06_v2",
        split: "train",
        recordingId: "synth_rec_train_C",
        sceneGroupId: "scene_train_C2",
        scenarioTag: "thin_wire_and_mast",
        sceneSeed: 106
      },
      {
        pairId: "synth_train_07_v2",
        split: "train",
        recordingId: "synth_rec_train_C",
        sceneGroupId: "scene_train_C3",
        scenarioTag: "no_stripe_clean_hard_negative",
        sceneSeed: 107
      }
    );
  }
  const pairs = specs.map(
    (s) => generateSyntheticPair({
      ...s,
      width,
      height
    })
  );
  const decoder = {
    width,
    height,
    headerBytes: 0,
    littleEndian: true,
    bits: 14,
    shift: 0
  };
  const manifest = {
    schema: "clearhot-dataset-manifest-v1",
    datasetId: `clearhot-synthetic-known-clean-v${version}`,
    version,
    createdAt: "2026-11-14T00:00:00.000Z",
    synthetic: true,
    description: `Deterministic synthetic 14-bit thermal dataset v${version} with known clean targets, column/row FPN, thin wires, and stripe-free hard negatives.`,
    humanAttestation: {
      attestedBy: "ClearHot Synthetic Generator (automated deterministic fixture)",
      attestedAt: "2026-11-14T00:00:00.000Z",
      targetProvenanceDescription: "SYNTHETIC ONLY: Known clean 14-bit mathematical scene rendered prior to adding deterministic column/row fixed-pattern stripes and sensor read noise.",
      targetType: "synthetic_known_clean",
      alignmentVerified: true,
      notAdjacentFrameNoise2Noise: true,
      notModelPredictionOrBlur: true,
      countDomainConfirmed14Bit: true
    },
    entries: pairs.map((p) => ({
      pairId: p.pairId,
      split: p.split,
      recordingId: p.recordingId,
      sceneGroupId: p.sceneGroupId,
      deviceOrConditionId: "synthetic_simulator_14bit",
      scenarioTag: p.scenarioTag,
      synthetic: true,
      sourceFile: `${p.pairId}_noisy.raw`,
      sourceSha256: p.sourceSha256,
      sourceFrameIndex: 0,
      targetFile: `${p.pairId}_clean.raw`,
      targetSha256: p.targetSha256,
      targetFrameIndex: 0,
      decoder,
      notes: "Synthetic known-clean fixture; does not represent real sensor generalisation."
    })),
    limitationsNote: "SYNTHETIC DATASET ONLY: Training or validation gains on these generated fixtures demonstrate functional pipeline mechanics and do not prove improvement on the user's ~180 MB real recording."
  };
  const validation = validateDatasetManifest(manifest);
  return { manifest, pairs, validation };
}

// src/cnn/evaluator.ts
var DEFAULT_SAFETY_THRESHOLDS = {
  minPsnrDeltaVsBaselineDb: 0.1,
  maxStripeRmsRatioVsBaseline: 1,
  maxNoStripeFalseCorrectionRmsAdu: 8,
  minThinFeatureRetention: 0.72,
  maxThinFeatureOversharpen: 1.35,
  maxHaloOvershootAdu: 18,
  maxClippingIncreaseFrac: 0.01,
  isTestOnlyThresholdOverride: false
};
function computeArgos2Stage1Clean14(raw14, W, H) {
  const cfg = { ...DEFAULT_ISP_CONFIGS.instance2, enableLiveCnnResidual: false };
  const res = runThermalInstancePipeline({
    methodology: "instance2",
    raw14,
    W,
    H,
    cfg,
    cnnState: createInitialCnnState("instance2"),
    prevBlackRef: { current: 7100 },
    prevWhiteRef: { current: 7950 },
    lastFrameKeyRef: { current: "" },
    prevNormFrameRef: { current: null },
    prevKalman14Ref: { current: null },
    frameKey: "0"
  });
  return {
    stage1Clean14: res.stage1Clean14,
    nativeProcessed8: res.processed8
  };
}
function map14BitToFixedWindow8(buf14, lo, hi) {
  const fn = toneFn({ lo, hi, gamma: 1, knee: 1 });
  const out = new Uint8Array(buf14.length);
  for (let i = 0; i < buf14.length; i++) out[i] = fn(buf14[i]);
  return out;
}
function map14BitThroughArgos2NativeStages(restored14, W, H) {
  const u16 = new Uint16Array(restored14.length);
  for (let i = 0; i < restored14.length; i++) {
    u16[i] = Math.max(0, Math.min(16383, Math.round(restored14[i])));
  }
  const cfg = {
    ...DEFAULT_ISP_CONFIGS.instance2,
    stage1DestripeAndBadPx: false,
    enableLiveCnnResidual: false
  };
  const res = runThermalInstancePipeline({
    methodology: "instance2",
    raw14: u16,
    W,
    H,
    cfg,
    cnnState: createInitialCnnState("instance2"),
    prevBlackRef: { current: 7100 },
    prevWhiteRef: { current: 7950 },
    lastFrameKeyRef: { current: "" },
    prevNormFrameRef: { current: null },
    prevKalman14Ref: { current: null },
    frameKey: "0"
  });
  return new Uint8Array(res.processed8);
}
function computePsnr14Bit(pred14, clean14) {
  const n = pred14.length;
  if (n === 0) return 0;
  let mse = 0;
  for (let i = 0; i < n; i++) {
    const d = pred14[i] - clean14[i];
    mse += d * d;
  }
  mse /= n;
  if (mse < 1e-9) return 99;
  return 10 * Math.log10(16383 * 16383 / mse);
}
function computeSsim14Bit(pred14, clean14, W, H) {
  const n = W * H;
  if (n === 0) return 1;
  let meanX = 0, meanY = 0;
  for (let i = 0; i < n; i++) {
    meanX += pred14[i];
    meanY += clean14[i];
  }
  meanX /= n;
  meanY /= n;
  let varX = 0, varY = 0, covXY = 0;
  for (let i = 0; i < n; i++) {
    const dx = pred14[i] - meanX;
    const dy = clean14[i] - meanY;
    varX += dx * dx;
    varY += dy * dy;
    covXY += dx * dy;
  }
  varX /= n;
  varY /= n;
  covXY /= n;
  const L = 2048;
  const c1 = (0.01 * L) ** 2;
  const c2 = (0.03 * L) ** 2;
  return (2 * meanX * meanY + c1) * (2 * covXY + c2) / ((meanX ** 2 + meanY ** 2 + c1) * (varX + varY + c2));
}
function computeFlatStripeRmsAdu(buf14, W, H) {
  const y0 = 2;
  const y1 = Math.max(y0 + 4, Math.floor(H * 0.24));
  const x0 = Math.floor(W * 0.15);
  const x1 = Math.max(x0 + 6, Math.floor(W * 0.65));
  const colMeans = [];
  for (let x = x0; x < x1; x++) {
    let s = 0;
    for (let y = y0; y < y1; y++) s += buf14[y * W + x];
    colMeans.push(s / (y1 - y0));
  }
  let colSq = 0;
  for (let i = 1; i < colMeans.length - 1; i++) {
    const hp = colMeans[i] - 0.5 * (colMeans[i - 1] + colMeans[i + 1]);
    colSq += hp * hp;
  }
  const colRms = Math.sqrt(colSq / Math.max(1, colMeans.length - 2));
  const rowMeans = [];
  for (let y = y0; y < y1; y++) {
    let s = 0;
    for (let x = x0; x < x1; x++) s += buf14[y * W + x];
    rowMeans.push(s / (x1 - x0));
  }
  let rowSq = 0;
  for (let i = 1; i < rowMeans.length - 1; i++) {
    const hp = rowMeans[i] - 0.5 * (rowMeans[i - 1] + rowMeans[i + 1]);
    rowSq += hp * hp;
  }
  const rowRms = Math.sqrt(rowSq / Math.max(1, rowMeans.length - 2));
  return { colRms, rowRms };
}
function computeThinFeatureRetention(pred14, clean14, wireMask, W, H) {
  if (!wireMask) return null;
  let cleanContrastSum = 0;
  let predContrastSum = 0;
  let count = 0;
  for (let y = 2; y < H - 2; y++) {
    for (let x = 2; x < W - 2; x++) {
      const idx = y * W + x;
      if (wireMask[idx] !== 1) continue;
      const bgClean = 0.25 * (clean14[idx - 2] + clean14[idx + 2] + clean14[idx - 2 * W] + clean14[idx + 2 * W]);
      const bgPred = 0.25 * (pred14[idx - 2] + pred14[idx + 2] + pred14[idx - 2 * W] + pred14[idx + 2 * W]);
      const cDiff = Math.abs(clean14[idx] - bgClean);
      if (cDiff > 40) {
        cleanContrastSum += cDiff;
        predContrastSum += Math.abs(pred14[idx] - bgPred);
        count++;
      }
    }
  }
  if (count === 0 || cleanContrastSum < 1e-3) return null;
  return predContrastSum / cleanContrastSum;
}
function computeHaloOvershootAdu(pred14, clean14, W, H) {
  let overshootSq = 0;
  let cnt = 0;
  const noiseAllowance = 16;
  for (let y = 2; y < H - 2; y++) {
    for (let x = 2; x < W - 2; x++) {
      const idx = y * W + x;
      const gClean = Math.abs(clean14[idx + 1] - clean14[idx - 1]) + Math.abs(clean14[idx + W] - clean14[idx - W]);
      if (gClean > 140) {
        let cMin = Infinity, cMax = -Infinity;
        for (let dy = -2; dy <= 2; dy++) {
          for (let dx = -2; dx <= 2; dx++) {
            const cv = clean14[(y + dy) * W + (x + dx)];
            if (cv < cMin) cMin = cv;
            if (cv > cMax) cMax = cv;
          }
        }
        const pv = pred14[idx];
        const over = pv > cMax + noiseAllowance ? pv - (cMax + noiseAllowance) : pv < cMin - noiseAllowance ? cMin - noiseAllowance - pv : 0;
        overshootSq += over * over;
        cnt++;
      }
    }
  }
  return cnt > 0 ? Math.sqrt(overshootSq / cnt) : 0;
}
function trainCnnCandidate(params) {
  const validation = validateDatasetManifest(params.manifest);
  if (!validation.valid) {
    throw new Error(`Dataset validation failed; refusing to train:
- ${validation.errors.join("\n- ")}`);
  }
  const hp = { ...DEFAULT_CNN_HYPERPARAMS, ...params.hyperParams || {} };
  const seed = params.seed ?? 1337;
  const steps = params.steps ?? 28;
  const trainPairs = params.pairs.filter((p) => p.split === "train");
  const valPairs = params.pairs.filter((p) => p.split === "validation");
  if (trainPairs.length === 0 || valPairs.length === 0) {
    throw new Error("Both train and validation pairs must be provided in memory.");
  }
  const prepareInput = (p) => {
    if (hp.insertionMode === "post_stage1_14bit") {
      return computeArgos2Stage1Clean14(p.noisy14, p.width, p.height).stage1Clean14;
    }
    return Float32Array.from(p.noisy14);
  };
  const trainInputs = trainPairs.map(prepareInput);
  const valInputs = valPairs.map(prepareInput);
  const weights = params.initialWeights ? deserializeParameters(params.initialWeights) : createInitialParameters(seed, hp);
  const initialSnapshot = deserializeParameters(serializeParameters(weights));
  const initialWeightsSha256 = computeWeightsSha256(weights);
  const opt = createAdamState(weights);
  const stepHistory = [];
  for (let s = 1; s <= steps; s++) {
    let trainLossSum = 0;
    let accumGrads = null;
    for (let i = 0; i < trainPairs.length; i++) {
      const p = trainPairs[i];
      const targetForCnn = p.scenarioTag === "no_stripe_clean_hard_negative" ? trainInputs[i] : p.clean14;
      const fb = forwardAndBackward(trainInputs[i], targetForCnn, p.width, p.height, weights, hp);
      trainLossSum += fb.loss ?? 0;
      if (!accumGrads) {
        accumGrads = fb.grads;
      } else {
        for (const k of Object.keys(accumGrads)) {
          const dst = accumGrads[k];
          const src = fb.grads[k];
          for (let j = 0; j < dst.length; j++) dst[j] += src[j];
        }
      }
    }
    for (const k of Object.keys(accumGrads)) {
      const dst = accumGrads[k];
      for (let j = 0; j < dst.length; j++) dst[j] /= trainPairs.length;
    }
    const { gradNorm, weightsDeltaL2 } = applyAdamStep(weights, accumGrads, opt, hp);
    const finite = allParametersFinite(weights);
    if (!finite) {
      throw new Error(`Training failed at step ${s}: non-finite parameter detected.`);
    }
    let valLossSum = 0;
    for (let i = 0; i < valPairs.length; i++) {
      const p = valPairs[i];
      const targetForCnn = p.scenarioTag === "no_stripe_clean_hard_negative" ? valInputs[i] : p.clean14;
      const fb = forwardAndBackward(valInputs[i], targetForCnn, p.width, p.height, weights, hp);
      valLossSum += fb.loss ?? 0;
    }
    stepHistory.push({
      step: s,
      trainLoss: Number((trainLossSum / trainPairs.length).toFixed(6)),
      valLoss: Number((valLossSum / valPairs.length).toFixed(6)),
      gradNorm: Number(gradNorm.toFixed(6)),
      weightsDeltaL2: Number(weightsDeltaL2.toFixed(6)),
      allFinite: finite
    });
  }
  const totalWeightUpdateL2 = Number(parameterL2Distance(initialSnapshot, weights).toFixed(6));
  const weightsSha256 = computeWeightsSha256(weights);
  return {
    schema: "clearhot-cnn-checkpoint-v1",
    checkpointId: params.checkpointId,
    cycleNumber: params.cycleNumber,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    isSimulatedDemo: params.manifest.synthetic,
    status: "candidate",
    architectureId: CNN_ARCHITECTURE_ID,
    architectureHash: computeArchitectureHash(hp),
    initialWeightsSha256,
    weightsSha256,
    parameterCount: countParameters(weights),
    seed,
    stepsRun: steps,
    totalWeightUpdateL2,
    hyperParams: hp,
    datasetSummary: {
      datasetId: params.manifest.datasetId,
      version: params.manifest.version,
      synthetic: params.manifest.synthetic,
      trainPairs: trainPairs.length,
      validationPairs: valPairs.length
    },
    environment: {
      runtime: typeof process !== "undefined" && process.version ? `Node.js ${process.version}` : "Browser JS",
      platform: typeof process !== "undefined" ? `${process.platform}/${process.arch}` : "browser-local",
      codeVersion: "1.2.0"
    },
    stepHistory,
    weights: serializeParameters(weights),
    optimizerState: opt,
    notes: params.notes
  };
}
function evaluateCnnCandidate(params) {
  const split = params.split ?? "validation";
  const splitPairs = params.pairs.filter((p) => p.split === split);
  if (splitPairs.length === 0) {
    throw new Error(`No pairs found for requested evaluation split '${split}'.`);
  }
  const thresholds = params.thresholds ?? DEFAULT_SAFETY_THRESHOLDS;
  const candWeights = deserializeParameters(params.candidate.weights);
  const activeWeights = params.activeCheckpoint ? deserializeParameters(params.activeCheckpoint.weights) : null;
  const hp = params.candidate.hyperParams;
  const perScene = [];
  let allOutputsFinite = true;
  for (const p of splitPairs) {
    const W = p.width;
    const H = p.height;
    const N = W * H;
    const { stage1Clean14 } = computeArgos2Stage1Clean14(p.noisy14, W, H);
    const modelInput = hp.insertionMode === "post_stage1_14bit" ? stage1Clean14 : Float32Array.from(p.noisy14);
    const candOut = inferCnn14(modelInput, W, H, candWeights, hp, false);
    for (let i = 0; i < N; i++) {
      if (!Number.isFinite(candOut.restored14[i])) allOutputsFinite = false;
    }
    const activeOut = activeWeights ? inferCnn14(modelInput, W, H, activeWeights, params.activeCheckpoint.hyperParams, false) : null;
    const rawPsnr = computePsnr14Bit(p.noisy14, p.clean14);
    const basePsnr = computePsnr14Bit(stage1Clean14, p.clean14);
    const candPsnr = computePsnr14Bit(candOut.restored14, p.clean14);
    const activePsnr = activeOut ? computePsnr14Bit(activeOut.restored14, p.clean14) : null;
    const candSsim = computeSsim14Bit(candOut.restored14, p.clean14, W, H);
    const rawStripes = computeFlatStripeRmsAdu(p.noisy14, W, H);
    const baseStripes = computeFlatStripeRmsAdu(stage1Clean14, W, H);
    const candStripes = computeFlatStripeRmsAdu(candOut.restored14, W, H);
    const thinRet = computeThinFeatureRetention(candOut.restored14, p.clean14, p.wireMask, W, H);
    const haloAdu = computeHaloOvershootAdu(candOut.restored14, p.clean14, W, H);
    let baseClips = 0;
    let candClips = 0;
    for (let i = 0; i < N; i++) {
      if (stage1Clean14[i] <= 0 || stage1Clean14[i] >= 16383) baseClips++;
      if (candOut.restored14[i] <= 0 || candOut.restored14[i] >= 16383) candClips++;
    }
    const clipDeltaFrac = Math.max(0, (candClips - baseClips) / N);
    perScene.push({
      pairId: p.pairId,
      scenarioTag: p.scenarioTag,
      synthetic: p.synthetic,
      rawPsnr14Db: Number(rawPsnr.toFixed(3)),
      baselineArgos2Stage1Psnr14Db: Number(basePsnr.toFixed(3)),
      activeCnnPsnr14Db: activePsnr !== null ? Number(activePsnr.toFixed(3)) : null,
      candidateCnnPsnr14Db: Number(candPsnr.toFixed(3)),
      candidateSsim14: Number(candSsim.toFixed(4)),
      rawColStripeRmsAdu: Number(rawStripes.colRms.toFixed(2)),
      baselineColStripeRmsAdu: Number(baseStripes.colRms.toFixed(2)),
      candidateColStripeRmsAdu: Number(candStripes.colRms.toFixed(2)),
      rawRowStripeRmsAdu: Number(rawStripes.rowRms.toFixed(2)),
      baselineRowStripeRmsAdu: Number(baseStripes.rowRms.toFixed(2)),
      candidateRowStripeRmsAdu: Number(candStripes.rowRms.toFixed(2)),
      thinFeatureRetention: thinRet !== null ? Number(thinRet.toFixed(3)) : null,
      haloOvershootAdu: Number(haloAdu.toFixed(2)),
      clipDeltaFrac: Number(clipDeltaFrac.toFixed(5))
    });
  }
  const mean = (arr) => arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
  const meanRawPsnr = mean(perScene.map((s) => s.rawPsnr14Db ?? 0));
  const meanBasePsnr = mean(perScene.map((s) => s.baselineArgos2Stage1Psnr14Db ?? 0));
  const meanCandPsnr = mean(perScene.map((s) => s.candidateCnnPsnr14Db ?? 0));
  const meanActivePsnr = activeWeights ? mean(perScene.map((s) => s.activeCnnPsnr14Db ?? 0)) : null;
  const meanCandSsim = mean(perScene.map((s) => s.candidateSsim14 ?? 0));
  const stripedScenes = perScene.filter((s) => s.scenarioTag !== "no_stripe_clean_hard_negative");
  const meanRawStripe = mean(
    stripedScenes.map((s) => Math.hypot(s.rawColStripeRmsAdu, s.rawRowStripeRmsAdu))
  );
  const meanBaseStripe = mean(
    stripedScenes.map((s) => Math.hypot(s.baselineColStripeRmsAdu, s.baselineRowStripeRmsAdu))
  );
  const meanCandStripe = mean(
    stripedScenes.map((s) => Math.hypot(s.candidateColStripeRmsAdu, s.candidateRowStripeRmsAdu))
  );
  const noStripePairs = splitPairs.filter((p) => p.scenarioTag === "no_stripe_clean_hard_negative");
  let noStripeRms = 0;
  if (noStripePairs.length > 0) {
    let sq = 0;
    let cnt = 0;
    for (const p of noStripePairs) {
      const { stage1Clean14 } = computeArgos2Stage1Clean14(p.noisy14, p.width, p.height);
      const modelIn = hp.insertionMode === "post_stage1_14bit" ? stage1Clean14 : Float32Array.from(p.noisy14);
      const candOut = inferCnn14(modelIn, p.width, p.height, candWeights, hp, false);
      for (let i = 0; i < modelIn.length; i++) {
        const d = candOut.restored14[i] - modelIn[i];
        sq += d * d;
        cnt++;
      }
    }
    noStripeRms = Math.sqrt(sq / Math.max(1, cnt));
  }
  const thinValues = perScene.map((s) => s.thinFeatureRetention).filter((v) => v !== null);
  const minThin = thinValues.length > 0 ? Math.min(...thinValues) : 1;
  const maxThin = thinValues.length > 0 ? Math.max(...thinValues) : 1;
  const maxHalo = Math.max(...perScene.map((s) => s.haloOvershootAdu));
  const maxClipInc = Math.max(...perScene.map((s) => s.clipDeltaFrac));
  const psnrDeltaVsBaseline = meanCandPsnr - meanBasePsnr;
  const psnrDeltaVsActive = meanActivePsnr !== null ? meanCandPsnr - meanActivePsnr : null;
  const stripeRatio = meanBaseStripe > 1e-6 ? meanCandStripe / meanBaseStripe : 1;
  const gates = [
    {
      gateId: "finite_outputs_gate",
      description: "All restored 14-bit pixels and parameters must be finite",
      passed: allOutputsFinite && allParametersFinite(candWeights),
      measuredValue: allOutputsFinite ? 1 : 0,
      thresholdValue: "== 1 (true)",
      unit: "boolean"
    },
    {
      gateId: "psnr_gain_vs_baseline_gate",
      description: "Mean 14-bit PSNR (dB) must improve over frozen Argos 2 Stage 1 classical baseline",
      passed: psnrDeltaVsBaseline >= thresholds.minPsnrDeltaVsBaselineDb,
      measuredValue: Number(psnrDeltaVsBaseline.toFixed(3)),
      thresholdValue: `>= +${thresholds.minPsnrDeltaVsBaselineDb.toFixed(2)}`,
      unit: "dB (14-bit ADU)"
    },
    {
      gateId: "stripe_residual_reduction_gate",
      description: "Flat-region stripe residual RMS ratio vs classical baseline must not regress",
      passed: stripeRatio <= thresholds.maxStripeRmsRatioVsBaseline,
      measuredValue: Number(stripeRatio.toFixed(3)),
      thresholdValue: `<= ${thresholds.maxStripeRmsRatioVsBaseline.toFixed(2)}`,
      unit: "ratio"
    },
    {
      gateId: "no_stripe_false_correction_gate",
      description: "Clean stripe-free hard-negative scene must not suffer excessive false stripe subtraction",
      passed: noStripeRms <= thresholds.maxNoStripeFalseCorrectionRmsAdu,
      measuredValue: Number(noStripeRms.toFixed(2)),
      thresholdValue: `<= ${thresholds.maxNoStripeFalseCorrectionRmsAdu.toFixed(1)}`,
      unit: "ADU RMS"
    },
    {
      gateId: "thin_feature_retention_gate",
      description: "Individual 1-pixel vertical mast / horizontal wire retention must stay within safe bounds (not erased or artificially oversharpened)",
      passed: minThin >= thresholds.minThinFeatureRetention && maxThin <= thresholds.maxThinFeatureOversharpen,
      measuredValue: Number(minThin.toFixed(3)),
      thresholdValue: `[${thresholds.minThinFeatureRetention.toFixed(2)}, ${thresholds.maxThinFeatureOversharpen.toFixed(2)}]`,
      unit: "contrast ratio"
    },
    {
      gateId: "halo_overshoot_gate",
      description: "Step-edge halo overshoot RMS must stay bounded",
      passed: maxHalo <= thresholds.maxHaloOvershootAdu,
      measuredValue: Number(maxHalo.toFixed(2)),
      thresholdValue: `<= ${thresholds.maxHaloOvershootAdu.toFixed(1)}`,
      unit: "ADU RMS"
    },
    {
      gateId: "clipping_safety_gate",
      description: "0 / 16383 saturation clipping fraction increase vs baseline must stay <= 1%",
      passed: maxClipInc <= thresholds.maxClippingIncreaseFrac,
      measuredValue: Number(maxClipInc.toFixed(5)),
      thresholdValue: `<= ${thresholds.maxClippingIncreaseFrac}`,
      unit: "fraction"
    }
  ];
  const failedGates = gates.filter((g) => !g.passed).map((g) => g.gateId);
  return {
    schema: "clearhot-cnn-evaluation-v1",
    evaluatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    checkpointId: params.candidate.checkpointId,
    checkpointWeightsSha256: params.candidate.weightsSha256,
    comparedActiveCheckpointId: params.activeCheckpoint?.checkpointId ?? null,
    splitEvaluated: split,
    syntheticDataOnly: splitPairs.every((p) => p.synthetic),
    domainNote: "Quantitative PSNR, SSIM, stripe RMS and halo metrics are computed in the 14-bit sensor count (ADU, 0..16383) domain prior to display tone mapping so AGC differences do not distort error measurement.",
    sampleSize: splitPairs.length,
    thresholds,
    aggregate: {
      meanRawPsnr14Db: Number(meanRawPsnr.toFixed(3)),
      meanBaselineArgos2Stage1Psnr14Db: Number(meanBasePsnr.toFixed(3)),
      meanActiveCnnPsnr14Db: meanActivePsnr !== null ? Number(meanActivePsnr.toFixed(3)) : null,
      meanCandidateCnnPsnr14Db: Number(meanCandPsnr.toFixed(3)),
      psnrDeltaVsBaselineDb: Number(psnrDeltaVsBaseline.toFixed(3)),
      psnrDeltaVsActiveDb: psnrDeltaVsActive !== null ? Number(psnrDeltaVsActive.toFixed(3)) : null,
      meanCandidateSsim14: Number(meanCandSsim.toFixed(4)),
      meanRawStripeRmsAdu: Number(meanRawStripe.toFixed(2)),
      meanBaselineStripeRmsAdu: Number(meanBaseStripe.toFixed(2)),
      meanCandidateStripeRmsAdu: Number(meanCandStripe.toFixed(2)),
      noStripeFalseCorrectionRmsAdu: Number(noStripeRms.toFixed(2)),
      minThinFeatureRetention: Number(minThin.toFixed(3)),
      maxThinFeatureRetention: Number(maxThin.toFixed(3)),
      maxHaloOvershootAdu: Number(maxHalo.toFixed(2)),
      maxClipIncreaseFrac: Number(maxClipInc.toFixed(5))
    },
    gates,
    allMandatoryGatesPassed: failedGates.length === 0,
    failedGates,
    perScene,
    tradeoffsAndLimitations: [
      "Strong alternating column stripes (Nyquist period 2) are suppressed more effectively by the learned 1D profile branch than by Original Argos 2's default trimmed Haar shrinkage, which clips high-amplitude alternating differences.",
      "On clean stripe-free scenes, any non-zero residual represents slight false correction; the no_stripe_false_correction_gate bounds this below 8.0 ADU RMS.",
      "Passing synthetic gates proves software mechanics and regression protection; it does NOT prove improvement on the user's ~180 MB real recording without curated real-data validation and blinded human sequence review."
    ]
  };
}

// src/lab/hardNegativeBench.ts
function generateHardNegativeFixtures(W = 64, H = 64, baseSeed = 500) {
  const scenarioIds = [
    "no_stripe_false_correction",
    "alternating_strong_stripes",
    "true_full_height_wire",
    "small_point_targets",
    "textured_ground_occlusion",
    "motion_sequence_ghosting",
    "fpn_plus_read_noise",
    "similar_brightness_animal_bridge"
  ];
  return scenarioIds.map((scenarioId, idx) => {
    const rng = mulberry32(baseSeed + idx * 31);
    const N = W * H;
    const clean14 = new Uint16Array(N);
    const noisy14 = new Uint16Array(N);
    let prevNoisy14;
    const horizonY = Math.floor(H * 0.36);
    const mastCol = scenarioId === "true_full_height_wire" ? Math.floor(W * 0.72) : null;
    const wireRow = scenarioId === "true_full_height_wire" ? Math.floor(H * 0.25) : null;
    const pointCoords = [];
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const i = y * W + x;
        let v = y < horizonY ? 6100 + Math.sin(x * 0.06) * 25 + y / Math.max(1, horizonY) * 40 : 6420 + Math.cos(x * 0.08) * 45 + Math.sin((y - horizonY) * 0.1) * 50;
        if (scenarioId === "textured_ground_occlusion" && y >= horizonY) {
          v += Math.sin(x * 0.45) * Math.cos(y * 0.45) * 65 + (x * 17 ^ y * 29) % 23 * 2.5;
          if (x >= Math.floor(W * 0.45) && x <= Math.floor(W * 0.52) && y >= Math.floor(H * 0.45)) {
            v -= 160;
          }
        }
        if (mastCol !== null && x === mastCol) {
          v += 320;
        }
        if (wireRow !== null && y === wireRow) {
          v += 260;
        }
        const tx = Math.floor(W * 0.36);
        const ty = Math.floor(H * 0.68);
        const rx = Math.max(3, Math.floor(W * 0.07));
        const ry = Math.max(2, Math.floor(H * 0.05));
        const distSq = ((x - tx) / rx) ** 2 + ((y - ty) / ry) ** 2;
        if (distSq <= 1) {
          v += 280;
        }
        if (scenarioId === "similar_brightness_animal_bridge") {
          const bY0 = Math.floor(H * 0.48), bY1 = Math.floor(H * 0.56);
          const bX0 = Math.floor(W * 0.15), bX1 = Math.floor(W * 0.45);
          const aY0 = Math.floor(H * 0.62), aY1 = Math.floor(H * 0.72);
          const aX0 = Math.floor(W * 0.55), aX1 = Math.floor(W * 0.75);
          if (y >= bY0 && y < bY1 && x >= bX0 && x < bX1) v = 6780;
          if (y >= aY0 && y < aY1 && x >= aX0 && x < aX1) v = 6815;
        }
        clean14[i] = Math.max(0, Math.min(16383, Math.round(v)));
      }
    }
    if (scenarioId === "small_point_targets") {
      const p1 = { x: Math.floor(W * 0.25), y: Math.floor(H * 0.22) };
      const p2 = { x: Math.floor(W * 0.55), y: Math.floor(H * 0.22) };
      clean14[p1.y * W + p1.x] += 550;
      pointCoords.push(p1);
      for (let dy = 0; dy <= 1; dy++) {
        for (let dx = 0; dx <= 1; dx++) {
          clean14[(p2.y + dy) * W + (p2.x + dx)] += 500;
          pointCoords.push({ x: p2.x + dx, y: p2.y + dy });
        }
      }
    }
    for (let y = 0; y < H; y++) {
      const rStripe = scenarioId === "no_stripe_false_correction" ? 0 : scenarioId === "alternating_strong_stripes" ? (y % 2 === 0 ? 1 : -1) * 75 : Math.round(Math.sin(y * 0.9) * 22);
      for (let x = 0; x < W; x++) {
        const i = y * W + x;
        const cStripe = scenarioId === "no_stripe_false_correction" ? 0 : scenarioId === "alternating_strong_stripes" ? (x % 2 === 0 ? 1 : -1) * 150 : (x % 2 === 0 ? 1 : -1) * 32 + Math.round((rng() - 0.5) * 28);
        const noise = scenarioId === "no_stripe_false_correction" ? 0 : Math.round((rng() + rng() - 1) * (scenarioId === "fpn_plus_read_noise" ? 18 : 7));
        noisy14[i] = Math.max(0, Math.min(16383, clean14[i] + cStripe + rStripe + noise));
      }
    }
    if (scenarioId === "motion_sequence_ghosting") {
      prevNoisy14 = new Uint16Array(noisy14);
      const shiftX = Math.floor(W * 0.36) - 6;
      const ty = Math.floor(H * 0.68);
      for (let dy = -3; dy <= 3; dy++) {
        for (let dx = -4; dx <= 4; dx++) {
          const px = Math.max(0, Math.min(W - 1, shiftX + dx));
          const py = Math.max(0, Math.min(H - 1, ty + dy));
          prevNoisy14[py * W + px] = Math.min(16383, prevNoisy14[py * W + px] + 320);
        }
      }
    }
    const titles = {
      no_stripe_false_correction: [
        "1 \xB7 No-Stripe Clean Scene (False-Correction Test)",
        "Zero stripes or read noise injected. Tests whether line/CNN stages falsely remove real vertical/horizontal scene structure."
      ],
      alternating_strong_stripes: [
        "2 \xB7 Alternating Strong \xB1150 ADU Column Stripes",
        "High-amplitude Nyquist column stripes (\xB1150 ADU) + \xB175 ADU row stripes. Tests whether edge-gating or shrinkage thresholds fail on strong stripes."
      ],
      true_full_height_wire: [
        "3 \xB7 True Full-Height 1px Vertical Mast & Horizontal Wire",
        "Genuine 1-pixel vertical mast (100% height) and 1-pixel horizontal wire (100% width). Tests individual thin-feature erasure vs preservation."
      ],
      small_point_targets: [
        "4 \xB7 Small 1\xD71 & 2\xD72 Warm Point Targets",
        "Compact sub-resolved warm targets. Tests whether outlier/bad-pixel filters mistake 1\xD71 targets for dead/hot sensor spikes."
      ],
      textured_ground_occlusion: [
        "5 \xB7 Multi-Scale Ground Texture & Occlusion",
        "High-frequency ground clutter with a sharp vertical occluding pillar."
      ],
      motion_sequence_ghosting: [
        "6 \xB7 Moving Target Sequence (Motion / Ghosting Test)",
        "Target moves 6 pixels between consecutive frames. Tests whether temporal filtering leaves ghost trails."
      ],
      fpn_plus_read_noise: [
        "7 \xB7 Combined Fixed-Pattern Stripes + High Read Noise",
        "Mixed column/row FPN with elevated random temporal read noise."
      ],
      similar_brightness_animal_bridge: [
        "8 \xB7 Similar-Brightness Animal (+35 ADU) vs Bridge",
        "Animal (6815 ADU) and bridge (6780 ADU) separated by only 35 ADU across different background rows."
      ]
    };
    return {
      scenarioId,
      title: titles[scenarioId][0],
      description: titles[scenarioId][1],
      synthetic: true,
      width: W,
      height: H,
      clean14,
      noisy14,
      prevNoisy14,
      verticalMastCol: mastCol,
      horizontalWireRow: wireRow,
      pointTargetCoords: pointCoords,
      animalBridgeBoxes: scenarioId === "similar_brightness_animal_bridge" ? {
        bridge: {
          x: Math.floor(W * 0.15),
          y: Math.floor(H * 0.48),
          w: Math.floor(W * 0.3),
          h: Math.floor(H * 0.08)
        },
        animal: {
          x: Math.floor(W * 0.55),
          y: Math.floor(H * 0.62),
          w: Math.floor(W * 0.2),
          h: Math.floor(H * 0.1)
        }
      } : void 0
    };
  });
}
function measureSingleLineRetention(pred14, clean14, W, H, mode, index) {
  if (index === null) return null;
  let cleanContrast = 0;
  let predContrast = 0;
  if (mode === "vertical") {
    const xL = Math.max(0, index - 2);
    const xR = Math.min(W - 1, index + 2);
    for (let y = 4; y < H - 4; y++) {
      const cBg = 0.5 * (clean14[y * W + xL] + clean14[y * W + xR]);
      const pBg = 0.5 * (pred14[y * W + xL] + pred14[y * W + xR]);
      cleanContrast += Math.abs(clean14[y * W + index] - cBg);
      predContrast += Math.abs(pred14[y * W + index] - pBg);
    }
  } else {
    const yU = Math.max(0, index - 2);
    const yD = Math.min(H - 1, index + 2);
    for (let x = 4; x < W - 4; x++) {
      const cBg = 0.5 * (clean14[yU * W + x] + clean14[yD * W + x]);
      const pBg = 0.5 * (pred14[yU * W + x] + pred14[yD * W + x]);
      cleanContrast += Math.abs(clean14[index * W + x] - cBg);
      predContrast += Math.abs(pred14[index * W + x] - pBg);
    }
  }
  return cleanContrast > 1e-3 ? Number((predContrast / cleanContrast).toFixed(3)) : null;
}
function measurePointTargetRetention(pred14, clean14, W, H, coords) {
  if (!coords.length) return null;
  let cSum = 0;
  let pSum = 0;
  for (const pt of coords) {
    const idx = pt.y * W + pt.x;
    const bgIdx = Math.max(0, pt.y - 3) * W + pt.x;
    cSum += Math.max(1, clean14[idx] - clean14[bgIdx]);
    pSum += Math.max(0, pred14[idx] - pred14[bgIdx]);
  }
  return Number((pSum / Math.max(1, cSum)).toFixed(3));
}
async function runHardNegativeBenchmarkSuite(params) {
  const W = params?.width ?? 64;
  const H = params?.height ?? 64;
  const fixtures = generateHardNegativeFixtures(W, H, 500);
  const cnnCkpt = params?.cnnCheckpoint ?? null;
  const cnnWeights = cnnCkpt ? deserializeParameters(cnnCkpt.weights) : null;
  const methods = [
    {
      id: "raw",
      label: "Raw Identity (14-bit)",
      run14: async (f) => Float32Array.from(f.noisy14)
    },
    {
      id: "argos2",
      label: "Original Argos 2 (Stage 1 14-bit)",
      run14: async (f) => {
        const res = runThermalInstancePipeline({
          methodology: "instance2",
          raw14: f.noisy14,
          W,
          H,
          cfg: { ...DEFAULT_ISP_CONFIGS.instance2, enableLiveCnnResidual: false },
          cnnState: createInitialCnnState("instance2"),
          prevBlackRef: { current: 7100 },
          prevWhiteRef: { current: 7950 },
          lastFrameKeyRef: { current: "" },
          prevNormFrameRef: { current: null },
          prevKalman14Ref: { current: null },
          frameKey: "0"
        });
        return res.stage1Clean14;
      }
    },
    {
      id: "claudeA",
      label: "Original Claude A (Restored 14-bit)",
      run14: async (f) => {
        const res = await runPipeline(
          "A",
          {
            raw: f.noisy14,
            W,
            H,
            key: "0",
            idx: 0,
            total: 1,
            reset: true,
            getFrame: async () => f.noisy14
          },
          { ...defaultCfg("A"), cnn: false },
          newState()
        );
        return res.restored;
      }
    },
    {
      id: "lab",
      label: "New Claude Lab (Line + Guided Detail 14-bit)",
      run14: async (f) => {
        const c = cloneConfig(DEFAULT_CONFIG);
        return runPipeline2(f.noisy14, W, H, c).enhanced;
      }
    },
    {
      id: "argos2-guided-cored",
      label: "Argos 2 Variant (Separated Line + Guided Cored 14-bit)",
      run14: async (f) => {
        const line14 = argos2SeparatedLineOnly14(f.noisy14, W, H, 0.85, 0.65);
        return argos2SeparatedGuidedDetail14(line14, W, H, 2, 1.8, 180);
      }
    }
  ];
  if (cnnCkpt && cnnWeights) {
    methods.push({
      id: "cnn-active",
      label: `CNN (${cnnCkpt.checkpointId} \xB7 ${cnnCkpt.status})`,
      run14: async (f) => {
        const stage1 = runThermalInstancePipeline({
          methodology: "instance2",
          raw14: f.noisy14,
          W,
          H,
          cfg: { ...DEFAULT_ISP_CONFIGS.instance2, enableLiveCnnResidual: false },
          cnnState: createInitialCnnState("instance2"),
          prevBlackRef: { current: 7100 },
          prevWhiteRef: { current: 7950 },
          lastFrameKeyRef: { current: "" },
          prevNormFrameRef: { current: null },
          prevKalman14Ref: { current: null },
          frameKey: "0"
        }).stage1Clean14;
        const input = cnnCkpt.hyperParams.insertionMode === "post_stage1_14bit" ? stage1 : Float32Array.from(f.noisy14);
        return inferCnn14(input, W, H, cnnWeights, cnnCkpt.hyperParams, false).restored14;
      }
    });
  }
  const cases = [];
  for (const f of fixtures) {
    for (const m of methods) {
      const pred14 = await m.run14(f);
      const N = W * H;
      const psnr = computePsnr14Bit(pred14, f.clean14);
      const ssim = computeSsim14Bit(pred14, f.clean14, W, H);
      const stripes = computeFlatStripeRmsAdu(pred14, W, H);
      const vRet = measureSingleLineRetention(pred14, f.clean14, W, H, "vertical", f.verticalMastCol);
      const hRet = measureSingleLineRetention(pred14, f.clean14, W, H, "horizontal", f.horizontalWireRow);
      const ptRet = measurePointTargetRetention(pred14, f.clean14, W, H, f.pointTargetCoords);
      const halo = computeHaloOvershootAdu(pred14, f.clean14, W, H);
      let noStripeRms = null;
      if (f.scenarioId === "no_stripe_false_correction") {
        let sq = 0;
        for (let i = 0; i < N; i++) {
          const d = pred14[i] - f.clean14[i];
          sq += d * d;
        }
        noStripeRms = Number(Math.sqrt(sq / N).toFixed(2));
      }
      let lowClip = 0;
      let highClip = 0;
      for (let i = 0; i < N; i++) {
        if (pred14[i] <= 0) lowClip++;
        if (pred14[i] >= 16383) highClip++;
      }
      const oversharpen = vRet !== null && vRet > 1.05 || hRet !== null && hRet > 1.05;
      let note = null;
      if (f.scenarioId === "alternating_strong_stripes" && stripes.colRms > 100 && m.id !== "raw") {
        note = "Tradeoff/Failure: Local difference threshold gated out the \xB1150 ADU alternating stripe, leaving most stripe energy unremoved.";
      } else if (f.scenarioId === "true_full_height_wire" && (vRet !== null && vRet < 0.75 || hRet !== null && hRet < 0.75)) {
        note = "Tradeoff/Failure: Full-height/width 1-pixel wire was partially mistaken for a sensor stripe and attenuated (<0.75 retention).";
      } else if (oversharpen) {
        note = "Caution: Thin-feature contrast ratio > 1.05 reflects detail amplification/sharpening rather than pure radiometric restoration.";
      } else if (f.scenarioId === "small_point_targets" && ptRet !== null && ptRet < 0.7) {
        note = "Tradeoff/Failure: 1\xD71 warm point target was attenuated by spatial/outlier filtering.";
      }
      cases.push({
        scenarioId: f.scenarioId,
        methodId: m.id,
        methodLabel: m.label,
        syntheticCleanTruthAvailable: true,
        domain: "14-bit ADU (0..16383)",
        sampleSizePixels: N,
        psnr14Db: Number(psnr.toFixed(2)),
        ssim14: Number(ssim.toFixed(4)),
        colStripeRmsAdu: Number(stripes.colRms.toFixed(2)),
        rowStripeRmsAdu: Number(stripes.rowRms.toFixed(2)),
        noStripeFalseCorrectionRmsAdu: noStripeRms,
        verticalMastRetention: vRet,
        horizontalWireRetention: hRet,
        thinOversharpeningFlag: oversharpen,
        pointTargetPeakRetention: ptRet,
        haloOvershootAdu: Number(halo.toFixed(2)),
        lowClipFrac: Number((lowClip / N).toFixed(5)),
        highClipFrac: Number((highClip / N).toFixed(5)),
        failureOrTradeoffNote: note
      });
    }
  }
  const summaryByMethod = {};
  for (const m of methods) {
    const mc = cases.filter((c) => c.methodId === m.id);
    const mean = (arr) => arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
    const noStripeCase = mc.find((c) => c.scenarioId === "no_stripe_false_correction");
    const altCase = mc.find((c) => c.scenarioId === "alternating_strong_stripes");
    const wireCase = mc.find((c) => c.scenarioId === "true_full_height_wire");
    const ptCase = mc.find((c) => c.scenarioId === "small_point_targets");
    summaryByMethod[m.id] = {
      meanPsnr14Db: Number(mean(mc.map((c) => c.psnr14Db)).toFixed(2)),
      meanSsim14: Number(mean(mc.map((c) => c.ssim14)).toFixed(4)),
      noStripeAddedRmsAdu: noStripeCase?.noStripeFalseCorrectionRmsAdu ?? 0,
      strongAlternatingColRmsAdu: altCase?.colStripeRmsAdu ?? 0,
      verticalMastRetention: wireCase?.verticalMastRetention ?? 1,
      horizontalWireRetention: wireCase?.horizontalWireRetention ?? 1,
      pointTargetRetention: ptCase?.pointTargetPeakRetention ?? 1,
      maxHaloOvershootAdu: Number(Math.max(...mc.map((c) => c.haloOvershootAdu)).toFixed(2)),
      documentedFailuresAndTradeoffs: mc.map((c) => c.failureOrTradeoffNote).filter((x) => x !== null)
    };
  }
  return {
    schema: "clearhot-hard-negative-suite-v1",
    generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    syntheticOnly: true,
    width: W,
    height: H,
    methodsCompared: methods.map((m) => m.id),
    cases,
    summaryByMethod
  };
}
function computeNoReferenceRealFootageProxies(raw14, restored14, display8, W, H) {
  const N = W * H;
  const stripes = computeFlatStripeRmsAdu(restored14, W, H);
  let absDiffSum = 0;
  let s0 = 0;
  let s255 = 0;
  for (let i = 0; i < N; i++) {
    absDiffSum += Math.abs(restored14[i] - raw14[i]);
    if (display8[i] === 0) s0++;
    if (display8[i] === 255) s255++;
  }
  return {
    cleanTruthAvailable: false,
    psnrDb: null,
    ssim: null,
    calibratedTemperatureCelsius: null,
    flatPatchColHighPassProxyAdu: Number(stripes.colRms.toFixed(2)),
    flatPatchRowHighPassProxyAdu: Number(stripes.rowRms.toFixed(2)),
    meanAbsModificationAdu: Number((absDiffSum / Math.max(1, N)).toFixed(2)),
    displaySat0Frac: Number((s0 / Math.max(1, N)).toFixed(5)),
    displaySat255Frac: Number((s255 / Math.max(1, N)).toFixed(5)),
    warning: "NO-REFERENCE PROXY ONLY: Real recordings lack clean ground truth and radiometric calibration. PSNR, SSIM and temperatures are undefined (null). High-pass profile proxies can be confounded by real vertical/horizontal scene edges; rely on blinded visual and ROI review."
  };
}

// src/cnn/registry.ts
function createEmptyRegistry() {
  const now2 = (/* @__PURE__ */ new Date()).toISOString();
  return {
    schema: "clearhot-model-registry-v1",
    createdAt: now2,
    updatedAt: now2,
    activeCheckpointId: null,
    previousActiveCheckpointId: null,
    promotionStack: [],
    checkpoints: {},
    validationReports: {},
    approvalRecords: {},
    auditLog: [],
    finalTestInvocations: []
  };
}
function verifyCheckpointIntegrity(ckpt) {
  if (!ckpt || ckpt.schema !== "clearhot-cnn-checkpoint-v1") return false;
  const params = deserializeParameters(ckpt.weights);
  const actualHash = computeWeightsSha256(params);
  return actualHash.toLowerCase() === ckpt.weightsSha256.toLowerCase();
}
function registerCandidateCheckpoint(state, ckpt, actor = "local-trainer") {
  if (!verifyCheckpointIntegrity(ckpt)) {
    throw new Error(`Checkpoint '${ckpt.checkpointId}' failed weightsSha256 integrity check.`);
  }
  const copy = { ...ckpt, status: "candidate" };
  state.checkpoints[ckpt.checkpointId] = copy;
  state.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  state.auditLog.push({
    timestamp: state.updatedAt,
    eventType: ckpt.isSimulatedDemo ? "simulated/demo" : "candidate",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor,
    summary: `Registered ${ckpt.isSimulatedDemo ? "[SIMULATED/DEMO] " : ""}candidate '${ckpt.checkpointId}' (cycle ${ckpt.cycleNumber}, steps=${ckpt.stepsRun}, weightUpdateL2=${ckpt.totalWeightUpdateL2}).`
  });
  state.auditLog.push({
    timestamp: state.updatedAt,
    eventType: "candidate",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor,
    summary: `Candidate '${ckpt.checkpointId}' awaiting validation against frozen classical Argos 2 baseline.`
  });
  return state;
}
function validateRegisteredCandidate(state, params) {
  const ckpt = state.checkpoints[params.checkpointId];
  if (!ckpt) {
    throw new Error(`Checkpoint '${params.checkpointId}' not found in registry.`);
  }
  if (!verifyCheckpointIntegrity(ckpt)) {
    throw new Error(`Checkpoint '${params.checkpointId}' failed weightsSha256 verification before validation.`);
  }
  const activeCkpt = state.activeCheckpointId ? state.checkpoints[state.activeCheckpointId] ?? null : null;
  const report = evaluateCnnCandidate({
    candidate: ckpt,
    activeCheckpoint: activeCkpt,
    pairs: params.pairs,
    split: "validation",
    thresholds: params.thresholds ?? DEFAULT_SAFETY_THRESHOLDS
  });
  state.validationReports[ckpt.checkpointId] = report;
  state.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  if (report.allMandatoryGatesPassed) {
    ckpt.status = "validated";
    state.auditLog.push({
      timestamp: state.updatedAt,
      eventType: "validated",
      checkpointId: ckpt.checkpointId,
      weightsSha256: ckpt.weightsSha256,
      actor: params.actor ?? "local-evaluator",
      summary: `Validated '${ckpt.checkpointId}': PASSED all ${report.gates.length} mandatory safety gates (\u0394PSNR vs Argos 2 Stage 1 = +${report.aggregate.psnrDeltaVsBaselineDb.toFixed(2)} dB). Requires explicit human approval before promotion.`
    });
  } else {
    ckpt.status = "rejected";
    state.auditLog.push({
      timestamp: state.updatedAt,
      eventType: "rejected",
      checkpointId: ckpt.checkpointId,
      weightsSha256: ckpt.weightsSha256,
      actor: params.actor ?? "local-evaluator",
      summary: `Candidate '${ckpt.checkpointId}' FAILED mandatory safety gate(s): [${report.failedGates.join(", ")}]. Automatically marked REJECTED and blocked from promotion.`
    });
  }
  return report;
}
function approveAndPromoteCandidate(state, params) {
  if (params.explicitHumanApprove !== true) {
    throw new Error("Promotion refused: explicitHumanApprove must be true. Auto-promotion without human sign-off is forbidden.");
  }
  if (!params.reviewer || params.reviewer.trim().length < 2) {
    throw new Error("Promotion refused: a human reviewer identity or pseudonym is required.");
  }
  if (!params.note || params.note.trim().length < 4) {
    throw new Error("Promotion refused: an approval note documenting the review decision is required.");
  }
  const ckpt = state.checkpoints[params.checkpointId];
  if (!ckpt) {
    throw new Error(`Checkpoint '${params.checkpointId}' does not exist in registry.`);
  }
  if (!verifyCheckpointIntegrity(ckpt)) {
    throw new Error(`Checkpoint '${params.checkpointId}' failed weightsSha256 integrity verification.`);
  }
  const report = state.validationReports[params.checkpointId];
  if (!report) {
    throw new Error(`Cannot promote '${params.checkpointId}': candidate has not been validated yet.`);
  }
  if (!report.allMandatoryGatesPassed) {
    ckpt.status = "rejected";
    throw new Error(
      `Cannot promote '${params.checkpointId}': candidate failed mandatory safety gate(s) [${report.failedGates.join(", ")}].`
    );
  }
  if (ckpt.status === "rejected") {
    throw new Error(`Cannot promote '${params.checkpointId}': candidate status is 'rejected'.`);
  }
  const now2 = (/* @__PURE__ */ new Date()).toISOString();
  if (state.activeCheckpointId && state.activeCheckpointId !== ckpt.checkpointId) {
    const prev = state.checkpoints[state.activeCheckpointId];
    if (prev) prev.status = "approved";
    state.previousActiveCheckpointId = state.activeCheckpointId;
    state.promotionStack.push(state.activeCheckpointId);
  }
  ckpt.status = "active";
  state.activeCheckpointId = ckpt.checkpointId;
  state.updatedAt = now2;
  state.approvalRecords[ckpt.checkpointId] = {
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    decision: "approved",
    reviewer: params.reviewer.trim(),
    note: params.note.trim(),
    decidedAt: now2,
    isSimulatedDemo: ckpt.isSimulatedDemo
  };
  state.auditLog.push({
    timestamp: now2,
    eventType: "approved",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor: params.reviewer.trim(),
    summary: `Human reviewer '${params.reviewer.trim()}' APPROVED '${ckpt.checkpointId}' (${ckpt.isSimulatedDemo ? "simulated/demo" : "curated"}): ${params.note.trim()}`
  });
  state.auditLog.push({
    timestamp: now2,
    eventType: "active",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor: params.reviewer.trim(),
    summary: `Promoted '${ckpt.checkpointId}' to ACTIVE model (previous active: ${state.previousActiveCheckpointId ?? "none / classical baseline"}).`
  });
  return state;
}
function rejectCandidateByHuman(state, params) {
  if (!params.reviewer || params.reviewer.trim().length < 2) {
    throw new Error("Reviewer identity is required to record a rejection.");
  }
  const ckpt = state.checkpoints[params.checkpointId];
  if (!ckpt) {
    throw new Error(`Checkpoint '${params.checkpointId}' not found.`);
  }
  const now2 = (/* @__PURE__ */ new Date()).toISOString();
  if (state.activeCheckpointId === ckpt.checkpointId) {
    throw new Error(
      `Checkpoint '${ckpt.checkpointId}' is currently active; use rollbackActiveModel() to revert to the previous active model or classical baseline.`
    );
  }
  ckpt.status = "rejected";
  state.approvalRecords[ckpt.checkpointId] = {
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    decision: "rejected",
    reviewer: params.reviewer.trim(),
    note: params.reason.trim(),
    decidedAt: now2,
    isSimulatedDemo: ckpt.isSimulatedDemo
  };
  state.updatedAt = now2;
  state.auditLog.push({
    timestamp: now2,
    eventType: "rejected",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor: params.reviewer.trim(),
    summary: `Human reviewer '${params.reviewer.trim()}' REJECTED candidate '${ckpt.checkpointId}': ${params.reason.trim()}`
  });
  return state;
}
function rollbackActiveModel(state, params) {
  if (!params.reviewer || params.reviewer.trim().length < 2) {
    throw new Error("Reviewer identity is required for rollback.");
  }
  const rolledBackId = state.activeCheckpointId;
  if (!rolledBackId) {
    throw new Error("No active CNN checkpoint is currently promoted; already at classical baseline.");
  }
  const rolledBackCkpt = state.checkpoints[rolledBackId];
  if (rolledBackCkpt) {
    rolledBackCkpt.status = "rejected";
  }
  const nextActiveId = state.promotionStack.length > 0 ? state.promotionStack.pop() : state.previousActiveCheckpointId;
  if (nextActiveId) {
    const restored = state.checkpoints[nextActiveId];
    if (!restored || !verifyCheckpointIntegrity(restored)) {
      throw new Error(`Rollback target checkpoint '${nextActiveId}' failed integrity verification.`);
    }
    restored.status = "active";
    state.activeCheckpointId = restored.checkpointId;
    state.previousActiveCheckpointId = state.promotionStack.length > 0 ? state.promotionStack[state.promotionStack.length - 1] : null;
  } else {
    state.activeCheckpointId = null;
    state.previousActiveCheckpointId = null;
  }
  const now2 = (/* @__PURE__ */ new Date()).toISOString();
  state.updatedAt = now2;
  state.auditLog.push({
    timestamp: now2,
    eventType: "rollback",
    checkpointId: state.activeCheckpointId,
    weightsSha256: state.activeCheckpointId ? state.checkpoints[state.activeCheckpointId]?.weightsSha256 ?? null : null,
    actor: params.reviewer.trim(),
    summary: `ROLLBACK executed by '${params.reviewer.trim()}' (${params.reason.trim()}): reverted from '${rolledBackId}' to '${state.activeCheckpointId ?? "classical Argos 2 baseline"}'.`
  });
  return {
    restoredCheckpointId: state.activeCheckpointId,
    rolledBackCheckpointId: rolledBackId
  };
}
function invokeUntouchedFinalTest(state, params) {
  if (params.unlockFinalTest !== true) {
    throw new Error("Final test split is locked by default. Pass unlockFinalTest=true only for final once-off evaluation.");
  }
  if (!params.reviewer || params.reviewer.trim().length < 2) {
    throw new Error("Reviewer identity is required when unlocking the final_test split.");
  }
  const ckpt = state.checkpoints[params.checkpointId];
  if (!ckpt || !verifyCheckpointIntegrity(ckpt)) {
    throw new Error(`Invalid or missing checkpoint '${params.checkpointId}'.`);
  }
  const report = evaluateCnnCandidate({
    candidate: ckpt,
    pairs: params.pairs,
    split: "final_test"
  });
  const now2 = (/* @__PURE__ */ new Date()).toISOString();
  state.finalTestInvocations.push({
    invokedAt: now2,
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    reviewer: params.reviewer.trim(),
    reason: params.reason.trim(),
    report
  });
  state.updatedAt = now2;
  state.auditLog.push({
    timestamp: now2,
    eventType: "final_test_invoked",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor: params.reviewer.trim(),
    summary: `UNTOUCHED FINAL TEST invoked by '${params.reviewer.trim()}' on '${ckpt.checkpointId}' (invocation #${state.finalTestInvocations.length}): mean 14-bit PSNR = ${report.aggregate.meanCandidateCnnPsnr14Db.toFixed(2)} dB (\u0394 vs Argos 2 Stage 1 = +${report.aggregate.psnrDeltaVsBaselineDb.toFixed(2)} dB).`
  });
  return report;
}
function runTwoCycleSyntheticDemo(options) {
  const width = options?.width ?? 64;
  const height = options?.height ?? 64;
  const steps1 = options?.stepsCycle1 ?? 24;
  const steps2 = options?.stepsCycle2 ?? 28;
  const leaveCycle1Active = options?.leaveCycle1ActiveAfterRollback ?? true;
  const registry = createEmptyRegistry();
  const dsV1 = buildSyntheticDataset({ version: 1, width, height });
  const ckpt1 = trainCnnCandidate({
    checkpointId: "ckpt-cycle1-synth-v1",
    cycleNumber: 1,
    manifest: dsV1.manifest,
    pairs: dsV1.pairs,
    seed: 1337,
    steps: steps1,
    notes: "Cycle 1 synthetic demonstration model trained on synth-v1 (4 training scenes, 4 disjoint validation scenes)."
  });
  registerCandidateCheckpoint(registry, ckpt1, "demo-trainer-cycle1");
  const report1 = validateRegisteredCandidate(registry, {
    checkpointId: ckpt1.checkpointId,
    pairs: dsV1.pairs,
    actor: "demo-evaluator-cycle1"
  });
  approveAndPromoteCandidate(registry, {
    checkpointId: ckpt1.checkpointId,
    reviewer: "Demo Operator (Simulated Human Review)",
    note: "Cycle 1 simulated approval: all 7 safety gates passed on synthetic validation; promoted as active demo model.",
    explicitHumanApprove: true
  });
  const dsV2 = buildSyntheticDataset({ version: 2, width, height });
  const badWeights = structuredClone(ckpt1.weights);
  badWeights.branchScales = [4.5, -3.8, -3.8];
  badWeights.conv3B = [1.85];
  const badParams = deserializeParameters(badWeights);
  const ckpt2Failing = {
    ...structuredClone(ckpt1),
    checkpointId: "ckpt-cycle2-regressing-cand",
    cycleNumber: 2,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    status: "candidate",
    weights: badWeights,
    weightsSha256: computeWeightsSha256(badParams),
    notes: "Cycle 2 deliberately over-aggressive candidate to verify safety-gate rejection."
  };
  registerCandidateCheckpoint(registry, ckpt2Failing, "demo-trainer-cycle2");
  const report2Failing = validateRegisteredCandidate(registry, {
    checkpointId: ckpt2Failing.checkpointId,
    pairs: dsV2.pairs,
    actor: "demo-evaluator-cycle2"
  });
  let promotionBlockedError = "";
  try {
    approveAndPromoteCandidate(registry, {
      checkpointId: ckpt2Failing.checkpointId,
      reviewer: "Demo Operator",
      note: "Attempted promotion of failing candidate (must be blocked by safety gates).",
      explicitHumanApprove: true
    });
  } catch (err) {
    promotionBlockedError = String(err instanceof Error ? err.message : err);
  }
  const ckpt2Passing = trainCnnCandidate({
    checkpointId: "ckpt-cycle2-synth-v2",
    cycleNumber: 2,
    manifest: dsV2.manifest,
    pairs: dsV2.pairs,
    seed: 2026,
    steps: steps2,
    initialWeights: ckpt1.weights,
    hyperParams: { learningRate: 8e-4 },
    notes: "Cycle 2 fine-tuned candidate on expanded curated synthetic dataset v2 (7 training scenes)."
  });
  registerCandidateCheckpoint(registry, ckpt2Passing, "demo-trainer-cycle2");
  const report2Passing = validateRegisteredCandidate(registry, {
    checkpointId: ckpt2Passing.checkpointId,
    pairs: dsV2.pairs,
    actor: "demo-evaluator-cycle2"
  });
  approveAndPromoteCandidate(registry, {
    checkpointId: ckpt2Passing.checkpointId,
    reviewer: "Demo Operator (Simulated Human Review)",
    note: "Cycle 2 simulated approval: fine-tuned candidate passed all safety gates on v2.",
    explicitHumanApprove: true
  });
  const rollbackResult = rollbackActiveModel(registry, {
    reviewer: "Demo Operator (Rollback Drill)",
    reason: "Verifying atomic rollback restores exact Cycle 1 checkpoint identity and weightsSha256."
  });
  if (!leaveCycle1Active) {
    registry.checkpoints[ckpt2Passing.checkpointId].status = "validated";
    approveAndPromoteCandidate(registry, {
      checkpointId: ckpt2Passing.checkpointId,
      reviewer: "Demo Operator",
      note: "Re-promoted Cycle 2 after successful rollback verification.",
      explicitHumanApprove: true
    });
  }
  return {
    registry,
    cycle1Checkpoint: registry.checkpoints[ckpt1.checkpointId],
    cycle1Report: report1,
    cycle2FailingCheckpoint: registry.checkpoints[ckpt2Failing.checkpointId],
    cycle2FailingReport: report2Failing,
    cycle2PassingCheckpoint: registry.checkpoints[ckpt2Passing.checkpointId],
    cycle2PassingReport: report2Passing,
    promotionBlockedError,
    rollbackResult
  };
}
function estimateInferenceCacheDiskBytes(width, height, frameCount) {
  const rawCacheBytes = width * height * 2 * frameCount;
  const manifestApproxBytes = 2048;
  const totalBytes = rawCacheBytes + manifestApproxBytes;
  return {
    rawCacheBytes,
    manifestApproxBytes,
    totalBytes,
    humanReadableMiB: `${(totalBytes / (1024 * 1024)).toFixed(2)} MiB`
  };
}
function buildLocalInferenceCache(params) {
  if (!verifyCheckpointIntegrity(params.checkpoint)) {
    throw new Error(`Checkpoint '${params.checkpoint.checkpointId}' failed weightsSha256 integrity verification.`);
  }
  const { frames } = frameCountFor(params.sourceBytes.byteLength, params.decoder);
  if (frames < 1) {
    throw new Error("Source recording has 0 complete frames under the specified decoder configuration.");
  }
  const W = params.decoder.width;
  const H = params.decoder.height;
  const fb = frameBytes(params.decoder);
  const sourceSha256 = sha256Bytes(params.sourceBytes);
  const weights = deserializeParameters(params.checkpoint.weights);
  const hp = params.checkpoint.hyperParams;
  const outBytes = new Uint8Array(frames * fb);
  for (let i = 0; i < frames; i++) {
    const start = params.decoder.headerBytes + i * fb;
    const slice = params.sourceBytes.slice(start, start + fb);
    const raw14 = decodeBuffer(slice.buffer, params.decoder);
    const modelIn = hp.insertionMode === "post_stage1_14bit" ? computeArgos2Stage1Clean14(raw14, W, H).stage1Clean14 : Float32Array.from(raw14);
    const inf = inferCnn14(modelIn, W, H, weights, hp, false);
    const frameU16 = new Uint16Array(W * H);
    for (let k = 0; k < W * H; k++) {
      frameU16[k] = Math.max(0, Math.min(16383, Math.round(inf.restored14[k])));
    }
    const encoded = encodeUint16LeBytes(frameU16);
    outBytes.set(encoded, i * fb);
  }
  const cacheSha256 = sha256Bytes(outBytes);
  const manifest = {
    schema: "clearhot-inference-cache-v1",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    sourceFileName: params.sourceFileName,
    sourceByteLength: params.sourceBytes.byteLength,
    sourceSha256,
    frameCount: frames,
    decoder: params.decoder,
    checkpointId: params.checkpoint.checkpointId,
    checkpointWeightsSha256: params.checkpoint.weightsSha256,
    checkpointStatus: params.checkpoint.status,
    isApprovedActiveModel: params.isApprovedActiveModel,
    isSimulatedDemoModel: params.checkpoint.isSimulatedDemo,
    insertionMode: hp.insertionMode,
    cacheByteLength: outBytes.byteLength,
    cacheSha256
  };
  return { manifest, cacheBytes: outBytes };
}
function verifyCacheAgainstSource(params) {
  const m = params.manifest;
  if (!m || m.schema !== "clearhot-inference-cache-v1") {
    return { valid: false, error: "Invalid inference cache manifest schema." };
  }
  if (m.sourceByteLength !== params.sourceByteLength) {
    return {
      valid: false,
      error: `Cache source size mismatch: cache was built for ${m.sourceByteLength} bytes, current source is ${params.sourceByteLength} bytes.`
    };
  }
  if (m.frameCount !== params.expectedFrames) {
    return {
      valid: false,
      error: `Cache frame count mismatch: cache has ${m.frameCount} frames, current source has ${params.expectedFrames} frames.`
    };
  }
  const d = params.decoder;
  if (m.decoder.width !== d.width || m.decoder.height !== d.height || m.decoder.headerBytes !== d.headerBytes || m.decoder.shift !== d.shift || m.decoder.littleEndian !== d.littleEndian) {
    return {
      valid: false,
      error: "Cache decoder configuration (width, height, headerBytes, shift, or endianness) does not match current source settings."
    };
  }
  if (params.requireSha256Match !== false && params.sourceSha256) {
    if (m.sourceSha256.toLowerCase() !== params.sourceSha256.toLowerCase()) {
      return {
        valid: false,
        error: `Cache source SHA-256 mismatch: cache=${m.sourceSha256.slice(0, 16)}..., source=${params.sourceSha256.slice(0, 16)}...`
      };
    }
  }
  return { valid: true, error: null };
}

// src/core.ts
var VERSION = "1.2.0";
var METHODS = [
  "argos2",
  "argos1",
  "argos3",
  "claudeA",
  "claudeB",
  "claudeC",
  "lab",
  "argos2-no-line",
  "argos2-no-detail",
  "lab-line-only",
  "lab-detail-low",
  "lab-detail-high"
];
var CONTROLLED_VARIANT_METHODS = [
  "argos2-guided-cored",
  "argos2-causal-temporal",
  "claudeB-causal",
  "cnn-active"
];
var PLAYABLE_METHODS = [
  ...METHODS,
  ...CONTROLLED_VARIANT_METHODS
];
var LABELS = {
  argos2: "Argos 2 \xB7 original default (native AGC + fused detail)",
  argos1: "Argos 1 \xB7 original default (native AGC + DPHE)",
  argos3: "Argos 3 \xB7 original default (native AGC + ACE)",
  claudeA: "Claude A \xB7 original default (native quantile + CLAHE)",
  claudeB: "Claude B \xB7 original default (offline look-ahead)",
  claudeC: "Claude C \xB7 original default (native spectral + multiscale)",
  lab: "New Claude lab \xB7 line + detail (locked fixed window)",
  "argos2-no-line": "Argos 2 \xB7 stage 1 bypass (disables line + bad-pixel)",
  "argos2-no-detail": "Argos 2 \xB7 stage 4 detail bypass",
  "lab-line-only": "New lab \xB7 line only (locked fixed window)",
  "lab-detail-low": "New lab \xB7 lower detail (gain 1.5, locked window)",
  "lab-detail-high": "New lab \xB7 higher detail (gain 3.5, locked window)"
};
var VARIANT_LABELS = {
  "argos2-guided-cored": "Argos 2 Variant \xB7 Guided Detail + Noise Coring (locked monotone window)",
  "argos2-causal-temporal": "Argos 2 Variant \xB7 Causal Motion-Gated Temporal (3-frame warm-up, locked window)",
  "claudeB-causal": "Claude B Variant \xB7 Strictly Causal Past-Frame Window (no look-ahead)",
  "cnn-active": "Opt-in CNN Residual \xB7 Active/Selected Checkpoint (14-bit residual + Argos 2 / locked window)"
};
var ALL_LABELS = {
  ...LABELS,
  ...VARIANT_LABELS
};
function validSettings(s) {
  if (!Number.isInteger(s.width) || !Number.isInteger(s.height) || s.width < 32 || s.height < 32 || s.width % 2 || s.height % 2 || s.width * s.height > 4194304) {
    return "Width and height must be even integers \u226532, with at most 4,194,304 pixels.";
  }
  if (!Number.isInteger(s.headerBytes) || s.headerBytes < 0 || !Number.isSafeInteger(s.headerBytes)) {
    return "Header bytes must be a non-negative integer.";
  }
  const bits = s.bits ?? 14;
  if (![8, 12, 14, 15, 16].includes(bits)) {
    return "Bit depth must be 14 (default for original methods) or an explicit 8, 12, 15 or 16-bit setting.";
  }
  const maxShift = 16 - bits;
  if (!Number.isInteger(s.shift) || s.shift < 0 || s.shift > maxShift) {
    return bits === 14 ? "Right shift must be 0, 1 or 2 for a 14-bit field in uint16." : `Right shift must be between 0 and ${maxShift} for a ${bits}-bit field in uint16.`;
  }
  const topCode = (1 << bits) - 1;
  if (!Number.isFinite(s.lo) || !Number.isFinite(s.hi) || s.lo < 0 || s.hi > topCode || s.hi <= s.lo) {
    return `Fixed window must satisfy 0 \u2264 low < high \u2264 ${topCode}.`;
  }
  return null;
}
var decodeConfig = (s) => ({
  width: s.width,
  height: s.height,
  headerBytes: s.headerBytes,
  shift: s.shift,
  littleEndian: s.littleEndian,
  bits: s.bits ?? 14,
  allow14BitCompatibilityScaling: s.allow14BitCompatibilityScaling ?? false
});
function reference(raw, s) {
  const c = cloneConfig(DEFAULT_CONFIG);
  c.tone.fixedLo = s.lo;
  c.tone.fixedHi = s.hi;
  return referenceDisplay(raw, c);
}
function configFor(id, s) {
  if (id === "argos2-guided-cored") {
    return {
      variant: "argos2-guided-cored",
      lineVerticalStrength: 0.85,
      lineHorizontalStrength: 0.65,
      guidedRadius: 3,
      edgeAdu: 140,
      detailGain: 2.2,
      coringK: 1.6,
      maxBoostAdu: 220,
      toneMode: "locked_monotone_window_soft_knee",
      lo: s.lo,
      hi: s.hi
    };
  }
  if (id === "argos2-causal-temporal") {
    return {
      variant: "argos2-causal-temporal",
      causalOnly: true,
      declaredWarmupFrames: 3,
      temporalAlpha: 0.4,
      motionGateK: 3.8,
      lo: s.lo,
      hi: s.hi
    };
  }
  if (id === "claudeB-causal") {
    return {
      ...defaultCfg("B"),
      cnn: false,
      variant: "claudeB-causal",
      causalEnforced: true,
      splitStartIndex: s.splitStartIndex ?? 0
    };
  }
  if (id === "cnn-active") {
    return {
      variant: "cnn-active",
      insertionMode: "post_stage1_14bit",
      lo: s.lo,
      hi: s.hi
    };
  }
  if (id.startsWith("argos")) {
    const m = id === "argos1" ? "instance1" : id === "argos3" ? "instance3" : "instance2";
    const c2 = { ...DEFAULT_ISP_CONFIGS[m] };
    c2.enableLiveCnnResidual = false;
    if (id === "argos2-no-line") c2.stage1DestripeAndBadPx = false;
    if (id === "argos2-no-detail") c2.stage4EdgePreservingDetail = false;
    return c2;
  }
  if (id.startsWith("claude")) {
    const v = id.slice(-1);
    return { ...defaultCfg(v), cnn: false };
  }
  const c = cloneConfig(DEFAULT_CONFIG);
  c.tone.fixedLo = s.lo;
  c.tone.fixedHi = s.hi;
  c.tone.mode = "fixed";
  c.temporal.on = false;
  if (id === "lab-line-only") c.detail.on = false;
  if (id === "lab-detail-low") c.detail.gain = 1.5;
  if (id === "lab-detail-high") c.detail.gain = 3.5;
  return c;
}
function createMethodRunner(id, s, total, getFrame, cnnOptions) {
  const cfg = configFor(id, s);
  const W = s.width;
  const H = s.height;
  const bits = s.bits ?? 14;
  const allowScale = s.allow14BitCompatibilityScaling ?? false;
  const methodology = id === "argos1" ? "instance1" : id === "argos3" ? "instance3" : "instance2";
  let argos = {
    prevBlackRef: { current: 7100 },
    prevWhiteRef: { current: 7950 },
    lastFrameKeyRef: { current: "" },
    prevNormFrameRef: { current: null },
    prevKalman14Ref: { current: null }
  };
  let claude = newState();
  let causalArgos = createCausalArgosState();
  let last = -1;
  return async (raw, index) => {
    const start = performance.now();
    let pixels;
    let restored;
    let toneDomain = "native_method_agc";
    let compatibilityWarning = null;
    let requestedFrameIndices;
    const reset = last < 0 || index !== last + 1;
    if (reset) {
      argos = {
        prevBlackRef: { current: 7100 },
        prevWhiteRef: { current: 7950 },
        lastFrameKeyRef: { current: "" },
        prevNormFrameRef: { current: null },
        prevKalman14Ref: { current: null }
      };
      claude = newState();
      causalArgos = createCausalArgosState();
    }
    let input14 = raw;
    if (bits !== 14 && id !== "lab" && id !== "lab-line-only" && id !== "lab-detail-low" && id !== "lab-detail-high") {
      const conv = to14BitForLegacyMethods(raw, bits, allowScale);
      input14 = conv.data14;
      compatibilityWarning = conv.warning;
    }
    if (id === "argos2-guided-cored") {
      const r = runArgos2GuidedCoredCandidate(input14, W, H, s.lo, s.hi);
      pixels = r.pixels;
      restored = r.restored14;
      toneDomain = "locked_fixed_window";
    } else if (id === "argos2-causal-temporal") {
      const r = runArgos2CausalTemporalCandidate(input14, W, H, s.lo, s.hi, index, causalArgos);
      pixels = r.pixels;
      restored = r.restored14;
      toneDomain = "locked_fixed_window";
    } else if (id === "claudeB-causal") {
      const r = await runClaudeBCausalCandidate(
        input14,
        W,
        H,
        index,
        reset,
        getFrame,
        claude,
        s.splitStartIndex ?? 0
      );
      pixels = r.pixels;
      restored = r.restored14;
      requestedFrameIndices = r.requestedFrames;
      toneDomain = "native_method_agc";
    } else if (id === "cnn-active") {
      const bypass = cnnOptions?.bypassCnn ?? false;
      const ckpt = cnnOptions?.checkpoint ?? null;
      const cachedFrame = !bypass && cnnOptions?.cachedFrameGetter ? cnnOptions.cachedFrameGetter(index) : null;
      if (cachedFrame) {
        restored = Float32Array.from(cachedFrame);
      } else if (!bypass && ckpt) {
        const weights = deserializeParameters(ckpt.weights);
        const hp = ckpt.hyperParams;
        const stage1 = hp.insertionMode === "post_stage1_14bit" ? computeArgos2Stage1Clean14(input14, W, H).stage1Clean14 : Float32Array.from(input14);
        restored = inferCnn14(stage1, W, H, weights, hp, false).restored14;
      } else {
        restored = computeArgos2Stage1Clean14(input14, W, H).stage1Clean14;
      }
      if (cnnOptions?.useNativeArgos2ToneForCnn) {
        pixels = map14BitThroughArgos2NativeStages(restored, W, H);
        toneDomain = "native_method_agc";
      } else {
        pixels = map14BitToFixedWindow8(restored, s.lo, s.hi);
        toneDomain = "locked_fixed_window";
      }
    } else if (id.startsWith("argos")) {
      const a = runThermalInstancePipeline({
        methodology,
        raw14: input14,
        W,
        H,
        cfg,
        cnnState: createInitialCnnState(methodology),
        ...argos,
        frameKey: `${index}`
      });
      pixels = new Uint8Array(a.processed8);
      restored = a.stage1Clean14;
      toneDomain = "native_method_agc";
    } else if (id.startsWith("claude")) {
      const v = id.slice(-1);
      const a = await runPipeline(
        v,
        { raw: input14, W, H, key: `${index}`, idx: index, total, reset, getFrame },
        cfg,
        claude
      );
      pixels = new Uint8Array(a.out8);
      restored = a.restored;
      toneDomain = "native_method_agc";
    } else {
      const topCode = (1 << bits) - 1;
      const a = runPipeline2(raw, W, H, cfg, void 0, topCode);
      pixels = a.display;
      restored = a.enhanced;
      toneDomain = "locked_fixed_window";
    }
    last = index;
    return {
      pixels,
      restored,
      ms: performance.now() - start,
      config: cfg,
      toneDomain,
      compatibilityWarning,
      requestedFrameIndices
    };
  };
}
async function runMethod(id, raw, s, index, total, getFrame, cnnOptions) {
  return createMethodRunner(id, s, total, getFrame, cnnOptions)(raw, index);
}
function stats(data, w, h, r, sat) {
  const x0 = Math.max(0, Math.floor(r.x));
  const y0 = Math.max(0, Math.floor(r.y));
  const x1 = Math.min(w, Math.ceil(r.x + r.w));
  const y1 = Math.min(h, Math.ceil(r.y + r.h));
  if (x1 <= x0 || y1 <= y0) throw new Error("ROI is outside the image");
  return roiStats(data, w, h, { ...r, x: x0, y: y0, w: x1 - x0, h: y1 - y0 }, sat);
}
function temporalDifference(a, b, w, h, r) {
  const x0 = Math.max(0, Math.floor(r.x));
  const y0 = Math.max(0, Math.floor(r.y));
  const x1 = Math.min(w, Math.ceil(r.x + r.w));
  const y1 = Math.min(h, Math.ceil(r.y + r.h));
  let sum = 0;
  let n = 0;
  for (let y = y0; y < y1; y++) {
    for (let x = x0; x < x1; x++) {
      const i = y * w + x;
      sum += Math.abs(a[i] - b[i]);
      n++;
    }
  }
  return n ? sum / n : null;
}
function medianGap(a, b) {
  const spread = Math.sqrt((a.sigma * a.sigma + b.sigma * b.sigma) / 2);
  return {
    delta: a.median - b.median,
    pooledRobustSpread: spread,
    ratio: spread > 1e-6 ? Math.abs(a.median - b.median) / spread : null,
    interpretation: "Descriptive ROI statistic only; no universal separability or temperature conclusion."
  };
}
function synthetic(w, h, frame) {
  const a = new Uint16Array(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const target = (x - 0.3 * w - frame) ** 2 / (0.04 * w * w) + (y - 0.7 * h) ** 2 / (0.01 * h * h) < 1 ? 250 : 0;
      const bridge = Math.abs(y - 0.45 * h) < 2 ? 300 : 0;
      const line = x === Math.floor(w * 0.7) ? 150 : 0;
      const stripe = (x % 2 ? 1 : -1) * 35;
      a[y * w + x] = Math.round(
        6e3 + 180 * y / h + target + bridge + line + stripe + ((x * 19 + y * 31 + frame * 7) % 13 - 6)
      );
    }
  }
  return a;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ALL_LABELS,
  CNN_ARCHITECTURE_ID,
  CONTROLLED_VARIANT_METHODS,
  DEFAULT_CNN_HYPERPARAMS,
  DEFAULT_SAFETY_THRESHOLDS,
  LABELS,
  METHODS,
  PLAYABLE_METHODS,
  VARIANT_LABELS,
  VERSION,
  allParametersFinite,
  applyAdamStep,
  approveAndPromoteCandidate,
  argos2SeparatedGuidedDetail14,
  argos2SeparatedLineOnly14,
  buildLocalInferenceCache,
  buildSyntheticDataset,
  checkMonotonic,
  cnr,
  computeAblationContextKey,
  computeArchitectureHash,
  computeArgos2Stage1Clean14,
  computeFlatStripeRmsAdu,
  computeHaloOvershootAdu,
  computeNoReferenceRealFootageProxies,
  computePsnr14Bit,
  computeRows,
  computeSsim14Bit,
  computeThinFeatureRetention,
  computeWeightsSha256,
  configFor,
  countParameters,
  createAdamState,
  createEmptyRegistry,
  createInitialParameters,
  createMethodRunner,
  decodeBuffer,
  decodeConfig,
  deserializeParameters,
  diagnoseFormat,
  encodeUint16LeBytes,
  estimateInferenceCacheDiskBytes,
  evaluateCnnCandidate,
  forwardAndBackward,
  frameBytes,
  frameCountFor,
  frameStats,
  generateHardNegativeFixtures,
  generateSyntheticPair,
  inferCnn14,
  invokeUntouchedFinalTest,
  map14BitThroughArgos2NativeStages,
  map14BitToFixedWindow8,
  maxCode,
  medianGap,
  nearestBackground,
  parameterL2Distance,
  percentileWindow,
  readFrame,
  reference,
  registerCandidateCheckpoint,
  rejectCandidateByHuman,
  roiStats,
  rollbackActiveModel,
  runArgos2CausalTemporalCandidate,
  runArgos2GuidedCoredCandidate,
  runClaudeBCausalCandidate,
  runGenuineStageAblation,
  runHardNegativeBenchmarkSuite,
  runMethod,
  runTwoCycleSyntheticDemo,
  serializeParameters,
  sha256Bytes,
  sha256File,
  stats,
  synthetic,
  temporalDifference,
  to14BitForLegacyMethods,
  toneFn,
  trainCnnCandidate,
  validSettings,
  validateDatasetManifest,
  validateRegisteredCandidate,
  verifyAndDecodeCuratedPair,
  verifyCacheAgainstSource,
  verifyCheckpointIntegrity
});
