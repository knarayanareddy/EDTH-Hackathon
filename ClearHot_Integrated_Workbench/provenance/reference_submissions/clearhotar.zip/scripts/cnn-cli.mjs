#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import readline from "node:readline";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const corePath = path.resolve(process.cwd(), "tests/core.cjs");
if (!fs.existsSync(corePath)) {
  console.error("Error: tests/core.cjs not found. Run 'npm run build:local' or 'node build.mjs' first.");
  process.exit(1);
}
const core = require(corePath);

function parseArgs(argv) {
  const args = argv.slice(2);
  const cmd = args[0] && !args[0].startsWith("-") ? args[0] : "help";
  const flags = {};
  for (let i = cmd === args[0] ? 1 : 0; i < args.length; i++) {
    const a = args[i];
    if (a.startsWith("--")) {
      const key = a.slice(2);
      const next = args[i + 1];
      if (!next || next.startsWith("--")) {
        flags[key] = true;
      } else {
        flags[key] = next;
        i++;
      }
    }
  }
  return { cmd, flags };
}

function printHelp() {
  console.log(`ClearHot Offline CNN & Local Inference Cache CLI (v${core.VERSION})
=======================================================================
Offline by design: all datasets, model checkpoints, evaluation reports and
frame caches stay on your local disk. No network calls or cloud uploads.

Usage:
  node scripts/cnn-cli.mjs <command> [options]

Commands:
  help
      Show this help message and command reference.

  demo-two-cycles [--out-dir <dir>]
      Run the complete end-to-end 2-cycle synthetic offline CNN loop on disk:
      1) Generates synthetic datasets v1 and v2 on disk.
      2) Cycle 1: trains ckpt-cycle1-synth-v1, evaluates against frozen Argos 2
         Stage 1 baseline, passes all 7 mandatory safety gates, simulates
         explicit human approval, and promotes to ACTIVE.
      3) Cycle 2 (Failing Candidate): evaluates a regressing candidate, verifies
         safety gates reject it and block promotion.
      4) Cycle 2 (Validated Candidate + Rollback): trains ckpt-cycle2-synth-v2 on
         expanded data, validates, promotes, and executes atomic ROLLBACK to
         restore the exact Cycle 1 active checkpoint (verifying weightsSha256).
      5) Generates a 75-frame local test recording (.raw) and its precomputed
         CNN inference cache (.chcache.bin + .chcache.json) for player review.

  generate-synth [--version 1|2] [--width 64] [--height 64] --out-dir <dir>
      Generate deterministic synthetic known-clean 14-bit pairs (.raw) and
      a validated dataset manifest (manifest.json) on disk.

  validate-dataset --manifest <manifest.json> [--verify-files]
      Validate a dataset manifest (synthetic or user-curated real pairs):
      enforces human attestation, 14-bit count domain, split disjointness,
      no content-hash leakage, no adjacent-frame Noise2Noise targets, and
      (with --verify-files) verifies full-file SHA-256 of every .raw file.

  train --manifest <manifest.json> --registry <dir> --id <ckptId>
        [--cycle 1] [--steps 28] [--seed 1337] [--lr 0.006] [--init-from <ckpt.json>]
      Train a ClearHotResidualCNN14 candidate checkpoint on the validated train
      split and register it as 'candidate' in <dir>/registry.json.

  evaluate --registry <dir> --id <ckptId> --manifest <manifest.json>
           [--final-test --reviewer "<name>" --reason "<reason>"]
      Evaluate a registered candidate against raw identity, frozen Original
      Argos 2 Stage 1, and the current active checkpoint. Checks all 7 safety
      gates and updates status to 'validated' or 'rejected'.

  promote --registry <dir> --id <ckptId> --approve --reviewer "<name>" --note "<text>"
      Explicitly approve and promote a 'validated' candidate to 'active'.
      Fails if --approve is omitted or if any mandatory safety gate failed.

  reject --registry <dir> --id <ckptId> --reviewer "<name>" --reason "<text>"
      Explicitly mark a candidate checkpoint as 'rejected' in the registry.

  rollback --registry <dir> --reviewer "<name>" --reason "<text>"
      Atomically roll back from the current active model to the previous active
      checkpoint (or classical Argos 2 baseline if none), verifying SHA-256.

  infer-cache --input <recording.raw> --out-prefix <path/prefix>
              [--registry <dir> | --checkpoint <ckpt.json>]
              [--width 640] [--height 512] [--header 0] [--shift 0] [--endian le|be] [--yes]
      Predict disk space, prompt for confirmation (unless --yes), verify full
      recording SHA-256, and generate a frame-accurate local inference cache
      (<prefix>.chcache.bin + <prefix>.chcache.json) for ClearHot_Local.html.
`);
}

function loadOrCreateRegistry(regDir) {
  fs.mkdirSync(path.join(regDir, "checkpoints"), { recursive: true });
  fs.mkdirSync(path.join(regDir, "reports"), { recursive: true });
  const regFile = path.join(regDir, "registry.json");
  if (fs.existsSync(regFile)) {
    return JSON.parse(fs.readFileSync(regFile, "utf8"));
  }
  return core.createEmptyRegistry();
}

function saveRegistry(regDir, state) {
  fs.mkdirSync(path.join(regDir, "checkpoints"), { recursive: true });
  fs.mkdirSync(path.join(regDir, "reports"), { recursive: true });
  fs.writeFileSync(path.join(regDir, "registry.json"), JSON.stringify(state, null, 2));
  for (const [id, ckpt] of Object.entries(state.checkpoints)) {
    fs.writeFileSync(path.join(regDir, "checkpoints", `${id}.json`), JSON.stringify(ckpt, null, 2));
  }
  for (const [id, rep] of Object.entries(state.validationReports)) {
    fs.writeFileSync(path.join(regDir, "reports", `${id}-eval.json`), JSON.stringify(rep, null, 2));
  }
  if (state.activeCheckpointId && state.checkpoints[state.activeCheckpointId]) {
    fs.writeFileSync(
      path.join(regDir, "active_model.json"),
      JSON.stringify(state.checkpoints[state.activeCheckpointId], null, 2)
    );
  } else {
    const activePath = path.join(regDir, "active_model.json");
    if (fs.existsSync(activePath)) fs.unlinkSync(activePath);
  }
}

function loadPairsFromManifestOnDisk(manifestPath) {
  const baseDir = path.dirname(path.resolve(manifestPath));
  const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
  const valRes = core.validateDatasetManifest(manifest);
  if (!valRes.valid) {
    throw new Error(`Manifest validation failed:\n- ${valRes.errors.join("\n- ")}`);
  }
  const pairs = manifest.entries.map((entry) => {
    const srcPath = path.resolve(baseDir, entry.sourceFile);
    const tgtPath = path.resolve(baseDir, entry.targetFile);
    if (!fs.existsSync(srcPath)) throw new Error(`Missing source file: ${srcPath}`);
    if (!fs.existsSync(tgtPath)) throw new Error(`Missing target file: ${tgtPath}`);
    const srcBytes = new Uint8Array(fs.readFileSync(srcPath));
    const tgtBytes = new Uint8Array(fs.readFileSync(tgtPath));
    const decoded = core.verifyAndDecodeCuratedPair(entry, srcBytes, tgtBytes);
    // Reconstruct wireMask for thin_wire_and_mast synthetic fixtures if applicable
    if (entry.synthetic && (entry.scenarioTag === "thin_wire_and_mast" || entry.scenarioTag === "mixed_stripes_and_targets")) {
      const W = entry.decoder.width;
      const H = entry.decoder.height;
      const mask = new Uint8Array(W * H);
      for (let y = 2; y < H - 2; y++) {
        for (let x = 2; x < W - 2; x++) {
          const idx = y * W + x;
          const c = decoded.clean14[idx];
          const bgH = 0.5 * (decoded.clean14[idx - 2] + decoded.clean14[idx + 2]);
          const bgV = 0.5 * (decoded.clean14[idx - 2 * W] + decoded.clean14[idx + 2 * W]);
          if (c - bgH > 180 || c - bgV > 180) mask[idx] = 1;
        }
      }
      decoded.wireMask = mask;
    }
    return decoded;
  });
  return { manifest, pairs, validation: valRes };
}

async function promptConfirm(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => {
    rl.question(question, (ans) => {
      rl.close();
      resolve(/^y(es)?$/i.test(ans.trim()));
    });
  });
}

async function main() {
  const { cmd, flags } = parseArgs(process.argv);

  if (cmd === "help" || flags.help) {
    printHelp();
    return;
  }

  if (cmd === "generate-synth") {
    const outDir = path.resolve(String(flags["out-dir"] || "./artifacts/synth_dataset_v1"));
    const version = Number(flags.version || 1) === 2 ? 2 : 1;
    const width = Number(flags.width || 64);
    const height = Number(flags.height || 64);

    fs.mkdirSync(outDir, { recursive: true });
    const { manifest, pairs, validation } = core.buildSyntheticDataset({ version, width, height });
    for (const p of pairs) {
      fs.writeFileSync(path.join(outDir, `${p.pairId}_noisy.raw`), core.encodeUint16LeBytes(p.noisy14));
      fs.writeFileSync(path.join(outDir, `${p.pairId}_clean.raw`), core.encodeUint16LeBytes(p.clean14));
    }
    const manifestPath = path.join(outDir, "manifest.json");
    fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
    console.log(`[SYNTHETIC DATASET GENERATED] ${manifest.datasetId}`);
    console.log(`  Directory:   ${outDir}`);
    console.log(`  Manifest:    ${manifestPath}`);
    console.log(`  Dimensions:  ${width}x${height} (14-bit uint16 LE)`);
    console.log(
      `  Splits:      train=${validation.summary.trainCount}, validation=${validation.summary.validationCount}, final_test=${validation.summary.finalTestCount}`
    );
    console.log(`  Valid:       ${validation.valid}`);
    return;
  }

  if (cmd === "validate-dataset") {
    const manifestPath = flags.manifest;
    if (!manifestPath) throw new Error("--manifest <path> is required.");
    const manifest = JSON.parse(fs.readFileSync(String(manifestPath), "utf8"));
    const res = core.validateDatasetManifest(manifest);
    console.log(`Dataset Validation Report for '${manifest.datasetId}':`);
    console.log(`  Valid: ${res.valid}`);
    console.log(
      `  Summary: train=${res.summary.trainCount}, val=${res.summary.validationCount}, final_test=${res.summary.finalTestCount}, uniqueRecordings=${res.summary.uniqueRecordings}`
    );
    if (res.warnings.length) {
      console.log("  Warnings / Scientific Boundaries:");
      for (const w of res.warnings) console.log(`    - ${w}`);
    }
    if (!res.valid) {
      console.error("  Validation Errors:");
      for (const e of res.errors) console.error(`    * ${e}`);
      process.exit(1);
    }
    if (flags["verify-files"]) {
      const loaded = loadPairsFromManifestOnDisk(String(manifestPath));
      console.log(`  File Hash & Decode Check: VERIFIED all ${loaded.pairs.length} pairs on disk.`);
    }
    return;
  }

  if (cmd === "train") {
    const manifestPath = flags.manifest;
    const regDir = path.resolve(String(flags.registry || "./artifacts/model_registry"));
    const id = String(flags.id || `ckpt-cand-${Date.now()}`);
    if (!manifestPath) throw new Error("--manifest <path> is required.");

    const { manifest, pairs } = loadPairsFromManifestOnDisk(String(manifestPath));
    const state = loadOrCreateRegistry(regDir);
    let initialWeights = undefined;
    if (flags["init-from"]) {
      const initCkpt = JSON.parse(fs.readFileSync(String(flags["init-from"]), "utf8"));
      initialWeights = initCkpt.weights;
    }

    const ckpt = core.trainCnnCandidate({
      checkpointId: id,
      cycleNumber: Number(flags.cycle || 1),
      manifest,
      pairs,
      seed: Number(flags.seed || 1337),
      steps: Number(flags.steps || 24),
      hyperParams: flags.lr ? { learningRate: Number(flags.lr) } : undefined,
      initialWeights,
      notes: flags.notes ? String(flags.notes) : undefined,
    });

    core.registerCandidateCheckpoint(state, ckpt, "cli-trainer");
    saveRegistry(regDir, state);

    const firstStep = ckpt.stepHistory[0];
    const lastStep = ckpt.stepHistory[ckpt.stepHistory.length - 1];
    console.log(`[CANDIDATE TRAINED & REGISTERED]`);
    console.log(`  Checkpoint ID:       ${ckpt.checkpointId}`);
    console.log(`  Status:              ${ckpt.status.toUpperCase()} (${ckpt.isSimulatedDemo ? "SIMULATED/DEMO" : "CURATED"})`);
    console.log(`  Architecture Hash:   ${ckpt.architectureHash}`);
    console.log(`  Initial Weights SHA: ${ckpt.initialWeightsSha256}`);
    console.log(`  Trained Weights SHA: ${ckpt.weightsSha256}`);
    console.log(`  Total Weight Δ L2:   ${ckpt.totalWeightUpdateL2}`);
    console.log(`  Train Loss:          ${firstStep.trainLoss} -> ${lastStep.trainLoss}`);
    console.log(`  Validation Loss:     ${firstStep.valLoss} -> ${lastStep.valLoss}`);
    return;
  }

  if (cmd === "evaluate") {
    const regDir = path.resolve(String(flags.registry || "./artifacts/model_registry"));
    const id = String(flags.id || "");
    const manifestPath = flags.manifest;
    if (!id || !manifestPath) throw new Error("--id <ckptId> and --manifest <path> are required.");

    const { pairs } = loadPairsFromManifestOnDisk(String(manifestPath));
    const state = loadOrCreateRegistry(regDir);

    if (flags["final-test"]) {
      const rep = core.invokeUntouchedFinalTest(state, {
        checkpointId: id,
        reviewer: String(flags.reviewer || ""),
        reason: String(flags.reason || "CLI final test invocation"),
        pairs,
        unlockFinalTest: true,
      });
      saveRegistry(regDir, state);
      console.log(`[UNTOUCHED FINAL TEST REPORT] Checkpoint: ${id}`);
      console.log(`  Invocation Count: ${state.finalTestInvocations.length}`);
      console.log(`  Mean Raw PSNR:    ${rep.aggregate.meanRawPsnr14Db} dB`);
      console.log(`  Argos 2 Stage 1:  ${rep.aggregate.meanBaselineArgos2Stage1Psnr14Db} dB`);
      console.log(`  Candidate CNN:    ${rep.aggregate.meanCandidateCnnPsnr14Db} dB (Δ = +${rep.aggregate.psnrDeltaVsBaselineDb} dB)`);
      return;
    }

    const rep = core.validateRegisteredCandidate(state, {
      checkpointId: id,
      pairs,
      actor: "cli-evaluator",
    });
    saveRegistry(regDir, state);

    console.log(`[CANDIDATE EVALUATION REPORT] Checkpoint: ${id}`);
    console.log(`  Split:                 ${rep.splitEvaluated} (n=${rep.sampleSize}, synthetic=${rep.syntheticDataOnly})`);
    console.log(`  Mean Raw 14-bit PSNR:  ${rep.aggregate.meanRawPsnr14Db} dB`);
    console.log(`  Argos 2 Stage 1 PSNR:  ${rep.aggregate.meanBaselineArgos2Stage1Psnr14Db} dB`);
    console.log(`  Candidate CNN PSNR:    ${rep.aggregate.meanCandidateCnnPsnr14Db} dB (Δ = +${rep.aggregate.psnrDeltaVsBaselineDb} dB)`);
    console.log(`  Stripe RMS (Base->CNN): ${rep.aggregate.meanBaselineStripeRmsAdu} -> ${rep.aggregate.meanCandidateStripeRmsAdu} ADU`);
    console.log(`  No-Stripe False RMS:   ${rep.aggregate.noStripeFalseCorrectionRmsAdu} ADU`);
    console.log(`  Thin Wire Retention:   min=${rep.aggregate.minThinFeatureRetention}, max=${rep.aggregate.maxThinFeatureRetention}`);
    console.log(`  Mandatory Gates:");`);
    for (const g of rep.gates) {
      console.log(`    - [${g.passed ? "PASS" : "FAIL"}] ${g.gateId}: ${g.measuredValue} ${g.unit} (req: ${g.thresholdValue})`);
    }
    console.log(`  Resulting Status:      ${state.checkpoints[id].status.toUpperCase()}`);
    if (!rep.allMandatoryGatesPassed) {
      process.exitCode = 2;
    }
    return;
  }

  if (cmd === "promote") {
    const regDir = path.resolve(String(flags.registry || "./artifacts/model_registry"));
    const id = String(flags.id || "");
    const state = loadOrCreateRegistry(regDir);
    core.approveAndPromoteCandidate(state, {
      checkpointId: id,
      reviewer: String(flags.reviewer || ""),
      note: String(flags.note || ""),
      explicitHumanApprove: flags.approve === true,
    });
    saveRegistry(regDir, state);
    console.log(`[PROMOTED TO ACTIVE] Checkpoint '${id}' is now ACTIVE.`);
    console.log(`  Previous Active (Rollback target): ${state.previousActiveCheckpointId ?? "none (classical baseline)"}`);
    return;
  }

  if (cmd === "reject") {
    const regDir = path.resolve(String(flags.registry || "./artifacts/model_registry"));
    const id = String(flags.id || "");
    const state = loadOrCreateRegistry(regDir);
    core.rejectCandidateByHuman(state, {
      checkpointId: id,
      reviewer: String(flags.reviewer || ""),
      reason: String(flags.reason || "Rejected via CLI"),
    });
    saveRegistry(regDir, state);
    console.log(`[REJECTED] Candidate '${id}' marked REJECTED.`);
    return;
  }

  if (cmd === "rollback") {
    const regDir = path.resolve(String(flags.registry || "./artifacts/model_registry"));
    const state = loadOrCreateRegistry(regDir);
    const res = core.rollbackActiveModel(state, {
      reviewer: String(flags.reviewer || ""),
      reason: String(flags.reason || "Rollback requested via CLI"),
    });
    saveRegistry(regDir, state);
    console.log(`[ROLLBACK COMPLETE]`);
    console.log(`  Rolled back from: ${res.rolledBackCheckpointId}`);
    console.log(`  Restored Active:  ${res.restoredCheckpointId ?? "none (reverted to classical Argos 2 baseline)"}`);
    return;
  }

  if (cmd === "infer-cache") {
    const inputPath = flags.input ? path.resolve(String(flags.input)) : null;
    const outPrefix = flags["out-prefix"] ? path.resolve(String(flags["out-prefix"])) : null;
    if (!inputPath || !outPrefix) {
      throw new Error("--input <recording.raw> and --out-prefix <path/prefix> are required.");
    }
    if (!fs.existsSync(inputPath)) {
      throw new Error(`Input file does not exist: ${inputPath}`);
    }

    let ckpt = null;
    let isApprovedActive = false;
    if (flags.checkpoint) {
      ckpt = JSON.parse(fs.readFileSync(path.resolve(String(flags.checkpoint)), "utf8"));
      isApprovedActive = ckpt.status === "active" || ckpt.status === "approved";
    } else {
      const regDir = path.resolve(String(flags.registry || "./artifacts/demo_registry"));
      const state = loadOrCreateRegistry(regDir);
      if (!state.activeCheckpointId) {
        throw new Error(`No active checkpoint in registry ${regDir}. Pass --checkpoint or promote a model first.`);
      }
      ckpt = state.checkpoints[state.activeCheckpointId];
      isApprovedActive = true;
    }

    const decoder = {
      width: Number(flags.width || 640),
      height: Number(flags.height || 512),
      headerBytes: Number(flags.header || 0),
      shift: Number(flags.shift || 0),
      littleEndian: String(flags.endian || "le") !== "be",
      bits: 14,
    };

    const stat = fs.statSync(inputPath);
    const { frames, remainder } = core.frameCountFor(stat.size, decoder);
    if (frames < 1) {
      throw new Error(`File ${inputPath} (${stat.size} bytes) contains 0 complete frames for ${decoder.width}x${decoder.height}.`);
    }
    if (remainder > 0) {
      console.warn(`WARNING: File has ${remainder} remainder bytes after ${frames} whole frames. Format hypothesis may not match sensor spec.`);
    }

    const est = core.estimateInferenceCacheDiskBytes(decoder.width, decoder.height, frames);
    console.log(`Local Inference Cache Plan:`);
    console.log(`  Source File:      ${path.basename(inputPath)} (${stat.size.toLocaleString()} bytes, ${frames} frames)`);
    console.log(`  Decoder:          ${decoder.width}x${decoder.height}, 14-bit, ${decoder.littleEndian ? "LE" : "BE"}, header=${decoder.headerBytes}, shift=${decoder.shift}`);
    console.log(`  Model Checkpoint: ${ckpt.checkpointId} (status=${ckpt.status}, SHA=${ckpt.weightsSha256.slice(0, 16)}...)`);
    console.log(`  Predicted Disk:   ${est.humanReadableMiB} (${est.totalBytes.toLocaleString()} bytes)`);

    if (!flags.yes) {
      const ok = await promptConfirm(`Proceed with writing ${est.humanReadableMiB} local cache to '${outPrefix}.chcache.*'? [y/N] `);
      if (!ok) {
        console.log("Aborted by user; no files written.");
        return;
      }
    }

    const sourceBytes = new Uint8Array(fs.readFileSync(inputPath));
    const { manifest, cacheBytes } = core.buildLocalInferenceCache({
      sourceFileName: path.basename(inputPath),
      sourceBytes,
      decoder,
      checkpoint: ckpt,
      isApprovedActiveModel: isApprovedActive,
    });

    fs.mkdirSync(path.dirname(outPrefix), { recursive: true });
    fs.writeFileSync(`${outPrefix}.chcache.bin`, cacheBytes);
    fs.writeFileSync(`${outPrefix}.chcache.json`, JSON.stringify(manifest, null, 2));
    console.log(`[INFERENCE CACHE WRITTEN]`);
    console.log(`  Manifest:   ${outPrefix}.chcache.json`);
    console.log(`  Binary:     ${outPrefix}.chcache.bin (${cacheBytes.byteLength.toLocaleString()} bytes)`);
    console.log(`  Source SHA: ${manifest.sourceSha256}`);
    console.log(`  Cache SHA:  ${manifest.cacheSha256}`);
    return;
  }

  if (cmd === "demo-two-cycles") {
    const outDir = path.resolve(String(flags["out-dir"] || "./artifacts/demo_registry"));
    fs.mkdirSync(outDir, { recursive: true });

    console.log("=== Running 2-Cycle Controlled Offline CNN Loop (Synthetic Fixtures) ===");
    const res = core.runTwoCycleSyntheticDemo({
      width: 64,
      height: 64,
      stepsCycle1: 24,
      stepsCycle2: 28,
      leaveCycle1ActiveAfterRollback: true,
    });

    saveRegistry(outDir, res.registry);

    // Also save synthetic dataset manifests v1 and v2 for inspection
    const ds1Dir = path.join(outDir, "datasets", "synth_v1");
    const ds2Dir = path.join(outDir, "datasets", "synth_v2");
    fs.mkdirSync(ds1Dir, { recursive: true });
    fs.mkdirSync(ds2Dir, { recursive: true });
    const ds1 = core.buildSyntheticDataset({ version: 1, width: 64, height: 64 });
    const ds2 = core.buildSyntheticDataset({ version: 2, width: 64, height: 64 });
    fs.writeFileSync(path.join(ds1Dir, "manifest.json"), JSON.stringify(ds1.manifest, null, 2));
    fs.writeFileSync(path.join(ds2Dir, "manifest.json"), JSON.stringify(ds2.manifest, null, 2));

    // Generate a 75-frame (>60 frames) synthetic recording and its precomputed CNN cache
    const W = 64,
      H = 64,
      numFrames = 75;
    const fb = W * H * 2;
    const recBytes = new Uint8Array(numFrames * fb);
    for (let f = 0; f < numFrames; f++) {
      const frameArr = core.synthetic(W, H, f);
      recBytes.set(core.encodeUint16LeBytes(frameArr), f * fb);
    }
    const recPath = path.join(outDir, "test_recording_75frames_64x64.raw");
    fs.writeFileSync(recPath, recBytes);

    const activeCkpt = res.registry.checkpoints[res.registry.activeCheckpointId];
    const cache = core.buildLocalInferenceCache({
      sourceFileName: path.basename(recPath),
      sourceBytes: recBytes,
      decoder: { width: W, height: H, headerBytes: 0, shift: 0, littleEndian: true, bits: 14 },
      checkpoint: activeCkpt,
      isApprovedActiveModel: true,
    });
    fs.writeFileSync(path.join(outDir, "test_recording_75frames_64x64.chcache.bin"), cache.cacheBytes);
    fs.writeFileSync(
      path.join(outDir, "test_recording_75frames_64x64.chcache.json"),
      JSON.stringify(cache.manifest, null, 2)
    );

    console.log(`1) Cycle 1 Candidate (${res.cycle1Checkpoint.checkpointId}):`);
    console.log(`   - Weights SHA-256:       ${res.cycle1Checkpoint.weightsSha256}`);
    console.log(`   - Train Loss:            ${res.cycle1Checkpoint.stepHistory[0].trainLoss} -> ${res.cycle1Checkpoint.stepHistory.at(-1).trainLoss}`);
    console.log(`   - Validation PSNR (14b): ${res.cycle1Report.aggregate.meanCandidateCnnPsnr14Db} dB (Argos 2 Stage 1 = ${res.cycle1Report.aggregate.meanBaselineArgos2Stage1Psnr14Db} dB, Δ = +${res.cycle1Report.aggregate.psnrDeltaVsBaselineDb} dB)`);
    console.log(`   - Safety Gates:          ALL 7 PASSED -> Promoted to ACTIVE after simulated human review.`);
    console.log(`2) Cycle 2 Failing Candidate (${res.cycle2FailingCheckpoint.checkpointId}):`);
    console.log(`   - Failed Gates:          [${res.cycle2FailingReport.failedGates.join(", ")}]`);
    console.log(`   - Promotion Attempt:     BLOCKED ("${res.promotionBlockedError}")`);
    console.log(`   - Status:                ${res.cycle2FailingCheckpoint.status.toUpperCase()}`);
    console.log(`3) Cycle 2 Passing Candidate (${res.cycle2PassingCheckpoint.checkpointId}) & Atomic Rollback:`);
    console.log(`   - Validation PSNR (14b): ${res.cycle2PassingReport.aggregate.meanCandidateCnnPsnr14Db} dB (PASSED all 7 gates, promoted)`);
    console.log(`   - Rollback Executed:     Reverted from '${res.rollbackResult.rolledBackCheckpointId}' -> '${res.rollbackResult.restoredCheckpointId}'`);
    console.log(`   - Active Model Restored: ${res.registry.activeCheckpointId} (SHA-256 verified = ${core.verifyCheckpointIntegrity(activeCkpt)})`);
    console.log(`4) 75-Frame Local Recording & Precomputed Cache written to: ${outDir}`);
    return;
  }

  throw new Error(`Unknown command '${cmd}'. Run 'node scripts/cnn-cli.mjs --help' for usage.`);
}

main().catch((err) => {
  console.error("CLI Error:", err.message || err);
  process.exit(1);
});
