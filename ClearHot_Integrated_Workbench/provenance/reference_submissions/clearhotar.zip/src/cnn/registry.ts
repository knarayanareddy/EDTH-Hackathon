import { decodeBuffer, frameBytes, frameCountFor, sha256Bytes, type DecodeConfig } from "../lab/decode";
import {
  computeWeightsSha256,
  deserializeParameters,
  inferCnn14,
} from "./model";
import {
  buildSyntheticDataset,
  encodeUint16LeBytes,
  type InMemoryTrainingPair,
} from "./dataset";
import {
  computeArgos2Stage1Clean14,
  DEFAULT_SAFETY_THRESHOLDS,
  evaluateCnnCandidate,
  trainCnnCandidate,
  type CandidateEvaluationReport,
  type CnnCheckpoint,
  type ModelLifecycleStatus,
  type SafetyGateThresholds,
} from "./evaluator";

export interface HumanApprovalRecord {
  checkpointId: string;
  weightsSha256: string;
  decision: "approved" | "rejected";
  reviewer: string;
  note: string;
  decidedAt: string;
  isSimulatedDemo: boolean;
}

export interface RegistryAuditLogEntry {
  timestamp: string;
  eventType:
    | "simulated/demo"
    | "candidate"
    | "validated"
    | "approved"
    | "active"
    | "rejected"
    | "rollback"
    | "final_test_invoked";
  checkpointId: string | null;
  weightsSha256: string | null;
  actor: string;
  summary: string;
}

export interface FinalTestAuditEntry {
  invokedAt: string;
  checkpointId: string;
  weightsSha256: string;
  reviewer: string;
  reason: string;
  report: CandidateEvaluationReport;
}

export interface ModelRegistryState {
  schema: "clearhot-model-registry-v1";
  createdAt: string;
  updatedAt: string;
  activeCheckpointId: string | null;
  previousActiveCheckpointId: string | null;
  promotionStack: string[];
  checkpoints: Record<string, CnnCheckpoint>;
  validationReports: Record<string, CandidateEvaluationReport>;
  approvalRecords: Record<string, HumanApprovalRecord>;
  auditLog: RegistryAuditLogEntry[];
  finalTestInvocations: FinalTestAuditEntry[];
}

export function createEmptyRegistry(): ModelRegistryState {
  const now = new Date().toISOString();
  return {
    schema: "clearhot-model-registry-v1",
    createdAt: now,
    updatedAt: now,
    activeCheckpointId: null,
    previousActiveCheckpointId: null,
    promotionStack: [],
    checkpoints: {},
    validationReports: {},
    approvalRecords: {},
    auditLog: [],
    finalTestInvocations: [],
  };
}

export function verifyCheckpointIntegrity(ckpt: CnnCheckpoint): boolean {
  if (!ckpt || ckpt.schema !== "clearhot-cnn-checkpoint-v1") return false;
  const params = deserializeParameters(ckpt.weights);
  const actualHash = computeWeightsSha256(params);
  return actualHash.toLowerCase() === ckpt.weightsSha256.toLowerCase();
}

export function registerCandidateCheckpoint(
  state: ModelRegistryState,
  ckpt: CnnCheckpoint,
  actor = "local-trainer"
): ModelRegistryState {
  if (!verifyCheckpointIntegrity(ckpt)) {
    throw new Error(`Checkpoint '${ckpt.checkpointId}' failed weightsSha256 integrity check.`);
  }
  const copy: CnnCheckpoint = { ...ckpt, status: "candidate" };
  state.checkpoints[ckpt.checkpointId] = copy;
  state.updatedAt = new Date().toISOString();
  state.auditLog.push({
    timestamp: state.updatedAt,
    eventType: ckpt.isSimulatedDemo ? "simulated/demo" : "candidate",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor,
    summary: `Registered ${ckpt.isSimulatedDemo ? "[SIMULATED/DEMO] " : ""}candidate '${ckpt.checkpointId}' (cycle ${ckpt.cycleNumber}, steps=${ckpt.stepsRun}, weightUpdateL2=${ckpt.totalWeightUpdateL2}).`,
  });
  state.auditLog.push({
    timestamp: state.updatedAt,
    eventType: "candidate",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor,
    summary: `Candidate '${ckpt.checkpointId}' awaiting validation against frozen classical Argos 2 baseline.`,
  });
  return state;
}

export function validateRegisteredCandidate(
  state: ModelRegistryState,
  params: {
    checkpointId: string;
    pairs: InMemoryTrainingPair[];
    thresholds?: SafetyGateThresholds;
    actor?: string;
  }
): CandidateEvaluationReport {
  const ckpt = state.checkpoints[params.checkpointId];
  if (!ckpt) {
    throw new Error(`Checkpoint '${params.checkpointId}' not found in registry.`);
  }
  if (!verifyCheckpointIntegrity(ckpt)) {
    throw new Error(`Checkpoint '${params.checkpointId}' failed weightsSha256 verification before validation.`);
  }
  const activeCkpt = state.activeCheckpointId ? state.checkpoints[state.activeCheckpointId] ?? null : null;
  const report = evaluateCnnCandidate({
    candidate: ckpt,
    activeCheckpoint: activeCkpt,
    pairs: params.pairs,
    split: "validation",
    thresholds: params.thresholds ?? DEFAULT_SAFETY_THRESHOLDS,
  });

  state.validationReports[ckpt.checkpointId] = report;
  state.updatedAt = new Date().toISOString();

  if (report.allMandatoryGatesPassed) {
    ckpt.status = "validated";
    state.auditLog.push({
      timestamp: state.updatedAt,
      eventType: "validated",
      checkpointId: ckpt.checkpointId,
      weightsSha256: ckpt.weightsSha256,
      actor: params.actor ?? "local-evaluator",
      summary: `Validated '${ckpt.checkpointId}': PASSED all ${report.gates.length} mandatory safety gates (ΔPSNR vs Argos 2 Stage 1 = +${report.aggregate.psnrDeltaVsBaselineDb.toFixed(2)} dB). Requires explicit human approval before promotion.`,
    });
  } else {
    ckpt.status = "rejected";
    state.auditLog.push({
      timestamp: state.updatedAt,
      eventType: "rejected",
      checkpointId: ckpt.checkpointId,
      weightsSha256: ckpt.weightsSha256,
      actor: params.actor ?? "local-evaluator",
      summary: `Candidate '${ckpt.checkpointId}' FAILED mandatory safety gate(s): [${report.failedGates.join(", ")}]. Automatically marked REJECTED and blocked from promotion.`,
    });
  }

  return report;
}

export function approveAndPromoteCandidate(
  state: ModelRegistryState,
  params: {
    checkpointId: string;
    reviewer: string;
    note: string;
    explicitHumanApprove: boolean;
  }
): ModelRegistryState {
  if (params.explicitHumanApprove !== true) {
    throw new Error("Promotion refused: explicitHumanApprove must be true. Auto-promotion without human sign-off is forbidden.");
  }
  if (!params.reviewer || params.reviewer.trim().length < 2) {
    throw new Error("Promotion refused: a human reviewer identity or pseudonym is required.");
  }
  if (!params.note || params.note.trim().length < 4) {
    throw new Error("Promotion refused: an approval note documenting the review decision is required.");
  }

  const ckpt = state.checkpoints[params.checkpointId];
  if (!ckpt) {
    throw new Error(`Checkpoint '${params.checkpointId}' does not exist in registry.`);
  }
  if (!verifyCheckpointIntegrity(ckpt)) {
    throw new Error(`Checkpoint '${params.checkpointId}' failed weightsSha256 integrity verification.`);
  }

  const report = state.validationReports[params.checkpointId];
  if (!report) {
    throw new Error(`Cannot promote '${params.checkpointId}': candidate has not been validated yet.`);
  }
  if (!report.allMandatoryGatesPassed) {
    ckpt.status = "rejected";
    throw new Error(
      `Cannot promote '${params.checkpointId}': candidate failed mandatory safety gate(s) [${report.failedGates.join(", ")}].`
    );
  }
  if (ckpt.status === "rejected") {
    throw new Error(`Cannot promote '${params.checkpointId}': candidate status is 'rejected'.`);
  }

  const now = new Date().toISOString();

  // Demote current active model to 'approved' and push onto promotionStack for atomic rollback
  if (state.activeCheckpointId && state.activeCheckpointId !== ckpt.checkpointId) {
    const prev = state.checkpoints[state.activeCheckpointId];
    if (prev) prev.status = "approved";
    state.previousActiveCheckpointId = state.activeCheckpointId;
    state.promotionStack.push(state.activeCheckpointId);
  }

  ckpt.status = "active";
  state.activeCheckpointId = ckpt.checkpointId;
  state.updatedAt = now;

  state.approvalRecords[ckpt.checkpointId] = {
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    decision: "approved",
    reviewer: params.reviewer.trim(),
    note: params.note.trim(),
    decidedAt: now,
    isSimulatedDemo: ckpt.isSimulatedDemo,
  };

  state.auditLog.push({
    timestamp: now,
    eventType: "approved",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor: params.reviewer.trim(),
    summary: `Human reviewer '${params.reviewer.trim()}' APPROVED '${ckpt.checkpointId}' (${ckpt.isSimulatedDemo ? "simulated/demo" : "curated"}): ${params.note.trim()}`,
  });

  state.auditLog.push({
    timestamp: now,
    eventType: "active",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor: params.reviewer.trim(),
    summary: `Promoted '${ckpt.checkpointId}' to ACTIVE model (previous active: ${state.previousActiveCheckpointId ?? "none / classical baseline"}).`,
  });

  return state;
}

export function rejectCandidateByHuman(
  state: ModelRegistryState,
  params: {
    checkpointId: string;
    reviewer: string;
    reason: string;
  }
): ModelRegistryState {
  if (!params.reviewer || params.reviewer.trim().length < 2) {
    throw new Error("Reviewer identity is required to record a rejection.");
  }
  const ckpt = state.checkpoints[params.checkpointId];
  if (!ckpt) {
    throw new Error(`Checkpoint '${params.checkpointId}' not found.`);
  }
  const now = new Date().toISOString();
  if (state.activeCheckpointId === ckpt.checkpointId) {
    throw new Error(
      `Checkpoint '${ckpt.checkpointId}' is currently active; use rollbackActiveModel() to revert to the previous active model or classical baseline.`
    );
  }
  ckpt.status = "rejected";
  state.approvalRecords[ckpt.checkpointId] = {
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    decision: "rejected",
    reviewer: params.reviewer.trim(),
    note: params.reason.trim(),
    decidedAt: now,
    isSimulatedDemo: ckpt.isSimulatedDemo,
  };
  state.updatedAt = now;
  state.auditLog.push({
    timestamp: now,
    eventType: "rejected",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor: params.reviewer.trim(),
    summary: `Human reviewer '${params.reviewer.trim()}' REJECTED candidate '${ckpt.checkpointId}': ${params.reason.trim()}`,
  });
  return state;
}

export function rollbackActiveModel(
  state: ModelRegistryState,
  params: {
    reviewer: string;
    reason: string;
  }
): { restoredCheckpointId: string | null; rolledBackCheckpointId: string | null } {
  if (!params.reviewer || params.reviewer.trim().length < 2) {
    throw new Error("Reviewer identity is required for rollback.");
  }
  const rolledBackId = state.activeCheckpointId;
  if (!rolledBackId) {
    throw new Error("No active CNN checkpoint is currently promoted; already at classical baseline.");
  }

  const rolledBackCkpt = state.checkpoints[rolledBackId];
  if (rolledBackCkpt) {
    rolledBackCkpt.status = "rejected";
  }

  const nextActiveId =
    state.promotionStack.length > 0
      ? state.promotionStack.pop()!
      : state.previousActiveCheckpointId;

  if (nextActiveId) {
    const restored = state.checkpoints[nextActiveId];
    if (!restored || !verifyCheckpointIntegrity(restored)) {
      throw new Error(`Rollback target checkpoint '${nextActiveId}' failed integrity verification.`);
    }
    restored.status = "active";
    state.activeCheckpointId = restored.checkpointId;
    state.previousActiveCheckpointId =
      state.promotionStack.length > 0 ? state.promotionStack[state.promotionStack.length - 1] : null;
  } else {
    state.activeCheckpointId = null;
    state.previousActiveCheckpointId = null;
  }

  const now = new Date().toISOString();
  state.updatedAt = now;
  state.auditLog.push({
    timestamp: now,
    eventType: "rollback",
    checkpointId: state.activeCheckpointId,
    weightsSha256: state.activeCheckpointId ? state.checkpoints[state.activeCheckpointId]?.weightsSha256 ?? null : null,
    actor: params.reviewer.trim(),
    summary: `ROLLBACK executed by '${params.reviewer.trim()}' (${params.reason.trim()}): reverted from '${rolledBackId}' to '${state.activeCheckpointId ?? "classical Argos 2 baseline"}'.`,
  });

  return {
    restoredCheckpointId: state.activeCheckpointId,
    rolledBackCheckpointId: rolledBackId,
  };
}

export function invokeUntouchedFinalTest(
  state: ModelRegistryState,
  params: {
    checkpointId: string;
    reviewer: string;
    reason: string;
    pairs: InMemoryTrainingPair[];
    unlockFinalTest: boolean;
  }
): CandidateEvaluationReport {
  if (params.unlockFinalTest !== true) {
    throw new Error("Final test split is locked by default. Pass unlockFinalTest=true only for final once-off evaluation.");
  }
  if (!params.reviewer || params.reviewer.trim().length < 2) {
    throw new Error("Reviewer identity is required when unlocking the final_test split.");
  }
  const ckpt = state.checkpoints[params.checkpointId];
  if (!ckpt || !verifyCheckpointIntegrity(ckpt)) {
    throw new Error(`Invalid or missing checkpoint '${params.checkpointId}'.`);
  }

  const report = evaluateCnnCandidate({
    candidate: ckpt,
    pairs: params.pairs,
    split: "final_test",
  });

  const now = new Date().toISOString();
  state.finalTestInvocations.push({
    invokedAt: now,
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    reviewer: params.reviewer.trim(),
    reason: params.reason.trim(),
    report,
  });
  state.updatedAt = now;
  state.auditLog.push({
    timestamp: now,
    eventType: "final_test_invoked",
    checkpointId: ckpt.checkpointId,
    weightsSha256: ckpt.weightsSha256,
    actor: params.reviewer.trim(),
    summary: `UNTOUCHED FINAL TEST invoked by '${params.reviewer.trim()}' on '${ckpt.checkpointId}' (invocation #${state.finalTestInvocations.length}): mean 14-bit PSNR = ${report.aggregate.meanCandidateCnnPsnr14Db.toFixed(2)} dB (Δ vs Argos 2 Stage 1 = +${report.aggregate.psnrDeltaVsBaselineDb.toFixed(2)} dB).`,
  });

  return report;
}

/**
 * Runs the complete two-cycle synthetic demonstration required by Section 4.3:
 * - Cycle 1: Train ckpt-cycle1-synth -> validate -> pass gates -> explicit human approval -> promote to active.
 * - Cycle 2 (Failing candidate): Add curated v2 data -> evaluate a regressing candidate ckpt-cycle2-failing ->
 *   fails mandatory gates -> rejected and blocked from promotion.
 * - Cycle 2 (Valid candidate + Rollback verification): Train ckpt-cycle2-synth -> validate -> promote ->
 *   rollback to ckpt-cycle1-synth and verify exact checkpoint hash restoration.
 */
export function runTwoCycleSyntheticDemo(options?: {
  width?: number;
  height?: number;
  stepsCycle1?: number;
  stepsCycle2?: number;
  leaveCycle1ActiveAfterRollback?: boolean;
}): {
  registry: ModelRegistryState;
  cycle1Checkpoint: CnnCheckpoint;
  cycle1Report: CandidateEvaluationReport;
  cycle2FailingCheckpoint: CnnCheckpoint;
  cycle2FailingReport: CandidateEvaluationReport;
  cycle2PassingCheckpoint: CnnCheckpoint;
  cycle2PassingReport: CandidateEvaluationReport;
  promotionBlockedError: string;
  rollbackResult: { restoredCheckpointId: string | null; rolledBackCheckpointId: string | null };
} {
  const width = options?.width ?? 64;
  const height = options?.height ?? 64;
  const steps1 = options?.stepsCycle1 ?? 24;
  const steps2 = options?.stepsCycle2 ?? 28;
  const leaveCycle1Active = options?.leaveCycle1ActiveAfterRollback ?? true;

  const registry = createEmptyRegistry();

  // --- CYCLE 1: Initial Synthetic Dataset v1 ---
  const dsV1 = buildSyntheticDataset({ version: 1, width, height });
  const ckpt1 = trainCnnCandidate({
    checkpointId: "ckpt-cycle1-synth-v1",
    cycleNumber: 1,
    manifest: dsV1.manifest,
    pairs: dsV1.pairs,
    seed: 1337,
    steps: steps1,
    notes: "Cycle 1 synthetic demonstration model trained on synth-v1 (4 training scenes, 4 disjoint validation scenes).",
  });
  registerCandidateCheckpoint(registry, ckpt1, "demo-trainer-cycle1");
  const report1 = validateRegisteredCandidate(registry, {
    checkpointId: ckpt1.checkpointId,
    pairs: dsV1.pairs,
    actor: "demo-evaluator-cycle1",
  });

  approveAndPromoteCandidate(registry, {
    checkpointId: ckpt1.checkpointId,
    reviewer: "Demo Operator (Simulated Human Review)",
    note: "Cycle 1 simulated approval: all 7 safety gates passed on synthetic validation; promoted as active demo model.",
    explicitHumanApprove: true,
  });

  // --- CYCLE 2A: Curated Dataset Expansion (v2) + Deliberately Failing Candidate ---
  const dsV2 = buildSyntheticDataset({ version: 2, width, height });
  const badWeights = structuredClone(ckpt1.weights);
  // Corrupt branchScales and conv3B to induce severe false correction on stripe-free scenes and PSNR regression
  badWeights.branchScales = [4.5, -3.8, -3.8];
  badWeights.conv3B = [1.85];
  const badParams = deserializeParameters(badWeights);
  const ckpt2Failing: CnnCheckpoint = {
    ...structuredClone(ckpt1),
    checkpointId: "ckpt-cycle2-regressing-cand",
    cycleNumber: 2,
    createdAt: new Date().toISOString(),
    status: "candidate",
    weights: badWeights,
    weightsSha256: computeWeightsSha256(badParams),
    notes: "Cycle 2 deliberately over-aggressive candidate to verify safety-gate rejection.",
  };

  registerCandidateCheckpoint(registry, ckpt2Failing, "demo-trainer-cycle2");
  const report2Failing = validateRegisteredCandidate(registry, {
    checkpointId: ckpt2Failing.checkpointId,
    pairs: dsV2.pairs,
    actor: "demo-evaluator-cycle2",
  });

  let promotionBlockedError = "";
  try {
    approveAndPromoteCandidate(registry, {
      checkpointId: ckpt2Failing.checkpointId,
      reviewer: "Demo Operator",
      note: "Attempted promotion of failing candidate (must be blocked by safety gates).",
      explicitHumanApprove: true,
    });
  } catch (err) {
    promotionBlockedError = String(err instanceof Error ? err.message : err);
  }

  // --- CYCLE 2B: Second Validated Candidate on Expanded Dataset v2 + Rollback Test ---
  const ckpt2Passing = trainCnnCandidate({
    checkpointId: "ckpt-cycle2-synth-v2",
    cycleNumber: 2,
    manifest: dsV2.manifest,
    pairs: dsV2.pairs,
    seed: 2026,
    steps: steps2,
    initialWeights: ckpt1.weights,
    hyperParams: { learningRate: 0.0008 },
    notes: "Cycle 2 fine-tuned candidate on expanded curated synthetic dataset v2 (7 training scenes).",
  });
  registerCandidateCheckpoint(registry, ckpt2Passing, "demo-trainer-cycle2");
  const report2Passing = validateRegisteredCandidate(registry, {
    checkpointId: ckpt2Passing.checkpointId,
    pairs: dsV2.pairs,
    actor: "demo-evaluator-cycle2",
  });

  approveAndPromoteCandidate(registry, {
    checkpointId: ckpt2Passing.checkpointId,
    reviewer: "Demo Operator (Simulated Human Review)",
    note: "Cycle 2 simulated approval: fine-tuned candidate passed all safety gates on v2.",
    explicitHumanApprove: true,
  });

  // Exercise atomic rollback to verify exact previous active model (ckpt-cycle1-synth-v1) is restored
  const rollbackResult = rollbackActiveModel(registry, {
    reviewer: "Demo Operator (Rollback Drill)",
    reason: "Verifying atomic rollback restores exact Cycle 1 checkpoint identity and weightsSha256.",
  });

  if (!leaveCycle1Active) {
    // Re-validate and re-promote Cycle 2 if caller wants Cycle 2 active at end
    registry.checkpoints[ckpt2Passing.checkpointId].status = "validated";
    approveAndPromoteCandidate(registry, {
      checkpointId: ckpt2Passing.checkpointId,
      reviewer: "Demo Operator",
      note: "Re-promoted Cycle 2 after successful rollback verification.",
      explicitHumanApprove: true,
    });
  }

  return {
    registry,
    cycle1Checkpoint: registry.checkpoints[ckpt1.checkpointId],
    cycle1Report: report1,
    cycle2FailingCheckpoint: registry.checkpoints[ckpt2Failing.checkpointId],
    cycle2FailingReport: report2Failing,
    cycle2PassingCheckpoint: registry.checkpoints[ckpt2Passing.checkpointId],
    cycle2PassingReport: report2Passing,
    promotionBlockedError,
    rollbackResult,
  };
}

// ============================================================================
// LOCAL PRECOMPUTED INFERENCE CACHE FOR VIDEO PLAYBACK INTEGRATION (Sec 4.4)
// ============================================================================

export interface LocalInferenceCacheManifest {
  schema: "clearhot-inference-cache-v1";
  createdAt: string;
  sourceFileName: string;
  sourceByteLength: number;
  sourceSha256: string;
  frameCount: number;
  decoder: DecodeConfig;
  checkpointId: string;
  checkpointWeightsSha256: string;
  checkpointStatus: ModelLifecycleStatus;
  isApprovedActiveModel: boolean;
  isSimulatedDemoModel: boolean;
  insertionMode: "post_stage1_14bit" | "raw_14bit";
  cacheByteLength: number;
  cacheSha256: string;
}

export function estimateInferenceCacheDiskBytes(width: number, height: number, frameCount: number): {
  rawCacheBytes: number;
  manifestApproxBytes: number;
  totalBytes: number;
  humanReadableMiB: string;
} {
  const rawCacheBytes = width * height * 2 * frameCount;
  const manifestApproxBytes = 2048;
  const totalBytes = rawCacheBytes + manifestApproxBytes;
  return {
    rawCacheBytes,
    manifestApproxBytes,
    totalBytes,
    humanReadableMiB: `${(totalBytes / (1024 * 1024)).toFixed(2)} MiB`,
  };
}

/**
 * Processes a local recording byte buffer frame-by-frame with the specified CNN checkpoint
 * and produces a verified local inference cache (.chcache.bin + .chcache.json manifest).
 */
export function buildLocalInferenceCache(params: {
  sourceFileName: string;
  sourceBytes: Uint8Array;
  decoder: DecodeConfig;
  checkpoint: CnnCheckpoint;
  isApprovedActiveModel: boolean;
}): {
  manifest: LocalInferenceCacheManifest;
  cacheBytes: Uint8Array;
} {
  if (!verifyCheckpointIntegrity(params.checkpoint)) {
    throw new Error(`Checkpoint '${params.checkpoint.checkpointId}' failed weightsSha256 integrity verification.`);
  }
  const { frames } = frameCountFor(params.sourceBytes.byteLength, params.decoder);
  if (frames < 1) {
    throw new Error("Source recording has 0 complete frames under the specified decoder configuration.");
  }

  const W = params.decoder.width;
  const H = params.decoder.height;
  const fb = frameBytes(params.decoder);
  const sourceSha256 = sha256Bytes(params.sourceBytes);
  const weights = deserializeParameters(params.checkpoint.weights);
  const hp = params.checkpoint.hyperParams;

  const outBytes = new Uint8Array(frames * fb);
  for (let i = 0; i < frames; i++) {
    const start = params.decoder.headerBytes + i * fb;
    const slice = params.sourceBytes.slice(start, start + fb);
    const raw14 = decodeBuffer(slice.buffer, params.decoder);
    const modelIn =
      hp.insertionMode === "post_stage1_14bit"
        ? computeArgos2Stage1Clean14(raw14, W, H).stage1Clean14
        : Float32Array.from(raw14);
    const inf = inferCnn14(modelIn, W, H, weights, hp, false);
    const frameU16 = new Uint16Array(W * H);
    for (let k = 0; k < W * H; k++) {
      frameU16[k] = Math.max(0, Math.min(16383, Math.round(inf.restored14[k])));
    }
    const encoded = encodeUint16LeBytes(frameU16);
    outBytes.set(encoded, i * fb);
  }

  const cacheSha256 = sha256Bytes(outBytes);
  const manifest: LocalInferenceCacheManifest = {
    schema: "clearhot-inference-cache-v1",
    createdAt: new Date().toISOString(),
    sourceFileName: params.sourceFileName,
    sourceByteLength: params.sourceBytes.byteLength,
    sourceSha256,
    frameCount: frames,
    decoder: params.decoder,
    checkpointId: params.checkpoint.checkpointId,
    checkpointWeightsSha256: params.checkpoint.weightsSha256,
    checkpointStatus: params.checkpoint.status,
    isApprovedActiveModel: params.isApprovedActiveModel,
    isSimulatedDemoModel: params.checkpoint.isSimulatedDemo,
    insertionMode: hp.insertionMode,
    cacheByteLength: outBytes.byteLength,
    cacheSha256,
  };

  return { manifest, cacheBytes: outBytes };
}

/**
 * Validates that a loaded inference cache manifest matches the currently loaded source recording
 * (sourceSha256, byte size, frame count, and decoder dimensions/endian/shift) before reading any frame.
 */
export function verifyCacheAgainstSource(params: {
  manifest: LocalInferenceCacheManifest;
  sourceByteLength: number;
  sourceSha256: string | null;
  expectedFrames: number;
  decoder: DecodeConfig;
  requireSha256Match?: boolean;
}): { valid: boolean; error: string | null } {
  const m = params.manifest;
  if (!m || m.schema !== "clearhot-inference-cache-v1") {
    return { valid: false, error: "Invalid inference cache manifest schema." };
  }
  if (m.sourceByteLength !== params.sourceByteLength) {
    return {
      valid: false,
      error: `Cache source size mismatch: cache was built for ${m.sourceByteLength} bytes, current source is ${params.sourceByteLength} bytes.`,
    };
  }
  if (m.frameCount !== params.expectedFrames) {
    return {
      valid: false,
      error: `Cache frame count mismatch: cache has ${m.frameCount} frames, current source has ${params.expectedFrames} frames.`,
    };
  }
  const d = params.decoder;
  if (
    m.decoder.width !== d.width ||
    m.decoder.height !== d.height ||
    m.decoder.headerBytes !== d.headerBytes ||
    m.decoder.shift !== d.shift ||
    m.decoder.littleEndian !== d.littleEndian
  ) {
    return {
      valid: false,
      error: "Cache decoder configuration (width, height, headerBytes, shift, or endianness) does not match current source settings.",
    };
  }
  if (params.requireSha256Match !== false && params.sourceSha256) {
    if (m.sourceSha256.toLowerCase() !== params.sourceSha256.toLowerCase()) {
      return {
        valid: false,
        error: `Cache source SHA-256 mismatch: cache=${m.sourceSha256.slice(0, 16)}..., source=${params.sourceSha256.slice(0, 16)}...`,
      };
    }
  }
  return { valid: true, error: null };
}
