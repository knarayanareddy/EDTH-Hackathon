import { DEFAULT_ISP_CONFIGS, runThermalInstancePipeline } from "../argos/thermalPipelineEngine";
import { createInitialCnnState } from "../argos/cnnPrototypeEngine";
import { toneFn } from "../lab/pipeline";
import {
  allParametersFinite,
  applyAdamStep,
  CNN_ARCHITECTURE_ID,
  computeArchitectureHash,
  computeWeightsSha256,
  countParameters,
  createAdamState,
  createInitialParameters,
  DEFAULT_CNN_HYPERPARAMS,
  deserializeParameters,
  forwardAndBackward,
  inferCnn14,
  parameterL2Distance,
  serializeParameters,
  type AdamOptimizerState,
  type CnnHyperParams,
  type CnnParameterTensors,
  type SerializedCnnWeights,
} from "./model";
import {
  validateDatasetManifest,
  type DatasetManifest,
  type InMemoryTrainingPair,
  type SplitName,
} from "./dataset";

export type ModelLifecycleStatus =
  | "candidate"
  | "validated"
  | "approved"
  | "active"
  | "rejected";

export interface TrainingStepLog {
  step: number;
  trainLoss: number;
  valLoss: number;
  gradNorm: number;
  weightsDeltaL2: number;
  allFinite: boolean;
}

export interface CnnCheckpoint {
  schema: "clearhot-cnn-checkpoint-v1";
  checkpointId: string;
  cycleNumber: number;
  createdAt: string;
  isSimulatedDemo: boolean;
  status: ModelLifecycleStatus;
  architectureId: string;
  architectureHash: string;
  initialWeightsSha256: string;
  weightsSha256: string;
  parameterCount: number;
  seed: number;
  stepsRun: number;
  totalWeightUpdateL2: number;
  hyperParams: CnnHyperParams;
  datasetSummary: {
    datasetId: string;
    version: number;
    synthetic: boolean;
    trainPairs: number;
    validationPairs: number;
  };
  environment: {
    runtime: string;
    platform: string;
    codeVersion: string;
  };
  stepHistory: TrainingStepLog[];
  weights: SerializedCnnWeights;
  optimizerState: AdamOptimizerState;
  notes?: string;
}

export interface SafetyGateThresholds {
  minPsnrDeltaVsBaselineDb: number; // default +0.10 dB on synthetic known-clean validation
  maxStripeRmsRatioVsBaseline: number; // default 1.00 (must not worsen stripe residual vs Argos 2 Stage 1)
  maxNoStripeFalseCorrectionRmsAdu: number; // default 8.0 ADU on clean stripe-free hard negative
  minThinFeatureRetention: number; // default 0.72
  maxThinFeatureOversharpen: number; // default 1.35 (values >1.35 indicate artificial oversharpening)
  maxHaloOvershootAdu: number; // default 18.0 ADU
  maxClippingIncreaseFrac: number; // default 0.01 (1%)
  isTestOnlyThresholdOverride?: boolean;
}

export const DEFAULT_SAFETY_THRESHOLDS: SafetyGateThresholds = {
  minPsnrDeltaVsBaselineDb: 0.1,
  maxStripeRmsRatioVsBaseline: 1.0,
  maxNoStripeFalseCorrectionRmsAdu: 8.0,
  minThinFeatureRetention: 0.72,
  maxThinFeatureOversharpen: 1.35,
  maxHaloOvershootAdu: 18.0,
  maxClippingIncreaseFrac: 0.01,
  isTestOnlyThresholdOverride: false,
};

export interface PerSceneMetricReport {
  pairId: string;
  scenarioTag: string;
  synthetic: boolean;
  rawPsnr14Db: number | null;
  baselineArgos2Stage1Psnr14Db: number | null;
  activeCnnPsnr14Db: number | null;
  candidateCnnPsnr14Db: number | null;
  candidateSsim14: number | null;
  rawColStripeRmsAdu: number;
  baselineColStripeRmsAdu: number;
  candidateColStripeRmsAdu: number;
  rawRowStripeRmsAdu: number;
  baselineRowStripeRmsAdu: number;
  candidateRowStripeRmsAdu: number;
  thinFeatureRetention: number | null;
  haloOvershootAdu: number;
  clipDeltaFrac: number;
}

export interface SafetyGateOutcome {
  gateId: string;
  description: string;
  passed: boolean;
  measuredValue: number;
  thresholdValue: string;
  unit: string;
}

export interface CandidateEvaluationReport {
  schema: "clearhot-cnn-evaluation-v1";
  evaluatedAt: string;
  checkpointId: string;
  checkpointWeightsSha256: string;
  comparedActiveCheckpointId: string | null;
  splitEvaluated: SplitName;
  syntheticDataOnly: boolean;
  domainNote: string;
  sampleSize: number;
  thresholds: SafetyGateThresholds;
  aggregate: {
    meanRawPsnr14Db: number;
    meanBaselineArgos2Stage1Psnr14Db: number;
    meanActiveCnnPsnr14Db: number | null;
    meanCandidateCnnPsnr14Db: number;
    psnrDeltaVsBaselineDb: number;
    psnrDeltaVsActiveDb: number | null;
    meanCandidateSsim14: number;
    meanRawStripeRmsAdu: number;
    meanBaselineStripeRmsAdu: number;
    meanCandidateStripeRmsAdu: number;
    noStripeFalseCorrectionRmsAdu: number;
    minThinFeatureRetention: number;
    maxThinFeatureRetention: number;
    maxHaloOvershootAdu: number;
    maxClipIncreaseFrac: number;
  };
  gates: SafetyGateOutcome[];
  allMandatoryGatesPassed: boolean;
  failedGates: string[];
  perScene: PerSceneMetricReport[];
  tradeoffsAndLimitations: string[];
}

/**
 * Runs untouched Original Argos 2 Stage 1 destriping to produce the 14-bit intermediate input
 * when insertionMode === 'post_stage1_14bit'.
 */
export function computeArgos2Stage1Clean14(raw14: Uint16Array, W: number, H: number): {
  stage1Clean14: Float32Array;
  nativeProcessed8: Uint8ClampedArray;
} {
  const cfg = { ...DEFAULT_ISP_CONFIGS.instance2, enableLiveCnnResidual: false };
  const res = runThermalInstancePipeline({
    methodology: "instance2",
    raw14,
    W,
    H,
    cfg,
    cnnState: createInitialCnnState("instance2"),
    prevBlackRef: { current: 7100 },
    prevWhiteRef: { current: 7950 },
    lastFrameKeyRef: { current: "" },
    prevNormFrameRef: { current: null },
    prevKalman14Ref: { current: null },
    frameKey: "0",
  });
  return {
    stage1Clean14: res.stage1Clean14,
    nativeProcessed8: res.processed8,
  };
}

/**
 * Maps any 14-bit ADU buffer through the locked common monotone reference window [lo, hi] -> 0..255.
 * This provides a controlled common-tone comparison separate from native Argos 2 AGC.
 */
export function map14BitToFixedWindow8(
  buf14: ArrayLike<number>,
  lo: number,
  hi: number
): Uint8Array {
  const fn = toneFn({ lo, hi, gamma: 1, knee: 1 });
  const out = new Uint8Array(buf14.length);
  for (let i = 0; i < buf14.length; i++) out[i] = fn(buf14[i]);
  return out;
}

/**
 * Applies Argos 2 Stage 2/3/4 native enhancement to a CNN-restored 14-bit buffer so the user
 * can view both common-fixed-window CNN output AND native-Argos2-toned CNN output.
 */
export function map14BitThroughArgos2NativeStages(
  restored14: ArrayLike<number>,
  W: number,
  H: number
): Uint8Array {
  // Pass restored14 into Argos 2 with Stage 1 bypassed so Stages 2, 3, and 4 run on the CNN-restored 14-bit frame
  const u16 = new Uint16Array(restored14.length);
  for (let i = 0; i < restored14.length; i++) {
    u16[i] = Math.max(0, Math.min(16383, Math.round(restored14[i])));
  }
  const cfg = {
    ...DEFAULT_ISP_CONFIGS.instance2,
    stage1DestripeAndBadPx: false,
    enableLiveCnnResidual: false,
  };
  const res = runThermalInstancePipeline({
    methodology: "instance2",
    raw14: u16,
    W,
    H,
    cfg,
    cnnState: createInitialCnnState("instance2"),
    prevBlackRef: { current: 7100 },
    prevWhiteRef: { current: 7950 },
    lastFrameKeyRef: { current: "" },
    prevNormFrameRef: { current: null },
    prevKalman14Ref: { current: null },
    frameKey: "0",
  });
  return new Uint8Array(res.processed8);
}

export function computePsnr14Bit(pred14: ArrayLike<number>, clean14: ArrayLike<number>): number {
  const n = pred14.length;
  if (n === 0) return 0;
  let mse = 0;
  for (let i = 0; i < n; i++) {
    const d = pred14[i] - clean14[i];
    mse += d * d;
  }
  mse /= n;
  if (mse < 1e-9) return 99.0;
  return 10 * Math.log10((16383 * 16383) / mse);
}

export function computeSsim14Bit(
  pred14: ArrayLike<number>,
  clean14: ArrayLike<number>,
  W: number,
  H: number
): number {
  const n = W * H;
  if (n === 0) return 1;
  let meanX = 0,
    meanY = 0;
  for (let i = 0; i < n; i++) {
    meanX += pred14[i];
    meanY += clean14[i];
  }
  meanX /= n;
  meanY /= n;
  let varX = 0,
    varY = 0,
    covXY = 0;
  for (let i = 0; i < n; i++) {
    const dx = pred14[i] - meanX;
    const dy = clean14[i] - meanY;
    varX += dx * dx;
    varY += dy * dy;
    covXY += dx * dy;
  }
  varX /= n;
  varY /= n;
  covXY /= n;
  // Dynamic range of typical scene is ~2000 ADU around pedestal
  const L = 2048;
  const c1 = (0.01 * L) ** 2;
  const c2 = (0.03 * L) ** 2;
  return ((2 * meanX * meanY + c1) * (2 * covXY + c2)) / ((meanX ** 2 + meanY ** 2 + c1) * (varX + varY + c2));
}

export function computeFlatStripeRmsAdu(
  buf14: ArrayLike<number>,
  W: number,
  H: number
): { colRms: number; rowRms: number } {
  const y0 = 2;
  const y1 = Math.max(y0 + 4, Math.floor(H * 0.24));
  const x0 = Math.floor(W * 0.15);
  const x1 = Math.max(x0 + 6, Math.floor(W * 0.65));

  const colMeans: number[] = [];
  for (let x = x0; x < x1; x++) {
    let s = 0;
    for (let y = y0; y < y1; y++) s += buf14[y * W + x];
    colMeans.push(s / (y1 - y0));
  }
  let colSq = 0;
  for (let i = 1; i < colMeans.length - 1; i++) {
    const hp = colMeans[i] - 0.5 * (colMeans[i - 1] + colMeans[i + 1]);
    colSq += hp * hp;
  }
  const colRms = Math.sqrt(colSq / Math.max(1, colMeans.length - 2));

  const rowMeans: number[] = [];
  for (let y = y0; y < y1; y++) {
    let s = 0;
    for (let x = x0; x < x1; x++) s += buf14[y * W + x];
    rowMeans.push(s / (x1 - x0));
  }
  let rowSq = 0;
  for (let i = 1; i < rowMeans.length - 1; i++) {
    const hp = rowMeans[i] - 0.5 * (rowMeans[i - 1] + rowMeans[i + 1]);
    rowSq += hp * hp;
  }
  const rowRms = Math.sqrt(rowSq / Math.max(1, rowMeans.length - 2));

  return { colRms, rowRms };
}

export function computeThinFeatureRetention(
  pred14: ArrayLike<number>,
  clean14: ArrayLike<number>,
  wireMask: Uint8Array | undefined,
  W: number,
  H: number
): number | null {
  if (!wireMask) return null;
  let cleanContrastSum = 0;
  let predContrastSum = 0;
  let count = 0;

  for (let y = 2; y < H - 2; y++) {
    for (let x = 2; x < W - 2; x++) {
      const idx = y * W + x;
      if (wireMask[idx] !== 1) continue;
      // Local background 2 pixels away perpendicular to wire/mast
      const bgClean = 0.25 * (clean14[idx - 2] + clean14[idx + 2] + clean14[idx - 2 * W] + clean14[idx + 2 * W]);
      const bgPred = 0.25 * (pred14[idx - 2] + pred14[idx + 2] + pred14[idx - 2 * W] + pred14[idx + 2 * W]);
      const cDiff = Math.abs(clean14[idx] - bgClean);
      if (cDiff > 40) {
        cleanContrastSum += cDiff;
        predContrastSum += Math.abs(pred14[idx] - bgPred);
        count++;
      }
    }
  }
  if (count === 0 || cleanContrastSum < 1e-3) return null;
  return predContrastSum / cleanContrastSum;
}

export function computeHaloOvershootAdu(
  pred14: ArrayLike<number>,
  clean14: ArrayLike<number>,
  W: number,
  H: number
): number {
  let overshootSq = 0;
  let cnt = 0;
  const noiseAllowance = 16; // allow normal read-noise floor around clean step bounds
  for (let y = 2; y < H - 2; y++) {
    for (let x = 2; x < W - 2; x++) {
      const idx = y * W + x;
      const gClean =
        Math.abs(clean14[idx + 1] - clean14[idx - 1]) + Math.abs(clean14[idx + W] - clean14[idx - W]);
      if (gClean > 140) {
        let cMin = Infinity,
          cMax = -Infinity;
        for (let dy = -2; dy <= 2; dy++) {
          for (let dx = -2; dx <= 2; dx++) {
            const cv = clean14[(y + dy) * W + (x + dx)];
            if (cv < cMin) cMin = cv;
            if (cv > cMax) cMax = cv;
          }
        }
        const pv = pred14[idx];
        const over =
          pv > cMax + noiseAllowance
            ? pv - (cMax + noiseAllowance)
            : pv < cMin - noiseAllowance
            ? cMin - noiseAllowance - pv
            : 0;
        overshootSq += over * over;
        cnt++;
      }
    }
  }
  return cnt > 0 ? Math.sqrt(overshootSq / cnt) : 0;
}

/**
 * Trains a new candidate CNN checkpoint on the validated training split and records
 * step-by-step train/validation losses, weight deltas, and cryptographic hashes.
 */
export function trainCnnCandidate(params: {
  checkpointId: string;
  cycleNumber: number;
  manifest: DatasetManifest;
  pairs: InMemoryTrainingPair[];
  seed?: number;
  steps?: number;
  hyperParams?: Partial<CnnHyperParams>;
  initialWeights?: SerializedCnnWeights;
  notes?: string;
}): CnnCheckpoint {
  const validation = validateDatasetManifest(params.manifest);
  if (!validation.valid) {
    throw new Error(`Dataset validation failed; refusing to train:\n- ${validation.errors.join("\n- ")}`);
  }

  const hp: CnnHyperParams = { ...DEFAULT_CNN_HYPERPARAMS, ...(params.hyperParams || {}) };
  const seed = params.seed ?? 1337;
  const steps = params.steps ?? 28;

  const trainPairs = params.pairs.filter((p) => p.split === "train");
  const valPairs = params.pairs.filter((p) => p.split === "validation");
  if (trainPairs.length === 0 || valPairs.length === 0) {
    throw new Error("Both train and validation pairs must be provided in memory.");
  }

  // Precompute classical stage1 inputs if insertionMode === 'post_stage1_14bit'
  const prepareInput = (p: InMemoryTrainingPair): Float32Array => {
    if (hp.insertionMode === "post_stage1_14bit") {
      return computeArgos2Stage1Clean14(p.noisy14, p.width, p.height).stage1Clean14;
    }
    return Float32Array.from(p.noisy14);
  };

  const trainInputs = trainPairs.map(prepareInput);
  const valInputs = valPairs.map(prepareInput);

  const weights: CnnParameterTensors = params.initialWeights
    ? deserializeParameters(params.initialWeights)
    : createInitialParameters(seed, hp);
  const initialSnapshot = deserializeParameters(serializeParameters(weights));
  const initialWeightsSha256 = computeWeightsSha256(weights);
  const opt = createAdamState(weights);

  const stepHistory: TrainingStepLog[] = [];

  for (let s = 1; s <= steps; s++) {
    let trainLossSum = 0;
    let accumGrads: CnnParameterTensors | null = null;

    for (let i = 0; i < trainPairs.length; i++) {
      const p = trainPairs[i];
      const targetForCnn =
        p.scenarioTag === "no_stripe_clean_hard_negative" ? trainInputs[i] : p.clean14;
      const fb = forwardAndBackward(trainInputs[i], targetForCnn, p.width, p.height, weights, hp);
      trainLossSum += fb.loss ?? 0;
      if (!accumGrads) {
        accumGrads = fb.grads!;
      } else {
        for (const k of Object.keys(accumGrads) as (keyof CnnParameterTensors)[]) {
          const dst = accumGrads[k];
          const src = fb.grads![k];
          for (let j = 0; j < dst.length; j++) dst[j] += src[j];
        }
      }
    }

    // Average gradients over training batch
    for (const k of Object.keys(accumGrads!) as (keyof CnnParameterTensors)[]) {
      const dst = accumGrads![k];
      for (let j = 0; j < dst.length; j++) dst[j] /= trainPairs.length;
    }

    const { gradNorm, weightsDeltaL2 } = applyAdamStep(weights, accumGrads!, opt, hp);
    const finite = allParametersFinite(weights);
    if (!finite) {
      throw new Error(`Training failed at step ${s}: non-finite parameter detected.`);
    }

    let valLossSum = 0;
    for (let i = 0; i < valPairs.length; i++) {
      const p = valPairs[i];
      const targetForCnn =
        p.scenarioTag === "no_stripe_clean_hard_negative" ? valInputs[i] : p.clean14;
      const fb = forwardAndBackward(valInputs[i], targetForCnn, p.width, p.height, weights, hp);
      valLossSum += fb.loss ?? 0;
    }

    stepHistory.push({
      step: s,
      trainLoss: Number((trainLossSum / trainPairs.length).toFixed(6)),
      valLoss: Number((valLossSum / valPairs.length).toFixed(6)),
      gradNorm: Number(gradNorm.toFixed(6)),
      weightsDeltaL2: Number(weightsDeltaL2.toFixed(6)),
      allFinite: finite,
    });
  }

  const totalWeightUpdateL2 = Number(parameterL2Distance(initialSnapshot, weights).toFixed(6));
  const weightsSha256 = computeWeightsSha256(weights);

  return {
    schema: "clearhot-cnn-checkpoint-v1",
    checkpointId: params.checkpointId,
    cycleNumber: params.cycleNumber,
    createdAt: new Date().toISOString(),
    isSimulatedDemo: params.manifest.synthetic,
    status: "candidate",
    architectureId: CNN_ARCHITECTURE_ID,
    architectureHash: computeArchitectureHash(hp),
    initialWeightsSha256,
    weightsSha256,
    parameterCount: countParameters(weights),
    seed,
    stepsRun: steps,
    totalWeightUpdateL2,
    hyperParams: hp,
    datasetSummary: {
      datasetId: params.manifest.datasetId,
      version: params.manifest.version,
      synthetic: params.manifest.synthetic,
      trainPairs: trainPairs.length,
      validationPairs: valPairs.length,
    },
    environment: {
      runtime: typeof process !== "undefined" && process.version ? `Node.js ${process.version}` : "Browser JS",
      platform: typeof process !== "undefined" ? `${process.platform}/${process.arch}` : "browser-local",
      codeVersion: "1.2.0",
    },
    stepHistory,
    weights: serializeParameters(weights),
    optimizerState: opt,
    notes: params.notes,
  };
}

/**
 * Evaluates a candidate checkpoint on the specified split ('validation' or explicitly unlocked 'final_test')
 * against raw identity, frozen Original Argos 2 classical baseline, and optional current active checkpoint.
 */
export function evaluateCnnCandidate(params: {
  candidate: CnnCheckpoint;
  activeCheckpoint?: CnnCheckpoint | null;
  pairs: InMemoryTrainingPair[];
  split?: SplitName;
  thresholds?: SafetyGateThresholds;
}): CandidateEvaluationReport {
  const split = params.split ?? "validation";
  const splitPairs = params.pairs.filter((p) => p.split === split);
  if (splitPairs.length === 0) {
    throw new Error(`No pairs found for requested evaluation split '${split}'.`);
  }

  const thresholds = params.thresholds ?? DEFAULT_SAFETY_THRESHOLDS;
  const candWeights = deserializeParameters(params.candidate.weights);
  const activeWeights = params.activeCheckpoint ? deserializeParameters(params.activeCheckpoint.weights) : null;
  const hp = params.candidate.hyperParams;

  const perScene: PerSceneMetricReport[] = [];
  let allOutputsFinite = true;

  for (const p of splitPairs) {
    const W = p.width;
    const H = p.height;
    const N = W * H;

    const { stage1Clean14 } = computeArgos2Stage1Clean14(p.noisy14, W, H);
    const modelInput = hp.insertionMode === "post_stage1_14bit" ? stage1Clean14 : Float32Array.from(p.noisy14);

    const candOut = inferCnn14(modelInput, W, H, candWeights, hp, false);
    for (let i = 0; i < N; i++) {
      if (!Number.isFinite(candOut.restored14[i])) allOutputsFinite = false;
    }

    const activeOut = activeWeights
      ? inferCnn14(modelInput, W, H, activeWeights, params.activeCheckpoint!.hyperParams, false)
      : null;

    const rawPsnr = computePsnr14Bit(p.noisy14, p.clean14);
    const basePsnr = computePsnr14Bit(stage1Clean14, p.clean14);
    const candPsnr = computePsnr14Bit(candOut.restored14, p.clean14);
    const activePsnr = activeOut ? computePsnr14Bit(activeOut.restored14, p.clean14) : null;
    const candSsim = computeSsim14Bit(candOut.restored14, p.clean14, W, H);

    const rawStripes = computeFlatStripeRmsAdu(p.noisy14, W, H);
    const baseStripes = computeFlatStripeRmsAdu(stage1Clean14, W, H);
    const candStripes = computeFlatStripeRmsAdu(candOut.restored14, W, H);

    const thinRet = computeThinFeatureRetention(candOut.restored14, p.clean14, p.wireMask, W, H);
    const haloAdu = computeHaloOvershootAdu(candOut.restored14, p.clean14, W, H);

    let baseClips = 0;
    let candClips = 0;
    for (let i = 0; i < N; i++) {
      if (stage1Clean14[i] <= 0 || stage1Clean14[i] >= 16383) baseClips++;
      if (candOut.restored14[i] <= 0 || candOut.restored14[i] >= 16383) candClips++;
    }
    const clipDeltaFrac = Math.max(0, (candClips - baseClips) / N);

    perScene.push({
      pairId: p.pairId,
      scenarioTag: p.scenarioTag,
      synthetic: p.synthetic,
      rawPsnr14Db: Number(rawPsnr.toFixed(3)),
      baselineArgos2Stage1Psnr14Db: Number(basePsnr.toFixed(3)),
      activeCnnPsnr14Db: activePsnr !== null ? Number(activePsnr.toFixed(3)) : null,
      candidateCnnPsnr14Db: Number(candPsnr.toFixed(3)),
      candidateSsim14: Number(candSsim.toFixed(4)),
      rawColStripeRmsAdu: Number(rawStripes.colRms.toFixed(2)),
      baselineColStripeRmsAdu: Number(baseStripes.colRms.toFixed(2)),
      candidateColStripeRmsAdu: Number(candStripes.colRms.toFixed(2)),
      rawRowStripeRmsAdu: Number(rawStripes.rowRms.toFixed(2)),
      baselineRowStripeRmsAdu: Number(baseStripes.rowRms.toFixed(2)),
      candidateRowStripeRmsAdu: Number(candStripes.rowRms.toFixed(2)),
      thinFeatureRetention: thinRet !== null ? Number(thinRet.toFixed(3)) : null,
      haloOvershootAdu: Number(haloAdu.toFixed(2)),
      clipDeltaFrac: Number(clipDeltaFrac.toFixed(5)),
    });
  }

  const mean = (arr: number[]) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0);

  const meanRawPsnr = mean(perScene.map((s) => s.rawPsnr14Db ?? 0));
  const meanBasePsnr = mean(perScene.map((s) => s.baselineArgos2Stage1Psnr14Db ?? 0));
  const meanCandPsnr = mean(perScene.map((s) => s.candidateCnnPsnr14Db ?? 0));
  const meanActivePsnr = activeWeights ? mean(perScene.map((s) => s.activeCnnPsnr14Db ?? 0)) : null;
  const meanCandSsim = mean(perScene.map((s) => s.candidateSsim14 ?? 0));

  const stripedScenes = perScene.filter((s) => s.scenarioTag !== "no_stripe_clean_hard_negative");
  const meanRawStripe = mean(
    stripedScenes.map((s) => Math.hypot(s.rawColStripeRmsAdu, s.rawRowStripeRmsAdu))
  );
  const meanBaseStripe = mean(
    stripedScenes.map((s) => Math.hypot(s.baselineColStripeRmsAdu, s.baselineRowStripeRmsAdu))
  );
  const meanCandStripe = mean(
    stripedScenes.map((s) => Math.hypot(s.candidateColStripeRmsAdu, s.candidateRowStripeRmsAdu))
  );

  // Measure false correction RMS introduced by the CNN on stripe-free hard negatives
  const noStripePairs = splitPairs.filter((p) => p.scenarioTag === "no_stripe_clean_hard_negative");
  let noStripeRms = 0;
  if (noStripePairs.length > 0) {
    let sq = 0;
    let cnt = 0;
    for (const p of noStripePairs) {
      const { stage1Clean14 } = computeArgos2Stage1Clean14(p.noisy14, p.width, p.height);
      const modelIn = hp.insertionMode === "post_stage1_14bit" ? stage1Clean14 : Float32Array.from(p.noisy14);
      const candOut = inferCnn14(modelIn, p.width, p.height, candWeights, hp, false);
      for (let i = 0; i < modelIn.length; i++) {
        const d = candOut.restored14[i] - modelIn[i];
        sq += d * d;
        cnt++;
      }
    }
    noStripeRms = Math.sqrt(sq / Math.max(1, cnt));
  }

  const thinValues = perScene
    .map((s) => s.thinFeatureRetention)
    .filter((v): v is number => v !== null);
  const minThin = thinValues.length > 0 ? Math.min(...thinValues) : 1.0;
  const maxThin = thinValues.length > 0 ? Math.max(...thinValues) : 1.0;
  const maxHalo = Math.max(...perScene.map((s) => s.haloOvershootAdu));
  const maxClipInc = Math.max(...perScene.map((s) => s.clipDeltaFrac));

  const psnrDeltaVsBaseline = meanCandPsnr - meanBasePsnr;
  const psnrDeltaVsActive = meanActivePsnr !== null ? meanCandPsnr - meanActivePsnr : null;
  const stripeRatio = meanBaseStripe > 1e-6 ? meanCandStripe / meanBaseStripe : 1.0;

  const gates: SafetyGateOutcome[] = [
    {
      gateId: "finite_outputs_gate",
      description: "All restored 14-bit pixels and parameters must be finite",
      passed: allOutputsFinite && allParametersFinite(candWeights),
      measuredValue: allOutputsFinite ? 1 : 0,
      thresholdValue: "== 1 (true)",
      unit: "boolean",
    },
    {
      gateId: "psnr_gain_vs_baseline_gate",
      description: "Mean 14-bit PSNR (dB) must improve over frozen Argos 2 Stage 1 classical baseline",
      passed: psnrDeltaVsBaseline >= thresholds.minPsnrDeltaVsBaselineDb,
      measuredValue: Number(psnrDeltaVsBaseline.toFixed(3)),
      thresholdValue: `>= +${thresholds.minPsnrDeltaVsBaselineDb.toFixed(2)}`,
      unit: "dB (14-bit ADU)",
    },
    {
      gateId: "stripe_residual_reduction_gate",
      description: "Flat-region stripe residual RMS ratio vs classical baseline must not regress",
      passed: stripeRatio <= thresholds.maxStripeRmsRatioVsBaseline,
      measuredValue: Number(stripeRatio.toFixed(3)),
      thresholdValue: `<= ${thresholds.maxStripeRmsRatioVsBaseline.toFixed(2)}`,
      unit: "ratio",
    },
    {
      gateId: "no_stripe_false_correction_gate",
      description: "Clean stripe-free hard-negative scene must not suffer excessive false stripe subtraction",
      passed: noStripeRms <= thresholds.maxNoStripeFalseCorrectionRmsAdu,
      measuredValue: Number(noStripeRms.toFixed(2)),
      thresholdValue: `<= ${thresholds.maxNoStripeFalseCorrectionRmsAdu.toFixed(1)}`,
      unit: "ADU RMS",
    },
    {
      gateId: "thin_feature_retention_gate",
      description: "Individual 1-pixel vertical mast / horizontal wire retention must stay within safe bounds (not erased or artificially oversharpened)",
      passed:
        minThin >= thresholds.minThinFeatureRetention &&
        maxThin <= thresholds.maxThinFeatureOversharpen,
      measuredValue: Number(minThin.toFixed(3)),
      thresholdValue: `[${thresholds.minThinFeatureRetention.toFixed(2)}, ${thresholds.maxThinFeatureOversharpen.toFixed(2)}]`,
      unit: "contrast ratio",
    },
    {
      gateId: "halo_overshoot_gate",
      description: "Step-edge halo overshoot RMS must stay bounded",
      passed: maxHalo <= thresholds.maxHaloOvershootAdu,
      measuredValue: Number(maxHalo.toFixed(2)),
      thresholdValue: `<= ${thresholds.maxHaloOvershootAdu.toFixed(1)}`,
      unit: "ADU RMS",
    },
    {
      gateId: "clipping_safety_gate",
      description: "0 / 16383 saturation clipping fraction increase vs baseline must stay <= 1%",
      passed: maxClipInc <= thresholds.maxClippingIncreaseFrac,
      measuredValue: Number(maxClipInc.toFixed(5)),
      thresholdValue: `<= ${thresholds.maxClippingIncreaseFrac}`,
      unit: "fraction",
    },
  ];

  const failedGates = gates.filter((g) => !g.passed).map((g) => g.gateId);

  return {
    schema: "clearhot-cnn-evaluation-v1",
    evaluatedAt: new Date().toISOString(),
    checkpointId: params.candidate.checkpointId,
    checkpointWeightsSha256: params.candidate.weightsSha256,
    comparedActiveCheckpointId: params.activeCheckpoint?.checkpointId ?? null,
    splitEvaluated: split,
    syntheticDataOnly: splitPairs.every((p) => p.synthetic),
    domainNote:
      "Quantitative PSNR, SSIM, stripe RMS and halo metrics are computed in the 14-bit sensor count (ADU, 0..16383) domain prior to display tone mapping so AGC differences do not distort error measurement.",
    sampleSize: splitPairs.length,
    thresholds,
    aggregate: {
      meanRawPsnr14Db: Number(meanRawPsnr.toFixed(3)),
      meanBaselineArgos2Stage1Psnr14Db: Number(meanBasePsnr.toFixed(3)),
      meanActiveCnnPsnr14Db: meanActivePsnr !== null ? Number(meanActivePsnr.toFixed(3)) : null,
      meanCandidateCnnPsnr14Db: Number(meanCandPsnr.toFixed(3)),
      psnrDeltaVsBaselineDb: Number(psnrDeltaVsBaseline.toFixed(3)),
      psnrDeltaVsActiveDb: psnrDeltaVsActive !== null ? Number(psnrDeltaVsActive.toFixed(3)) : null,
      meanCandidateSsim14: Number(meanCandSsim.toFixed(4)),
      meanRawStripeRmsAdu: Number(meanRawStripe.toFixed(2)),
      meanBaselineStripeRmsAdu: Number(meanBaseStripe.toFixed(2)),
      meanCandidateStripeRmsAdu: Number(meanCandStripe.toFixed(2)),
      noStripeFalseCorrectionRmsAdu: Number(noStripeRms.toFixed(2)),
      minThinFeatureRetention: Number(minThin.toFixed(3)),
      maxThinFeatureRetention: Number(maxThin.toFixed(3)),
      maxHaloOvershootAdu: Number(maxHalo.toFixed(2)),
      maxClipIncreaseFrac: Number(maxClipInc.toFixed(5)),
    },
    gates,
    allMandatoryGatesPassed: failedGates.length === 0,
    failedGates,
    perScene,
    tradeoffsAndLimitations: [
      "Strong alternating column stripes (Nyquist period 2) are suppressed more effectively by the learned 1D profile branch than by Original Argos 2's default trimmed Haar shrinkage, which clips high-amplitude alternating differences.",
      "On clean stripe-free scenes, any non-zero residual represents slight false correction; the no_stripe_false_correction_gate bounds this below 8.0 ADU RMS.",
      "Passing synthetic gates proves software mechanics and regression protection; it does NOT prove improvement on the user's ~180 MB real recording without curated real-data validation and blinded human sequence review.",
    ],
  };
}
