import { sha256Bytes } from "../lab/decode";

export const CNN_ARCHITECTURE_ID = "ClearHotResidualCNN14-v1";
export const ADU_NORM_SCALE = 100.0;

export interface CnnHyperParams {
  spatialChannels: number; // default 6
  profileChannels: number; // default 4
  maxResidualAdu: number; // default 240 ADU safety bound
  insertionMode: "post_stage1_14bit" | "raw_14bit";
  learningRate: number;
  weightDecay: number;
  gradClipNorm: number;
  tileSize: number; // default 128 for tiled inference when requested, or 0 for full-frame
  tileOverlap: number; // default 16
}

export const DEFAULT_CNN_HYPERPARAMS: CnnHyperParams = {
  spatialChannels: 6,
  profileChannels: 4,
  maxResidualAdu: 240,
  insertionMode: "post_stage1_14bit",
  learningRate: 0.006,
  weightDecay: 0.0001,
  gradClipNorm: 5.0,
  tileSize: 0,
  tileOverlap: 16,
};

export interface CnnParameterTensors {
  // 2D Spatial branch: 1 -> C -> C -> 1 (3x3 kernels)
  conv1W: Float32Array; // [C, 1, 3, 3]
  conv1B: Float32Array; // [C]
  conv2W: Float32Array; // [C, C, 3, 3]
  conv2B: Float32Array; // [C]
  conv3W: Float32Array; // [1, C, 3, 3]
  conv3B: Float32Array; // [1]
  // 1D Column profile branch: 1 -> P -> 1 (kernel 5)
  col1W: Float32Array; // [P, 1, 5]
  col1B: Float32Array; // [P]
  col2W: Float32Array; // [1, P, 5]
  col2B: Float32Array; // [1]
  // 1D Row profile branch: 1 -> P -> 1 (kernel 5)
  row1W: Float32Array; // [P, 1, 5]
  row1B: Float32Array; // [P]
  row2W: Float32Array; // [1, P, 5]
  row2B: Float32Array; // [1]
  // Branch fusion scales
  branchScales: Float32Array; // [spatialScale, colScale, rowScale]
}

export interface AdamOptimizerState {
  step: number;
  m: Record<keyof CnnParameterTensors, number[]>;
  v: Record<keyof CnnParameterTensors, number[]>;
}

export interface SerializedCnnWeights {
  conv1W: number[];
  conv1B: number[];
  conv2W: number[];
  conv2B: number[];
  conv3W: number[];
  conv3B: number[];
  col1W: number[];
  col1B: number[];
  col2W: number[];
  col2B: number[];
  row1W: number[];
  row1B: number[];
  row2W: number[];
  row2B: number[];
  branchScales: number[];
}

const PARAM_KEYS: (keyof CnnParameterTensors)[] = [
  "conv1W",
  "conv1B",
  "conv2W",
  "conv2B",
  "conv3W",
  "conv3B",
  "col1W",
  "col1B",
  "col2W",
  "col2B",
  "row1W",
  "row1B",
  "row2W",
  "row2B",
  "branchScales",
];

// Deterministic Mulberry32 PRNG for reproducible weight initialization
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function createInitialParameters(
  seed = 1337,
  hp: CnnHyperParams = DEFAULT_CNN_HYPERPARAMS
): CnnParameterTensors {
  const rng = mulberry32(seed);
  const randn = () => {
    const u1 = Math.max(1e-7, rng());
    const u2 = rng();
    return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  };
  const C = hp.spatialChannels;
  const P = hp.profileChannels;

  const init = (n: number, scale: number) => {
    const out = new Float32Array(n);
    for (let i = 0; i < n; i++) out[i] = randn() * scale;
    return out;
  };

  const conv1W = init(C * 9, 0.2);
  const conv1B = new Float32Array(C);
  // Initialize first two 2D filters as horizontal/vertical high-pass detectors (+ and -)
  if (C >= 2) {
    conv1W.set([0, -0.25, 0, -0.25, 1.0, -0.25, 0, -0.25, 0], 0);
    conv1W.set([0, 0.25, 0, 0.25, -1.0, 0.25, 0, 0.25, 0], 9);
  }
  const conv2W = init(C * C * 9, 0.15);
  const conv2B = new Float32Array(C);
  for (let c = 0; c < C; c++) {
    conv2W[(c * C + c) * 9 + 4] = 0.8; // center tap identity path
  }
  const conv3W = init(C * 9, 0.01);
  const conv3B = new Float32Array(1);

  const col1W = init(P * 5, 0.1);
  const col1B = new Float32Array(P);
  // Symmetric +/- identity and +/- high-pass filters so LeakyReLU preserves both positive and negative stripe offsets
  if (P >= 4) {
    col1W.set([0, 0, 1.0, 0, 0], 0);
    col1W.set([0, 0, -1.0, 0, 0], 5);
    col1W.set([-0.25, 0.5, 0.5, 0.5, -0.25], 10);
    col1W.set([0.25, -0.5, -0.5, -0.5, 0.25], 15);
  }
  const col2W = init(P * 5, 0.01);
  if (P >= 2) {
    col2W[0 * 5 + 2] = 0.5;
    col2W[1 * 5 + 2] = -0.5;
  }
  const col2B = new Float32Array(1);

  const row1W = init(P * 5, 0.1);
  const row1B = new Float32Array(P);
  if (P >= 4) {
    row1W.set([0, 0, 1.0, 0, 0], 0);
    row1W.set([0, 0, -1.0, 0, 0], 5);
    row1W.set([-0.25, 0.5, 0.5, 0.5, -0.25], 10);
    row1W.set([0.25, -0.5, -0.5, -0.5, 0.25], 15);
  }
  const row2W = init(P * 5, 0.01);
  if (P >= 2) {
    row2W[0 * 5 + 2] = 0.5;
    row2W[1 * 5 + 2] = -0.5;
  }
  const row2B = new Float32Array(1);

  const branchScales = new Float32Array([0.15, 0.75, 0.75]);

  return {
    conv1W,
    conv1B,
    conv2W,
    conv2B,
    conv3W,
    conv3B,
    col1W,
    col1B,
    col2W,
    col2B,
    row1W,
    row1B,
    row2W,
    row2B,
    branchScales,
  };
}

export function createAdamState(params: CnnParameterTensors): AdamOptimizerState {
  const m = {} as Record<keyof CnnParameterTensors, number[]>;
  const v = {} as Record<keyof CnnParameterTensors, number[]>;
  for (const k of PARAM_KEYS) {
    m[k] = new Array(params[k].length).fill(0);
    v[k] = new Array(params[k].length).fill(0);
  }
  return { step: 0, m, v };
}

export function serializeParameters(p: CnnParameterTensors): SerializedCnnWeights {
  const out = {} as SerializedCnnWeights;
  for (const k of PARAM_KEYS) {
    out[k] = Array.from(p[k]).map((v) => Math.fround(v));
  }
  return out;
}

export function deserializeParameters(s: SerializedCnnWeights): CnnParameterTensors {
  const out = {} as CnnParameterTensors;
  for (const k of PARAM_KEYS) {
    if (!Array.isArray(s[k])) {
      throw new Error(`Missing or invalid parameter tensor '${k}' in serialized CNN weights.`);
    }
    out[k] = Float32Array.from(s[k]);
  }
  return out;
}

export function countParameters(p: CnnParameterTensors): number {
  let total = 0;
  for (const k of PARAM_KEYS) total += p[k].length;
  return total;
}

export function allParametersFinite(p: CnnParameterTensors): boolean {
  for (const k of PARAM_KEYS) {
    const arr = p[k];
    for (let i = 0; i < arr.length; i++) {
      if (!Number.isFinite(arr[i])) return false;
    }
  }
  return true;
}

export function computeArchitectureHash(hp: CnnHyperParams = DEFAULT_CNN_HYPERPARAMS): string {
  const spec = JSON.stringify({
    arch: CNN_ARCHITECTURE_ID,
    spatialChannels: hp.spatialChannels,
    profileChannels: hp.profileChannels,
    maxResidualAdu: hp.maxResidualAdu,
    insertionMode: hp.insertionMode,
    normScale: ADU_NORM_SCALE,
  });
  return sha256Bytes(new TextEncoder().encode(spec));
}

export function computeWeightsSha256(p: CnnParameterTensors): string {
  const totalFloats = countParameters(p);
  const buf = new ArrayBuffer(totalFloats * 4);
  const dv = new DataView(buf);
  let offset = 0;
  for (const k of PARAM_KEYS) {
    const arr = p[k];
    for (let i = 0; i < arr.length; i++) {
      // Quantize to float32 representation deterministically
      dv.setFloat32(offset, Math.fround(arr[i]), true);
      offset += 4;
    }
  }
  return sha256Bytes(new Uint8Array(buf));
}

export function parameterL2Distance(a: CnnParameterTensors, b: CnnParameterTensors): number {
  let sumSq = 0;
  for (const k of PARAM_KEYS) {
    const tA = a[k];
    const tB = b[k];
    for (let i = 0; i < tA.length; i++) {
      const d = tA[i] - tB[i];
      sumSq += d * d;
    }
  }
  return Math.sqrt(sumSq);
}

// Compute robust frame median by sampling
export function frameMedian14(x: ArrayLike<number>): number {
  const n = x.length;
  if (n === 0) return 7000;
  const stride = Math.max(1, Math.floor(n / 2048));
  const sample: number[] = [];
  for (let i = 0; i < n; i += stride) sample.push(x[i]);
  sample.sort((a, b) => a - b);
  return sample[Math.floor(sample.length / 2)];
}

/**
 * Extracts edge-gated column and row residual profiles in normalized ADU units.
 * High-contrast localized steps (e.g., horizons or 1-pixel warm wires/targets) are gated
 * so the 1D profile branch focuses on periodic/stationary stripe offsets.
 */
export function extractProfilesNorm(
  xNorm: Float32Array,
  W: number,
  H: number
): { colProf: Float32Array; rowProf: Float32Array; colProtect: Float32Array; rowProtect: Float32Array } {
  const colProf = new Float32Array(W);
  const rowProf = new Float32Array(H);
  const colProtect = new Float32Array(W * H);
  const rowProtect = new Float32Array(W * H);

  for (let x = 0; x < W; x++) {
    let sum = 0;
    let wSum = 0;
    const xL = Math.max(0, x - 1);
    const xR = Math.min(W - 1, x + 1);
    const xL2 = Math.max(0, x - 3);
    const xR2 = Math.min(W - 1, x + 3);
    for (let y = 0; y < H; y++) {
      const idx = y * W + x;
      const c = xNorm[idx];
      const bg = 0.5 * (xNorm[y * W + xL] + xNorm[y * W + xR]);
      const diff = c - bg;
      const yU = Math.max(0, y - 1);
      const yD = Math.min(H - 1, y + 1);
      const vGrad = Math.abs(xNorm[yD * W + x] - xNorm[yU * W + x]);
      const stepGrad = Math.abs(xNorm[y * W + xL] - xNorm[y * W + xR]);
      // Gate out vertical step boundaries and strong vertical gradient transitions
      const w = stepGrad > 0.8 ? 0.02 : 1.0 / (1.0 + (diff * diff) / 1.5 + (vGrad * vGrad) / 1.0);
      sum += diff * w;
      wSum += w;
      const localSpike = Math.abs(c - bg);
      colProtect[idx] = (localSpike > 1.8 && stepGrad < 0.4) || stepGrad > 1.2 ? 0.2 : 1.0;
    }
    colProf[x] = wSum > 1e-5 ? sum / wSum : 0;
  }

  for (let y = 0; y < H; y++) {
    let sum = 0;
    let wSum = 0;
    const yU = Math.max(0, y - 1);
    const yD = Math.min(H - 1, y + 1);
    const yU2 = Math.max(0, y - 3);
    const yD2 = Math.min(H - 1, y + 3);
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const c = xNorm[idx];
      const bg = 0.5 * (xNorm[yU * W + x] + xNorm[yD * W + x]);
      const diff = c - bg;
      const xL = Math.max(0, x - 1);
      const xR = Math.min(W - 1, x + 1);
      const hGrad = Math.abs(xNorm[y * W + xR] - xNorm[y * W + xL]);
      const stepGrad = Math.abs(xNorm[yU * W + x] - xNorm[yD * W + x]);
      // Gate out horizontal step boundaries (like bridge edges or horizons) where y-1 and y+1 differ strongly
      const w = stepGrad > 0.8 ? 0.02 : 1.0 / (1.0 + (diff * diff) / 1.5 + (hGrad * hGrad) / 1.0);
      sum += diff * w;
      wSum += w;
      const localSpike = Math.abs(c - bg);
      rowProtect[idx] = (localSpike > 1.8 && stepGrad < 0.4) || stepGrad > 1.2 ? 0.2 : 1.0;
    }
    rowProf[y] = wSum > 1e-5 ? sum / wSum : 0;
  }

  return { colProf, rowProf, colProtect, rowProtect };
}

const leakyRelu = (x: number) => (x >= 0 ? x : 0.1 * x);
const dLeakyRelu = (pre: number) => (pre >= 0 ? 1.0 : 0.1);

/**
 * Runs forward inference AND (when cleanTarget14 is supplied) exact analytical backpropagation
 * with respect to all convolution kernels, biases, and branch fusion weights.
 */
export function forwardAndBackward(
  input14: ArrayLike<number>,
  cleanTarget14: ArrayLike<number> | null,
  W: number,
  H: number,
  params: CnnParameterTensors,
  hp: CnnHyperParams = DEFAULT_CNN_HYPERPARAMS
): {
  restored14: Float32Array;
  residualAdu: Float32Array;
  loss: number | null;
  grads: CnnParameterTensors | null;
  gradNorm: number;
} {
  const N = W * H;
  const C = hp.spatialChannels;
  const P = hp.profileChannels;
  const med = frameMedian14(input14);

  const xNorm = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    const v = (input14[i] - med) / ADU_NORM_SCALE;
    xNorm[i] = Math.max(-8.0, Math.min(8.0, v));
  }

  const { colProf, rowProf, colProtect, rowProtect } = extractProfilesNorm(xNorm, W, H);

  // --- Forward 1D Column Branch ---
  const col1Pre = new Float32Array(P * W);
  const col1Act = new Float32Array(P * W);
  for (let p = 0; p < P; p++) {
    const b = params.col1B[p];
    const wOff = p * 5;
    for (let x = 0; x < W; x++) {
      let sum = b;
      for (let k = -2; k <= 2; k++) {
        const xk = Math.max(0, Math.min(W - 1, x + k));
        sum += colProf[xk] * params.col1W[wOff + (k + 2)];
      }
      col1Pre[p * W + x] = sum;
      col1Act[p * W + x] = leakyRelu(sum);
    }
  }
  const colOut = new Float32Array(W);
  for (let x = 0; x < W; x++) {
    let sum = params.col2B[0];
    for (let p = 0; p < P; p++) {
      const wOff = p * 5;
      for (let k = -2; k <= 2; k++) {
        const xk = Math.max(0, Math.min(W - 1, x + k));
        sum += col1Act[p * W + xk] * params.col2W[wOff + (k + 2)];
      }
    }
    colOut[x] = sum;
  }

  // --- Forward 1D Row Branch ---
  const row1Pre = new Float32Array(P * H);
  const row1Act = new Float32Array(P * H);
  for (let p = 0; p < P; p++) {
    const b = params.row1B[p];
    const wOff = p * 5;
    for (let y = 0; y < H; y++) {
      let sum = b;
      for (let k = -2; k <= 2; k++) {
        const yk = Math.max(0, Math.min(H - 1, y + k));
        sum += rowProf[yk] * params.row1W[wOff + (k + 2)];
      }
      row1Pre[p * H + y] = sum;
      row1Act[p * H + y] = leakyRelu(sum);
    }
  }
  const rowOut = new Float32Array(H);
  for (let y = 0; y < H; y++) {
    let sum = params.row2B[0];
    for (let p = 0; p < P; p++) {
      const wOff = p * 5;
      for (let k = -2; k <= 2; k++) {
        const yk = Math.max(0, Math.min(H - 1, y + k));
        sum += row1Act[p * H + yk] * params.row2W[wOff + (k + 2)];
      }
    }
    rowOut[y] = sum;
  }

  // --- Forward 2D Spatial Branch ---
  // Layer 1: 1 -> C (3x3)
  const conv1Pre = new Float32Array(C * N);
  const conv1Act = new Float32Array(C * N);
  for (let c = 0; c < C; c++) {
    const b = params.conv1B[c];
    const wOff = c * 9;
    const cOff = c * N;
    for (let y = 0; y < H; y++) {
      const yU = Math.max(0, y - 1) * W;
      const yC = y * W;
      const yD = Math.min(H - 1, y + 1) * W;
      for (let x = 0; x < W; x++) {
        const xL = Math.max(0, x - 1);
        const xR = Math.min(W - 1, x + 1);
        const sum =
          b +
          xNorm[yU + xL] * params.conv1W[wOff + 0] +
          xNorm[yU + x] * params.conv1W[wOff + 1] +
          xNorm[yU + xR] * params.conv1W[wOff + 2] +
          xNorm[yC + xL] * params.conv1W[wOff + 3] +
          xNorm[yC + x] * params.conv1W[wOff + 4] +
          xNorm[yC + xR] * params.conv1W[wOff + 5] +
          xNorm[yD + xL] * params.conv1W[wOff + 6] +
          xNorm[yD + x] * params.conv1W[wOff + 7] +
          xNorm[yD + xR] * params.conv1W[wOff + 8];
        conv1Pre[cOff + yC + x] = sum;
        conv1Act[cOff + yC + x] = leakyRelu(sum);
      }
    }
  }

  // Layer 2: C -> C (3x3)
  const conv2Pre = new Float32Array(C * N);
  const conv2Act = new Float32Array(C * N);
  for (let co = 0; co < C; co++) {
    const b = params.conv2B[co];
    const coOff = co * N;
    for (let i = 0; i < N; i++) conv2Pre[coOff + i] = b;
    for (let ci = 0; ci < C; ci++) {
      const ciOff = ci * N;
      const wOff = (co * C + ci) * 9;
      for (let y = 0; y < H; y++) {
        const yU = Math.max(0, y - 1) * W;
        const yC = y * W;
        const yD = Math.min(H - 1, y + 1) * W;
        for (let x = 0; x < W; x++) {
          const xL = Math.max(0, x - 1);
          const xR = Math.min(W - 1, x + 1);
          conv2Pre[coOff + yC + x] +=
            conv1Act[ciOff + yU + xL] * params.conv2W[wOff + 0] +
            conv1Act[ciOff + yU + x] * params.conv2W[wOff + 1] +
            conv1Act[ciOff + yU + xR] * params.conv2W[wOff + 2] +
            conv1Act[ciOff + yC + xL] * params.conv2W[wOff + 3] +
            conv1Act[ciOff + yC + x] * params.conv2W[wOff + 4] +
            conv1Act[ciOff + yC + xR] * params.conv2W[wOff + 5] +
            conv1Act[ciOff + yD + xL] * params.conv2W[wOff + 6] +
            conv1Act[ciOff + yD + x] * params.conv2W[wOff + 7] +
            conv1Act[ciOff + yD + xR] * params.conv2W[wOff + 8];
        }
      }
    }
    for (let i = 0; i < N; i++) {
      conv2Act[coOff + i] = leakyRelu(conv2Pre[coOff + i]);
    }
  }

  // Layer 3: C -> 1 (3x3)
  const spatialOut = new Float32Array(N);
  const b3 = params.conv3B[0];
  for (let i = 0; i < N; i++) spatialOut[i] = b3;
  for (let ci = 0; ci < C; ci++) {
    const ciOff = ci * N;
    const wOff = ci * 9;
    for (let y = 0; y < H; y++) {
      const yU = Math.max(0, y - 1) * W;
      const yC = y * W;
      const yD = Math.min(H - 1, y + 1) * W;
      for (let x = 0; x < W; x++) {
        const xL = Math.max(0, x - 1);
        const xR = Math.min(W - 1, x + 1);
        spatialOut[yC + x] +=
          conv2Act[ciOff + yU + xL] * params.conv3W[wOff + 0] +
          conv2Act[ciOff + yU + x] * params.conv3W[wOff + 1] +
          conv2Act[ciOff + yU + xR] * params.conv3W[wOff + 2] +
          conv2Act[ciOff + yC + xL] * params.conv3W[wOff + 3] +
          conv2Act[ciOff + yC + x] * params.conv3W[wOff + 4] +
          conv2Act[ciOff + yC + xR] * params.conv3W[wOff + 5] +
          conv2Act[ciOff + yD + xL] * params.conv3W[wOff + 6] +
          conv2Act[ciOff + yD + x] * params.conv3W[wOff + 7] +
          conv2Act[ciOff + yD + xR] * params.conv3W[wOff + 8];
      }
    }
  }

  // --- Combine branches and apply safety clamp ---
  const sSpatial = params.branchScales[0];
  const sCol = params.branchScales[1];
  const sRow = params.branchScales[2];
  const maxNorm = hp.maxResidualAdu / ADU_NORM_SCALE;

  const predNorm = new Float32Array(N);
  const clampedMask = new Uint8Array(N);
  const residualAdu = new Float32Array(N);
  const restored14 = new Float32Array(N);

  for (let y = 0; y < H; y++) {
    const rVal = rowOut[y];
    const yOff = y * W;
    for (let x = 0; x < W; x++) {
      const idx = yOff + x;
      const rawPred =
        sSpatial * spatialOut[idx] +
        sCol * colOut[x] * colProtect[idx] +
        sRow * rVal * rowProtect[idx];
      if (rawPred > maxNorm) {
        predNorm[idx] = maxNorm;
        clampedMask[idx] = 0;
      } else if (rawPred < -maxNorm) {
        predNorm[idx] = -maxNorm;
        clampedMask[idx] = 0;
      } else {
        predNorm[idx] = rawPred;
        clampedMask[idx] = 1;
      }
      const dAdu = predNorm[idx] * ADU_NORM_SCALE;
      residualAdu[idx] = dAdu;
      restored14[idx] = Math.max(0, Math.min(16383, input14[idx] - dAdu));
    }
  }

  if (!cleanTarget14) {
    return { restored14, residualAdu, loss: null, grads: null, gradNorm: 0 };
  }

  // --- Compute Loss & Exact Analytical Gradients ---
  // Target residual in normalized units: targetDeltaNorm = (input14 - cleanTarget14) / ADU_NORM_SCALE
  const dPredNorm = new Float32Array(N);
  let totalLoss = 0;
  const invN = 1.0 / N;
  const huberDelta = 1.0; // 100 ADU transition

  for (let i = 0; i < N; i++) {
    const targetDeltaNorm = (input14[i] - cleanTarget14[i]) / ADU_NORM_SCALE;
    const err = predNorm[i] - targetDeltaNorm;
    const absErr = Math.abs(err);
    let l: number;
    let dErr: number;
    if (absErr <= huberDelta) {
      l = 0.5 * err * err;
      dErr = err;
    } else {
      l = huberDelta * (absErr - 0.5 * huberDelta);
      dErr = huberDelta * Math.sign(err);
    }
    totalLoss += l * invN;
    dPredNorm[i] = clampedMask[i] ? dErr * invN : 0;
  }

  const grads: CnnParameterTensors = {
    conv1W: new Float32Array(params.conv1W.length),
    conv1B: new Float32Array(params.conv1B.length),
    conv2W: new Float32Array(params.conv2W.length),
    conv2B: new Float32Array(params.conv2B.length),
    conv3W: new Float32Array(params.conv3W.length),
    conv3B: new Float32Array(params.conv3B.length),
    col1W: new Float32Array(params.col1W.length),
    col1B: new Float32Array(params.col1B.length),
    col2W: new Float32Array(params.col2W.length),
    col2B: new Float32Array(params.col2B.length),
    row1W: new Float32Array(params.row1W.length),
    row1B: new Float32Array(params.row1B.length),
    row2W: new Float32Array(params.row2W.length),
    row2B: new Float32Array(params.row2B.length),
    branchScales: new Float32Array(3),
  };

  const dSpatialOut = new Float32Array(N);
  const dColOut = new Float32Array(W);
  const dRowOut = new Float32Array(H);

  for (let y = 0; y < H; y++) {
    const yOff = y * W;
    const rVal = rowOut[y];
    for (let x = 0; x < W; x++) {
      const idx = yOff + x;
      const g = dPredNorm[idx];
      grads.branchScales[0] += g * spatialOut[idx];
      grads.branchScales[1] += g * colOut[x] * colProtect[idx];
      grads.branchScales[2] += g * rVal * rowProtect[idx];

      dSpatialOut[idx] = g * sSpatial;
      dColOut[x] += g * sCol * colProtect[idx];
      dRowOut[y] += g * sRow * rowProtect[idx];
    }
  }

  // --- Backward 1D Column Branch ---
  const dCol1Act = new Float32Array(P * W);
  for (let x = 0; x < W; x++) {
    const g = dColOut[x];
    grads.col2B[0] += g;
    for (let p = 0; p < P; p++) {
      const wOff = p * 5;
      for (let k = -2; k <= 2; k++) {
        const xk = Math.max(0, Math.min(W - 1, x + k));
        grads.col2W[wOff + (k + 2)] += g * col1Act[p * W + xk];
        dCol1Act[p * W + xk] += g * params.col2W[wOff + (k + 2)];
      }
    }
  }
  for (let p = 0; p < P; p++) {
    const wOff = p * 5;
    for (let x = 0; x < W; x++) {
      const g = dCol1Act[p * W + x] * dLeakyRelu(col1Pre[p * W + x]);
      grads.col1B[p] += g;
      for (let k = -2; k <= 2; k++) {
        const xk = Math.max(0, Math.min(W - 1, x + k));
        grads.col1W[wOff + (k + 2)] += g * colProf[xk];
      }
    }
  }

  // --- Backward 1D Row Branch ---
  const dRow1Act = new Float32Array(P * H);
  for (let y = 0; y < H; y++) {
    const g = dRowOut[y];
    grads.row2B[0] += g;
    for (let p = 0; p < P; p++) {
      const wOff = p * 5;
      for (let k = -2; k <= 2; k++) {
        const yk = Math.max(0, Math.min(H - 1, y + k));
        grads.row2W[wOff + (k + 2)] += g * row1Act[p * H + yk];
        dRow1Act[p * H + yk] += g * params.row2W[wOff + (k + 2)];
      }
    }
  }
  for (let p = 0; p < P; p++) {
    const wOff = p * 5;
    for (let y = 0; y < H; y++) {
      const g = dRow1Act[p * H + y] * dLeakyRelu(row1Pre[p * H + y]);
      grads.row1B[p] += g;
      for (let k = -2; k <= 2; k++) {
        const yk = Math.max(0, Math.min(H - 1, y + k));
        grads.row1W[wOff + (k + 2)] += g * rowProf[yk];
      }
    }
  }

  // --- Backward 2D Spatial Branch ---
  // Layer 3 backward
  const dConv2Act = new Float32Array(C * N);
  for (let i = 0; i < N; i++) grads.conv3B[0] += dSpatialOut[i];

  for (let ci = 0; ci < C; ci++) {
    const ciOff = ci * N;
    const wOff = ci * 9;
    for (let y = 0; y < H; y++) {
      const yU = Math.max(0, y - 1) * W;
      const yC = y * W;
      const yD = Math.min(H - 1, y + 1) * W;
      for (let x = 0; x < W; x++) {
        const g = dSpatialOut[yC + x];
        if (g === 0) continue;
        const xL = Math.max(0, x - 1);
        const xR = Math.min(W - 1, x + 1);
        const i0 = ciOff + yU + xL,
          i1 = ciOff + yU + x,
          i2 = ciOff + yU + xR,
          i3 = ciOff + yC + xL,
          i4 = ciOff + yC + x,
          i5 = ciOff + yC + xR,
          i6 = ciOff + yD + xL,
          i7 = ciOff + yD + x,
          i8 = ciOff + yD + xR;

        grads.conv3W[wOff + 0] += g * conv2Act[i0];
        grads.conv3W[wOff + 1] += g * conv2Act[i1];
        grads.conv3W[wOff + 2] += g * conv2Act[i2];
        grads.conv3W[wOff + 3] += g * conv2Act[i3];
        grads.conv3W[wOff + 4] += g * conv2Act[i4];
        grads.conv3W[wOff + 5] += g * conv2Act[i5];
        grads.conv3W[wOff + 6] += g * conv2Act[i6];
        grads.conv3W[wOff + 7] += g * conv2Act[i7];
        grads.conv3W[wOff + 8] += g * conv2Act[i8];

        dConv2Act[i0] += g * params.conv3W[wOff + 0];
        dConv2Act[i1] += g * params.conv3W[wOff + 1];
        dConv2Act[i2] += g * params.conv3W[wOff + 2];
        dConv2Act[i3] += g * params.conv3W[wOff + 3];
        dConv2Act[i4] += g * params.conv3W[wOff + 4];
        dConv2Act[i5] += g * params.conv3W[wOff + 5];
        dConv2Act[i6] += g * params.conv3W[wOff + 6];
        dConv2Act[i7] += g * params.conv3W[wOff + 7];
        dConv2Act[i8] += g * params.conv3W[wOff + 8];
      }
    }
  }

  // Layer 2 backward
  const dConv2Pre = new Float32Array(C * N);
  for (let i = 0; i < C * N; i++) {
    dConv2Pre[i] = dConv2Act[i] * dLeakyRelu(conv2Pre[i]);
  }
  const dConv1Act = new Float32Array(C * N);
  for (let co = 0; co < C; co++) {
    const coOff = co * N;
    for (let i = 0; i < N; i++) grads.conv2B[co] += dConv2Pre[coOff + i];
    for (let ci = 0; ci < C; ci++) {
      const ciOff = ci * N;
      const wOff = (co * C + ci) * 9;
      for (let y = 0; y < H; y++) {
        const yU = Math.max(0, y - 1) * W;
        const yC = y * W;
        const yD = Math.min(H - 1, y + 1) * W;
        for (let x = 0; x < W; x++) {
          const g = dConv2Pre[coOff + yC + x];
          if (g === 0) continue;
          const xL = Math.max(0, x - 1);
          const xR = Math.min(W - 1, x + 1);
          const i0 = ciOff + yU + xL,
            i1 = ciOff + yU + x,
            i2 = ciOff + yU + xR,
            i3 = ciOff + yC + xL,
            i4 = ciOff + yC + x,
            i5 = ciOff + yC + xR,
            i6 = ciOff + yD + xL,
            i7 = ciOff + yD + x,
            i8 = ciOff + yD + xR;

          grads.conv2W[wOff + 0] += g * conv1Act[i0];
          grads.conv2W[wOff + 1] += g * conv1Act[i1];
          grads.conv2W[wOff + 2] += g * conv1Act[i2];
          grads.conv2W[wOff + 3] += g * conv1Act[i3];
          grads.conv2W[wOff + 4] += g * conv1Act[i4];
          grads.conv2W[wOff + 5] += g * conv1Act[i5];
          grads.conv2W[wOff + 6] += g * conv1Act[i6];
          grads.conv2W[wOff + 7] += g * conv1Act[i7];
          grads.conv2W[wOff + 8] += g * conv1Act[i8];

          dConv1Act[i0] += g * params.conv2W[wOff + 0];
          dConv1Act[i1] += g * params.conv2W[wOff + 1];
          dConv1Act[i2] += g * params.conv2W[wOff + 2];
          dConv1Act[i3] += g * params.conv2W[wOff + 3];
          dConv1Act[i4] += g * params.conv2W[wOff + 4];
          dConv1Act[i5] += g * params.conv2W[wOff + 5];
          dConv1Act[i6] += g * params.conv2W[wOff + 6];
          dConv1Act[i7] += g * params.conv2W[wOff + 7];
          dConv1Act[i8] += g * params.conv2W[wOff + 8];
        }
      }
    }
  }

  // Layer 1 backward
  for (let c = 0; c < C; c++) {
    const cOff = c * N;
    const wOff = c * 9;
    for (let y = 0; y < H; y++) {
      const yU = Math.max(0, y - 1) * W;
      const yC = y * W;
      const yD = Math.min(H - 1, y + 1) * W;
      for (let x = 0; x < W; x++) {
        const g = dConv1Act[cOff + yC + x] * dLeakyRelu(conv1Pre[cOff + yC + x]);
        if (g === 0) continue;
        grads.conv1B[c] += g;
        const xL = Math.max(0, x - 1);
        const xR = Math.min(W - 1, x + 1);
        grads.conv1W[wOff + 0] += g * xNorm[yU + xL];
        grads.conv1W[wOff + 1] += g * xNorm[yU + x];
        grads.conv1W[wOff + 2] += g * xNorm[yU + xR];
        grads.conv1W[wOff + 3] += g * xNorm[yC + xL];
        grads.conv1W[wOff + 4] += g * xNorm[yC + x];
        grads.conv1W[wOff + 5] += g * xNorm[yC + xR];
        grads.conv1W[wOff + 6] += g * xNorm[yD + xL];
        grads.conv1W[wOff + 7] += g * xNorm[yD + x];
        grads.conv1W[wOff + 8] += g * xNorm[yD + xR];
      }
    }
  }

  // Compute global gradient L2 norm
  let normSq = 0;
  for (const k of PARAM_KEYS) {
    const gArr = grads[k];
    for (let i = 0; i < gArr.length; i++) normSq += gArr[i] * gArr[i];
  }
  const gradNorm = Math.sqrt(normSq);

  return { restored14, residualAdu, loss: totalLoss, grads, gradNorm };
}

/**
 * Accumulates gradients over a mini-batch and performs one Adam optimizer step.
 */
export function applyAdamStep(
  params: CnnParameterTensors,
  grads: CnnParameterTensors,
  opt: AdamOptimizerState,
  hp: CnnHyperParams = DEFAULT_CNN_HYPERPARAMS
): { gradNorm: number; weightsDeltaL2: number } {
  let normSq = 0;
  for (const k of PARAM_KEYS) {
    const gArr = grads[k];
    for (let i = 0; i < gArr.length; i++) normSq += gArr[i] * gArr[i];
  }
  const gradNorm = Math.sqrt(normSq);
  const clipScale = gradNorm > hp.gradClipNorm ? hp.gradClipNorm / Math.max(1e-8, gradNorm) : 1.0;

  opt.step += 1;
  const beta1 = 0.9;
  const beta2 = 0.999;
  const eps = 1e-8;
  const bc1 = 1 - Math.pow(beta1, opt.step);
  const bc2 = 1 - Math.pow(beta2, opt.step);

  let deltaSq = 0;
  for (const k of PARAM_KEYS) {
    const pArr = params[k];
    const gArr = grads[k];
    const mArr = opt.m[k];
    const vArr = opt.v[k];
    const isWeight = k.endsWith("W");
    for (let i = 0; i < pArr.length; i++) {
      const g = gArr[i] * clipScale + (isWeight ? hp.weightDecay * pArr[i] : 0);
      mArr[i] = beta1 * mArr[i] + (1 - beta1) * g;
      vArr[i] = beta2 * vArr[i] + (1 - beta2) * g * g;
      const mHat = mArr[i] / bc1;
      const vHat = vArr[i] / bc2;
      const stepVal = (hp.learningRate * mHat) / (Math.sqrt(vHat) + eps);
      pArr[i] = Math.fround(pArr[i] - stepVal);
      deltaSq += stepVal * stepVal;
    }
  }
  return { gradNorm, weightsDeltaL2: Math.sqrt(deltaSq) };
}

/**
 * Runs 14-bit inference with optional overlapped tiling or full-frame mode, plus immediate identity bypass.
 */
export function inferCnn14(
  input14: ArrayLike<number>,
  W: number,
  H: number,
  params: CnnParameterTensors | null,
  hp: CnnHyperParams = DEFAULT_CNN_HYPERPARAMS,
  bypass = false
): { restored14: Float32Array; residualAdu: Float32Array; usedCnn: boolean } {
  const N = W * H;
  if (bypass || !params) {
    return {
      restored14: Float32Array.from(input14 as ArrayLike<number>),
      residualAdu: new Float32Array(N),
      usedCnn: false,
    };
  }

  // If tileSize <= 0 or frame fits within tileSize, run full-frame inference directly
  if (hp.tileSize <= 0 || (W <= hp.tileSize && H <= hp.tileSize)) {
    const res = forwardAndBackward(input14, null, W, H, params, hp);
    return { restored14: res.restored14, residualAdu: res.residualAdu, usedCnn: true };
  }

  // Overlapped tile inference with cosine/linear feathering in overlap regions
  const T = Math.max(32, hp.tileSize);
  const O = Math.min(Math.floor(T / 4), Math.max(4, hp.tileOverlap));
  const step = T - O * 2;
  const accRestored = new Float32Array(N);
  const accResidual = new Float32Array(N);
  const accWeight = new Float32Array(N);

  for (let y0 = 0; y0 < H; y0 += step) {
    const ty0 = Math.max(0, Math.min(H - T, y0));
    const th = Math.min(T, H - ty0);
    for (let x0 = 0; x0 < W; x0 += step) {
      const tx0 = Math.max(0, Math.min(W - T, x0));
      const tw = Math.min(T, W - tx0);
      const tileIn = new Float32Array(tw * th);
      for (let ty = 0; ty < th; ty++) {
        for (let tx = 0; tx < tw; tx++) {
          tileIn[ty * tw + tx] = input14[(ty0 + ty) * W + (tx0 + tx)];
        }
      }
      const tileOut = forwardAndBackward(tileIn, null, tw, th, params, hp);
      for (let ty = 0; ty < th; ty++) {
        const wy =
          ty < O && ty0 > 0
            ? (ty + 1) / (O + 1)
            : ty >= th - O && ty0 + th < H
            ? (th - ty) / (O + 1)
            : 1.0;
        for (let tx = 0; tx < tw; tx++) {
          const wx =
            tx < O && tx0 > 0
              ? (tx + 1) / (O + 1)
              : tx >= tw - O && tx0 + tw < W
              ? (tw - tx) / (O + 1)
              : 1.0;
          const w = wx * wy;
          const dstIdx = (ty0 + ty) * W + (tx0 + tx);
          accRestored[dstIdx] += tileOut.restored14[ty * tw + tx] * w;
          accResidual[dstIdx] += tileOut.residualAdu[ty * tw + tx] * w;
          accWeight[dstIdx] += w;
        }
      }
      if (tx0 + tw >= W) break;
    }
    if (ty0 + th >= H) break;
  }

  const restored14 = new Float32Array(N);
  const residualAdu = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    const w = accWeight[i] > 1e-6 ? accWeight[i] : 1.0;
    restored14[i] = Math.max(0, Math.min(16383, accRestored[i] / w));
    residualAdu[i] = accResidual[i] / w;
  }
  return { restored14, residualAdu, usedCnn: true };
}
