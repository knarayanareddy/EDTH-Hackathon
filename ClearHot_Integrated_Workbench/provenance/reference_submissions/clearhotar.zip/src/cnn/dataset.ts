import { decodeBuffer, frameBytes, frameCountFor, sha256Bytes, type DecodeConfig } from "../lab/decode";
import { mulberry32 } from "./model";

export type SplitName = "train" | "validation" | "final_test";

export interface HumanCuratedAttestation {
  attestedBy: string;
  attestedAt: string;
  targetProvenanceDescription: string;
  targetType:
    | "multi_frame_registered_clean_reference"
    | "calibrated_blackbody_flatfield_corrected"
    | "external_clean_sensor_reference"
    | "synthetic_known_clean"
    | string;
  alignmentVerified: boolean;
  notAdjacentFrameNoise2Noise: boolean;
  notModelPredictionOrBlur: boolean;
  countDomainConfirmed14Bit: boolean;
}

export interface DatasetPairEntry {
  pairId: string;
  split: SplitName;
  recordingId: string;
  sceneGroupId: string;
  deviceOrConditionId: string;
  scenarioTag: string;
  synthetic: boolean;
  sourceFile: string;
  sourceSha256: string;
  sourceFrameIndex: number;
  targetFile: string;
  targetSha256: string;
  targetFrameIndex: number;
  decoder: DecodeConfig;
  notes?: string;
}

export interface DatasetManifest {
  schema: "clearhot-dataset-manifest-v1";
  datasetId: string;
  version: number;
  createdAt: string;
  synthetic: boolean;
  description: string;
  allowExploratoryTimeBlockSplit?: boolean;
  minTemporalGapFrames?: number;
  humanAttestation: HumanCuratedAttestation;
  entries: DatasetPairEntry[];
  limitationsNote: string;
}

export interface InMemoryTrainingPair {
  pairId: string;
  split: SplitName;
  recordingId: string;
  sceneGroupId: string;
  scenarioTag: string;
  synthetic: boolean;
  width: number;
  height: number;
  noisy14: Uint16Array;
  clean14: Uint16Array;
  sourceSha256: string;
  targetSha256: string;
  wireMask?: Uint8Array;
  pointMask?: Uint8Array;
}

export interface DatasetValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  summary: {
    trainCount: number;
    validationCount: number;
    finalTestCount: number;
    uniqueRecordings: number;
    exploratoryTimeBlockOnly: boolean;
  };
}

const FORBIDDEN_TARGET_PATTERNS = [
  /adjacent[_\s-]*frame/i,
  /noise2noise/i,
  /unlabeled/i,
  /single[_\s-]*frame/i,
  /gaussian[_\s-]*blur/i,
  /blurred/i,
  /model[_\s-]*prediction/i,
  /self[_\s-]*train/i,
  /pseudo[_\s-]*label/i,
];

/**
 * Validates a dataset manifest for split hygiene, human attestation, 14-bit domain consistency,
 * and absence of cross-split hash/recording/temporal-window leakage.
 */
export function validateDatasetManifest(manifest: DatasetManifest): DatasetValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!manifest || manifest.schema !== "clearhot-dataset-manifest-v1") {
    errors.push("Manifest schema must be 'clearhot-dataset-manifest-v1'.");
  }
  if (!manifest.datasetId || typeof manifest.datasetId !== "string") {
    errors.push("datasetId is required.");
  }
  if (!Number.isInteger(manifest.version) || manifest.version < 1) {
    errors.push("version must be a positive integer.");
  }

  const att = manifest.humanAttestation;
  if (!att) {
    errors.push("humanAttestation block is required.");
  } else {
    if (!att.attestedBy || att.attestedBy.trim().length < 2) {
      errors.push("humanAttestation.attestedBy must identify the human reviewer/curator.");
    }
    if (!att.targetProvenanceDescription || att.targetProvenanceDescription.trim().length < 8) {
      errors.push("humanAttestation.targetProvenanceDescription must document how clean targets were obtained.");
    }
    if (att.alignmentVerified !== true) {
      errors.push("humanAttestation.alignmentVerified must be true (source and target frames must be spatially/temporally aligned).");
    }
    if (att.notAdjacentFrameNoise2Noise !== true) {
      errors.push("humanAttestation.notAdjacentFrameNoise2Noise must be true (unlabeled adjacent video frames are rejected).");
    }
    if (att.notModelPredictionOrBlur !== true) {
      errors.push("humanAttestation.notModelPredictionOrBlur must be true (blurred frames or model predictions are rejected).");
    }
    if (att.countDomainConfirmed14Bit !== true) {
      errors.push("humanAttestation.countDomainConfirmed14Bit must be true (both input and target must be in the same 14-bit count domain).");
    }
    for (const pat of FORBIDDEN_TARGET_PATTERNS) {
      if (pat.test(att.targetType || "") || pat.test(att.targetProvenanceDescription || "")) {
        errors.push(
          `Rejected target provenance ('${att.targetType}'): single unlabeled frames, adjacent noisy frames, blurred images, and model predictions are not valid clean targets.`
        );
        break;
      }
    }
  }

  if (!Array.isArray(manifest.entries) || manifest.entries.length === 0) {
    errors.push("Manifest entries array must not be empty.");
  }

  const hashSplits = new Map<string, Set<SplitName>>();
  const recordingSplits = new Map<string, Set<SplitName>>();
  const recordingFramesBySplit = new Map<string, Map<SplitName, number[]>>();
  const sceneSplits = new Map<string, Set<SplitName>>();

  let trainCount = 0;
  let validationCount = 0;
  let finalTestCount = 0;

  for (const e of manifest.entries || []) {
    if (!["train", "validation", "final_test"].includes(e.split)) {
      errors.push(`Entry '${e.pairId}' has invalid split '${e.split}'.`);
      continue;
    }
    if (e.split === "train") trainCount++;
    else if (e.split === "validation") validationCount++;
    else if (e.split === "final_test") finalTestCount++;

    if (!/^[0-9a-f]{64}$/i.test(e.sourceSha256) || !/^[0-9a-f]{64}$/i.test(e.targetSha256)) {
      errors.push(`Entry '${e.pairId}' must provide full 64-hex SHA-256 digests for both sourceSha256 and targetSha256.`);
    }

    // Reject identical source and target hash (unlabeled identity or adjacent frame from same raw file)
    if (e.sourceSha256.toLowerCase() === e.targetSha256.toLowerCase()) {
      if (e.sourceFrameIndex === e.targetFrameIndex) {
        errors.push(`Entry '${e.pairId}' has identical source and target file hash and frame index (unlabeled identity target rejected).`);
      } else if (Math.abs(e.sourceFrameIndex - e.targetFrameIndex) <= 12) {
        errors.push(
          `Entry '${e.pairId}' uses adjacent/nearby frames (${e.sourceFrameIndex} vs ${e.targetFrameIndex}) from the same file hash as input/target. Adjacent noisy frames are rejected.`
        );
      } else {
        errors.push(
          `Entry '${e.pairId}' uses the same raw recording file hash for both noisy source and clean target. Supply a separately verified clean reference file.`
        );
      }
    }

    const d = e.decoder;
    if (!d || d.bits !== 14 || d.width < 32 || d.height < 32 || d.width % 2 !== 0 || d.height % 2 !== 0) {
      errors.push(`Entry '${e.pairId}' has invalid decoder settings (must be 14-bit with even width/height >= 32).`);
    }
    if (!Number.isInteger(e.sourceFrameIndex) || e.sourceFrameIndex < 0 || !Number.isInteger(e.targetFrameIndex) || e.targetFrameIndex < 0) {
      errors.push(`Entry '${e.pairId}' has negative or non-integer frame index.`);
    }

    for (const h of [e.sourceSha256.toLowerCase(), e.targetSha256.toLowerCase()]) {
      if (!hashSplits.has(h)) hashSplits.set(h, new Set());
      hashSplits.get(h)!.add(e.split);
    }

    if (!recordingSplits.has(e.recordingId)) recordingSplits.set(e.recordingId, new Set());
    recordingSplits.get(e.recordingId)!.add(e.split);

    if (!recordingFramesBySplit.has(e.recordingId)) recordingFramesBySplit.set(e.recordingId, new Map());
    const splitMap = recordingFramesBySplit.get(e.recordingId)!;
    if (!splitMap.has(e.split)) splitMap.set(e.split, []);
    splitMap.get(e.split)!.push(e.sourceFrameIndex);

    if (!sceneSplits.has(e.sceneGroupId)) sceneSplits.set(e.sceneGroupId, new Set());
    sceneSplits.get(e.sceneGroupId)!.add(e.split);
  }

  // Check content hash leakage across splits
  for (const [h, splits] of hashSplits.entries()) {
    if (splits.size > 1) {
      errors.push(
        `Content SHA-256 '${h.slice(0, 16)}...' is assigned to multiple splits (${Array.from(splits).join(", ")}). Exact content hash leakage is forbidden.`
      );
    }
  }

  // Check scene group leakage across splits
  for (const [sceneId, splits] of sceneSplits.entries()) {
    if (splits.size > 1) {
      errors.push(
        `Scene group '${sceneId}' appears in multiple splits (${Array.from(splits).join(", ")}). Disjoint scene groups are required.`
      );
    }
  }

  // Check recording-level split hygiene
  let exploratoryTimeBlockOnly = false;
  const minGap = manifest.minTemporalGapFrames ?? 25;

  for (const [recId, splits] of recordingSplits.entries()) {
    if (splits.size > 1) {
      if (!manifest.allowExploratoryTimeBlockSplit) {
        errors.push(
          `Recording '${recId}' appears across multiple splits (${Array.from(splits).join(", ")}). Separate recordings are required unless allowExploratoryTimeBlockSplit=true is explicitly set with a >=25-frame temporal buffer.`
        );
      } else {
        exploratoryTimeBlockOnly = true;
        warnings.push(
          `Recording '${recId}' is shared across splits via time-blocks: results are exploratory time-block estimates only and do not establish cross-recording generalization.`
        );
        const splitMap = recordingFramesBySplit.get(recId)!;
        const splitEntries = Array.from(splitMap.entries());
        for (let i = 0; i < splitEntries.length; i++) {
          for (let j = i + 1; j < splitEntries.length; j++) {
            const [sA, framesA] = splitEntries[i];
            const [sB, framesB] = splitEntries[j];
            for (const fA of framesA) {
              for (const fB of framesB) {
                if (Math.abs(fA - fB) < minGap) {
                  errors.push(
                    `Temporal context leakage in recording '${recId}': frame ${fA} (${sA}) and frame ${fB} (${sB}) are closer than the required ${minGap}-frame buffer (needed to prevent multi-frame context overlap such as Claude B's 12-frame window).`
                  );
                }
              }
            }
          }
        }
      }
    }
  }

  if (trainCount === 0) errors.push("Dataset must contain at least one 'train' pair.");
  if (validationCount === 0) errors.push("Dataset must contain at least one 'validation' pair.");

  warnings.push(
    "Scientific limitation: code validation confirms hash, dimension and split-rule compliance, but cannot independently prove that two distinct file hashes come from different physical cameras/scenes or that a user-supplied target is radiometrically calibrated."
  );

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    summary: {
      trainCount,
      validationCount,
      finalTestCount,
      uniqueRecordings: recordingSplits.size,
      exploratoryTimeBlockOnly,
    },
  };
}

/**
 * Verifies a single curated pair against actual raw byte buffers (checking full SHA-256 and frame bounds)
 * and decodes the 14-bit noisy input and aligned 14-bit clean target.
 */
export function verifyAndDecodeCuratedPair(
  entry: DatasetPairEntry,
  sourceBytes: Uint8Array,
  targetBytes: Uint8Array
): InMemoryTrainingPair {
  const actualSourceHash = sha256Bytes(sourceBytes);
  if (actualSourceHash.toLowerCase() !== entry.sourceSha256.toLowerCase()) {
    throw new Error(
      `Source file SHA-256 mismatch for pair '${entry.pairId}': expected ${entry.sourceSha256}, got ${actualSourceHash}.`
    );
  }
  const actualTargetHash = sha256Bytes(targetBytes);
  if (actualTargetHash.toLowerCase() !== entry.targetSha256.toLowerCase()) {
    throw new Error(
      `Target file SHA-256 mismatch for pair '${entry.pairId}': expected ${entry.targetSha256}, got ${actualTargetHash}.`
    );
  }

  const fb = frameBytes(entry.decoder);
  const srcCounts = frameCountFor(sourceBytes.byteLength, entry.decoder);
  const tgtCounts = frameCountFor(targetBytes.byteLength, entry.decoder);

  if (srcCounts.frames < 1 || entry.sourceFrameIndex >= srcCounts.frames) {
    throw new Error(`Invalid source frame index ${entry.sourceFrameIndex} for pair '${entry.pairId}' (frames: ${srcCounts.frames}).`);
  }
  if (tgtCounts.frames < 1 || entry.targetFrameIndex >= tgtCounts.frames) {
    throw new Error(`Invalid target frame index ${entry.targetFrameIndex} for pair '${entry.pairId}' (frames: ${tgtCounts.frames}).`);
  }

  const srcStart = entry.decoder.headerBytes + entry.sourceFrameIndex * fb;
  const tgtStart = entry.decoder.headerBytes + entry.targetFrameIndex * fb;

  const srcSlice = sourceBytes.slice(srcStart, srcStart + fb);
  const tgtSlice = targetBytes.slice(tgtStart, tgtStart + fb);

  const noisy14 = decodeBuffer(srcSlice.buffer, entry.decoder);
  const clean14 = decodeBuffer(tgtSlice.buffer, entry.decoder);

  return {
    pairId: entry.pairId,
    split: entry.split,
    recordingId: entry.recordingId,
    sceneGroupId: entry.sceneGroupId,
    scenarioTag: entry.scenarioTag,
    synthetic: entry.synthetic,
    width: entry.decoder.width,
    height: entry.decoder.height,
    noisy14,
    clean14,
    sourceSha256: actualSourceHash,
    targetSha256: actualTargetHash,
  };
}

export function encodeUint16LeBytes(arr: Uint16Array): Uint8Array {
  const buf = new ArrayBuffer(arr.length * 2);
  const dv = new DataView(buf);
  for (let i = 0; i < arr.length; i++) {
    dv.setUint16(i * 2, arr[i] & 0x3fff, true);
  }
  return new Uint8Array(buf);
}

/**
 * Generates a deterministic synthetic known-clean thermal pair with distinct scene geometry per sceneSeed.
 * Includes smooth sky/ground background, bridge/structure, warm animal/target, true 1px thin features,
 * and realistic column/row FPN + sensor read noise.
 */
export function generateSyntheticPair(params: {
  pairId: string;
  split: SplitName;
  recordingId: string;
  sceneGroupId: string;
  scenarioTag:
    | "mixed_stripes_and_targets"
    | "strong_alternating_stripes"
    | "no_stripe_clean_hard_negative"
    | "thin_wire_and_mast"
    | "small_point_targets";
  sceneSeed: number;
  width: number;
  height: number;
}): InMemoryTrainingPair {
  const { pairId, split, recordingId, sceneGroupId, scenarioTag, sceneSeed, width: W, height: H } = params;
  const rng = mulberry32(sceneSeed);
  const N = W * H;
  const clean14 = new Uint16Array(N);
  const noisy14 = new Uint16Array(N);
  const wireMask = new Uint8Array(N);
  const pointMask = new Uint8Array(N);

  const horizonY = Math.floor(H * (0.28 + 0.22 * rng()));
  const baseSky = 6100 + Math.round((rng() - 0.5) * 240);
  const baseGround = 6420 + Math.round((rng() - 0.5) * 260);
  const bridgeY = Math.floor(H * (0.44 + 0.14 * rng()));
  const bridgeHalfH = Math.max(2, Math.floor(H * 0.03));
  const bridgeDelta = 260 + Math.round(rng() * 90);

  // Elliptical warm target (animal/vehicle)
  const targetX = Math.floor(W * (0.22 + 0.55 * rng()));
  const targetY = Math.floor(H * (0.62 + 0.22 * rng()));
  const rx = Math.max(3, Math.floor(W * 0.055));
  const ry = Math.max(2, Math.floor(H * 0.04));
  const targetDelta = 310 + Math.round(rng() * 110);

  // True 1-pixel vertical mast and horizontal wire
  const mastX = Math.floor(W * (0.72 + 0.15 * rng()));
  const wireY = Math.floor(H * (0.2 + 0.12 * rng()));
  const includeWire = scenarioTag === "thin_wire_and_mast" || scenarioTag === "mixed_stripes_and_targets";

  for (let y = 0; y < H; y++) {
    const isSky = y < horizonY;
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      let v = isSky
        ? baseSky + Math.sin(x * 0.05 + sceneSeed) * 28 + (y / Math.max(1, horizonY)) * 45
        : baseGround +
          Math.cos(x * 0.07 + sceneSeed * 0.5) * 55 +
          Math.sin((y - horizonY) * 0.11) * 48;

      if (Math.abs(y - bridgeY) <= bridgeHalfH) {
        v += bridgeDelta;
      }

      const dx = (x - targetX) / rx;
      const dy = (y - targetY) / ry;
      if (dx * dx + dy * dy <= 1.0) {
        v += targetDelta * (1 - 0.25 * (dx * dx + dy * dy));
      }

      if (includeWire) {
        if (x === mastX && y >= Math.floor(H * 0.15) && y <= Math.floor(H * 0.85)) {
          v += 320;
          wireMask[idx] = 1;
        }
        if (y === wireY && x >= Math.floor(W * 0.12) && x <= Math.floor(W * 0.88)) {
          v += 260;
          wireMask[idx] = 1;
        }
      }

      if (scenarioTag === "small_point_targets") {
        const py = Math.floor(H * 0.24);
        const p1x = Math.floor(W * 0.25);
        const p2x = Math.floor(W * 0.55);
        if (y === py && x === p1x) {
          v += 480;
          pointMask[idx] = 1;
        }
        if (Math.abs(y - py) <= 1 && Math.abs(x - p2x) <= 1) {
          v += 420;
          pointMask[idx] = 1;
        }
      }

      clean14[idx] = Math.max(0, Math.min(16383, Math.round(v)));
    }
  }

  // Generate column and row fixed-pattern stripe offsets
  const colStripe = new Float32Array(W);
  const rowStripe = new Float32Array(H);

  if (scenarioTag !== "no_stripe_clean_hard_negative") {
    const altAmp = scenarioTag === "strong_alternating_stripes" ? 95 : 42;
    for (let x = 0; x < W; x++) {
      const alt = (x % 2 === 0 ? 1 : -1) * altAmp;
      const randCol = (rng() - 0.5) * 56;
      colStripe[x] = alt + randCol;
    }
    for (let y = 0; y < H; y++) {
      const altR = (y % 3 === 0 ? 1 : -0.5) * (scenarioTag === "strong_alternating_stripes" ? 45 : 24);
      const randRow = (rng() - 0.5) * 32;
      rowStripe[y] = altR + randRow;
    }
    // Zero-mean the stripe offsets so they don't shift global DC pedestal
    let cMean = 0;
    for (let x = 0; x < W; x++) cMean += colStripe[x];
    cMean /= W;
    for (let x = 0; x < W; x++) colStripe[x] -= cMean;

    let rMean = 0;
    for (let y = 0; y < H; y++) rMean += rowStripe[y];
    rMean /= H;
    for (let y = 0; y < H; y++) rowStripe[y] -= rMean;
  }

  const readNoiseAmp = scenarioTag === "no_stripe_clean_hard_negative" ? 2.5 : 8.0;

  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const idx = y * W + x;
      const n = (rng() + rng() - 1.0) * readNoiseAmp;
      const corrupted = clean14[idx] + colStripe[x] + rowStripe[y] + n;
      noisy14[idx] = Math.max(0, Math.min(16383, Math.round(corrupted)));
    }
  }

  const sourceSha256 = sha256Bytes(encodeUint16LeBytes(noisy14));
  const targetSha256 = sha256Bytes(encodeUint16LeBytes(clean14));

  return {
    pairId,
    split,
    recordingId,
    sceneGroupId,
    scenarioTag,
    synthetic: true,
    width: W,
    height: H,
    noisy14,
    clean14,
    sourceSha256,
    targetSha256,
    wireMask,
    pointMask,
  };
}

/**
 * Builds a complete, validated synthetic dataset (v1 or v2 expanded) with strictly disjoint
 * recording/scene groups across train, validation, and final_test splits.
 */
export function buildSyntheticDataset(params?: {
  version?: 1 | 2;
  width?: number;
  height?: number;
}): {
  manifest: DatasetManifest;
  pairs: InMemoryTrainingPair[];
  validation: DatasetValidationResult;
} {
  const version = params?.version ?? 1;
  const width = params?.width ?? 64;
  const height = params?.height ?? 64;

  const specs: Array<{
    pairId: string;
    split: SplitName;
    recordingId: string;
    sceneGroupId: string;
    scenarioTag:
      | "mixed_stripes_and_targets"
      | "strong_alternating_stripes"
      | "no_stripe_clean_hard_negative"
      | "thin_wire_and_mast"
      | "small_point_targets";
    sceneSeed: number;
  }> = [
    // Train split: seeds 101..106, distinct recording group synth_rec_train_*
    {
      pairId: "synth_train_01",
      split: "train",
      recordingId: "synth_rec_train_A",
      sceneGroupId: "scene_train_A1",
      scenarioTag: "mixed_stripes_and_targets",
      sceneSeed: 101,
    },
    {
      pairId: "synth_train_02",
      split: "train",
      recordingId: "synth_rec_train_A",
      sceneGroupId: "scene_train_A2",
      scenarioTag: "strong_alternating_stripes",
      sceneSeed: 102,
    },
    {
      pairId: "synth_train_03",
      split: "train",
      recordingId: "synth_rec_train_B",
      sceneGroupId: "scene_train_B1",
      scenarioTag: "thin_wire_and_mast",
      sceneSeed: 103,
    },
    {
      pairId: "synth_train_04",
      split: "train",
      recordingId: "synth_rec_train_B",
      sceneGroupId: "scene_train_B2",
      scenarioTag: "no_stripe_clean_hard_negative",
      sceneSeed: 104,
    },
    // Validation split: seeds 201..204, strictly disjoint recording group synth_rec_val_*
    {
      pairId: "synth_val_01",
      split: "validation",
      recordingId: "synth_rec_val_A",
      sceneGroupId: "scene_val_A1",
      scenarioTag: "mixed_stripes_and_targets",
      sceneSeed: 201,
    },
    {
      pairId: "synth_val_02",
      split: "validation",
      recordingId: "synth_rec_val_A",
      sceneGroupId: "scene_val_A2",
      scenarioTag: "strong_alternating_stripes",
      sceneSeed: 202,
    },
    {
      pairId: "synth_val_03",
      split: "validation",
      recordingId: "synth_rec_val_B",
      sceneGroupId: "scene_val_B1",
      scenarioTag: "thin_wire_and_mast",
      sceneSeed: 203,
    },
    {
      pairId: "synth_val_04",
      split: "validation",
      recordingId: "synth_rec_val_B",
      sceneGroupId: "scene_val_B2",
      scenarioTag: "no_stripe_clean_hard_negative",
      sceneSeed: 204,
    },
    // Untouched Final Test split: seeds 901..903, strictly disjoint recording group synth_rec_test_*
    {
      pairId: "synth_test_01",
      split: "final_test",
      recordingId: "synth_rec_test_A",
      sceneGroupId: "scene_test_A1",
      scenarioTag: "mixed_stripes_and_targets",
      sceneSeed: 901,
    },
    {
      pairId: "synth_test_02",
      split: "final_test",
      recordingId: "synth_rec_test_A",
      sceneGroupId: "scene_test_A2",
      scenarioTag: "thin_wire_and_mast",
      sceneSeed: 902,
    },
    {
      pairId: "synth_test_03",
      split: "final_test",
      recordingId: "synth_rec_test_B",
      sceneGroupId: "scene_test_B1",
      scenarioTag: "no_stripe_clean_hard_negative",
      sceneSeed: 903,
    },
  ];

  // If version 2 (Cycle 2 curated expansion), add new vetted training pairs without touching validation or final_test
  if (version === 2) {
    specs.push(
      {
        pairId: "synth_train_05_v2",
        split: "train",
        recordingId: "synth_rec_train_C",
        sceneGroupId: "scene_train_C1",
        scenarioTag: "small_point_targets",
        sceneSeed: 105,
      },
      {
        pairId: "synth_train_06_v2",
        split: "train",
        recordingId: "synth_rec_train_C",
        sceneGroupId: "scene_train_C2",
        scenarioTag: "thin_wire_and_mast",
        sceneSeed: 106,
      },
      {
        pairId: "synth_train_07_v2",
        split: "train",
        recordingId: "synth_rec_train_C",
        sceneGroupId: "scene_train_C3",
        scenarioTag: "no_stripe_clean_hard_negative",
        sceneSeed: 107,
      }
    );
  }

  const pairs = specs.map((s) =>
    generateSyntheticPair({
      ...s,
      width,
      height,
    })
  );

  const decoder: DecodeConfig = {
    width,
    height,
    headerBytes: 0,
    littleEndian: true,
    bits: 14,
    shift: 0,
  };

  const manifest: DatasetManifest = {
    schema: "clearhot-dataset-manifest-v1",
    datasetId: `clearhot-synthetic-known-clean-v${version}`,
    version,
    createdAt: "2026-11-14T00:00:00.000Z",
    synthetic: true,
    description: `Deterministic synthetic 14-bit thermal dataset v${version} with known clean targets, column/row FPN, thin wires, and stripe-free hard negatives.`,
    humanAttestation: {
      attestedBy: "ClearHot Synthetic Generator (automated deterministic fixture)",
      attestedAt: "2026-11-14T00:00:00.000Z",
      targetProvenanceDescription:
        "SYNTHETIC ONLY: Known clean 14-bit mathematical scene rendered prior to adding deterministic column/row fixed-pattern stripes and sensor read noise.",
      targetType: "synthetic_known_clean",
      alignmentVerified: true,
      notAdjacentFrameNoise2Noise: true,
      notModelPredictionOrBlur: true,
      countDomainConfirmed14Bit: true,
    },
    entries: pairs.map((p) => ({
      pairId: p.pairId,
      split: p.split,
      recordingId: p.recordingId,
      sceneGroupId: p.sceneGroupId,
      deviceOrConditionId: "synthetic_simulator_14bit",
      scenarioTag: p.scenarioTag,
      synthetic: true,
      sourceFile: `${p.pairId}_noisy.raw`,
      sourceSha256: p.sourceSha256,
      sourceFrameIndex: 0,
      targetFile: `${p.pairId}_clean.raw`,
      targetSha256: p.targetSha256,
      targetFrameIndex: 0,
      decoder,
      notes: "Synthetic known-clean fixture; does not represent real sensor generalisation.",
    })),
    limitationsNote:
      "SYNTHETIC DATASET ONLY: Training or validation gains on these generated fixtures demonstrate functional pipeline mechanics and do not prove improvement on the user's ~180 MB real recording.",
  };

  const validation = validateDatasetManifest(manifest);
  return { manifest, pairs, validation };
}
