import {
  METHODS,
  LABELS,
  ALL_LABELS,
  PLAYABLE_METHODS,
  VERSION,
  validSettings,
  decodeConfig,
  decodeBuffer,
  frameBytes,
  frameCountFor,
  readFrame,
  reference,
  configFor,
  runMethod,
  createMethodRunner,
  stats,
  medianGap,
  synthetic,
  temporalDifference,
  sha256File,
  sha256Bytes,
  runGenuineStageAblation,
  computeAblationContextKey,
  runHardNegativeBenchmarkSuite,
  runTwoCycleSyntheticDemo,
  rollbackActiveModel,
  verifyCheckpointIntegrity,
  verifyCacheAgainstSource,
  estimateInferenceCacheDiskBytes,
  type Settings,
  type Method,
  type AnyPlayableMethod,
  type Roi,
  type CnnCheckpoint,
  type ModelRegistryState,
  type LocalInferenceCacheManifest,
  type CompleteAblationReport,
} from "./core";

const $ = <T extends HTMLElement = HTMLElement>(s: string) => document.querySelector(s) as T;
const esc = (s: unknown) =>
  String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));

$("#app").innerHTML = `<header><h1>ClearHot · Local comparison &amp; controlled offline CNN workbench (v${VERSION})</h1><p class="intro">Seven classical pipelines, controlled Argos 2 / causal Claude B variants, genuine stage ablation, and an opt-in offline CNN residual loop on one locally loaded frame and shared ROIs. Argos 2 is your practical reference—not a proven winner. Experimental research tool, not a temperature instrument or operational detection system.</p></header><main class="wrap">
<div class="warning"><b>Offline by design:</b> this file contains its code and uses no server or database. Your recording is read in your browser; session exports, checkpoints and caches are saved locally only when you choose. Treat exported names, coordinates, metrics and notes as potentially sensitive. No real recording has been validated here.</div>
<section class="box"><h2>1 · Source and shared decoder</h2><div class="bar"><label>Local uint16 file<input id="file" type="file"></label><button id="synth" class="alt">Use synthetic sample</button><label>Synthetic frames<input id="synthFrames" type="number" value="80" min="5" max="500" style="width:72px"></label><button id="hash" class="alt">Calculate SHA-256 locally</button><button id="cancelHash" class="alt" disabled>Cancel hash</button><span id="source" class="muted"></span></div><p class="muted">Headerless frames with optional one-time file header. The original six algorithms are 14-bit, so this evaluator defaults to 14-bit values in uint16 (optional 15/16-bit sources require explicit compatibility scaling approval). Width/height must be even. File size alone does not verify format. Above-range bits are masked after shifting; confirm the sensor spec first.</p><div class="bar" id="settings"><label>Width<input id="w" type="number" value="640"></label><label>Height<input id="h" type="number" value="512"></label><label>Header bytes<input id="header" type="number" value="0"></label><label>Right shift<input id="shift" type="number" value="0" min="0" max="2"></label><label>Byte order<select id="endian"><option value="le">Little-endian</option><option value="be">Big-endian</option></select></label><label>Reference low<input id="lo" type="number" value="5500"></label><label>Reference high<input id="hi" type="number" value="7500"></label><button id="apply" class="alt">Apply decoder &amp; window</button><button id="autoWindow" class="alt">Suggest window from current frame</button></div><p id="decoder" class="muted"></p><p id="hashtext" class="muted"></p></section>
<section class="box"><h2>1B · Controlled offline CNN registry &amp; local inference cache</h2><div class="bar"><button id="runCnnDemo" class="alt">Run 2-cycle synthetic CNN demo (train → validate → approve → reject bad → rollback)</button><label>Load checkpoint (.json)<input id="loadCheckpointFile" type="file" accept=".json,application/json"></label><label>Load cache manifest (.chcache.json)<input id="loadCacheManifest" type="file" accept=".json,application/json"></label><label>Load cache binary (.chcache.bin)<input id="loadCacheBin" type="file"></label><label style="display:inline-flex;align-items:center;gap:4px"><input id="cnnNativeTone" type="checkbox">Map CNN through Argos 2 native AGC (unchecked = locked fixed window)</label><button id="bypassCnnBtn" class="alt">Bypass CNN (use classical baseline)</button><button id="rollbackCnnBtn" class="alt">Rollback active CNN</button></div><p id="cnnStatusText" class="muted">No CNN checkpoint active (operating in classical baseline mode). Run the 2-cycle synthetic demo or load a local checkpoint/cache.</p><div id="cnnDetailsBox" class="stats"></div></section>
<section class="box"><h2>▶ Video playback · local (Raw + Selected / CNN + Unchanged Argos 2)</h2><div class="bar"><label>Display method<select id="playMethod"><option value="raw">Raw fixed-window reference (fast)</option>${PLAYABLE_METHODS.map((id) => `<option value="${id}" ${id === "argos2" ? "selected" : ""}>${esc(ALL_LABELS[id])}</option>`).join("")}</select></label><label>Target playback fps<select id="playFps"><option>1</option><option>2</option><option selected>5</option><option>10</option><option>15</option><option>25</option><option>30</option></select></label><button id="play">▶ Play from current frame</button><button id="restart" class="alt">↤ Start over</button><button id="showFrame" class="alt">Show selected method on this frame</button></div><label style="width:100%;margin-top:10px">Seek through recording<input id="seek" type="range" min="0" max="79" value="0" step="1" style="width:100%"></label><p id="playerStatus" role="status" class="muted">Ready. Select a recording or use the synthetic sample, then press Play.</p><div class="grid"><div class="card"><h3>Reference · raw, fixed window</h3><canvas id="playerRaw"></canvas></div><div class="card"><h3 id="playerTitle">Selected processed method</h3><canvas id="playerProcessed"></canvas></div><div class="card"><h3 id="playerArgos2Title">Unchanged Original Argos 2 (reference baseline)</h3><canvas id="playerArgos2"></canvas></div></div><p class="muted">The selected method is named here, so do not use playback during a blinded review. Plays all whole frames sequentially to the end of the file (no 60-frame limit and no deliberate frame skipping); processing may run slower than target fps on large frames. Temporal state is kept within each uninterrupted play run and reset on pause, seek, source, decoder or method changes. Claude B (original) may read future frames and is offline; choose 'Claude B Variant · Strictly Causal' for causal past-only operation. Raw/processed images are display intensities, not temperatures.</p></section>
<section class="box"><h2>2 · Evaluation plan</h2><div class="bar"><label>Frame index<input id="frame" type="number" value="0" min="0"></label><button id="prev" class="alt">← Previous</button><button id="next" class="alt">Next →</button><label>Split<select id="split"><option>development</option><option>validation</option><option>held-out</option></select></label><label>Reviewer pseudonym<input id="reviewerId" type="text" value="local-reviewer-1" style="width:130px"></label><button id="freeze">Freeze settings</button><button id="unfreeze" class="alt">Unlock / start new plan</button><button id="shuffle" class="alt">New blind order</button><button id="reveal" class="alt">Reveal method names</button></div><p class="muted">Freeze locks source, decoder, window and method settings. Reserve different sequences before tuning; this tool records your split label and reviewer pseudonym but cannot enforce truly independent recordings. Every single-frame comparison run starts fresh temporal state. Native method outputs (Argos 1–3, Claude A–C) use their own internal AGC/tone mapping, whereas the reference, new-lab and locked-window variants use the shared fixed window [lo, hi].</p><p id="plan" class="good"></p><p id="status" role="status"></p></section>
<section class="box"><h2>3 · Place shared ROIs, then run</h2><div class="flex"><div class="reference"><p>Fixed-window raw reference · drag to draw</p><canvas id="reference"></canvas><p class="muted">ROIs are common to every method. Check their placement after moving to another frame. Counts are uncalibrated sensor values, not °C. A rectangle is not an object segmentation.</p></div><div style="flex:1;min-width:260px"><div class="bar"><label>ROI role<select id="role"><option>animal</option><option>bridge</option><option>background</option><option>thin feature</option><option>stripe / flat region</option></select></label><button id="clearRoi" class="alt">Clear all ROIs</button><button id="loadFrame" class="alt">Load reference frame</button></div><div id="roiList"></div><p class="muted">Use separate rectangles for animal, nearby background, bridge, thin structures and flat striped areas. Change frame and reposition them for moving objects.</p><div class="bar"><button id="run">Run all methods on this frame</button><button id="save" disabled>Record measurements &amp; ratings</button><button id="runAblation" class="alt">Run 7-view stage ablation on this frame</button></div><p class="muted">Full-size processing is compute-intensive and can take time. Timings include each method’s wrapper and differ in internal work; they are not production throughput.</p></div></div></section>
<section class="box"><h2>3B · Genuine stage ablation (locked reference window vs untouched Argos 2)</h2><p id="ablationStatus" class="muted">Click "Run 7-view stage ablation on this frame" above to inspect isolated Line-Only, Tone-Only, Detail-Only (Modified Ablations under locked window), Combined Classical, Untouched Original Argos 2, and Opt-in CNN Residual. Automatically marked STALE if source, frame, settings, ROIs or CNN state change.</p><div id="ablationGrid" class="grid"></div></section>
<section class="box"><h2>4 · Blind review and measurements</h2><p class="muted">Choose scores independently before revealing names: 1 poor → 5 good, or 'tie/uncertain'. These subjective scores are not ground truth. Pixel medians and robust spread are descriptive, not classification or temperature. Consecutive-frame difference is motion-contaminated and not a standalone flicker score.</p><div id="results" class="grid"></div></section>
<section class="box"><h2>4B · Deterministic synthetic hard-negative benchmark (8 scenarios, known clean truth)</h2><div class="bar"><button id="runHardNegBench" class="alt">Run 8-scenario synthetic hard-negative benchmark</button><span id="hardNegStatus" class="muted">Evaluates no-stripe false correction, ±150 ADU alternating stripes, 1px vertical mast &amp; horizontal wire retention, 1×1 point targets, texture/occlusion, motion, FPN+noise, and similar-brightness animal/bridge in 14-bit ADU.</span></div><div id="hardNegTable" class="stats"></div></section>
<section class="box"><h2>5 · Save work locally</h2><label style="width:100%">Frame / observation note<textarea id="note" rows="2" placeholder="Scene, motion, camera movement, artifacts, uncertain ROI placement…"></textarea></label><div class="bar"><button id="export">Export session JSON</button><button id="csv" class="alt">Export measurements CSV</button><label>Restore session JSON<input id="import" type="file" accept=".json,application/json"></label></div><p class="warning">The JSON/CSV exports contain method identities and the blind mapping. Do not open them during a blinded review. The recording is not included. Exports may contain file name, file hash, ROI coordinates, reviewer pseudonym, notes and ratings. Importing a session does not restore the recording; select the original local file again and check identity.</p><p id="records" class="muted">No observations recorded.</p></section>
<details class="box"><summary>Scope, scientific limits, privacy and reproducibility</summary><p>Original classical algorithms (Argos 1–3, Claude A–C) are preserved untouched from starting_point. Argos 2 stage-1 bypass disables both line correction and bad-pixel processing; because Original Argos 2 fuses guided detail decomposition inside its Stage 2/3 S-curve loop, the isolated Line-Only and Detail-Only stage ablation views are explicitly labeled Modified Ablations constructed under the shared locked reference window [lo, hi].</p><p>Sensitive fields in local session exports include local file names, file sizes, SHA-256 digests, reviewer pseudonyms, ROI coordinates and free-text notes. They are stored only in browser memory until you click Export, and can be deleted by deleting the downloaded JSON/CSV files or refreshing the tab. No network requests, analytics or remote uploads occur during local operation.</p></details></main>`;

let file: File | null = null,
  fileHash: string | null = null;
let hashAbort: AbortController | null = null;
let expectedSource: { kind: string; name?: string; size?: number; sha256?: string | null } | null = null;
let s: Settings = { width: 640, height: 512, headerBytes: 0, shift: 0, littleEndian: true, lo: 5500, hi: 7500 };
let rois: Roi[] = [];
let frozen = false,
  revealed = false,
  busy = false,
  sourceLabel = "Synthetic sample",
  runToken = 0;
let raw: Uint16Array | null = null;
let currentFrame = -1;
let current: any = null;
let prior: any = null;
let records: any[] = [];
let order: Method[] = [];
let ratings: Record<
  string,
  {
    visibility: string;
    detail: string;
    artifacts: string;
    note: string;
    perRoi: Record<string, { visibility: string; loss: string; note: string }>;
  }
> = {};
let planId = 1,
  loadEpoch = 0,
  playEpoch = 0,
  playing = false;

// Controlled Offline CNN & Cache state
let cnnRegistry: ModelRegistryState | null = null;
let activeCnnCheckpoint: CnnCheckpoint | null = null;
let cnnBypassed = false;
let cacheManifest: LocalInferenceCacheManifest | null = null;
let cacheBytes: Uint8Array | null = null;

// Genuine Stage Ablation state
let lastAblationReport: CompleteAblationReport | null = null;

const val = (sel: string) => ($<HTMLInputElement>(sel)?.value ?? "").trim();
const setVal = (sel: string, v: unknown) => {
  const el = $<HTMLInputElement>(sel);
  if (el) el.value = String(v);
};

function currentSourceKey(): string {
  return file ? `file:${file.name}:${file.size}:${fileHash ?? "unhashed"}` : `synth:${synthFrameCount()}`;
}

function synthFrameCount(): number {
  const n = Number(val("#synthFrames"));
  return Number.isInteger(n) && n >= 5 && n <= 500 ? n : 80;
}

function currentAblationKey(): string {
  return computeAblationContextKey({
    sourceKey: currentSourceKey(),
    frameIndex: idx(),
    width: s.width,
    height: s.height,
    headerBytes: s.headerBytes,
    shift: s.shift,
    littleEndian: s.littleEndian,
    lo: s.lo,
    hi: s.hi,
    rois,
    cnnCheckpointId: activeCnnCheckpoint?.checkpointId ?? null,
    cnnBypassed,
  });
}

function updateAblationStaleBanner() {
  const el = $("#ablationStatus");
  if (!el) return;
  if (!lastAblationReport) {
    el.className = "muted";
    return;
  }
  const isStale = lastAblationReport.contextKey !== currentAblationKey();
  if (isStale) {
    el.className = "warning";
    el.textContent =
      "STALE ABLATION WARNING: Source, frame index, decoder/window settings, ROIs or CNN state changed since this ablation was computed. Click 'Run 7-view stage ablation on this frame' to refresh.";
  } else {
    el.className = "good";
    el.textContent = `Stage ablation is current for frame ${lastAblationReport.frameIndex} · locked window [${lastAblationReport.lockedWindow.lo}, ${lastAblationReport.lockedWindow.hi}] · monotonic=${lastAblationReport.monotonicityOfLockedWindow.nonDecreasing}.`;
  }
}

function cachedFrameGetter(frameIdx: number): Uint16Array | null {
  if (!cacheManifest || !cacheBytes || cnnBypassed) return null;
  const check = verifyCacheAgainstSource({
    manifest: cacheManifest,
    sourceByteLength: file ? file.size : synthFrameCount() * frameBytes(decodeConfig(s)),
    sourceSha256: fileHash,
    expectedFrames: counts().frames,
    decoder: decodeConfig(s),
    requireSha256Match: !!fileHash,
  });
  if (!check.valid) return null;
  const fb = frameBytes(decodeConfig(s));
  if (frameIdx < 0 || frameIdx >= cacheManifest.frameCount) return null;
  const start = frameIdx * fb;
  const slice = cacheBytes.slice(start, start + fb);
  return decodeBuffer(slice.buffer, decodeConfig(s));
}

function currentCnnRunnerOptions() {
  return {
    checkpoint: activeCnnCheckpoint,
    bypassCnn: cnnBypassed,
    useNativeArgos2ToneForCnn: ($<HTMLInputElement>("#cnnNativeTone")?.checked ?? false),
    cachedFrameGetter: cacheManifest && cacheBytes ? cachedFrameGetter : null,
  };
}

function updateCnnPanel() {
  const txt = $("#cnnStatusText");
  const details = $("#cnnDetailsBox");
  if (!txt || !details) return;
  if (!activeCnnCheckpoint && !cacheManifest) {
    txt.textContent =
      "CNN Status: INACTIVE / CLASSICAL BASELINE ONLY. Run the 2-cycle synthetic demo or load a local checkpoint/cache.";
    details.innerHTML = "";
    return;
  }
  const ckptId = activeCnnCheckpoint?.checkpointId ?? cacheManifest?.checkpointId ?? "none";
  const ckptHash = (activeCnnCheckpoint?.weightsSha256 ?? cacheManifest?.checkpointWeightsSha256 ?? "").slice(0, 16);
  const statusBadge = cnnBypassed
    ? "BYPASSED → Classical Argos 2 Baseline"
    : activeCnnCheckpoint
    ? `${activeCnnCheckpoint.status.toUpperCase()}${activeCnnCheckpoint.isSimulatedDemo ? " (SYNTHETIC DEMO)" : " (CURATED)"}`
    : cacheManifest?.isApprovedActiveModel
    ? "APPROVED CACHE LOADED"
    : "UNAPPROVED CANDIDATE CACHE";

  txt.textContent = `CNN Model: ${ckptId} · weights SHA-256: ${ckptHash}… · Status: ${statusBadge}${
    cacheManifest ? ` · Cache synced (${cacheManifest.frameCount} frames)` : ""
  }`;

  if (cnnRegistry) {
    const logs = cnnRegistry.auditLog
      .slice(-6)
      .map((l) => `[${esc(l.eventType.toUpperCase())}] ${esc(l.summary)}`)
      .join("<br>");
    details.innerHTML = `<b>Registry Active ID:</b> ${esc(cnnRegistry.activeCheckpointId ?? "none")} · <b>Previous Active (Rollback Target):</b> ${esc(
      cnnRegistry.previousActiveCheckpointId ?? "none"
    )}<br><b>Recent Registry Audit Log:</b><br>${logs}`;
  } else if (activeCnnCheckpoint) {
    details.innerHTML = `<b>Loaded Checkpoint:</b> ${esc(activeCnnCheckpoint.checkpointId)} · cycle ${
      activeCnnCheckpoint.cycleNumber
    } · params: ${activeCnnCheckpoint.parameterCount} · steps: ${activeCnnCheckpoint.stepsRun} · weightUpdateL2: ${
      activeCnnCheckpoint.totalWeightUpdateL2
    }`;
  }
}

function clearPlayerProcessed() {
  for (const sel of ["#playerProcessed", "#playerArgos2"]) {
    const c = $<HTMLCanvasElement>(sel);
    if (c) c.getContext("2d")?.clearRect(0, 0, c.width, c.height);
  }
  $("#playerTitle").textContent = "Selected processed method";
}

function stopPlayback(msg = "Paused. Play starts with fresh temporal state.") {
  playing = false;
  playEpoch++;
  $("#playerStatus").textContent = msg;
  displayStatus();
}

function readForm(): Settings {
  return {
    width: Number(val("#w")),
    height: Number(val("#h")),
    headerBytes: Number(val("#header")),
    shift: Number(val("#shift")),
    littleEndian: val("#endian") === "le",
    lo: Number(val("#lo")),
    hi: Number(val("#hi")),
  };
}
function putForm() {
  setVal("#w", s.width);
  setVal("#h", s.height);
  setVal("#header", s.headerBytes);
  setVal("#shift", s.shift);
  setVal("#endian", s.littleEndian ? "le" : "be");
  setVal("#lo", s.lo);
  setVal("#hi", s.hi);
}
function status(t: string) {
  $("#status").textContent = t;
}
function counts() {
  return file ? frameCountFor(file.size, decodeConfig(s)) : { frames: synthFrameCount(), remainder: 0 };
}
function idx() {
  return Number(val("#frame"));
}
function validFrame() {
  if (expectedSource?.kind === "file" && !file) throw Error("Reselect the original local recording first.");
  const i = idx(),
    n = counts().frames;
  if (!Number.isInteger(i) || i < 0 || i >= n) throw Error(`Frame must be an integer between 0 and ${n - 1}.`);
  return i;
}
async function getFrame(i: number) {
  if (i < 0 || i >= counts().frames) return null;
  return file ? readFrame(file, decodeConfig(s), i) : synthetic(s.width, s.height, i);
}
function displayStatus() {
  const c = counts();
  $("#source").textContent = file
    ? `${file.name} · ${file.size.toLocaleString()} bytes`
    : expectedSource?.kind === "file"
    ? "Reselect original local file"
    : `${sourceLabel} (${c.frames} frames)`;
  $("#decoder").textContent = `${c.frames} whole frames · ${c.remainder} leftover bytes${
    c.remainder ? " — format suspect (leftover bytes may indicate unsupported format/header)" : ""
  } · 14-bit mask · ${s.width}×${s.height} · reference ${s.lo}–${s.hi}`;
  $("#hashtext").textContent = fileHash ? "Local SHA-256: " + fileHash : "";
  $("#plan").textContent = `Plan ${planId} · ${frozen ? "SETTINGS FROZEN" : "not frozen"} · ${
    revealed ? "names revealed" : "blind labels"
  } · ${records.length} recorded observation(s)`;
  $("#records").textContent = `${records.length} observations recorded in this browser tab. Export before closing.`;
  for (const id of ["file", "synth", "synthFrames", "w", "h", "header", "shift", "endian", "lo", "hi", "apply", "autoWindow", "shuffle"])
    ($("#" + id) as HTMLInputElement).disabled = frozen || busy || playing;
  for (const id of [
    "frame",
    "prev",
    "next",
    "loadFrame",
    "clearRoi",
    "run",
    "runAblation",
    "runHardNegBench",
    "freeze",
    "unfreeze",
    "reveal",
    "import",
    "hash",
    "seek",
    "playMethod",
    "restart",
    "showFrame",
  ])
    ($("#" + id) as HTMLInputElement).disabled = busy || playing;
  ($("#save") as HTMLButtonElement).disabled = busy || playing || !current;
  ($("#play") as HTMLButtonElement).disabled = busy;
  $("#play").textContent = playing ? "⏸ Pause" : "▶ Play from current frame";
  setVal("#seek", Math.max(0, Math.min(idx() || 0, Math.max(0, c.frames - 1))));
  ($("#seek") as HTMLInputElement).max = String(Math.max(0, c.frames - 1));
  updateCnnPanel();
  updateAblationStaleBanner();
}
function shuffle() {
  order = [...METHODS];
  for (let i = order.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  revealed = false;
  ratings = {};
}
function invalidate(keepPrior = true) {
  runToken++;
  if (!keepPrior) prior = null;
  current = null;
  ($("#results") as HTMLElement).innerHTML = "";
  displayStatus();
}
function drawGray(canvas: HTMLCanvasElement, pixels: ArrayLike<number>, w = s.width, h = s.height) {
  canvas.width = w;
  canvas.height = h;
  const c = canvas.getContext("2d")!;
  const d = c.createImageData(w, h);
  for (let i = 0; i < pixels.length; i++) {
    const v = pixels[i];
    d.data[i * 4] = v;
    d.data[i * 4 + 1] = v;
    d.data[i * 4 + 2] = v;
    d.data[i * 4 + 3] = 255;
  }
  c.putImageData(d, 0, 0);
}
function drawReference() {
  if (!raw) return;
  const c = $<HTMLCanvasElement>("#reference");
  drawGray(c, reference(raw, s));
  const ctx = c.getContext("2d")!;
  ctx.lineWidth = Math.max(1, s.width / 500);
  ctx.strokeStyle = "#5fffc1";
  ctx.font = `${Math.max(10, s.width / 55)}px sans-serif`;
  for (const r of rois) {
    ctx.strokeRect(r.x, r.y, r.w, r.h);
    ctx.fillStyle = "#5fffc1";
    ctx.fillText(r.label, r.x + 2, Math.max(12, r.y + 12));
  }
}
function listRois() {
  $("#roiList").innerHTML = rois.length
    ? "<table><tr><th>ROI</th><th>x,y · w×h</th><th></th></tr>" +
      rois
        .map(
          (r, i) =>
            `<tr><td>${esc(r.label)}</td><td>${r.x},${r.y} · ${r.w}×${r.h}</td><td><button class="remove alt" data-index="${i}">Remove</button></td></tr>`
        )
        .join("") +
      "</table>"
    : '<p class="muted">No ROIs yet.</p>';
  if (raw && rois.length) {
    const rows = rois.map((r) => ({ roi: r, st: stats(raw!, s.width, s.height, r, 16383) }));
    $("#roiList").innerHTML +=
      '<p class="stats"><b>Raw counts (median / robust spread / sat%):</b><br>' +
      rows
        .map(
          (x) =>
            `${esc(x.roi.label)}: ${x.st.median.toFixed(1)} / ${x.st.sigma.toFixed(1)} ADU (clip ${(
              x.st.satFrac * 100
            ).toFixed(1)}%)`
        )
        .join("<br>") +
      "</p>";
    for (const a of rows.filter((x) => x.roi.role === "animal"))
      for (const b of rows.filter((x) => x.roi.role === "bridge")) {
        const p = medianGap(a.st, b.st);
        $("#roiList").innerHTML += `<p class="stats">${esc(a.roi.label)} − ${esc(b.roi.label)}: ${p.delta.toFixed(
          1
        )} counts; ratio ${
          p.ratio === null ? "not defined" : p.ratio.toFixed(2)
        }. Descriptive only, not a separability or temperature verdict.</p>`;
      }
  }
  drawReference();
  updateAblationStaleBanner();
}
async function load() {
  const ticket = ++loadEpoch;
  try {
    const i = validFrame();
    const nextRaw = await getFrame(i);
    if (ticket !== loadEpoch) return;
    raw = nextRaw;
    currentFrame = i;
    invalidate();
    listRois();
    if (raw) drawGray($<HTMLCanvasElement>("#playerRaw"), reference(raw, s));
    clearPlayerProcessed();
    $("#playerStatus").textContent = `Frame ${i} / ${Math.max(0, counts().frames - 1)} loaded. Press Play or Show selected method.`;
    status(`Frame ${i} loaded. Review ROI positions before running.`);
  } catch (e) {
    if (ticket === loadEpoch) status(String(e));
  }
}
function finishResult() {
  if (!current) return;
  const box = $("#results");
  box.innerHTML = order
    .map((id, k) => {
      const name = revealed ? LABELS[id] : `Candidate ${String.fromCharCode(65 + k)}`;
      return `<article class="card"><h3>${esc(name)}</h3><canvas id="card-${k}"></canvas><div class="stats" id="stat-${k}"></div><details><summary>Per-ROI review</summary>${rois
        .map(
          (r) =>
            `<div class="rating"><b>${esc(r.label)}</b><label>Visibility<select data-method="${id}" data-roi="${esc(
              r.id
            )}" data-rating="visibility"><option value="">Not scored</option>${[1, 2, 3, 4, 5, "tie/uncertain"]
              .map(
                (n) =>
                  `<option value="${n}" ${
                    ratings[id]?.perRoi?.[r.id]?.visibility === String(n) ? "selected" : ""
                  }>${n}</option>`
              )
              .join("")}</select></label><label>Feature loss<select data-method="${id}" data-roi="${esc(
              r.id
            )}" data-rating="loss"><option value="">Not judged</option>${["no", "uncertain", "yes"]
              .map(
                (x) =>
                  `<option value="${x}" ${ratings[id]?.perRoi?.[r.id]?.loss === x ? "selected" : ""}>${x}</option>`
              )
              .join("")}</select></label><label>Observation<input type="text" data-method="${id}" data-roi="${esc(
              r.id
            )}" data-rating="note" value="${esc(ratings[id]?.perRoi?.[r.id]?.note || "")}"></label></div>`
        )
        .join("")}</details><div class="rating">${["visibility", "detail", "artifacts"]
        .map(
          (key) =>
            `<label>${key === "artifacts" ? "Artifact control" : key}<select data-method="${id}" data-rating="${key}"><option value="">Not scored</option>${[
              1,
              2,
              3,
              4,
              5,
              "tie/uncertain",
            ]
              .map(
                (n) =>
                  `<option value="${n}" ${
                    ratings[id]?.[key as "visibility"] === String(n) ? "selected" : ""
                  }>${n}</option>`
              )
              .join("")}</select></label>`
        )
        .join("")}</div><label style="width:100%;margin-top:6px">Candidate note<input type="text" data-method="${id}" data-rating="note" value="${esc(
        ratings[id]?.note || ""
      )}"></label></article>`;
    })
    .join("");
  order.forEach((id, k) => {
    const a = current.results[id];
    const canvas = $<HTMLCanvasElement>("#card-" + k);
    drawGray(canvas, a.pixels);
    const ctx = canvas.getContext("2d")!;
    ctx.lineWidth = Math.max(1, s.width / 500);
    ctx.strokeStyle = "#5fffc1";
    for (const r of rois) ctx.strokeRect(r.x, r.y, r.w, r.h);
    const lines = rois.map((r) => {
      const x = stats(a.pixels, s.width, s.height, r, 255);
      const t = current.temporal?.[id]?.[r.id];
      return `${esc(r.label)}: median ${x.median.toFixed(1)} / spread ${x.sigma.toFixed(1)} levels${
        t != null ? " · prev Δ " + t.toFixed(1) : ""
      }`;
    });
    $("#stat-" + k).innerHTML = `${a.ms.toFixed(1)} ms · ${
      a.toneDomain === "locked_fixed_window" ? "locked window" : "native AGC"
    } · ${lines.join("<br>") || "Add ROIs for measurements."}`;
  });
}
async function run() {
  if (busy) return;
  ++loadEpoch;
  try {
    const err = validSettings(s);
    if (err) throw Error(err);
    const frame = validFrame();
    busy = true;
    displayStatus();
    status("Loading and running 12 configurations. Please wait…");
    await new Promise((r) => setTimeout(r, 30));
    const input = await getFrame(frame);
    if (!input) throw Error("Frame unavailable");
    raw = input;
    currentFrame = frame;
    listRois();
    const out: Record<string, any> = {};
    for (let j = 0; j < order.length; j++) {
      const id = order[j];
      status(`Processing ${j + 1} / ${order.length}…`);
      await new Promise((r) => setTimeout(r, 0));
      out[id] = await runMethod(id, input, s, frame, counts().frames, getFrame, currentCnnRunnerOptions());
    }
    const temporal: any = {};
    if (
      prior &&
      prior.index === frame - 1 &&
      JSON.stringify(prior.rois) === JSON.stringify(rois) &&
      JSON.stringify(prior.settings) === JSON.stringify(s)
    ) {
      for (const id of order) {
        temporal[id] = {};
        for (const r of rois)
          temporal[id][r.id] = temporalDifference(out[id].pixels, prior.results[id].pixels, s.width, s.height, r);
      }
    }
    current = {
      index: frame,
      settings: { ...s },
      rois: structuredClone(rois),
      results: out,
      temporal,
      activeCnnCheckpointId: activeCnnCheckpoint?.checkpointId ?? null,
      cnnBypassed,
    };
    ratings = {};
    finishResult();
    status(`Frame ${frame} complete. Rate candidates before revealing names, then record.`);
  } catch (e) {
    status("Error: " + String(e));
  } finally {
    busy = false;
    displayStatus();
  }
}
function snapshot() {
  if (!current || !raw) return;
  if (val("#split") === "held-out" && !frozen) {
    status("Freeze settings before recording held-out observations.");
    return;
  }
  const rawRows = rois.map((r) => ({ roi: r, stats: stats(raw!, s.width, s.height, r, 16383) }));
  const pairs: any[] = [];
  for (const a of rawRows.filter((x) => x.roi.role === "animal"))
    for (const b of rawRows.filter((x) => x.roi.role === "bridge"))
      pairs.push({ animal: a.roi.label, bridge: b.roi.label, ...medianGap(a.stats, b.stats) });
  const methods: any = {};
  for (const id of order) {
    const a = current.results[id];
    methods[id] = {
      label: LABELS[id],
      blindLabel: `Candidate ${String.fromCharCode(65 + order.indexOf(id))}`,
      config: a.config,
      toneDomain: a.toneDomain,
      ms: a.ms,
      rating: ratings[id] || {},
      rois: rois.map((r) => ({
        roi: r,
        display: stats(a.pixels, s.width, s.height, r, 255),
        restored14: a.restored ? stats(a.restored, s.width, s.height, r, 16383) : null,
        meanAbsChangeFromPrevious: current.temporal?.[id]?.[r.id] ?? null,
      })),
    };
  }
  records.push({
    planId,
    index: current.index,
    split: val("#split"),
    reviewer: val("#reviewerId") || "local-reviewer",
    timestamp: new Date().toISOString(),
    blindAtRecording: !revealed,
    source: file
      ? { name: file.name, size: file.size, lastModified: file.lastModified, sha256: fileHash }
      : { name: "synthetic", frames: synthFrameCount() },
    settings: { ...s },
    activeCnnCheckpointId: current.activeCnnCheckpointId ?? null,
    cnnBypassed: current.cnnBypassed ?? true,
    note: val("#note"),
    rois: structuredClone(rois),
    raw: rawRows,
    animalBridgePairs: pairs,
    methods,
  });
  prior = current;
  status(`Recorded frame ${current.index}. Export the session before closing.`);
  displayStatus();
}
function download(name: string, content: string, type: string) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function session() {
  return {
    schema: "clearhot-local-session-v1",
    version: VERSION,
    created: new Date().toISOString(),
    warning: "Contains blind mapping and sensitive metadata. No recording pixels are included.",
    source: file
      ? { kind: "file", name: file.name, size: file.size, lastModified: file.lastModified, sha256: fileHash }
      : { kind: "synthetic", frames: synthFrameCount() },
    settings: s,
    methodOrder: order,
    methodLabels: LABELS,
    configs: Object.fromEntries(METHODS.map((id) => [id, configFor(id, s)])),
    activeCnnCheckpointId: activeCnnCheckpoint?.checkpointId ?? null,
    activeCnnWeightsSha256: activeCnnCheckpoint?.weightsSha256 ?? null,
    cnnBypassed,
    frozen,
    revealed,
    planId,
    rois,
    records,
  };
}
function exportCsv() {
  const q = (x: any) => '"' + String(x ?? "").replace(/"/g, '""') + '"';
  const rows = [
    [
      "plan",
      "frame",
      "split",
      "reviewer",
      "blind_at_recording",
      "method",
      "blind_label",
      "tone_domain",
      "role",
      "roi",
      "x",
      "y",
      "width",
      "height",
      "raw_adu_median",
      "raw_adu_robust_sigma",
      "display_median",
      "display_robust_sigma",
      "mean_abs_prev_display_delta",
      "ms",
      "visibility_1_to_5",
      "detail_1_to_5",
      "artifact_control_1_to_5",
      "candidate_note",
      "roi_visibility_1_to_5",
      "roi_feature_loss",
      "roi_observation",
      "frame_note",
    ],
  ];
  for (const rec of records)
    for (const [id, m] of Object.entries(rec.methods) as [string, any][]) {
      const rt = m.rating || {};
      if (!m.rois.length)
        rows.push([
          rec.planId,
          rec.index,
          rec.split,
          rec.reviewer ?? "",
          rec.blindAtRecording,
          id,
          m.blindLabel,
          m.toneDomain ?? "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          m.ms.toFixed(2),
          rt.visibility,
          rt.detail,
          rt.artifacts,
          rt.note,
          "",
          "",
          "",
          rec.note,
        ]);
      for (const r of m.rois) {
        const rr = rt.perRoi?.[r.roi.id] || {};
        const rawEntry = rec.raw?.find((x: any) => x.roi.id === r.roi.id)?.stats;
        rows.push([
          rec.planId,
          rec.index,
          rec.split,
          rec.reviewer ?? "",
          rec.blindAtRecording,
          id,
          m.blindLabel,
          m.toneDomain ?? "",
          r.roi.role,
          r.roi.label,
          r.roi.x,
          r.roi.y,
          r.roi.w,
          r.roi.h,
          rawEntry ? rawEntry.median.toFixed(2) : "",
          rawEntry ? rawEntry.sigma.toFixed(2) : "",
          r.display.median.toFixed(2),
          r.display.sigma.toFixed(2),
          r.meanAbsChangeFromPrevious?.toFixed(2) ?? "",
          m.ms.toFixed(2),
          rt.visibility,
          rt.detail,
          rt.artifacts,
          rt.note,
          rr.visibility,
          rr.loss,
          rr.note,
          rec.note,
        ]);
      }
    }
  download("clearhot-measurements.csv", rows.map((r) => r.map(q).join(",")).join("\n"), "text/csv");
}

async function playOneOrSequence(one: boolean) {
  if (busy) return;
  const err = validSettings(s);
  if (err) {
    status(err);
    return;
  }
  let start = 0;
  try {
    start = validFrame();
  } catch (e) {
    status(String(e));
    return;
  }
  const token = ++playEpoch;
  playing = !one;
  displayStatus();
  const mode = val("#playMethod");
  const totalFrames = counts().frames;
  const cnnOpts = currentCnnRunnerOptions();
  const runner =
    mode === "raw"
      ? null
      : createMethodRunner(mode as AnyPlayableMethod, { ...s }, totalFrames, getFrame, cnnOpts);
  const argos2Runner = createMethodRunner("argos2", { ...s }, totalFrames, getFrame);

  try {
    for (let i = start; i < totalFrames; i++) {
      if (token !== playEpoch) return;
      const began = performance.now();
      const frame = await getFrame(i);
      if (token !== playEpoch) return;
      if (!frame) throw Error("Frame unavailable.");
      const ref = reference(frame, s);
      const out = runner ? await runner(frame, i) : null;
      const argos2Out = mode === "argos2" && out ? out : await argos2Runner(frame, i);
      if (token !== playEpoch) return;
      raw = frame;
      currentFrame = i;
      setVal("#frame", i);
      drawGray($<HTMLCanvasElement>("#playerRaw"), ref);
      drawGray($<HTMLCanvasElement>("#playerProcessed"), out?.pixels ?? ref);
      drawGray($<HTMLCanvasElement>("#playerArgos2"), argos2Out.pixels);

      let titleText = runner ? ALL_LABELS[mode as AnyPlayableMethod] : "Raw reference (identical to left)";
      if (mode === "cnn-active") {
        const ckptId = activeCnnCheckpoint?.checkpointId ?? cacheManifest?.checkpointId ?? "none";
        titleText = cnnBypassed
          ? "CNN BYPASSED → Showing Classical Stage 1 Baseline"
          : `CNN (${ckptId} · ${activeCnnCheckpoint?.status ?? "cache"})`;
      }
      $("#playerTitle").textContent = titleText;
      setVal("#seek", i);
      const elapsed = performance.now() - began;
      $("#playerStatus").textContent = `Frame ${i} / ${totalFrames - 1} · ${elapsed.toFixed(
        0
      )} ms/frame · target ${val("#playFps")} fps${
        elapsed > 1000 / Number(val("#playFps")) ? " · processing slower than target" : ""
      }`;
      if (one) {
        stopPlayback(`Showing frame ${i}. Play starts with fresh temporal state.`);
        return;
      }
      if (i === totalFrames - 1) {
        stopPlayback(`Reached the final frame (${i}). Use Start over to replay.`);
        return;
      }
      const delay = Math.max(0, 1000 / Number(val("#playFps")) - elapsed);
      await new Promise((r) => setTimeout(r, delay));
    }
  } catch (e) {
    if (token === playEpoch) stopPlayback("Playback error: " + String(e));
  }
}

$("#play").onclick = () => {
  if (playing) stopPlayback();
  else playOneOrSequence(false);
};
$("#restart").onclick = async () => {
  setVal("#frame", 0);
  await load();
  playOneOrSequence(false);
};
$("#showFrame").onclick = () => playOneOrSequence(true);
$("#seek").addEventListener("change", () => {
  setVal("#frame", val("#seek"));
  load();
});
$("#playMethod").addEventListener("change", () => {
  clearPlayerProcessed();
  $("#playerStatus").textContent = "Method changed. Press Play or Show selected method.";
});
$("#file").addEventListener("change", async (e) => {
  const f = (e.target as HTMLInputElement).files?.[0];
  if (!f) return;
  const expected = expectedSource;
  const matches = expected?.kind === "file" && f.name === expected.name && f.size === expected.size;
  if (
    expected?.kind === "file" &&
    !matches &&
    !confirm("This file name or size differs from the imported session. Continue as a different source and clear current ROIs?")
  ) {
    (e.target as HTMLInputElement).value = "";
    return;
  }
  file = f;
  fileHash = null;
  if (!matches) rois = [];
  if (!matches) expectedSource = null;
  setVal("#frame", 0);
  invalidate(false);
  listRois();
  displayStatus();
  await load();
  if (matches)
    status("Name and size match the imported session; verify the optional SHA-256 before relying on identity. ROI locations were retained.");
});
$("#synth").onclick = async () => {
  file = null;
  fileHash = null;
  expectedSource = null;
  rois = [];
  setVal("#frame", 0);
  invalidate(false);
  listRois();
  displayStatus();
  await load();
};
$("#synthFrames")?.addEventListener("change", async () => {
  if (!file) {
    setVal("#frame", 0);
    invalidate(false);
    displayStatus();
    await load();
  }
});
$("#apply").onclick = async () => {
  const proposed = readForm();
  const error = validSettings(proposed);
  if (error) {
    status(error);
    return;
  }
  s = proposed;
  rois = [];
  setVal("#frame", 0);
  invalidate(false);
  listRois();
  displayStatus();
  await load();
};
$("#autoWindow").onclick = () => {
  if (!raw) {
    status("Load a frame first.");
    return;
  }
  if (JSON.stringify(readForm()) !== JSON.stringify(s)) {
    status("Apply edited decoder settings first.");
    return;
  }
  const hist = new Uint32Array(16384);
  for (const v of raw) hist[Math.min(16383, v)]++;
  let acc = 0,
    lo = 0,
    hi = 16383,
    found = false;
  for (let i = 0; i < hist.length; i++) {
    acc += hist[i];
    if (!found && acc >= raw.length * 0.01) {
      lo = i;
      found = true;
    }
    if (acc >= raw.length * 0.99) {
      hi = i;
      break;
    }
  }
  const pad = Math.max(50, Math.round((hi - lo) * 0.1));
  s = { ...s, lo: Math.max(0, lo - pad), hi: Math.min(16383, Math.max(hi + pad, lo - pad + 1)) };
  if (s.lo >= s.hi) s = { ...s, lo: Math.max(0, s.hi - 1) };
  putForm();
  invalidate(false);
  listRois();
  drawGray($<HTMLCanvasElement>("#playerRaw"), reference(raw, s));
  clearPlayerProcessed();
  displayStatus();
  status(`Suggested fixed window ${s.lo}–${s.hi} from this frame. Verify visually; it will remain fixed.`);
};
$("#loadFrame").onclick = load;
$("#prev").onclick = () => {
  setVal("#frame", Math.max(0, idx() - 1));
  load();
};
$("#next").onclick = () => {
  setVal("#frame", Math.min(counts().frames - 1, idx() + 1));
  load();
};
$("#frame").addEventListener("change", () => {
  invalidate();
  load();
});
$("#freeze").onclick = () => {
  if (frozen) {
    status("Settings already frozen.");
    return;
  }
  if (JSON.stringify(readForm()) !== JSON.stringify(s)) {
    status("Apply the edited decoder/window before freezing.");
    return;
  }
  const err = validSettings(s);
  if (err) {
    status(err);
    return;
  }
  if (expectedSource?.kind === "file" && !file) {
    status("Reselect the original local recording first.");
    return;
  }
  if (file && counts().frames === 0) {
    status("No complete frame. Check decoder settings.");
    return;
  }
  frozen = true;
  planId++;
  displayStatus();
  status("Plan frozen. Frame, split and ROI annotations remain editable.");
};
$("#unfreeze").onclick = () => {
  if (
    records.length &&
    !confirm("Unlock for a new plan? Existing recorded observations will remain with their own plan IDs.")
  )
    return;
  frozen = false;
  invalidate(false);
  displayStatus();
  status("Unlocked. Freeze again before evaluating held-out data.");
};
$("#shuffle").onclick = () => {
  shuffle();
  invalidate(false);
  displayStatus();
  status("Blind candidate order shuffled.");
};
$("#reveal").onclick = () => {
  revealed = true;
  finishResult();
  displayStatus();
};
$("#clearRoi").onclick = () => {
  rois = [];
  invalidate(false);
  listRois();
};
$("#roiList").onclick = (e) => {
  const b = (e.target as HTMLElement).closest<HTMLButtonElement>("button.remove");
  if (!b) return;
  rois.splice(Number(b.dataset.index), 1);
  invalidate(false);
  listRois();
};

let start: { x: number; y: number } | null = null;
const cv = $<HTMLCanvasElement>("#reference");
function position(e: PointerEvent) {
  const r = cv.getBoundingClientRect();
  return {
    x: Math.max(0, Math.min(s.width, Math.round(((e.clientX - r.left) * s.width) / r.width))),
    y: Math.max(0, Math.min(s.height, Math.round(((e.clientY - r.top) * s.height) / r.height))),
  };
}
cv.onpointerdown = (e) => {
  if (!raw || busy || playing) return;
  start = position(e);
  cv.setPointerCapture(e.pointerId);
};
cv.onpointerup = (e) => {
  if (!start) return;
  const p = position(e);
  const x = Math.min(p.x, start.x),
    y = Math.min(p.y, start.y),
    w = Math.abs(p.x - start.x),
    h = Math.abs(p.y - start.y);
  start = null;
  if (w < 2 || h < 2) return;
  const role = val("#role");
  rois.push({
    id: `r${Date.now()}-${rois.length}`,
    role: role as Roi["role"],
    label: `${role} ${rois.filter((r) => r.role === role).length + 1}`,
    x,
    y,
    w,
    h,
  });
  invalidate(false);
  listRois();
};

$("#run").onclick = run;
$("#save").onclick = snapshot;
$("#results").addEventListener("input", (e) => {
  const el = e.target as HTMLInputElement;
  const id = el.dataset.method,
    key = el.dataset.rating;
  if (!id || !key) return;
  ratings[id] ??= { visibility: "", detail: "", artifacts: "", note: "", perRoi: {} };
  const roi = el.dataset.roi;
  if (roi) {
    ratings[id].perRoi[roi] ??= { visibility: "", loss: "", note: "" };
    (ratings[id].perRoi[roi] as any)[key] = el.value;
  } else (ratings[id] as any)[key] = el.value;
});
$("#export").onclick = () => download("clearhot-session.json", JSON.stringify(session(), null, 2), "application/json");
$("#csv").onclick = exportCsv;

// Cancellable full-file streaming SHA-256
$("#hash").onclick = async () => {
  if (!file) {
    status("Select a file first.");
    return;
  }
  busy = true;
  hashAbort = new AbortController();
  const cancelBtn = $<HTMLButtonElement>("#cancelHash");
  if (cancelBtn) cancelBtn.disabled = false;
  displayStatus();
  try {
    const selected = file;
    fileHash = await sha256File(
      selected,
      (p) => status(`Hashing locally (full-file SHA-256): ${(p * 100).toFixed(0)}%`),
      hashAbort.signal
    );
    status(
      expectedSource?.sha256
        ? fileHash === expectedSource.sha256
          ? "Local hash matches imported session."
          : "WARNING: local hash differs from imported session!"
        : "Local hash complete."
    );
  } catch (e) {
    status("Hash failed: " + String(e));
  } finally {
    busy = false;
    hashAbort = null;
    if (cancelBtn) cancelBtn.disabled = true;
    displayStatus();
  }
};
$("#cancelHash")?.addEventListener("click", () => {
  hashAbort?.abort();
});

$("#import").addEventListener("change", async (e) => {
  try {
    const f = (e.target as HTMLInputElement).files?.[0];
    if (!f) return;
    const obj = JSON.parse(await f.text());
    if (
      obj.schema !== "clearhot-local-session-v1" ||
      validSettings(obj.settings) ||
      !Array.isArray(obj.records) ||
      !Array.isArray(obj.rois) ||
      !Array.isArray(obj.methodOrder) ||
      obj.methodOrder.length !== METHODS.length ||
      new Set(obj.methodOrder).size !== METHODS.length ||
      obj.methodOrder.some((x: string) => !METHODS.includes(x as Method))
    )
      throw Error("Invalid session");
    s = obj.settings;
    records = obj.records;
    rois = obj.rois;
    order = obj.methodOrder;
    planId = Number(obj.planId) || 0;
    frozen = false;
    revealed = !!obj.revealed;
    file = null;
    fileHash = null;
    expectedSource = obj.source?.kind === "file" ? obj.source : null;
    raw = null;
    prior = null;
    current = null;
    $<HTMLCanvasElement>("#reference").getContext("2d")!.clearRect(0, 0, s.width, s.height);
    setVal("#frame", 0);
    putForm();
    listRois();
    displayStatus();
    status(
      `Session restored. ${
        obj.source?.kind === "file"
          ? "Reselect the original file; name/size-matched ROIs are retained. Verify the optional SHA-256 against the export."
          : "Synthetic source selected."
      }`
    );
  } catch (e) {
    status("Import failed: " + String(e));
  }
});

// --- Controlled Offline CNN & Cache Handlers ---
$("#runCnnDemo")?.addEventListener("click", async () => {
  if (busy || playing) return;
  busy = true;
  displayStatus();
  status("Running 2-cycle synthetic offline CNN loop (train → validate → approve → reject failing → rollback)…");
  await new Promise((r) => setTimeout(r, 20));
  try {
    const demo = runTwoCycleSyntheticDemo({ width: 64, height: 64, stepsCycle1: 20, stepsCycle2: 20 });
    cnnRegistry = demo.registry;
    activeCnnCheckpoint = demo.registry.activeCheckpointId
      ? demo.registry.checkpoints[demo.registry.activeCheckpointId]
      : null;
    cnnBypassed = false;
    setVal("#playMethod", "cnn-active");
    status(
      `2-Cycle CNN Demo complete: Active model is '${activeCnnCheckpoint?.checkpointId}' (ΔPSNR vs Argos 2 Stage 1 = +${demo.cycle1Report.aggregate.psnrDeltaVsBaselineDb.toFixed(
        2
      )} dB). Failing Cycle-2 candidate was rejected by safety gates (${demo.cycle2FailingReport.failedGates.join(
        ", "
      )}). Display method set to Opt-in CNN.`
    );
  } catch (e) {
    status("CNN demo error: " + String(e));
  } finally {
    busy = false;
    displayStatus();
  }
});

$("#loadCheckpointFile")?.addEventListener("change", async (e) => {
  try {
    const f = (e.target as HTMLInputElement).files?.[0];
    if (!f) return;
    const obj = JSON.parse(await f.text()) as CnnCheckpoint;
    if (!verifyCheckpointIntegrity(obj)) {
      throw new Error("Checkpoint failed schema or weightsSha256 integrity verification.");
    }
    activeCnnCheckpoint = obj;
    cnnBypassed = false;
    setVal("#playMethod", "cnn-active");
    displayStatus();
    status(`Loaded CNN checkpoint '${obj.checkpointId}' (status: ${obj.status}).`);
  } catch (err) {
    status("Checkpoint load failed: " + String(err));
  }
});

$("#loadCacheManifest")?.addEventListener("change", async (e) => {
  try {
    const f = (e.target as HTMLInputElement).files?.[0];
    if (!f) return;
    const m = JSON.parse(await f.text()) as LocalInferenceCacheManifest;
    if (m.schema !== "clearhot-inference-cache-v1") {
      throw new Error("Invalid cache manifest schema.");
    }
    cacheManifest = m;
    displayStatus();
    status(
      `Cache manifest loaded for '${m.sourceFileName}' (${m.frameCount} frames, model ${m.checkpointId}). Now select the matching .chcache.bin file.`
    );
  } catch (err) {
    status("Cache manifest error: " + String(err));
  }
});

$("#loadCacheBin")?.addEventListener("change", async (e) => {
  try {
    const f = (e.target as HTMLInputElement).files?.[0];
    if (!f) return;
    if (!cacheManifest) {
      throw new Error("Load the .chcache.json manifest first.");
    }
    const ab = await f.arrayBuffer();
    const bytes = new Uint8Array(ab);
    const actualCacheHash = sha256Bytes(bytes);
    if (actualCacheHash.toLowerCase() !== cacheManifest.cacheSha256.toLowerCase()) {
      throw new Error("Cache binary SHA-256 does not match manifest cacheSha256.");
    }
    const check = verifyCacheAgainstSource({
      manifest: cacheManifest,
      sourceByteLength: file ? file.size : synthFrameCount() * frameBytes(decodeConfig(s)),
      sourceSha256: fileHash,
      expectedFrames: counts().frames,
      decoder: decodeConfig(s),
      requireSha256Match: !!fileHash,
    });
    if (!check.valid) {
      throw new Error(check.error || "Cache does not match current source recording.");
    }
    cacheBytes = bytes;
    cnnBypassed = false;
    setVal("#playMethod", "cnn-active");
    displayStatus();
    status(`Verified local inference cache (${cacheManifest.frameCount} frames) synced to player.`);
  } catch (err) {
    status("Cache binary rejected: " + String(err));
  }
});

$("#bypassCnnBtn")?.addEventListener("click", () => {
  cnnBypassed = !cnnBypassed;
  displayStatus();
  status(
    cnnBypassed
      ? "CNN bypassed: player and ablation now fall back immediately to classical Stage 1 / Argos 2 baseline."
      : "CNN re-enabled."
  );
  if (raw) playOneOrSequence(true);
});

$("#rollbackCnnBtn")?.addEventListener("click", () => {
  try {
    if (cnnRegistry && cnnRegistry.activeCheckpointId) {
      const res = rollbackActiveModel(cnnRegistry, {
        reviewer: val("#reviewerId") || "local-operator",
        reason: "User clicked Rollback active CNN in local player.",
      });
      activeCnnCheckpoint = res.restoredCheckpointId
        ? cnnRegistry.checkpoints[res.restoredCheckpointId]
        : null;
      cnnBypassed = !activeCnnCheckpoint;
      displayStatus();
      status(
        `Rolled back from '${res.rolledBackCheckpointId}' to '${
          res.restoredCheckpointId ?? "classical Argos 2 baseline"
        }'.`
      );
    } else {
      activeCnnCheckpoint = null;
      cacheManifest = null;
      cacheBytes = null;
      cnnBypassed = true;
      displayStatus();
      status("Cleared loaded CNN checkpoint/cache; reverted to classical Argos 2 baseline.");
    }
    if (raw) playOneOrSequence(true);
  } catch (err) {
    status("Rollback error: " + String(err));
  }
});

// --- Genuine 7-View Stage Ablation Handler ---
$("#runAblation")?.addEventListener("click", async () => {
  if (busy || playing) return;
  try {
    const i = validFrame();
    const frame = await getFrame(i);
    if (!frame) throw new Error("Frame unavailable.");
    raw = frame;
    lastAblationReport = runGenuineStageAblation({
      sourceKey: currentSourceKey(),
      raw14: frame,
      width: s.width,
      height: s.height,
      headerBytes: s.headerBytes,
      shift: s.shift,
      littleEndian: s.littleEndian,
      frameIndex: i,
      lo: s.lo,
      hi: s.hi,
      rois,
      cnnCheckpoint: activeCnnCheckpoint,
      cnnBypassed,
    });
    const grid = $("#ablationGrid");
    grid.innerHTML = lastAblationReport.views
      .map(
        (v, k) =>
          `<article class="card"><h3>${esc(v.title)}</h3><canvas id="abl-canvas-${k}"></canvas><div class="stats"><b>Domain:</b> ${esc(
            v.toneDomain
          )} · <b>RMS Δ vs Raw8:</b> ${v.rmsDiffFromRaw8} levels · <b>Clip0/255:</b> ${(
            v.lowClipFrac8 * 100
          ).toFixed(1)}% / ${(v.highClipFrac8 * 100).toFixed(1)}%<br>${esc(v.description)}</div></article>`
      )
      .join("");
    lastAblationReport.views.forEach((v, k) => {
      const c = $<HTMLCanvasElement>(`#abl-canvas-${k}`);
      if (c) drawGray(c, v.pixels8);
    });
    updateAblationStaleBanner();
    status(`Computed 7-view genuine stage ablation on frame ${i}.`);
  } catch (err) {
    status("Ablation error: " + String(err));
  }
});

// --- 8-Scenario Hard-Negative Benchmark Handler ---
$("#runHardNegBench")?.addEventListener("click", async () => {
  if (busy || playing) return;
  busy = true;
  displayStatus();
  $("#hardNegStatus").textContent = "Running 8-scenario synthetic hard-negative suite (64×64 known-clean truth)…";
  await new Promise((r) => setTimeout(r, 20));
  try {
    const rep = await runHardNegativeBenchmarkSuite({
      width: 64,
      height: 64,
      cnnCheckpoint: activeCnnCheckpoint,
    });
    const rows = Object.entries(rep.summaryByMethod)
      .map(
        ([mId, sum]) =>
          `<tr><td><b>${esc(mId)}</b></td><td>${sum.meanPsnr14Db.toFixed(2)} dB</td><td>${sum.meanSsim14.toFixed(
            4
          )}</td><td>${sum.noStripeAddedRmsAdu.toFixed(2)} ADU</td><td>${sum.strongAlternatingColRmsAdu.toFixed(
            2
          )} ADU</td><td>${sum.verticalMastRetention.toFixed(2)} / ${sum.horizontalWireRetention.toFixed(
            2
          )}</td><td>${sum.pointTargetRetention.toFixed(2)}</td><td>${sum.maxHaloOvershootAdu.toFixed(
            2
          )} ADU</td></tr>`
      )
      .join("");
    $("#hardNegTable").innerHTML = `<table><tr><th>Method (14-bit ADU domain)</th><th>Mean PSNR</th><th>Mean SSIM</th><th>No-Stripe False RMS</th><th>±150 Alternating Stripe RMS</th><th>1px Mast / Wire Retention</th><th>1×1 Target Retention</th><th>Max Halo RMS</th></tr>${rows}</table><p class="muted">Synthetic known-clean benchmark only (n=8 scenarios × ${rep.width}×${rep.height}). Values >1.0 for wire retention reflect contrast amplification. Original Argos 2 retains strong alternating stripes (~150 ADU) due to its local difference threshold, whereas separated line/CNN variants suppress them.</p>`;
    $("#hardNegStatus").textContent = "Hard-negative benchmark complete (synthetic 14-bit truth).";
  } catch (err) {
    $("#hardNegStatus").textContent = "Benchmark error: " + String(err);
  } finally {
    busy = false;
    displayStatus();
  }
});

shuffle();
displayStatus();
listRois();
load();
