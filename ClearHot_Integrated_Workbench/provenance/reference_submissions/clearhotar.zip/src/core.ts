import { DEFAULT_ISP_CONFIGS, runThermalInstancePipeline } from "./argos/thermalPipelineEngine";
import { createInitialCnnState } from "./argos/cnnPrototypeEngine";
import { defaultCfg, newState, runPipeline as claudeRun, type PVariant } from "./claude/pipeline";
import {
  DEFAULT_CONFIG,
  cloneConfig,
  runPipeline as labRun,
  referenceDisplay,
  frameStats,
  percentileWindow,
  checkMonotonic,
  toneFn,
} from "./lab/pipeline";
import {
  decodeBuffer,
  frameBytes,
  frameCountFor,
  maxCode,
  readFrame,
  sha256Bytes,
  sha256File,
  to14BitForLegacyMethods,
  diagnoseFormat,
  type DecodeConfig,
} from "./lab/decode";
import { roiStats, computeRows, cnr, nearestBackground, type Roi, type RoiRole, type RoiStats } from "./lab/roi";
import {
  argos2SeparatedGuidedDetail14,
  argos2SeparatedLineOnly14,
  computeAblationContextKey,
  createCausalArgosState,
  runArgos2CausalTemporalCandidate,
  runArgos2GuidedCoredCandidate,
  runClaudeBCausalCandidate,
  runGenuineStageAblation,
  type AblationViewResult,
  type CompleteAblationReport,
} from "./lab/ablationAndCandidates";
import {
  computeNoReferenceRealFootageProxies,
  generateHardNegativeFixtures,
  runHardNegativeBenchmarkSuite,
  type HardNegativeFixture,
  type HardNegativeMethodCaseMetrics,
  type HardNegativeScenarioId,
  type HardNegativeSuiteReport,
} from "./lab/hardNegativeBench";
import {
  allParametersFinite,
  applyAdamStep,
  CNN_ARCHITECTURE_ID,
  computeArchitectureHash,
  computeWeightsSha256,
  countParameters,
  createAdamState,
  createInitialParameters,
  DEFAULT_CNN_HYPERPARAMS,
  deserializeParameters,
  forwardAndBackward,
  inferCnn14,
  parameterL2Distance,
  serializeParameters,
  type CnnHyperParams,
  type CnnParameterTensors,
  type SerializedCnnWeights,
} from "./cnn/model";
import {
  buildSyntheticDataset,
  encodeUint16LeBytes,
  generateSyntheticPair,
  validateDatasetManifest,
  verifyAndDecodeCuratedPair,
  type DatasetManifest,
  type DatasetPairEntry,
  type DatasetValidationResult,
  type HumanCuratedAttestation,
  type InMemoryTrainingPair,
  type SplitName,
} from "./cnn/dataset";
import {
  computeArgos2Stage1Clean14,
  computeFlatStripeRmsAdu,
  computeHaloOvershootAdu,
  computePsnr14Bit,
  computeSsim14Bit,
  computeThinFeatureRetention,
  DEFAULT_SAFETY_THRESHOLDS,
  evaluateCnnCandidate,
  map14BitThroughArgos2NativeStages,
  map14BitToFixedWindow8,
  trainCnnCandidate,
  type CandidateEvaluationReport,
  type CnnCheckpoint,
  type ModelLifecycleStatus,
  type SafetyGateOutcome,
  type SafetyGateThresholds,
} from "./cnn/evaluator";
import {
  approveAndPromoteCandidate,
  buildLocalInferenceCache,
  createEmptyRegistry,
  estimateInferenceCacheDiskBytes,
  invokeUntouchedFinalTest,
  registerCandidateCheckpoint,
  rejectCandidateByHuman,
  rollbackActiveModel,
  runTwoCycleSyntheticDemo,
  validateRegisteredCandidate,
  verifyCacheAgainstSource,
  verifyCheckpointIntegrity,
  type FinalTestAuditEntry,
  type HumanApprovalRecord,
  type LocalInferenceCacheManifest,
  type ModelRegistryState,
  type RegistryAuditLogEntry,
} from "./cnn/registry";

export {
  decodeBuffer,
  frameBytes,
  frameCountFor,
  maxCode,
  readFrame,
  sha256Bytes,
  sha256File,
  to14BitForLegacyMethods,
  diagnoseFormat,
  frameStats,
  percentileWindow,
  checkMonotonic,
  toneFn,
  roiStats,
  computeRows,
  cnr,
  nearestBackground,
  argos2SeparatedLineOnly14,
  argos2SeparatedGuidedDetail14,
  runArgos2GuidedCoredCandidate,
  runArgos2CausalTemporalCandidate,
  runClaudeBCausalCandidate,
  runGenuineStageAblation,
  computeAblationContextKey,
  generateHardNegativeFixtures,
  runHardNegativeBenchmarkSuite,
  computeNoReferenceRealFootageProxies,
  CNN_ARCHITECTURE_ID,
  DEFAULT_CNN_HYPERPARAMS,
  createInitialParameters,
  createAdamState,
  serializeParameters,
  deserializeParameters,
  countParameters,
  allParametersFinite,
  computeArchitectureHash,
  computeWeightsSha256,
  parameterL2Distance,
  forwardAndBackward,
  applyAdamStep,
  inferCnn14,
  buildSyntheticDataset,
  generateSyntheticPair,
  validateDatasetManifest,
  verifyAndDecodeCuratedPair,
  encodeUint16LeBytes,
  DEFAULT_SAFETY_THRESHOLDS,
  trainCnnCandidate,
  evaluateCnnCandidate,
  computeArgos2Stage1Clean14,
  map14BitToFixedWindow8,
  map14BitThroughArgos2NativeStages,
  computePsnr14Bit,
  computeSsim14Bit,
  computeFlatStripeRmsAdu,
  computeThinFeatureRetention,
  computeHaloOvershootAdu,
  createEmptyRegistry,
  verifyCheckpointIntegrity,
  registerCandidateCheckpoint,
  validateRegisteredCandidate,
  approveAndPromoteCandidate,
  rejectCandidateByHuman,
  rollbackActiveModel,
  invokeUntouchedFinalTest,
  runTwoCycleSyntheticDemo,
  estimateInferenceCacheDiskBytes,
  buildLocalInferenceCache,
  verifyCacheAgainstSource,
};

export type {
  DecodeConfig,
  Roi,
  RoiRole,
  RoiStats,
  AblationViewResult,
  CompleteAblationReport,
  HardNegativeScenarioId,
  HardNegativeFixture,
  HardNegativeMethodCaseMetrics,
  HardNegativeSuiteReport,
  CnnHyperParams,
  CnnParameterTensors,
  SerializedCnnWeights,
  DatasetManifest,
  DatasetPairEntry,
  DatasetValidationResult,
  HumanCuratedAttestation,
  InMemoryTrainingPair,
  SplitName,
  CnnCheckpoint,
  CandidateEvaluationReport,
  SafetyGateThresholds,
  SafetyGateOutcome,
  ModelLifecycleStatus,
  ModelRegistryState,
  RegistryAuditLogEntry,
  HumanApprovalRecord,
  FinalTestAuditEntry,
  LocalInferenceCacheManifest,
};

export const VERSION = "1.2.0";

export const METHODS = [
  "argos2",
  "argos1",
  "argos3",
  "claudeA",
  "claudeB",
  "claudeC",
  "lab",
  "argos2-no-line",
  "argos2-no-detail",
  "lab-line-only",
  "lab-detail-low",
  "lab-detail-high",
] as const;

export type Method = (typeof METHODS)[number];

export const CONTROLLED_VARIANT_METHODS = [
  "argos2-guided-cored",
  "argos2-causal-temporal",
  "claudeB-causal",
  "cnn-active",
] as const;

export type ControlledVariantMethod = (typeof CONTROLLED_VARIANT_METHODS)[number];
export type AnyPlayableMethod = Method | ControlledVariantMethod;

export const PLAYABLE_METHODS: readonly AnyPlayableMethod[] = [
  ...METHODS,
  ...CONTROLLED_VARIANT_METHODS,
];

export const LABELS: Record<Method, string> = {
  argos2: "Argos 2 · original default (native AGC + fused detail)",
  argos1: "Argos 1 · original default (native AGC + DPHE)",
  argos3: "Argos 3 · original default (native AGC + ACE)",
  claudeA: "Claude A · original default (native quantile + CLAHE)",
  claudeB: "Claude B · original default (offline look-ahead)",
  claudeC: "Claude C · original default (native spectral + multiscale)",
  lab: "New Claude lab · line + detail (locked fixed window)",
  "argos2-no-line": "Argos 2 · stage 1 bypass (disables line + bad-pixel)",
  "argos2-no-detail": "Argos 2 · stage 4 detail bypass",
  "lab-line-only": "New lab · line only (locked fixed window)",
  "lab-detail-low": "New lab · lower detail (gain 1.5, locked window)",
  "lab-detail-high": "New lab · higher detail (gain 3.5, locked window)",
};

export const VARIANT_LABELS: Record<ControlledVariantMethod, string> = {
  "argos2-guided-cored": "Argos 2 Variant · Guided Detail + Noise Coring (locked monotone window)",
  "argos2-causal-temporal": "Argos 2 Variant · Causal Motion-Gated Temporal (3-frame warm-up, locked window)",
  "claudeB-causal": "Claude B Variant · Strictly Causal Past-Frame Window (no look-ahead)",
  "cnn-active": "Opt-in CNN Residual · Active/Selected Checkpoint (14-bit residual + Argos 2 / locked window)",
};

export const ALL_LABELS: Record<AnyPlayableMethod, string> = {
  ...LABELS,
  ...VARIANT_LABELS,
};

export interface Settings {
  width: number;
  height: number;
  headerBytes: number;
  shift: number;
  littleEndian: boolean;
  lo: number;
  hi: number;
  bits?: number; // default 14; if 15 or 16, requires allow14BitCompatibilityScaling for legacy methods
  allow14BitCompatibilityScaling?: boolean;
  splitStartIndex?: number; // optional split boundary index so causal multi-frame methods never cross splits
}

export function validSettings(s: Settings): string | null {
  if (
    !Number.isInteger(s.width) ||
    !Number.isInteger(s.height) ||
    s.width < 32 ||
    s.height < 32 ||
    s.width % 2 ||
    s.height % 2 ||
    s.width * s.height > 4194304
  ) {
    return "Width and height must be even integers ≥32, with at most 4,194,304 pixels.";
  }
  if (!Number.isInteger(s.headerBytes) || s.headerBytes < 0 || !Number.isSafeInteger(s.headerBytes)) {
    return "Header bytes must be a non-negative integer.";
  }
  const bits = s.bits ?? 14;
  if (![8, 12, 14, 15, 16].includes(bits)) {
    return "Bit depth must be 14 (default for original methods) or an explicit 8, 12, 15 or 16-bit setting.";
  }
  const maxShift = 16 - bits;
  if (!Number.isInteger(s.shift) || s.shift < 0 || s.shift > maxShift) {
    return bits === 14
      ? "Right shift must be 0, 1 or 2 for a 14-bit field in uint16."
      : `Right shift must be between 0 and ${maxShift} for a ${bits}-bit field in uint16.`;
  }
  const topCode = (1 << bits) - 1;
  if (!Number.isFinite(s.lo) || !Number.isFinite(s.hi) || s.lo < 0 || s.hi > topCode || s.hi <= s.lo) {
    return `Fixed window must satisfy 0 ≤ low < high ≤ ${topCode}.`;
  }
  return null;
}

export const decodeConfig = (s: Settings): DecodeConfig => ({
  width: s.width,
  height: s.height,
  headerBytes: s.headerBytes,
  shift: s.shift,
  littleEndian: s.littleEndian,
  bits: s.bits ?? 14,
  allow14BitCompatibilityScaling: s.allow14BitCompatibilityScaling ?? false,
});

export function reference(raw: Uint16Array, s: Settings): Uint8Array {
  const c = cloneConfig(DEFAULT_CONFIG);
  c.tone.fixedLo = s.lo;
  c.tone.fixedHi = s.hi;
  return referenceDisplay(raw, c);
}

export function configFor(id: AnyPlayableMethod, s: Settings): unknown {
  if (id === "argos2-guided-cored") {
    return {
      variant: "argos2-guided-cored",
      lineVerticalStrength: 0.85,
      lineHorizontalStrength: 0.65,
      guidedRadius: 3,
      edgeAdu: 140,
      detailGain: 2.2,
      coringK: 1.6,
      maxBoostAdu: 220,
      toneMode: "locked_monotone_window_soft_knee",
      lo: s.lo,
      hi: s.hi,
    };
  }
  if (id === "argos2-causal-temporal") {
    return {
      variant: "argos2-causal-temporal",
      causalOnly: true,
      declaredWarmupFrames: 3,
      temporalAlpha: 0.4,
      motionGateK: 3.8,
      lo: s.lo,
      hi: s.hi,
    };
  }
  if (id === "claudeB-causal") {
    return {
      ...defaultCfg("B"),
      cnn: false,
      variant: "claudeB-causal",
      causalEnforced: true,
      splitStartIndex: s.splitStartIndex ?? 0,
    };
  }
  if (id === "cnn-active") {
    return {
      variant: "cnn-active",
      insertionMode: "post_stage1_14bit",
      lo: s.lo,
      hi: s.hi,
    };
  }
  if (id.startsWith("argos")) {
    const m = id === "argos1" ? "instance1" : id === "argos3" ? "instance3" : "instance2";
    const c = { ...DEFAULT_ISP_CONFIGS[m] };
    c.enableLiveCnnResidual = false;
    if (id === "argos2-no-line") c.stage1DestripeAndBadPx = false;
    if (id === "argos2-no-detail") c.stage4EdgePreservingDetail = false;
    return c;
  }
  if (id.startsWith("claude")) {
    const v = id.slice(-1) as PVariant;
    return { ...defaultCfg(v), cnn: false };
  }
  const c = cloneConfig(DEFAULT_CONFIG);
  c.tone.fixedLo = s.lo;
  c.tone.fixedHi = s.hi;
  c.tone.mode = "fixed";
  c.temporal.on = false;
  if (id === "lab-line-only") c.detail.on = false;
  if (id === "lab-detail-low") c.detail.gain = 1.5;
  if (id === "lab-detail-high") c.detail.gain = 3.5;
  return c;
}

export interface MethodResult {
  pixels: Uint8Array;
  ms: number;
  config: unknown;
  restored?: Float32Array;
  toneDomain?: "native_method_agc" | "locked_fixed_window";
  compatibilityWarning?: string | null;
  requestedFrameIndices?: number[];
}

export interface RunnerCnnOptions {
  checkpoint?: CnnCheckpoint | null;
  bypassCnn?: boolean;
  useNativeArgos2ToneForCnn?: boolean;
  cachedFrameGetter?: ((index: number) => Uint16Array | null) | null;
}

/** A sequential player owns its temporal state. A seek or a new player resets it. */
export function createMethodRunner(
  id: AnyPlayableMethod,
  s: Settings,
  total: number,
  getFrame: (i: number) => Promise<Uint16Array | null>,
  cnnOptions?: RunnerCnnOptions
) {
  const cfg = configFor(id, s);
  const W = s.width;
  const H = s.height;
  const bits = s.bits ?? 14;
  const allowScale = s.allow14BitCompatibilityScaling ?? false;
  const methodology = id === "argos1" ? "instance1" : id === "argos3" ? "instance3" : "instance2";

  let argos = {
    prevBlackRef: { current: 7100 },
    prevWhiteRef: { current: 7950 },
    lastFrameKeyRef: { current: "" },
    prevNormFrameRef: { current: null as Float32Array | null },
    prevKalman14Ref: { current: null as Float32Array | null },
  };
  let claude = newState();
  let causalArgos = createCausalArgosState();
  let last = -1;

  return async (raw: Uint16Array, index: number): Promise<MethodResult> => {
    const start = performance.now();
    let pixels: Uint8Array;
    let restored: Float32Array | undefined;
    let toneDomain: "native_method_agc" | "locked_fixed_window" = "native_method_agc";
    let compatibilityWarning: string | null = null;
    let requestedFrameIndices: number[] | undefined;

    const reset = last < 0 || index !== last + 1;
    if (reset) {
      argos = {
        prevBlackRef: { current: 7100 },
        prevWhiteRef: { current: 7950 },
        lastFrameKeyRef: { current: "" },
        prevNormFrameRef: { current: null },
        prevKalman14Ref: { current: null },
      };
      claude = newState();
      causalArgos = createCausalArgosState();
    }

    // Handle >14-bit sources explicitly: never silently truncate or shift
    let input14 = raw;
    if (bits !== 14 && id !== "lab" && id !== "lab-line-only" && id !== "lab-detail-low" && id !== "lab-detail-high") {
      const conv = to14BitForLegacyMethods(raw, bits, allowScale);
      input14 = conv.data14;
      compatibilityWarning = conv.warning;
    }

    if (id === "argos2-guided-cored") {
      const r = runArgos2GuidedCoredCandidate(input14, W, H, s.lo, s.hi);
      pixels = r.pixels;
      restored = r.restored14;
      toneDomain = "locked_fixed_window";
    } else if (id === "argos2-causal-temporal") {
      const r = runArgos2CausalTemporalCandidate(input14, W, H, s.lo, s.hi, index, causalArgos);
      pixels = r.pixels;
      restored = r.restored14;
      toneDomain = "locked_fixed_window";
    } else if (id === "claudeB-causal") {
      const r = await runClaudeBCausalCandidate(
        input14,
        W,
        H,
        index,
        reset,
        getFrame,
        claude,
        s.splitStartIndex ?? 0
      );
      pixels = r.pixels;
      restored = r.restored14;
      requestedFrameIndices = r.requestedFrames;
      toneDomain = "native_method_agc";
    } else if (id === "cnn-active") {
      const bypass = cnnOptions?.bypassCnn ?? false;
      const ckpt = cnnOptions?.checkpoint ?? null;
      const cachedFrame = !bypass && cnnOptions?.cachedFrameGetter ? cnnOptions.cachedFrameGetter(index) : null;

      if (cachedFrame) {
        restored = Float32Array.from(cachedFrame);
      } else if (!bypass && ckpt) {
        const weights = deserializeParameters(ckpt.weights);
        const hp = ckpt.hyperParams;
        const stage1 =
          hp.insertionMode === "post_stage1_14bit"
            ? computeArgos2Stage1Clean14(input14, W, H).stage1Clean14
            : Float32Array.from(input14);
        restored = inferCnn14(stage1, W, H, weights, hp, false).restored14;
      } else {
        // Immediate classical baseline fallback when bypassed or no checkpoint loaded
        restored = computeArgos2Stage1Clean14(input14, W, H).stage1Clean14;
      }

      if (cnnOptions?.useNativeArgos2ToneForCnn) {
        pixels = map14BitThroughArgos2NativeStages(restored, W, H);
        toneDomain = "native_method_agc";
      } else {
        pixels = map14BitToFixedWindow8(restored, s.lo, s.hi);
        toneDomain = "locked_fixed_window";
      }
    } else if (id.startsWith("argos")) {
      const a = runThermalInstancePipeline({
        methodology,
        raw14: input14,
        W,
        H,
        cfg: cfg as typeof DEFAULT_ISP_CONFIGS.instance2,
        cnnState: createInitialCnnState(methodology),
        ...argos,
        frameKey: `${index}`,
      });
      pixels = new Uint8Array(a.processed8);
      restored = a.stage1Clean14;
      toneDomain = "native_method_agc";
    } else if (id.startsWith("claude")) {
      const v = id.slice(-1) as PVariant;
      const a = await claudeRun(
        v,
        { raw: input14, W, H, key: `${index}`, idx: index, total, reset, getFrame },
        cfg as ReturnType<typeof defaultCfg>,
        claude
      );
      pixels = new Uint8Array(a.out8);
      restored = a.restored;
      toneDomain = "native_method_agc";
    } else {
      const topCode = (1 << bits) - 1;
      const a = labRun(raw, W, H, cfg as typeof DEFAULT_CONFIG, undefined, topCode);
      pixels = a.display;
      restored = a.enhanced;
      toneDomain = "locked_fixed_window";
    }

    last = index;
    return {
      pixels,
      restored,
      ms: performance.now() - start,
      config: cfg,
      toneDomain,
      compatibilityWarning,
      requestedFrameIndices,
    };
  };
}

export async function runMethod(
  id: AnyPlayableMethod,
  raw: Uint16Array,
  s: Settings,
  index: number,
  total: number,
  getFrame: (i: number) => Promise<Uint16Array | null>,
  cnnOptions?: RunnerCnnOptions
): Promise<MethodResult> {
  return createMethodRunner(id, s, total, getFrame, cnnOptions)(raw, index);
}

export function stats(data: ArrayLike<number>, w: number, h: number, r: Roi, sat: number) {
  const x0 = Math.max(0, Math.floor(r.x));
  const y0 = Math.max(0, Math.floor(r.y));
  const x1 = Math.min(w, Math.ceil(r.x + r.w));
  const y1 = Math.min(h, Math.ceil(r.y + r.h));
  if (x1 <= x0 || y1 <= y0) throw new Error("ROI is outside the image");
  return roiStats(data, w, h, { ...r, x: x0, y: y0, w: x1 - x0, h: y1 - y0 }, sat);
}

export function temporalDifference(
  a: ArrayLike<number>,
  b: ArrayLike<number>,
  w: number,
  h: number,
  r: Roi
): number | null {
  const x0 = Math.max(0, Math.floor(r.x));
  const y0 = Math.max(0, Math.floor(r.y));
  const x1 = Math.min(w, Math.ceil(r.x + r.w));
  const y1 = Math.min(h, Math.ceil(r.y + r.h));
  let sum = 0;
  let n = 0;
  for (let y = y0; y < y1; y++) {
    for (let x = x0; x < x1; x++) {
      const i = y * w + x;
      sum += Math.abs(a[i] - b[i]);
      n++;
    }
  }
  return n ? sum / n : null;
}

export function medianGap(a: ReturnType<typeof stats>, b: ReturnType<typeof stats>) {
  const spread = Math.sqrt((a.sigma * a.sigma + b.sigma * b.sigma) / 2);
  return {
    delta: a.median - b.median,
    pooledRobustSpread: spread,
    ratio: spread > 1e-6 ? Math.abs(a.median - b.median) / spread : null,
    interpretation:
      "Descriptive ROI statistic only; no universal separability or temperature conclusion.",
  };
}

export function synthetic(w: number, h: number, frame: number): Uint16Array {
  const a = new Uint16Array(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const target =
        (x - 0.3 * w - frame) ** 2 / (0.04 * w * w) + (y - 0.7 * h) ** 2 / (0.01 * h * h) < 1
          ? 250
          : 0;
      const bridge = Math.abs(y - 0.45 * h) < 2 ? 300 : 0;
      const line = x === Math.floor(w * 0.7) ? 150 : 0;
      const stripe = (x % 2 ? 1 : -1) * 35;
      a[y * w + x] = Math.round(
        6000 + (180 * y) / h + target + bridge + line + stripe + (((x * 19 + y * 31 + frame * 7) % 13) - 6)
      );
    }
  }
  return a;
}
