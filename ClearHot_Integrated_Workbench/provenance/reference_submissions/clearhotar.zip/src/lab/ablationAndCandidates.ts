import { DEFAULT_ISP_CONFIGS, runThermalInstancePipeline } from "../argos/thermalPipelineEngine";
import { createInitialCnnState } from "../argos/cnnPrototypeEngine";
import { defaultCfg, newState, runPipeline as claudeRun, type PState } from "../claude/pipeline";
import { detailEnhance, estimateNoiseSigma, freshTemporal, temporalFilter, type TemporalState } from "./dsp";
import { checkMonotonic, toneFn, type MonotonicReport } from "./pipeline";
import { roiStats, type Roi, type RoiStats } from "./roi";
import { deserializeParameters, inferCnn14 } from "../cnn/model";
import type { CnnCheckpoint } from "../cnn/evaluator";

export interface CausalArgosState {
  temporalState: TemporalState;
  lastIndex: number;
}

export function createCausalArgosState(): CausalArgosState {
  return {
    temporalState: freshTemporal(),
    lastIndex: -1,
  };
}

/**
 * Separated Stage 1 Line-Only operator derived from Argos 2's 1D Haar wavelet shrinkage,
 * with explicit thin-wire gradient gating and NO bad-pixel neighbor replacement
 * (labeled as a Modified Ablation / Controlled Variant so original Argos 2 remains untouched).
 */
export function argos2SeparatedLineOnly14(
  raw14: ArrayLike<number>,
  W: number,
  H: number,
  verticalStrength = 0.85,
  horizontalStrength = 0.65
): Float32Array {
  const N = W * H;
  const out = new Float32Array(N);
  const colProf = new Float32Array(W);
  const rowProf = new Float32Array(H);

  // Estimate column profile excluding strong vertical transitions
  let colGlobal = 0;
  for (let x = 0; x < W; x++) {
    let sum = 0;
    let cnt = 0;
    for (let y = 4; y < H - 4; y++) {
      const idx = y * W + x;
      const v = raw14[idx];
      const vDiff = Math.abs(v - raw14[idx - W]);
      if (vDiff < 160 && v > 200 && v < 15500) {
        sum += v;
        cnt++;
      }
    }
    colProf[x] = cnt > 0 ? sum / cnt : 7000;
    colGlobal += colProf[x];
  }
  colGlobal /= Math.max(1, W);

  // High-pass column stripe offset relative to 9-tap local moving average
  const colStripe = new Float32Array(W);
  for (let x = 0; x < W; x++) {
    let s = 0;
    let c = 0;
    for (let k = -4; k <= 4; k++) {
      const xk = Math.max(0, Math.min(W - 1, x + k));
      s += colProf[xk];
      c++;
    }
    const hp = colProf[x] - s / c;
    // Softly bound extreme column jumps so a true full-height mast is not completely erased
    colStripe[x] = Math.abs(hp) > 180 ? Math.sign(hp) * 180 * 0.35 : hp;
  }

  // Estimate row profile excluding strong horizontal transitions
  for (let y = 0; y < H; y++) {
    let sum = 0;
    let cnt = 0;
    const yOff = y * W;
    for (let x = 4; x < W - 4; x++) {
      const idx = yOff + x;
      const v = raw14[idx];
      const hDiff = Math.abs(v - raw14[idx - 1]);
      if (hDiff < 160 && v > 200 && v < 15500) {
        sum += v;
        cnt++;
      }
    }
    rowProf[y] = cnt > 0 ? sum / cnt : colGlobal;
  }

  const rowStripe = new Float32Array(H);
  for (let y = 0; y < H; y++) {
    let s = 0;
    let c = 0;
    for (let k = -4; k <= 4; k++) {
      const yk = Math.max(0, Math.min(H - 1, y + k));
      s += rowProf[yk];
      c++;
    }
    const hp = rowProf[y] - s / c;
    rowStripe[y] = Math.abs(hp) > 180 ? Math.sign(hp) * 180 * 0.35 : hp;
  }

  for (let y = 0; y < H; y++) {
    const yOff = y * W;
    const rOff = rowStripe[y] * horizontalStrength;
    for (let x = 0; x < W; x++) {
      const idx = yOff + x;
      const v = raw14[idx];
      // Protect isolated 1-pixel high-contrast thin features
      const xL = Math.max(0, x - 1);
      const xR = Math.min(W - 1, x + 1);
      const yU = Math.max(0, y - 1);
      const yD = Math.min(H - 1, y + 1);
      const hSpike = Math.abs(v - 0.5 * (raw14[yOff + xL] + raw14[yOff + xR]));
      const vSpike = Math.abs(v - 0.5 * (raw14[yU * W + x] + raw14[yD * W + x]));
      const cScale = hSpike > 220 ? 0.25 : 1.0;
      const rScale = vSpike > 220 ? 0.25 : 1.0;
      const clean = v - colStripe[x] * verticalStrength * cScale - rOff * rScale;
      out[idx] = Math.max(0, Math.min(16383, clean));
    }
  }
  return out;
}

/**
 * Separated 14-bit Guided Base/Detail Enhancement with Noise-Aware Coring
 * (operates in 14-bit ADU prior to locked monotone window mapping).
 */
export function argos2SeparatedGuidedDetail14(
  input14: Float32Array,
  W: number,
  H: number,
  gain = 2.2,
  coringK = 1.6,
  maxBoostAdu = 220
): Float32Array {
  const sigma = Math.max(2.0, estimateNoiseSigma(input14, W, H));
  const enhanced = detailEnhance(
    input14,
    W,
    H,
    {
      radius: 3,
      edgeAdu: 140,
      gain,
      coringK,
      maxBoostAdu,
    },
    sigma
  );
  const out = new Float32Array(enhanced.length);
  for (let i = 0; i < enhanced.length; i++) {
    out[i] = Math.max(0, Math.min(16383, enhanced[i]));
  }
  return out;
}

/**
 * Controlled Candidate 1: 'argos2-guided-cored'
 * Separated line correction + bounded edge-aware guided detail with noise-aware coring +
 * locked monotone reference window [lo, hi] with soft highlight knee (0.92).
 */
export function runArgos2GuidedCoredCandidate(
  raw14: Uint16Array,
  W: number,
  H: number,
  lo: number,
  hi: number
): { pixels: Uint8Array; restored14: Float32Array; config: Record<string, unknown> } {
  const lineClean14 = argos2SeparatedLineOnly14(raw14, W, H, 0.85, 0.65);
  const enhanced14 = argos2SeparatedGuidedDetail14(lineClean14, W, H, 2.2, 1.6, 220);
  const fn = toneFn({ lo, hi, gamma: 1.0, knee: 0.92 });
  const pixels = new Uint8Array(W * H);
  for (let i = 0; i < pixels.length; i++) pixels[i] = fn(enhanced14[i]);
  return {
    pixels,
    restored14: enhanced14,
    config: {
      variant: "argos2-guided-cored",
      lineVerticalStrength: 0.85,
      lineHorizontalStrength: 0.65,
      guidedRadius: 3,
      edgeAdu: 140,
      detailGain: 2.2,
      coringK: 1.6,
      maxBoostAdu: 220,
      toneMode: "locked_monotone_window_soft_knee",
      lo,
      hi,
      knee: 0.92,
    },
  };
}

/**
 * Controlled Candidate 2: 'argos2-causal-temporal'
 * Strictly causal motion-gated temporal filter (declared 3-frame warm-up, resets on seek/reset) +
 * guided detail + locked monotone window.
 */
export function runArgos2CausalTemporalCandidate(
  raw14: Uint16Array,
  W: number,
  H: number,
  lo: number,
  hi: number,
  index: number,
  state: CausalArgosState
): { pixels: Uint8Array; restored14: Float32Array; config: Record<string, unknown> } {
  const isConsecutive = state.lastIndex >= 0 && index === state.lastIndex + 1;
  if (!isConsecutive) {
    state.temporalState = freshTemporal();
  }
  state.lastIndex = index;

  const lineClean14 = argos2SeparatedLineOnly14(raw14, W, H, 0.85, 0.65);
  const sigma = Math.max(2.0, estimateNoiseSigma(lineClean14, W, H));
  const tempRes = temporalFilter(lineClean14, state.temporalState, 0.4, 3.8, sigma);
  const enhanced14 = argos2SeparatedGuidedDetail14(tempRes.out, W, H, 2.0, 1.8, 200);
  const fn = toneFn({ lo, hi, gamma: 1.0, knee: 0.92 });
  const pixels = new Uint8Array(W * H);
  for (let i = 0; i < pixels.length; i++) pixels[i] = fn(enhanced14[i]);

  return {
    pixels,
    restored14: enhanced14,
    config: {
      variant: "argos2-causal-temporal",
      causalOnly: true,
      declaredWarmupFrames: 3,
      currentWarmupFrames: state.temporalState.frames,
      temporalAlpha: 0.4,
      motionGateK: 3.8,
      movingPixelFrac: Number(tempRes.movingFrac.toFixed(4)),
      lo,
      hi,
    },
  };
}

/**
 * Controlled Candidate 3: 'claudeB-causal'
 * Wraps Claude B's pipeline with a strictly causal past-frame-only getter that NEVER supplies
 * future frames (i > currentIdx) and NEVER crosses a declared splitStartIndex boundary.
 */
export async function runClaudeBCausalCandidate(
  raw14: Uint16Array,
  W: number,
  H: number,
  index: number,
  reset: boolean,
  getFrame: (i: number) => Promise<Uint16Array | null>,
  claudeState: PState,
  splitStartIndex = 0
): Promise<{ pixels: Uint8Array; restored14: Float32Array; config: Record<string, unknown>; requestedFrames: number[] }> {
  const requestedFrames: number[] = [];
  const causalGetFrame = async (reqIdx: number): Promise<Uint16Array | null> => {
    // Strictly clamp to causal range [splitStartIndex .. index]: never read future frames i > index!
    const clampedIdx = Math.max(splitStartIndex, Math.min(index, reqIdx));
    requestedFrames.push(clampedIdx);
    if (clampedIdx === index) return raw14;
    return getFrame(clampedIdx);
  };

  const cfg = { ...defaultCfg("B"), cnn: false };
  // Pass total = index + 1 so internal window logic [idx - win + 1 .. idx] never looks ahead of index
  const res = await claudeRun(
    "B",
    {
      raw: raw14,
      W,
      H,
      key: `causal-${index}`,
      idx: index,
      total: index + 1,
      reset,
      getFrame: causalGetFrame,
    },
    cfg,
    claudeState
  );

  return {
    pixels: new Uint8Array(res.out8),
    restored14: res.restored,
    config: {
      ...cfg,
      variant: "claudeB-causal",
      causalEnforced: true,
      splitStartIndex,
      maxFrameAllowed: index,
    },
    requestedFrames,
  };
}

// ============================================================================
// GENUINE STAGE ABLATION (Sec 3)
// ============================================================================

export interface AblationViewResult {
  id:
    | "raw_fixed_window"
    | "line_only_fixed_window"
    | "tone_only_ablation"
    | "detail_only_fixed_window"
    | "combined_classical_fixed_window"
    | "argos2_original_native"
    | "opt_in_cnn_fixed_window";
  title: string;
  isModifiedAblation: boolean;
  toneDomain: "locked_fixed_window" | "native_argos2_agc_scurve";
  description: string;
  pixels8: Uint8Array;
  intermediate14: Float32Array;
  rmsDiffFromRaw8: number;
  lowClipFrac8: number;
  highClipFrac8: number;
  roiStats8: Record<string, RoiStats>;
  roiStats14: Record<string, RoiStats>;
}

export interface CompleteAblationReport {
  contextKey: string;
  timestamp: string;
  frameIndex: number;
  width: number;
  height: number;
  lockedWindow: { lo: number; hi: number };
  monotonicityOfLockedWindow: MonotonicReport;
  activeCnnCheckpointId: string | null;
  cnnBypassed: boolean;
  views: AblationViewResult[];
  scientificNote: string;
}

export function computeAblationContextKey(params: {
  sourceKey: string;
  frameIndex: number;
  width: number;
  height: number;
  headerBytes: number;
  shift: number;
  littleEndian: boolean;
  lo: number;
  hi: number;
  rois: Roi[];
  cnnCheckpointId: string | null;
  cnnBypassed: boolean;
}): string {
  return JSON.stringify(params);
}

/**
 * Executes genuine stage-by-stage ablation on a single decoded frame.
 * Every controlled ablation view ('raw_fixed_window', 'line_only_fixed_window',
 * 'detail_only_fixed_window', 'combined_classical_fixed_window', 'opt_in_cnn_fixed_window')
 * uses the EXACT same locked reference window [lo, hi].
 * Separated stages from fused Original Argos 2 are explicitly labeled as 'Modified Ablation'.
 */
export function runGenuineStageAblation(params: {
  sourceKey: string;
  raw14: Uint16Array;
  width: number;
  height: number;
  headerBytes?: number;
  shift?: number;
  littleEndian?: boolean;
  frameIndex: number;
  lo: number;
  hi: number;
  rois: Roi[];
  cnnCheckpoint?: CnnCheckpoint | null;
  cnnBypassed?: boolean;
}): CompleteAblationReport {
  const { raw14, width: W, height: H, frameIndex, lo, hi, rois } = params;
  const N = W * H;
  const lockedFn = toneFn({ lo, hi, gamma: 1.0, knee: 1.0 });
  const monoReport = checkMonotonic(lockedFn, 16383);

  const mapFixed = (arr14: ArrayLike<number>): Uint8Array => {
    const out = new Uint8Array(N);
    for (let i = 0; i < N; i++) out[i] = lockedFn(arr14[i]);
    return out;
  };

  // 0. Raw fixed-window reference
  const rawFloat14 = Float32Array.from(raw14);
  const rawFixed8 = mapFixed(rawFloat14);

  // 1. Line correction only (Modified Ablation: separated 14-bit destripe in locked window)
  const lineOnly14 = argos2SeparatedLineOnly14(raw14, W, H, 0.85, 0.65);
  const lineOnly8 = mapFixed(lineOnly14);

  // 2. Tone map only (Modified Ablation: Argos 2 Stage 2/3 quantile AGC + S-curve with NO line correction and NO detail)
  const toneOnlyCfg = {
    ...DEFAULT_ISP_CONFIGS.instance2,
    stage1DestripeAndBadPx: false,
    enableMethodologyEnhancement: false,
    stage4EdgePreservingDetail: false,
    enableLiveCnnResidual: false,
  };
  const toneOnlyRes = runThermalInstancePipeline({
    methodology: "instance2",
    raw14,
    W,
    H,
    cfg: toneOnlyCfg,
    cnnState: createInitialCnnState("instance2"),
    prevBlackRef: { current: 7100 },
    prevWhiteRef: { current: 7950 },
    lastFrameKeyRef: { current: "" },
    prevNormFrameRef: { current: null },
    prevKalman14Ref: { current: null },
    frameKey: `${frameIndex}`,
  });
  const toneOnly8 = new Uint8Array(toneOnlyRes.processed8);

  // 3. Genuine Detail-Only (Modified Ablation: 14-bit guided filter base-detail with noise-aware coring on raw14, mapped through locked window [lo, hi])
  const detailOnly14 = argos2SeparatedGuidedDetail14(rawFloat14, W, H, 2.2, 1.5, 220);
  const detailOnly8 = mapFixed(detailOnly14);

  // 4. Combined Classical in Locked Fixed Window (Line + Guided Detail in locked window [lo, hi])
  const combinedClassical14 = argos2SeparatedGuidedDetail14(lineOnly14, W, H, 2.2, 1.5, 220);
  const combinedClassical8 = mapFixed(combinedClassical14);

  // 5. Untouched Original Argos 2 Native Display (for faithful comparison against the fused original)
  const origArgos2Res = runThermalInstancePipeline({
    methodology: "instance2",
    raw14,
    W,
    H,
    cfg: { ...DEFAULT_ISP_CONFIGS.instance2, enableLiveCnnResidual: false },
    cnnState: createInitialCnnState("instance2"),
    prevBlackRef: { current: 7100 },
    prevWhiteRef: { current: 7950 },
    lastFrameKeyRef: { current: "" },
    prevNormFrameRef: { current: null },
    prevKalman14Ref: { current: null },
    frameKey: `${frameIndex}`,
  });
  const origArgos2Pixels8 = new Uint8Array(origArgos2Res.processed8);

  // 6. Opt-in CNN Residual (in locked window [lo, hi])
  const cnnBypassed = params.cnnBypassed ?? !params.cnnCheckpoint;
  let cnnRestored14: Float32Array;
  if (!cnnBypassed && params.cnnCheckpoint) {
    const weights = deserializeParameters(params.cnnCheckpoint.weights);
    const hp = params.cnnCheckpoint.hyperParams;
    const cnnIn = hp.insertionMode === "post_stage1_14bit" ? origArgos2Res.stage1Clean14 : rawFloat14;
    cnnRestored14 = inferCnn14(cnnIn, W, H, weights, hp, false).restored14;
  } else {
    cnnRestored14 = origArgos2Res.stage1Clean14;
  }
  const cnnFixed8 = mapFixed(cnnRestored14);

  const buildView = (
    id: AblationViewResult["id"],
    title: string,
    isModifiedAblation: boolean,
    toneDomain: AblationViewResult["toneDomain"],
    description: string,
    pixels8: Uint8Array,
    intermediate14: Float32Array
  ): AblationViewResult => {
    let sq = 0;
    let c0 = 0;
    let c255 = 0;
    for (let i = 0; i < N; i++) {
      const d = pixels8[i] - rawFixed8[i];
      sq += d * d;
      if (pixels8[i] === 0) c0++;
      if (pixels8[i] === 255) c255++;
    }
    const roiStats8: Record<string, RoiStats> = {};
    const roiStats14: Record<string, RoiStats> = {};
    for (const r of rois) {
      roiStats8[r.id] = roiStats(pixels8, W, H, r, 255);
      roiStats14[r.id] = roiStats(intermediate14, W, H, r, 16383);
    }
    return {
      id,
      title,
      isModifiedAblation,
      toneDomain,
      description,
      pixels8,
      intermediate14,
      rmsDiffFromRaw8: Number(Math.sqrt(sq / Math.max(1, N)).toFixed(2)),
      lowClipFrac8: Number((c0 / Math.max(1, N)).toFixed(5)),
      highClipFrac8: Number((c255 / Math.max(1, N)).toFixed(5)),
      roiStats8,
      roiStats14,
    };
  };

  const contextKey = computeAblationContextKey({
    sourceKey: params.sourceKey,
    frameIndex,
    width: W,
    height: H,
    headerBytes: params.headerBytes ?? 0,
    shift: params.shift ?? 0,
    littleEndian: params.littleEndian ?? true,
    lo,
    hi,
    rois,
    cnnCheckpointId: params.cnnCheckpoint?.checkpointId ?? null,
    cnnBypassed,
  });

  const views: AblationViewResult[] = [
    buildView(
      "raw_fixed_window",
      "0 · Raw Fixed-Window Reference",
      false,
      "locked_fixed_window",
      `Unmodified 14-bit sensor counts mapped linearly through locked window [${lo}, ${hi}].`,
      rawFixed8,
      rawFloat14
    ),
    buildView(
      "line_only_fixed_window",
      "1 · Line Correction Only (Modified Ablation · Locked Window)",
      true,
      "locked_fixed_window",
      `Isolated 14-bit column/row stripe subtraction (separated from bad-pixel replacement and native AGC), mapped through locked window [${lo}, ${hi}].`,
      lineOnly8,
      lineOnly14
    ),
    buildView(
      "tone_only_ablation",
      "2 · Tone Curve Only (Modified Ablation · Native Quantile Window)",
      true,
      "native_argos2_agc_scurve",
      "Argos 2 Stage 2/3 quantile AGC window and soft-shoulder normalization applied to raw 14-bit with Stage 1 destriping and Stage 4 detail disabled.",
      toneOnly8,
      rawFloat14
    ),
    buildView(
      "detail_only_fixed_window",
      "3 · Detail Enhancement Only (Modified Ablation · Locked Window)",
      true,
      "locked_fixed_window",
      `Isolated 14-bit edge-aware guided filter base/detail boost with noise-aware coring (no line correction), mapped through locked window [${lo}, ${hi}]. Original Argos 2 fuses guided detail inside its tone-map loop, so this separated view is explicitly labeled a Modified Ablation.`,
      detailOnly8,
      detailOnly14
    ),
    buildView(
      "combined_classical_fixed_window",
      "4A · Combined Classical (Modified Ablation · Locked Window)",
      true,
      "locked_fixed_window",
      `Line correction + guided cored detail in 14-bit ADU, mapped through the shared locked window [${lo}, ${hi}].`,
      combinedClassical8,
      combinedClassical14
    ),
    buildView(
      "argos2_original_native",
      "4B · Original Argos 2 (Untouched Native AGC + Fused Detail)",
      false,
      "native_argos2_agc_scurve",
      "Exact untouched Original Argos 2 pipeline (Stage 1 Haar/comb + bad-pixel + Stage 2/3 quantile AGC + S-curve + fused guided detail + Stage 4 Laplacian).",
      origArgos2Pixels8,
      origArgos2Res.stage1Clean14
    ),
    buildView(
      "opt_in_cnn_fixed_window",
      cnnBypassed
        ? "5 · Opt-in CNN Residual (BYPASSED -> Classical Stage 1)"
        : `5 · Opt-in CNN Residual (${params.cnnCheckpoint?.checkpointId} · ${params.cnnCheckpoint?.status.toUpperCase()})`,
      true,
      "locked_fixed_window",
      cnnBypassed
        ? `CNN bypassed; showing classical Stage 1 14-bit output in locked window [${lo}, ${hi}].`
        : `Learned 14-bit CNN residual (${params.cnnCheckpoint?.checkpointId}, SHA-256 ${params.cnnCheckpoint?.weightsSha256.slice(0, 12)}…) applied in 14-bit ADU and mapped through locked window [${lo}, ${hi}].`,
      cnnFixed8,
      cnnRestored14
    ),
  ];

  return {
    contextKey,
    timestamp: new Date().toISOString(),
    frameIndex,
    width: W,
    height: H,
    lockedWindow: { lo, hi },
    monotonicityOfLockedWindow: monoReport,
    activeCnnCheckpointId: params.cnnCheckpoint?.checkpointId ?? null,
    cnnBypassed,
    views,
    scientificNote:
      "Original Argos 2 fuses bad-pixel replacement with Stage 1 destriping and fuses 14-bit guided detail decomposition with its Stage 2/3 S-curve tone mapper. Views 1, 2, 3, and 4A are therefore explicitly labeled Modified Ablations constructed to isolate each stage under a single locked fixed window [lo, hi], while View 4B retains the untouched Original Argos 2.",
  };
}
