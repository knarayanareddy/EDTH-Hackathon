import { DEFAULT_ISP_CONFIGS, runThermalInstancePipeline } from "../argos/thermalPipelineEngine";
import { createInitialCnnState } from "../argos/cnnPrototypeEngine";
import { defaultCfg, newState, runPipeline as claudeRun } from "../claude/pipeline";
import { DEFAULT_CONFIG, cloneConfig, runPipeline as labRun } from "./pipeline";
import { argos2SeparatedGuidedDetail14, argos2SeparatedLineOnly14 } from "./ablationAndCandidates";
import {
  computeFlatStripeRmsAdu,
  computeHaloOvershootAdu,
  computePsnr14Bit,
  computeSsim14Bit,
  type CnnCheckpoint,
} from "../cnn/evaluator";
import { deserializeParameters, inferCnn14, mulberry32 } from "../cnn/model";

export type HardNegativeScenarioId =
  | "no_stripe_false_correction"
  | "alternating_strong_stripes"
  | "true_full_height_wire"
  | "small_point_targets"
  | "textured_ground_occlusion"
  | "motion_sequence_ghosting"
  | "fpn_plus_read_noise"
  | "similar_brightness_animal_bridge";

export interface HardNegativeFixture {
  scenarioId: HardNegativeScenarioId;
  title: string;
  description: string;
  synthetic: true;
  width: number;
  height: number;
  clean14: Uint16Array;
  noisy14: Uint16Array;
  prevNoisy14?: Uint16Array;
  verticalMastCol: number | null;
  horizontalWireRow: number | null;
  pointTargetCoords: Array<{ x: number; y: number }>;
  animalBridgeBoxes?: {
    animal: { x: number; y: number; w: number; h: number };
    bridge: { x: number; y: number; w: number; h: number };
  };
}

export interface HardNegativeMethodCaseMetrics {
  scenarioId: HardNegativeScenarioId;
  methodId: string;
  methodLabel: string;
  syntheticCleanTruthAvailable: true;
  domain: "14-bit ADU (0..16383)";
  sampleSizePixels: number;
  psnr14Db: number;
  ssim14: number;
  colStripeRmsAdu: number;
  rowStripeRmsAdu: number;
  noStripeFalseCorrectionRmsAdu: number | null;
  verticalMastRetention: number | null; // reported individually
  horizontalWireRetention: number | null; // reported individually
  thinOversharpeningFlag: boolean; // true when retention > 1.05
  pointTargetPeakRetention: number | null;
  haloOvershootAdu: number;
  lowClipFrac: number;
  highClipFrac: number;
  failureOrTradeoffNote: string | null;
}

export interface HardNegativeSuiteReport {
  schema: "clearhot-hard-negative-suite-v1";
  generatedAt: string;
  syntheticOnly: true;
  width: number;
  height: number;
  methodsCompared: string[];
  cases: HardNegativeMethodCaseMetrics[];
  summaryByMethod: Record<
    string,
    {
      meanPsnr14Db: number;
      meanSsim14: number;
      noStripeAddedRmsAdu: number;
      strongAlternatingColRmsAdu: number;
      verticalMastRetention: number;
      horizontalWireRetention: number;
      pointTargetRetention: number;
      maxHaloOvershootAdu: number;
      documentedFailuresAndTradeoffs: string[];
    }
  >;
}

/**
 * Generates all 8 deterministic hard-negative synthetic fixtures with known clean 14-bit ground truth.
 */
export function generateHardNegativeFixtures(W = 64, H = 64, baseSeed = 500): HardNegativeFixture[] {
  const scenarioIds: HardNegativeScenarioId[] = [
    "no_stripe_false_correction",
    "alternating_strong_stripes",
    "true_full_height_wire",
    "small_point_targets",
    "textured_ground_occlusion",
    "motion_sequence_ghosting",
    "fpn_plus_read_noise",
    "similar_brightness_animal_bridge",
  ];

  return scenarioIds.map((scenarioId, idx) => {
    const rng = mulberry32(baseSeed + idx * 31);
    const N = W * H;
    const clean14 = new Uint16Array(N);
    const noisy14 = new Uint16Array(N);
    let prevNoisy14: Uint16Array | undefined;

    const horizonY = Math.floor(H * 0.36);
    const mastCol = scenarioId === "true_full_height_wire" ? Math.floor(W * 0.72) : null;
    const wireRow = scenarioId === "true_full_height_wire" ? Math.floor(H * 0.25) : null;
    const pointCoords: Array<{ x: number; y: number }> = [];

    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const i = y * W + x;
        let v =
          y < horizonY
            ? 6100 + Math.sin(x * 0.06) * 25 + (y / Math.max(1, horizonY)) * 40
            : 6420 + Math.cos(x * 0.08) * 45 + Math.sin((y - horizonY) * 0.1) * 50;

        if (scenarioId === "textured_ground_occlusion" && y >= horizonY) {
          // Multi-frequency ground texture + vertical occlusion bar
          v += Math.sin(x * 0.45) * Math.cos(y * 0.45) * 65 + (((x * 17) ^ (y * 29)) % 23) * 2.5;
          if (x >= Math.floor(W * 0.45) && x <= Math.floor(W * 0.52) && y >= Math.floor(H * 0.45)) {
            v -= 160; // cooler occluding pillar
          }
        }

        // True full-height 1-pixel vertical mast & full-width horizontal wire
        if (mastCol !== null && x === mastCol) {
          v += 320; // spans 100% of height (hardest test for column profile destripers!)
        }
        if (wireRow !== null && y === wireRow) {
          v += 260; // spans 100% of width (hardest test for row profile destripers!)
        }

        // Moving or static elliptical target
        const tx = Math.floor(W * 0.36);
        const ty = Math.floor(H * 0.68);
        const rx = Math.max(3, Math.floor(W * 0.07));
        const ry = Math.max(2, Math.floor(H * 0.05));
        const distSq = ((x - tx) / rx) ** 2 + ((y - ty) / ry) ** 2;
        if (distSq <= 1) {
          v += 280;
        }

        // Similar brightness animal & bridge on differing local backgrounds
        if (scenarioId === "similar_brightness_animal_bridge") {
          const bY0 = Math.floor(H * 0.48),
            bY1 = Math.floor(H * 0.56);
          const bX0 = Math.floor(W * 0.15),
            bX1 = Math.floor(W * 0.45);
          const aY0 = Math.floor(H * 0.62),
            aY1 = Math.floor(H * 0.72);
          const aX0 = Math.floor(W * 0.55),
            aX1 = Math.floor(W * 0.75);
          if (y >= bY0 && y < bY1 && x >= bX0 && x < bX1) v = 6780; // Bridge at 6780 ADU
          if (y >= aY0 && y < aY1 && x >= aX0 && x < aX1) v = 6815; // Animal only +35 ADU higher
        }

        clean14[i] = Math.max(0, Math.min(16383, Math.round(v)));
      }
    }

    if (scenarioId === "small_point_targets") {
      const p1 = { x: Math.floor(W * 0.25), y: Math.floor(H * 0.22) };
      const p2 = { x: Math.floor(W * 0.55), y: Math.floor(H * 0.22) };
      clean14[p1.y * W + p1.x] += 550;
      pointCoords.push(p1);
      for (let dy = 0; dy <= 1; dy++) {
        for (let dx = 0; dx <= 1; dx++) {
          clean14[(p2.y + dy) * W + (p2.x + dx)] += 500;
          pointCoords.push({ x: p2.x + dx, y: p2.y + dy });
        }
      }
    }

    // Corrupt clean14 according to scenario
    for (let y = 0; y < H; y++) {
      const rStripe =
        scenarioId === "no_stripe_false_correction"
          ? 0
          : scenarioId === "alternating_strong_stripes"
          ? (y % 2 === 0 ? 1 : -1) * 75
          : Math.round(Math.sin(y * 0.9) * 22);
      for (let x = 0; x < W; x++) {
        const i = y * W + x;
        const cStripe =
          scenarioId === "no_stripe_false_correction"
            ? 0
            : scenarioId === "alternating_strong_stripes"
            ? (x % 2 === 0 ? 1 : -1) * 150
            : ((x % 2 === 0 ? 1 : -1) * 32 + Math.round((rng() - 0.5) * 28));
        const noise =
          scenarioId === "no_stripe_false_correction"
            ? 0
            : Math.round((rng() + rng() - 1) * (scenarioId === "fpn_plus_read_noise" ? 18 : 7));
        noisy14[i] = Math.max(0, Math.min(16383, clean14[i] + cStripe + rStripe + noise));
      }
    }

    if (scenarioId === "motion_sequence_ghosting") {
      prevNoisy14 = new Uint16Array(noisy14);
      // Shift target by 5 pixels in previous frame to test motion trail / ghosting
      const shiftX = Math.floor(W * 0.36) - 6;
      const ty = Math.floor(H * 0.68);
      for (let dy = -3; dy <= 3; dy++) {
        for (let dx = -4; dx <= 4; dx++) {
          const px = Math.max(0, Math.min(W - 1, shiftX + dx));
          const py = Math.max(0, Math.min(H - 1, ty + dy));
          prevNoisy14[py * W + px] = Math.min(16383, prevNoisy14[py * W + px] + 320);
        }
      }
    }

    const titles: Record<HardNegativeScenarioId, [string, string]> = {
      no_stripe_false_correction: [
        "1 · No-Stripe Clean Scene (False-Correction Test)",
        "Zero stripes or read noise injected. Tests whether line/CNN stages falsely remove real vertical/horizontal scene structure.",
      ],
      alternating_strong_stripes: [
        "2 · Alternating Strong ±150 ADU Column Stripes",
        "High-amplitude Nyquist column stripes (±150 ADU) + ±75 ADU row stripes. Tests whether edge-gating or shrinkage thresholds fail on strong stripes.",
      ],
      true_full_height_wire: [
        "3 · True Full-Height 1px Vertical Mast & Horizontal Wire",
        "Genuine 1-pixel vertical mast (100% height) and 1-pixel horizontal wire (100% width). Tests individual thin-feature erasure vs preservation.",
      ],
      small_point_targets: [
        "4 · Small 1×1 & 2×2 Warm Point Targets",
        "Compact sub-resolved warm targets. Tests whether outlier/bad-pixel filters mistake 1×1 targets for dead/hot sensor spikes.",
      ],
      textured_ground_occlusion: [
        "5 · Multi-Scale Ground Texture & Occlusion",
        "High-frequency ground clutter with a sharp vertical occluding pillar.",
      ],
      motion_sequence_ghosting: [
        "6 · Moving Target Sequence (Motion / Ghosting Test)",
        "Target moves 6 pixels between consecutive frames. Tests whether temporal filtering leaves ghost trails.",
      ],
      fpn_plus_read_noise: [
        "7 · Combined Fixed-Pattern Stripes + High Read Noise",
        "Mixed column/row FPN with elevated random temporal read noise.",
      ],
      similar_brightness_animal_bridge: [
        "8 · Similar-Brightness Animal (+35 ADU) vs Bridge",
        "Animal (6815 ADU) and bridge (6780 ADU) separated by only 35 ADU across different background rows.",
      ],
    };

    return {
      scenarioId,
      title: titles[scenarioId][0],
      description: titles[scenarioId][1],
      synthetic: true,
      width: W,
      height: H,
      clean14,
      noisy14,
      prevNoisy14,
      verticalMastCol: mastCol,
      horizontalWireRow: wireRow,
      pointTargetCoords: pointCoords,
      animalBridgeBoxes:
        scenarioId === "similar_brightness_animal_bridge"
          ? {
              bridge: {
                x: Math.floor(W * 0.15),
                y: Math.floor(H * 0.48),
                w: Math.floor(W * 0.3),
                h: Math.floor(H * 0.08),
              },
              animal: {
                x: Math.floor(W * 0.55),
                y: Math.floor(H * 0.62),
                w: Math.floor(W * 0.2),
                h: Math.floor(H * 0.1),
              },
            }
          : undefined,
    };
  });
}

function measureSingleLineRetention(
  pred14: ArrayLike<number>,
  clean14: ArrayLike<number>,
  W: number,
  H: number,
  mode: "vertical" | "horizontal",
  index: number | null
): number | null {
  if (index === null) return null;
  let cleanContrast = 0;
  let predContrast = 0;
  if (mode === "vertical") {
    const xL = Math.max(0, index - 2);
    const xR = Math.min(W - 1, index + 2);
    for (let y = 4; y < H - 4; y++) {
      const cBg = 0.5 * (clean14[y * W + xL] + clean14[y * W + xR]);
      const pBg = 0.5 * (pred14[y * W + xL] + pred14[y * W + xR]);
      cleanContrast += Math.abs(clean14[y * W + index] - cBg);
      predContrast += Math.abs(pred14[y * W + index] - pBg);
    }
  } else {
    const yU = Math.max(0, index - 2);
    const yD = Math.min(H - 1, index + 2);
    for (let x = 4; x < W - 4; x++) {
      const cBg = 0.5 * (clean14[yU * W + x] + clean14[yD * W + x]);
      const pBg = 0.5 * (pred14[yU * W + x] + pred14[yD * W + x]);
      cleanContrast += Math.abs(clean14[index * W + x] - cBg);
      predContrast += Math.abs(pred14[index * W + x] - pBg);
    }
  }
  return cleanContrast > 1e-3 ? Number((predContrast / cleanContrast).toFixed(3)) : null;
}

function measurePointTargetRetention(
  pred14: ArrayLike<number>,
  clean14: ArrayLike<number>,
  W: number,
  H: number,
  coords: Array<{ x: number; y: number }>
): number | null {
  if (!coords.length) return null;
  let cSum = 0;
  let pSum = 0;
  for (const pt of coords) {
    const idx = pt.y * W + pt.x;
    const bgIdx = Math.max(0, pt.y - 3) * W + pt.x;
    cSum += Math.max(1, clean14[idx] - clean14[bgIdx]);
    pSum += Math.max(0, pred14[idx] - pred14[bgIdx]);
  }
  return Number((pSum / Math.max(1, cSum)).toFixed(3));
}

/**
 * Runs the 8-scenario hard-negative benchmark across Raw, Original Argos 2, Claude A, New Lab,
 * Argos 2 Guided-Cored Variant, and Active/Candidate CNN (if supplied).
 */
export async function runHardNegativeBenchmarkSuite(params?: {
  width?: number;
  height?: number;
  cnnCheckpoint?: CnnCheckpoint | null;
}): Promise<HardNegativeSuiteReport> {
  const W = params?.width ?? 64;
  const H = params?.height ?? 64;
  const fixtures = generateHardNegativeFixtures(W, H, 500);
  const cnnCkpt = params?.cnnCheckpoint ?? null;
  const cnnWeights = cnnCkpt ? deserializeParameters(cnnCkpt.weights) : null;

  const methods: Array<{
    id: string;
    label: string;
    run14: (f: HardNegativeFixture) => Promise<Float32Array>;
  }> = [
    {
      id: "raw",
      label: "Raw Identity (14-bit)",
      run14: async (f) => Float32Array.from(f.noisy14),
    },
    {
      id: "argos2",
      label: "Original Argos 2 (Stage 1 14-bit)",
      run14: async (f) => {
        const res = runThermalInstancePipeline({
          methodology: "instance2",
          raw14: f.noisy14,
          W,
          H,
          cfg: { ...DEFAULT_ISP_CONFIGS.instance2, enableLiveCnnResidual: false },
          cnnState: createInitialCnnState("instance2"),
          prevBlackRef: { current: 7100 },
          prevWhiteRef: { current: 7950 },
          lastFrameKeyRef: { current: "" },
          prevNormFrameRef: { current: null },
          prevKalman14Ref: { current: null },
          frameKey: "0",
        });
        return res.stage1Clean14;
      },
    },
    {
      id: "claudeA",
      label: "Original Claude A (Restored 14-bit)",
      run14: async (f) => {
        const res = await claudeRun(
          "A",
          {
            raw: f.noisy14,
            W,
            H,
            key: "0",
            idx: 0,
            total: 1,
            reset: true,
            getFrame: async () => f.noisy14,
          },
          { ...defaultCfg("A"), cnn: false },
          newState()
        );
        return res.restored;
      },
    },
    {
      id: "lab",
      label: "New Claude Lab (Line + Guided Detail 14-bit)",
      run14: async (f) => {
        const c = cloneConfig(DEFAULT_CONFIG);
        return labRun(f.noisy14, W, H, c).enhanced;
      },
    },
    {
      id: "argos2-guided-cored",
      label: "Argos 2 Variant (Separated Line + Guided Cored 14-bit)",
      run14: async (f) => {
        const line14 = argos2SeparatedLineOnly14(f.noisy14, W, H, 0.85, 0.65);
        return argos2SeparatedGuidedDetail14(line14, W, H, 2.0, 1.8, 180);
      },
    },
  ];

  if (cnnCkpt && cnnWeights) {
    methods.push({
      id: "cnn-active",
      label: `CNN (${cnnCkpt.checkpointId} · ${cnnCkpt.status})`,
      run14: async (f) => {
        const stage1 = runThermalInstancePipeline({
          methodology: "instance2",
          raw14: f.noisy14,
          W,
          H,
          cfg: { ...DEFAULT_ISP_CONFIGS.instance2, enableLiveCnnResidual: false },
          cnnState: createInitialCnnState("instance2"),
          prevBlackRef: { current: 7100 },
          prevWhiteRef: { current: 7950 },
          lastFrameKeyRef: { current: "" },
          prevNormFrameRef: { current: null },
          prevKalman14Ref: { current: null },
          frameKey: "0",
        }).stage1Clean14;
        const input =
          cnnCkpt.hyperParams.insertionMode === "post_stage1_14bit"
            ? stage1
            : Float32Array.from(f.noisy14);
        return inferCnn14(input, W, H, cnnWeights, cnnCkpt.hyperParams, false).restored14;
      },
    });
  }

  const cases: HardNegativeMethodCaseMetrics[] = [];

  for (const f of fixtures) {
    for (const m of methods) {
      const pred14 = await m.run14(f);
      const N = W * H;
      const psnr = computePsnr14Bit(pred14, f.clean14);
      const ssim = computeSsim14Bit(pred14, f.clean14, W, H);
      const stripes = computeFlatStripeRmsAdu(pred14, W, H);
      const vRet = measureSingleLineRetention(pred14, f.clean14, W, H, "vertical", f.verticalMastCol);
      const hRet = measureSingleLineRetention(pred14, f.clean14, W, H, "horizontal", f.horizontalWireRow);
      const ptRet = measurePointTargetRetention(pred14, f.clean14, W, H, f.pointTargetCoords);
      const halo = computeHaloOvershootAdu(pred14, f.clean14, W, H);

      let noStripeRms: number | null = null;
      if (f.scenarioId === "no_stripe_false_correction") {
        let sq = 0;
        for (let i = 0; i < N; i++) {
          const d = pred14[i] - f.clean14[i];
          sq += d * d;
        }
        noStripeRms = Number(Math.sqrt(sq / N).toFixed(2));
      }

      let lowClip = 0;
      let highClip = 0;
      for (let i = 0; i < N; i++) {
        if (pred14[i] <= 0) lowClip++;
        if (pred14[i] >= 16383) highClip++;
      }

      const oversharpen = (vRet !== null && vRet > 1.05) || (hRet !== null && hRet > 1.05);
      let note: string | null = null;
      if (f.scenarioId === "alternating_strong_stripes" && stripes.colRms > 100 && m.id !== "raw") {
        note =
          "Tradeoff/Failure: Local difference threshold gated out the ±150 ADU alternating stripe, leaving most stripe energy unremoved.";
      } else if (f.scenarioId === "true_full_height_wire" && ((vRet !== null && vRet < 0.75) || (hRet !== null && hRet < 0.75))) {
        note =
          "Tradeoff/Failure: Full-height/width 1-pixel wire was partially mistaken for a sensor stripe and attenuated (<0.75 retention).";
      } else if (oversharpen) {
        note =
          "Caution: Thin-feature contrast ratio > 1.05 reflects detail amplification/sharpening rather than pure radiometric restoration.";
      } else if (f.scenarioId === "small_point_targets" && ptRet !== null && ptRet < 0.7) {
        note =
          "Tradeoff/Failure: 1×1 warm point target was attenuated by spatial/outlier filtering.";
      }

      cases.push({
        scenarioId: f.scenarioId,
        methodId: m.id,
        methodLabel: m.label,
        syntheticCleanTruthAvailable: true,
        domain: "14-bit ADU (0..16383)",
        sampleSizePixels: N,
        psnr14Db: Number(psnr.toFixed(2)),
        ssim14: Number(ssim.toFixed(4)),
        colStripeRmsAdu: Number(stripes.colRms.toFixed(2)),
        rowStripeRmsAdu: Number(stripes.rowRms.toFixed(2)),
        noStripeFalseCorrectionRmsAdu: noStripeRms,
        verticalMastRetention: vRet,
        horizontalWireRetention: hRet,
        thinOversharpeningFlag: oversharpen,
        pointTargetPeakRetention: ptRet,
        haloOvershootAdu: Number(halo.toFixed(2)),
        lowClipFrac: Number((lowClip / N).toFixed(5)),
        highClipFrac: Number((highClip / N).toFixed(5)),
        failureOrTradeoffNote: note,
      });
    }
  }

  const summaryByMethod: HardNegativeSuiteReport["summaryByMethod"] = {};
  for (const m of methods) {
    const mc = cases.filter((c) => c.methodId === m.id);
    const mean = (arr: number[]) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0);
    const noStripeCase = mc.find((c) => c.scenarioId === "no_stripe_false_correction");
    const altCase = mc.find((c) => c.scenarioId === "alternating_strong_stripes");
    const wireCase = mc.find((c) => c.scenarioId === "true_full_height_wire");
    const ptCase = mc.find((c) => c.scenarioId === "small_point_targets");

    summaryByMethod[m.id] = {
      meanPsnr14Db: Number(mean(mc.map((c) => c.psnr14Db)).toFixed(2)),
      meanSsim14: Number(mean(mc.map((c) => c.ssim14)).toFixed(4)),
      noStripeAddedRmsAdu: noStripeCase?.noStripeFalseCorrectionRmsAdu ?? 0,
      strongAlternatingColRmsAdu: altCase?.colStripeRmsAdu ?? 0,
      verticalMastRetention: wireCase?.verticalMastRetention ?? 1,
      horizontalWireRetention: wireCase?.horizontalWireRetention ?? 1,
      pointTargetRetention: ptCase?.pointTargetPeakRetention ?? 1,
      maxHaloOvershootAdu: Number(Math.max(...mc.map((c) => c.haloOvershootAdu)).toFixed(2)),
      documentedFailuresAndTradeoffs: mc
        .map((c) => c.failureOrTradeoffNote)
        .filter((x): x is string => x !== null),
    };
  }

  return {
    schema: "clearhot-hard-negative-suite-v1",
    generatedAt: new Date().toISOString(),
    syntheticOnly: true,
    width: W,
    height: H,
    methodsCompared: methods.map((m) => m.id),
    cases,
    summaryByMethod,
  };
}

/**
 * Computes explicitly labeled NO-REFERENCE proxy statistics for real footage where
 * clean ground truth does NOT exist. Never invents PSNR, SSIM, or calibrated temperatures.
 */
export function computeNoReferenceRealFootageProxies(
  raw14: Uint16Array,
  restored14: ArrayLike<number>,
  display8: Uint8Array,
  W: number,
  H: number
): {
  cleanTruthAvailable: false;
  psnrDb: null;
  ssim: null;
  calibratedTemperatureCelsius: null;
  flatPatchColHighPassProxyAdu: number;
  flatPatchRowHighPassProxyAdu: number;
  meanAbsModificationAdu: number;
  displaySat0Frac: number;
  displaySat255Frac: number;
  warning: string;
} {
  const N = W * H;
  const stripes = computeFlatStripeRmsAdu(restored14, W, H);
  let absDiffSum = 0;
  let s0 = 0;
  let s255 = 0;
  for (let i = 0; i < N; i++) {
    absDiffSum += Math.abs(restored14[i] - raw14[i]);
    if (display8[i] === 0) s0++;
    if (display8[i] === 255) s255++;
  }
  return {
    cleanTruthAvailable: false,
    psnrDb: null,
    ssim: null,
    calibratedTemperatureCelsius: null,
    flatPatchColHighPassProxyAdu: Number(stripes.colRms.toFixed(2)),
    flatPatchRowHighPassProxyAdu: Number(stripes.rowRms.toFixed(2)),
    meanAbsModificationAdu: Number((absDiffSum / Math.max(1, N)).toFixed(2)),
    displaySat0Frac: Number((s0 / Math.max(1, N)).toFixed(5)),
    displaySat255Frac: Number((s255 / Math.max(1, N)).toFixed(5)),
    warning:
      "NO-REFERENCE PROXY ONLY: Real recordings lack clean ground truth and radiometric calibration. PSNR, SSIM and temperatures are undefined (null). High-pass profile proxies can be confounded by real vertical/horizontal scene edges; rely on blinded visual and ROI review.",
  };
}
